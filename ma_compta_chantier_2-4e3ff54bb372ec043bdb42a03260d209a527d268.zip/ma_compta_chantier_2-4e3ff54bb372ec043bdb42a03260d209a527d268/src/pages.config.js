/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AdminGuideUtilisateur from './pages/AdminGuideUtilisateur';
import Analytics from './pages/Analytics';
import ChantierDetails from './pages/ChantierDetails';
import Chantiers from './pages/Chantiers';
import Clients from './pages/Clients';
import Dashboard from './pages/Dashboard';
import Depenses from './pages/Depenses';
import EditionDocuments from './pages/EditionDocuments';
import Entreprises from './pages/Entreprises';
import EquipeGestionbat from './pages/EquipeGestionbat';
import ExportImportDonnees from './pages/ExportImportDonnees';
import GestionAnnonces from './pages/GestionAnnonces';
import GestionUtilisateurs from './pages/GestionUtilisateurs';
import GuideUtilisateur from './pages/GuideUtilisateur';
import Home from './pages/Home';
import MarchesEntreprises from './pages/MarchesEntreprises';
import Partenaires from './pages/Partenaires';
import PlanningChantiers from './pages/PlanningChantiers';
import Rapports from './pages/Rapports';
import TelechargementChantier from './pages/TelechargementChantier';
import GestionVersions from './pages/GestionVersions';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AdminGuideUtilisateur": AdminGuideUtilisateur,
    "Analytics": Analytics,
    "ChantierDetails": ChantierDetails,
    "Chantiers": Chantiers,
    "Clients": Clients,
    "Dashboard": Dashboard,
    "Depenses": Depenses,
    "EditionDocuments": EditionDocuments,
    "Entreprises": Entreprises,
    "EquipeGestionbat": EquipeGestionbat,
    "ExportImportDonnees": ExportImportDonnees,
    "GestionAnnonces": GestionAnnonces,
    "GestionUtilisateurs": GestionUtilisateurs,
    "GuideUtilisateur": GuideUtilisateur,
    "Home": Home,
    "MarchesEntreprises": MarchesEntreprises,
    "Partenaires": Partenaires,
    "PlanningChantiers": PlanningChantiers,
    "Rapports": Rapports,
    "TelechargementChantier": TelechargementChantier,
    "GestionVersions": GestionVersions,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};