import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Download, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function DocumentationPlaceholders() {
  const handleDownloadTxt = () => {
    const content = `═══════════════════════════════════════════════════════════════════════════════
                    LISTE DES PLACEHOLDERS DISPONIBLES
           Pour le remplissage automatique des trames Excel et Word
═══════════════════════════════════════════════════════════════════════════════

Dernière mise à jour : ${new Date().toLocaleDateString('fr-FR')}

───────────────────────────────────────────────────────────────────────────────
📅 DATES
───────────────────────────────────────────────────────────────────────────────
{{DATE_MARCHE}}                    Date du marché (format JJ/MM/AAAA)
{{DATE_GENERATION}}                Date de génération du document (format JJ/MM/AAAA)
{{CHANTIER_DATE_DEBUT}}            Date de début du chantier (format JJ mois AAAA)
{{CHANTIER_DATE_FIN}}              Date de fin prévue du chantier (format JJ mois AAAA)

───────────────────────────────────────────────────────────────────────────────
🏗️ CHANTIER
───────────────────────────────────────────────────────────────────────────────
{{CHANTIER_NOM}}                   Nom du chantier
{{CHANTIER_ADRESSE}}               Adresse complète du chantier

───────────────────────────────────────────────────────────────────────────────
👤 CLIENT
───────────────────────────────────────────────────────────────────────────────
{{CLIENT_NOM}}                     Nom du client
{{CLIENT_ADRESSE_1}}               Adresse ligne 1
{{CLIENT_ADRESSE_2}}               Adresse ligne 2
{{CLIENT_CODE_POSTAL}}             Code postal
{{CLIENT_VILLE}}                   Ville
{{CLIENT_SIRET}}                   Numéro SIRET

───────────────────────────────────────────────────────────────────────────────
🏢 ENTREPRISE
───────────────────────────────────────────────────────────────────────────────
{{ENTREPRISE_NOM}}                 Nom de l'entreprise
{{ENTREPRISE_ADRESSE_1}}           Adresse ligne 1
{{ENTREPRISE_ADRESSE_2}}           Adresse ligne 2
{{ENTREPRISE_CODE_POSTAL}}         Code postal
{{ENTREPRISE_VILLE}}               Ville
{{ENTREPRISE_SIRET}}               Numéro SIRET
{{ENTREPRISE_REPRESENTANT_CIVILITE}} Civilité du représentant (M. / Mme / Mlle)
{{ENTREPRISE_REPRESENTANT_PRENOM}} Prénom du représentant
{{ENTREPRISE_REPRESENTANT_NOM}}    Nom du représentant
{{ENTREPRISE_REPRESENTANT_QUALITE}} Qualité du représentant (ex: Gérant, Directeur)

───────────────────────────────────────────────────────────────────────────────
📋 MARCHÉ
───────────────────────────────────────────────────────────────────────────────
{{NUMERO_LOT}}                     Numéro du lot
{{INTITULE_LOT}}                   Intitulé du lot
{{NUMERO_MARCHE}}                  Numéro du marché

───────────────────────────────────────────────────────────────────────────────
💰 MONTANTS
───────────────────────────────────────────────────────────────────────────────
{{MONTANT_HT}}                     Montant Hors Taxes (format: 150000,00)
{{MONTANT_TVA}}                    Montant de la TVA (format: 30000,00)
{{MONTANT_TTC}}                    Montant Toutes Taxes Comprises (format: 180000,00)
{{TAUX_TVA}}                       Taux de TVA en pourcentage (ex: 20)

───────────────────────────────────────────────────────────────────────────────
🔐 CAUTIONS
───────────────────────────────────────────────────────────────────────────────
{{MARCHE_CAUTIONNE}}               Marché cautionné (Oui / Non)
{{CAUTION_REFERENCE}}              Référence de la première caution
{{CAUTION_MONTANT}}                Montant de la première caution (format: 15000,00)

Pour plusieurs cautions, utiliser :
{{CAUTION_1_REFERENCE}}            Référence de la caution n°1
{{CAUTION_1_MONTANT}}              Montant de la caution n°1
{{CAUTION_1_DATE}}                 Date d'ajout de la caution n°1
{{CAUTION_2_REFERENCE}}            Référence de la caution n°2
{{CAUTION_2_MONTANT}}              Montant de la caution n°2
{{CAUTION_2_DATE}}                 Date d'ajout de la caution n°2
... et ainsi de suite pour les cautions supplémentaires

───────────────────────────────────────────────────────────────────────────────
📊 RÉVISION DE PRIX
───────────────────────────────────────────────────────────────────────────────
{{INDICE_BT_1}}                    Indice BT n°1
{{INDICE_BT_2}}                    Indice BT n°2
{{M0_1}}                           Valeur M0 n°1 (mois de base)
{{M0_2}}                           Valeur M0 n°2 (mois de base)
{{REPARTITION_1}}                  Répartition en % pour l'indice BT n°1
{{REPARTITION_2}}                  Répartition en % pour l'indice BT n°2
{{FORMULE_ACTUALISATION_1}}        Formule d'actualisation n°1
{{FORMULE_ACTUALISATION_2}}        Formule d'actualisation n°2
{{FORMULE_REVISION_1}}             Formule de révision n°1
{{FORMULE_REVISION_2}}             Formule de révision n°2

───────────────────────────────────────────────────────────────────────────────
🏛️ GESTIONBAT
───────────────────────────────────────────────────────────────────────────────
{{GESTIONBAT_NOM}}                 Nom de l'entreprise GESTIONBAT
{{GESTIONBAT_ADRESSE}}             Adresse de GESTIONBAT
{{GESTIONBAT_CODE_POSTAL}}         Code postal de GESTIONBAT
{{GESTIONBAT_VILLE}}               Ville de GESTIONBAT
{{GESTIONBAT_TELEPHONE}}           Téléphone de GESTIONBAT
{{GESTIONBAT_SIRET}}               SIRET de GESTIONBAT

═══════════════════════════════════════════════════════════════════════════════
                              NOTES D'UTILISATION
═══════════════════════════════════════════════════════════════════════════════

1. Les placeholders doivent être écrits EXACTEMENT comme indiqué (respect des 
   majuscules et underscores)

2. Dans Excel : Placez les placeholders dans les cellules de votre trame

3. Format des nombres :
   - Montants : utilisez la virgule comme séparateur décimal (ex: 150000,00)
   - Les nombres sont automatiquement formatés lors du remplissage

4. Dates :
   - Format court : JJ/MM/AAAA (ex: 15/03/2026)
   - Format long : JJ mois AAAA (ex: 15 mars 2026)

═══════════════════════════════════════════════════════════════════════════════`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Placeholders_GESTIONBAT_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const placeholderCategories = [
    {
      title: "📅 Dates",
      icon: "📅",
      items: [
        { placeholder: "{{DATE_MARCHE}}", description: "Date du marché (format JJ/MM/AAAA)" },
        { placeholder: "{{DATE_GENERATION}}", description: "Date de génération du document" },
        { placeholder: "{{CHANTIER_DATE_DEBUT}}", description: "Date de début du chantier" },
        { placeholder: "{{CHANTIER_DATE_FIN}}", description: "Date de fin prévue" },
      ]
    },
    {
      title: "🏗️ Chantier",
      icon: "🏗️",
      items: [
        { placeholder: "{{CHANTIER_NOM}}", description: "Nom du chantier" },
        { placeholder: "{{CHANTIER_ADRESSE}}", description: "Adresse complète du chantier" },
      ]
    },
    {
      title: "👤 Client",
      icon: "👤",
      items: [
        { placeholder: "{{CLIENT_NOM}}", description: "Nom du client" },
        { placeholder: "{{CLIENT_ADRESSE_1}}", description: "Adresse ligne 1" },
        { placeholder: "{{CLIENT_ADRESSE_2}}", description: "Adresse ligne 2" },
        { placeholder: "{{CLIENT_CODE_POSTAL}}", description: "Code postal" },
        { placeholder: "{{CLIENT_VILLE}}", description: "Ville" },
        { placeholder: "{{CLIENT_SIRET}}", description: "Numéro SIRET" },
      ]
    },
    {
      title: "🏢 Entreprise",
      icon: "🏢",
      items: [
        { placeholder: "{{ENTREPRISE_NOM}}", description: "Nom de l'entreprise" },
        { placeholder: "{{ENTREPRISE_ADRESSE_1}}", description: "Adresse ligne 1" },
        { placeholder: "{{ENTREPRISE_ADRESSE_2}}", description: "Adresse ligne 2" },
        { placeholder: "{{ENTREPRISE_CODE_POSTAL}}", description: "Code postal" },
        { placeholder: "{{ENTREPRISE_VILLE}}", description: "Ville" },
        { placeholder: "{{ENTREPRISE_SIRET}}", description: "Numéro SIRET" },
        { placeholder: "{{ENTREPRISE_REPRESENTANT_CIVILITE}}", description: "Civilité du représentant" },
        { placeholder: "{{ENTREPRISE_REPRESENTANT_PRENOM}}", description: "Prénom du représentant" },
        { placeholder: "{{ENTREPRISE_REPRESENTANT_NOM}}", description: "Nom du représentant" },
        { placeholder: "{{ENTREPRISE_REPRESENTANT_QUALITE}}", description: "Qualité du représentant" },
      ]
    },
    {
      title: "📋 Marché",
      icon: "📋",
      items: [
        { placeholder: "{{NUMERO_LOT}}", description: "Numéro du lot" },
        { placeholder: "{{INTITULE_LOT}}", description: "Intitulé du lot" },
        { placeholder: "{{NUMERO_MARCHE}}", description: "Numéro du marché" },
      ]
    },
    {
      title: "💰 Montants",
      icon: "💰",
      items: [
        { placeholder: "{{MONTANT_HT}}", description: "Montant Hors Taxes" },
        { placeholder: "{{MONTANT_TVA}}", description: "Montant de la TVA" },
        { placeholder: "{{MONTANT_TTC}}", description: "Montant TTC" },
        { placeholder: "{{TAUX_TVA}}", description: "Taux de TVA en %" },
      ]
    },
    {
      title: "🔐 Cautions",
      icon: "🔐",
      items: [
        { placeholder: "{{MARCHE_CAUTIONNE}}", description: "Marché cautionné (Oui / Non)" },
        { placeholder: "{{CAUTION_REFERENCE}}", description: "Référence de la 1ère caution" },
        { placeholder: "{{CAUTION_MONTANT}}", description: "Montant de la 1ère caution" },
        { placeholder: "{{CAUTION_N_REFERENCE}}", description: "Pour plusieurs cautions : _1_, _2_, etc." },
        { placeholder: "{{CAUTION_N_MONTANT}}", description: "Montant de la caution n°N" },
        { placeholder: "{{CAUTION_N_DATE}}", description: "Date d'ajout de la caution n°N" },
      ]
    },
    {
      title: "📊 Révision de prix",
      icon: "📊",
      items: [
        { placeholder: "{{INDICE_BT_1}}", description: "Indice BT n°1" },
        { placeholder: "{{INDICE_BT_2}}", description: "Indice BT n°2" },
        { placeholder: "{{M0_1}}", description: "Valeur M0 n°1 (mois de base)" },
        { placeholder: "{{M0_2}}", description: "Valeur M0 n°2 (mois de base)" },
        { placeholder: "{{REPARTITION_1}}", description: "Répartition en % pour l'indice BT n°1" },
        { placeholder: "{{REPARTITION_2}}", description: "Répartition en % pour l'indice BT n°2" },
        { placeholder: "{{FORMULE_ACTUALISATION_1}}", description: "Formule d'actualisation n°1" },
        { placeholder: "{{FORMULE_ACTUALISATION_2}}", description: "Formule d'actualisation n°2" },
        { placeholder: "{{FORMULE_REVISION_1}}", description: "Formule de révision n°1" },
        { placeholder: "{{FORMULE_REVISION_2}}", description: "Formule de révision n°2" },
      ]
    },
    {
      title: "🏛️ GESTIONBAT",
      icon: "🏛️",
      items: [
        { placeholder: "{{GESTIONBAT_NOM}}", description: "Nom de l'entreprise" },
        { placeholder: "{{GESTIONBAT_ADRESSE}}", description: "Adresse" },
        { placeholder: "{{GESTIONBAT_CODE_POSTAL}}", description: "Code postal" },
        { placeholder: "{{GESTIONBAT_VILLE}}", description: "Ville" },
        { placeholder: "{{GESTIONBAT_TELEPHONE}}", description: "Téléphone" },
        { placeholder: "{{GESTIONBAT_SIRET}}", description: "SIRET" },
      ]
    },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Documentation Placeholders</h1>
            <p className="text-gray-600">Liste complète des variables disponibles pour vos trames Excel</p>
          </div>
          <Button onClick={handleDownloadTxt} className="bg-orange-600 hover:bg-orange-700 gap-2">
            <Download className="w-4 h-4" />
            Télécharger (.txt)
          </Button>
        </div>

        <Alert className="bg-blue-50 border-blue-200 mb-6">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Important :</strong> Les placeholders doivent être écrits EXACTEMENT comme indiqué (respect des majuscules et underscores). 
            Placez-les dans les cellules de votre trame Excel pour un remplissage automatique.
          </AlertDescription>
        </Alert>
      </div>

      <div className="grid gap-6">
        {placeholderCategories.map((category, idx) => (
          <Card key={idx}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <span>{category.icon}</span>
                {category.title}
              </CardTitle>
              <CardDescription>{category.items.length} placeholder(s) disponible(s)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {category.items.map((item, itemIdx) => (
                  <div key={itemIdx} className="flex items-start gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <code className="text-sm font-mono bg-white px-3 py-1 rounded border border-gray-300 text-orange-600 font-semibold min-w-[280px]">
                      {item.placeholder}
                    </code>
                    <span className="text-sm text-gray-700">{item.description}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6 bg-yellow-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-yellow-600" />
            Notes d'utilisation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-gray-700">
          <p><strong>Format des nombres :</strong> Utilisez la virgule comme séparateur décimal (ex: 150000,00)</p>
          <p><strong>Dates :</strong> Format court JJ/MM/AAAA (ex: 15/03/2026) ou format long JJ mois AAAA (ex: 15 mars 2026)</p>
          <p><strong>Fichiers concernés :</strong></p>
          <ul className="list-disc list-inside ml-4 space-y-1">
            <li>functions/fillExcelTemplate.js - Remplissage automatique des trames</li>
            <li>functions/generateMarcheTemplate.js - Génération du modèle d'import</li>
            <li>components/chantier-details/MarchesTab - Génération des actes d'engagement</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}