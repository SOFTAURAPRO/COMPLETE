/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Clock, Users, Shield, TrendingUp, Calendar, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function Analytics() {
  const { 
    data: sessions = [], 
    isLoading: sessionsLoading 
  } = useQuery({
    queryKey: ['session-analytics'],
    queryFn: () => base44.entities.SessionAnalytics.list(),
  });

  const { 
    data: user,
    isLoading: userLoading 
  } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const isLoading = sessionsLoading || userLoading;

  // Vérification admin + domaine
  const isAuthorizedAdmin = React.useMemo(() => {
    if (!user) return false;
    const email = user.email?.toLowerCase() || '';
    return user.role === 'admin' && email.endsWith('@gestionbat.fr');
  }, [user]);

  // === FILTRAGE : on ne garde QUE les @gestionbat.fr ===
  const filteredSessions = React.useMemo(() => {
    return sessions.filter(s => {
      const email = (s.user_email || '').toLowerCase();
      return email.endsWith('@gestionbat.fr');
    });
  }, [sessions]);

  // Stats basées uniquement sur les sessions filtrées
  const stats = React.useMemo(() => {
    const totalHours = filteredSessions.reduce((sum, s) => sum + (s.duration_hours || 0), 0);
    const adminHours = filteredSessions
      .filter(s => s.user_role === 'admin')
      .reduce((sum, s) => sum + (s.duration_hours || 0), 0);
    const userHours = filteredSessions
      .filter(s => s.user_role === 'user')
      .reduce((sum, s) => sum + (s.duration_hours || 0), 0);

    return {
      totalHours: Number(totalHours.toFixed(1)),
      adminHours: Number(adminHours.toFixed(1)),
      userHours: Number(userHours.toFixed(1)),
      totalSessions: filteredSessions.length,
    };
  }, [filteredSessions]);

  const sessionsByUser = React.useMemo(() => {
    const map = {};

    filteredSessions.forEach(s => {
      const email = s.user_email || 'Inconnu';
      if (!map[email]) {
        map[email] = { email, role: s.user_role, sessions: [] };
      }
      map[email].sessions.push(s);
    });

    return Object.values(map)
      .map(u => {
        const totalHours = u.sessions.reduce((sum, s) => sum + (s.duration_hours || 0), 0);
        const lastSessionDate = u.sessions.reduce((latest, s) => {
          const d = new Date(s.created_date);
          return d > latest ? d : latest;
        }, new Date(0));

        return {
          ...u,
          totalHours: Number(totalHours.toFixed(1)),
          totalSessions: u.sessions.length,
          lastSession: lastSessionDate,
          avgMinutesPerSession: u.sessions.length > 0 
            ? Math.round(totalHours / u.sessions.length * 60) 
            : 0,
        };
      })
      .sort((a, b) => b.lastSession.getTime() - a.lastSession.getTime());
  }, [filteredSessions]);

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  if (!isAuthorizedAdmin) {
    return (
      <div className="p-6">
        <Card className="p-12 text-center">
          <Shield className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Accès restreint</h3>
          <p className="text-gray-500">Cette page est réservée aux administrateurs @gestionbat.fr</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>
        <p className="text-gray-600 mt-2">
          Statistiques de temps de connexion — <span className="text-green-600 font-medium">uniquement @gestionbat.fr</span>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Heures</p>
              <p className="text-3xl font-bold text-orange-600">{stats.totalHours}h</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Heures Admin</p>
              <p className="text-3xl font-bold text-blue-600">{stats.adminHours}h</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Heures Utilisateurs</p>
              <p className="text-3xl font-bold text-green-600">{stats.userHours}h</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Users className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Sessions Totales</p>
              <p className="text-3xl font-bold text-purple-600">{stats.totalSessions}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-orange-500" />
          Connexions par utilisateur (@gestionbat.fr uniquement)
        </h2>
        {sessionsByUser.length === 0 ? (
          <p className="text-gray-500 text-sm">Aucune session enregistrée.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Utilisateur</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Rôle</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Sessions</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Durée totale</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Durée moy./session</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Dernière connexion</th>
                </tr>
              </thead>
              <tbody>
                {sessionsByUser.map((u, i) => (
                  <tr key={u.email} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-3 px-4 font-medium text-gray-900">{u.email}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        u.role === 'admin' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                      }`}>{u.role}</span>
                    </td>
                    <td className="py-3 px-4 text-right text-gray-600">{u.totalSessions}</td>
                    <td className="py-3 px-4 text-right font-semibold text-orange-600">{u.totalHours}h</td>
                    <td className="py-3 px-4 text-right text-gray-600">
                      {u.avgMinutesPerSession > 0 ? `${u.avgMinutesPerSession} min` : '-'}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-500 text-xs">
                      {u.lastSession.getTime() > 0 ? format(u.lastSession, 'dd/MM/yyyy HH:mm', { locale: fr }) : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4">
          Détail des sessions (50 dernières — @gestionbat.fr uniquement)
        </h2>
        {filteredSessions.length === 0 ? (
          <p className="text-gray-500 text-sm">Aucune session.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="text-left py-2 px-4 font-semibold text-gray-700">Date</th>
                  <th className="text-left py-2 px-4 font-semibold text-gray-700">Utilisateur</th>
                  <th className="text-left py-2 px-4 font-semibold text-gray-700">Rôle</th>
                  <th className="text-right py-2 px-4 font-semibold text-gray-700">Durée</th>
                </tr>
              </thead>
              <tbody>
                {[...filteredSessions]
                  .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
                  .slice(0, 50)
                  .map((s, i) => (
                  <tr key={s.id} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="py-2 px-4 text-gray-600 text-xs">
                      {s.created_date ? format(new Date(s.created_date), 'dd/MM/yyyy HH:mm', { locale: fr }) : '-'}
                    </td>
                    <td className="py-2 px-4 text-gray-700">{s.user_email || 'Inconnu'}</td>
                    <td className="py-2 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        s.user_role === 'admin' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                      }`}>{s.user_role}</span>
                    </td>
                    <td className="py-2 px-4 text-right font-medium text-orange-600">
                      {s.duration_minutes >= 60
                        ? `${(s.duration_hours || 0).toFixed(1)}h`
                        : `${s.duration_minutes || 0} min`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}