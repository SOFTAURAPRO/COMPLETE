import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Download, Loader2, FolderArchive, Settings2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import JSZip from 'jszip';
import { toast } from 'sonner';
import { format, getWeek } from 'date-fns';
import { generatePdfHtml } from '@/components/templates/PdfExportGenerator';
import { useInfoGestionbat } from '@/components/common/useInfoGestionbat';

const DOSSIERS = [
  { id: '1_marches', label: '1_Marchés entreprises', desc: 'Fichiers ZIP marchés + tableau PDF marchés' },
  { id: '2_cautions', label: '2_Cautions', desc: 'Documents cautions des marchés' },
  { id: '3_certificats', label: '3_Certificats de paiement', desc: 'CP envoyés MOE + tableau PDF récap avancement' },
  { id: '4_avenants', label: '4_Avenants', desc: 'Avenants signés uniquement' },
  { id: '5_ts_avenants', label: '5_TS Validés avec avenants', desc: 'Devis ayant un avenant + tableau PDF récap avenants' },
  { id: '6_ts_attente', label: '6_TS en attente', desc: 'Devis sans avenant' },
  { id: '7_cie', label: '7_CIE', desc: 'Documents CIE + tableau PDF suivi CIE' },
  { id: '8_sous_traitance', label: '8_Sous-Traitance', desc: 'Fichiers ZIP sous-traitance' },
  { id: '9_en_cours', label: '9_En cours marchés', desc: 'Tableau PDF en cours marchés' },
];

function getSemaine() {
  const now = new Date();
  const semaine = getWeek(now, { weekStartsOn: 1 });
  const annee = format(now, 'yyyy');
  return `S${String(semaine).padStart(2, '0')}_${annee}`;
}

export default function TelechargementChantier() {
  const [downloading, setDownloading] = useState({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedChantier, setSelectedChantier] = useState(null);
  const [selectedDossiers, setSelectedDossiers] = useState(
    Object.fromEntries(DOSSIERS.map(d => [d.id, true]))
  );

  const { infoGestionbat } = useInfoGestionbat();

  const { data: chantiers = [], isLoading } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list('-created_date'),
    initialData: []
  });

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
    initialData: []
  });

  const { data: entreprises = [] } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: []
  });

  const { data: partenaires = [] } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: []
  });

  const downloadFile = async (url) => {
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error('Erreur téléchargement');
      return await response.blob();
    } catch {
      return null;
    }
  };

  const getFileName = (url, fallback = 'document.pdf') => {
    try {
      const parts = new URL(url).pathname.split('/');
      return decodeURIComponent(parts[parts.length - 1]) || fallback;
    } catch {
      return fallback;
    }
  };

  const getPdfBase64 = async (htmlContent) => {
    const response = await base44.functions.invoke('htmlToPdf', { html_content: htmlContent });
    if (response.data?.success && response.data?.pdf_base64) {
      const byteChars = atob(response.data.pdf_base64);
      const byteArr = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) byteArr[i] = byteChars.charCodeAt(i);
      return byteArr;
    }
    return null;
  };

  const openDialog = (chantier) => {
    setSelectedChantier(chantier);
    setDialogOpen(true);
  };

  const toggleDossier = (id) => {
    setSelectedDossiers(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleAll = (val) => {
    setSelectedDossiers(Object.fromEntries(DOSSIERS.map(d => [d.id, val])));
  };

  const handleDownload = async () => {
    const chantier = selectedChantier;
    setDialogOpen(false);
    setDownloading(prev => ({ ...prev, [chantier.id]: true }));
    toast.loading('Préparation du ZIP...', { id: 'dl-zip' });

    try {
      const semaine = getSemaine();
      const nomChantier = (chantier.nom || 'chantier').replace(/[^a-zA-Z0-9_\-]/g, '_');
      const zip = new JSZip();
      const client = clients.find(c => c.id === chantier.client_id);

      // Charger toutes les données nécessaires en parallèle
      const [marches, travauxSup, avenants, sousTraitances, cieOps, cpEnvoyesMOE] = await Promise.all([
        base44.entities.MarcheEntreprise.filter({ chantier_id: chantier.id }),
        base44.entities.TravauxSupplementaire.filter({ chantier_id: chantier.id }),
        base44.entities.Avenant.filter({ chantier_id: chantier.id }),
        base44.entities.SousTraitance.filter({ chantier_id: chantier.id }),
        base44.entities.CieOperation.filter({ chantier_id: chantier.id }),
        base44.entities.CertificatEnvoyeMOE.list(),
      ]);

      const cpMoe = cpEnvoyesMOE.filter(f => f.chantier_id === chantier.id);
      const devisAvenant = travauxSup.filter(d => d.avenant_id);
      const devisAttente = travauxSup.filter(d => !d.avenant_id);
      const avenantsSignes = avenants.filter(a =>
        (a.avenants_signes && a.avenants_signes.length > 0) || a.avenant_signe_url
      );

      let fileCount = 0;

      // Helper pour nettoyer les noms de fichiers
      const sanitize = (s) => (s || '').replace(/[^a-zA-Z0-9_\-éèêëàâùûüîïôç]/g, '_').trim();

      // 1_Marchés entreprises (ZIP uniquement, nommés N°LOT_ENTREPRISE)
      if (selectedDossiers['1_marches']) {
        const folder = zip.folder('1_Marchés entreprises');
        for (const marche of marches) {
          const ent = entreprises.find(e => e.id === marche.entreprise_id);
          const nomFichierBase = `${sanitize(marche.numero_lot)}_${sanitize(ent?.nom)}`;
          if (marche.documents && Array.isArray(marche.documents)) {
            for (const doc of marche.documents) {
              if ((doc.type === 'marche' || (!doc.type && doc.url)) && doc.url) {
                const ext = doc.url.toLowerCase().includes('.zip') ? '.zip' : null;
                if (!ext) continue; // ZIP uniquement
                const blob = await downloadFile(doc.url);
                if (blob) { folder.file(`${nomFichierBase}.zip`, blob); fileCount++; }
              }
            }
          }
        }
        // Tableau PDF marchés
        try {
          const lignes = marches.sort((a, b) => (a.numero_lot || '').localeCompare(b.numero_lot || '', undefined, { numeric: true }))
            .map((m, i) => {
              const ent = entreprises.find(e => e.id === m.entreprise_id);
              const bg = i % 2 === 0 ? '' : 'style="background:#f9f9f9"';
              const montantHT = (m.montant || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
              const montantTTC = ((m.montant || 0) * (1 + (m.taux_tva || 20) / 100)).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
              return `<tr ${bg}><td>${m.numero_lot || '-'}</td><td>${m.intitule_lot || ''}</td><td>${ent?.nom || '-'}</td><td style="text-align:right">${montantHT} €</td><td style="text-align:right">${montantTTC} €</td><td>${m.numero_marche || '-'}</td><td>${m.date || '-'}</td></tr>`;
            }).join('');
          const totalHT = marches.reduce((s, m) => s + (m.montant || 0), 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
          const tableHtml = `<table><thead><tr><th>Lot</th><th>Intitulé</th><th>Entreprise</th><th style="text-align:right">Montant HT</th><th style="text-align:right">Montant TTC</th><th>N° Marché</th><th>Date</th></tr></thead><tbody>${lignes}<tr style="font-weight:bold;background:#fff3e0"><td colspan="3">TOTAL</td><td style="text-align:right">${totalHT} €</td><td></td><td></td><td></td></tr></tbody></table>`;
          const html = generatePdfHtml({ title: 'MARCHÉS ENTREPRISES', subtitle: semaine, chantier, client, infoGestionbat, partenaires, tableContentHtml: tableHtml, orientation: 'landscape' });
          const pdfBytes = await getPdfBase64(html);
          if (pdfBytes) { folder.file(`marchés_${nomChantier}_${semaine}.pdf`, pdfBytes); fileCount++; }
        } catch (e) { console.error('PDF marchés:', e); }
      }

      // 2_Cautions (nommés N°LOT_ENTREPRISE_MONTANT_TTC)
      if (selectedDossiers['2_cautions']) {
        const folder = zip.folder('2_Cautions');
        for (const marche of marches) {
          const ent = entreprises.find(e => e.id === marche.entreprise_id);
          if (marche.documents && Array.isArray(marche.documents)) {
            for (const doc of marche.documents) {
              if (doc.type === 'caution' && doc.url) {
                const montantTTC = Math.round((marche.montant || 0) * (1 + (marche.taux_tva || 20) / 100));
                const nomFichier = `${sanitize(marche.numero_lot)}_${sanitize(ent?.nom)}_${montantTTC}€TTC`;
                const ext = doc.url.toLowerCase().endsWith('.zip') ? '.zip' : '.pdf';
                const blob = await downloadFile(doc.url);
                if (blob) { folder.file(`${nomFichier}${ext}`, blob); fileCount++; }
              }
            }
          }
        }
      }

      // 3_Certificats de paiement
      if (selectedDossiers['3_certificats']) {
        const folder = zip.folder('3_Certificats de paiement');
        for (const f of cpMoe) {
          const blob = await downloadFile(f.url_fichier);
          if (blob) { folder.file(f.nom_fichier || getFileName(f.url_fichier), blob); fileCount++; }
        }
        // Tableau PDF récap avancement
        try {
          const certificats = await base44.entities.CertificatPaiement.filter({ chantier_id: chantier.id });
          const validés = certificats.filter(c => c.statut === 'valide');
          const lignes = marches.sort((a, b) => (a.numero_lot || '').localeCompare(b.numero_lot || '', undefined, { numeric: true }))
            .map((m, i) => {
              const certs = validés.filter(c => c.marche_id === m.id || (!c.marche_id && c.entreprise_id === m.entreprise_id));
              const avancement = certs.reduce((s, c) => s + (c.montant_ht || 0), 0);
              const ent = entreprises.find(e => e.id === m.entreprise_id);
              const bg = i % 2 === 0 ? '' : 'style="background:#f9f9f9"';
              const pct = m.montant ? Math.round(avancement / m.montant * 100) : 0;
              return `<tr ${bg}><td>${m.numero_lot || '-'}</td><td>${m.intitule_lot || ''}</td><td>${ent?.nom || '-'}</td><td style="text-align:right">${(m.montant || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €</td><td style="text-align:right">${avancement.toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €</td><td style="text-align:right">${pct}%</td></tr>`;
            }).join('');
          const tableHtml = `<table><thead><tr><th>Lot</th><th>Intitulé</th><th>Entreprise</th><th style="text-align:right">Marché HT</th><th style="text-align:right">Avancement HT</th><th style="text-align:right">%</th></tr></thead><tbody>${lignes}</tbody></table>`;
          const html = generatePdfHtml({ title: 'RÉCAPITULATIF AVANCEMENT', subtitle: semaine, chantier, client, infoGestionbat, partenaires, tableContentHtml: tableHtml, orientation: 'landscape' });
          const pdfBytes = await getPdfBase64(html);
          if (pdfBytes) { folder.file(`recapitulatif_avancement_${nomChantier}_${semaine}.pdf`, pdfBytes); fileCount++; }
        } catch (e) { console.error('PDF récap avancement:', e); }
      }

      // 4_Avenants (signés uniquement, nommés N°LOT_ENTREPRISE_N°AVENANT)
      if (selectedDossiers['4_avenants']) {
        const folder = zip.folder('4_Avenants');
        for (const avenant of avenantsSignes) {
          const ent = entreprises.find(e => e.id === avenant.entreprise_id);
          const marche = marches.find(m => m.id === avenant.marche_id);
          const nomFichierBase = `${sanitize(marche?.numero_lot)}_${sanitize(ent?.nom)}_Av${sanitize(avenant.numero)}`;
          if (avenant.avenants_signes && Array.isArray(avenant.avenants_signes)) {
            for (let idx = 0; idx < avenant.avenants_signes.length; idx++) {
              const doc = avenant.avenants_signes[idx];
              if (doc.url) {
                const blob = await downloadFile(doc.url);
                const suffix = avenant.avenants_signes.length > 1 ? `_${idx + 1}` : '';
                if (blob) { folder.file(`${nomFichierBase}${suffix}.pdf`, blob); fileCount++; }
              }
            }
          } else if (avenant.avenant_signe_url) {
            const blob = await downloadFile(avenant.avenant_signe_url);
            if (blob) { folder.file(`${nomFichierBase}.pdf`, blob); fileCount++; }
          }
        }
      }

      // 5_TS Validés avec avenants (nommés N°LOT_ENTREPRISE_N°AVENANT_N°DEVIS)
      if (selectedDossiers['5_ts_avenants']) {
        const folder = zip.folder('5_TS Validés avec avenants');
        for (const devis of devisAvenant) {
          if (devis.devis_pdf_url) {
            const ent = entreprises.find(e => e.id === devis.entreprise_id);
            const marche = marches.find(m => m.id === devis.marche_id || m.entreprise_id === devis.entreprise_id);
            const avenant = avenants.find(a => a.id === devis.avenant_id);
            const nomFichier = `${sanitize(marche?.numero_lot)}_${sanitize(ent?.nom)}_Av${sanitize(avenant?.numero)}_${sanitize(devis.numero_devis || devis.id)}`;
            const blob = await downloadFile(devis.devis_pdf_url);
            if (blob) { folder.file(`${nomFichier}.pdf`, blob); fileCount++; }
          }
        }
        // Tableau PDF récap avenants
        try {
          const lignes = avenants.sort((a, b) => (a.numero || '').localeCompare(b.numero || '', undefined, { numeric: true }))
            .map((av, i) => {
              const ent = entreprises.find(e => e.id === av.entreprise_id);
              const marche = marches.find(m => m.id === av.marche_id);
              const bg = i % 2 === 0 ? '' : 'style="background:#f9f9f9"';
              const statut = av.statut === 'signe' ? '✓ Signé' : av.statut === 'en_signature' ? 'En signature' : 'En préparation';
              const devisInclus = av.devis_ids?.length || 0;
              return `<tr ${bg}><td>${av.numero || '-'}</td><td>${av.intitule || ''}</td><td>${ent?.nom || '-'}</td><td>${marche ? `${marche.numero_lot || ''} - ${marche.intitule_lot || ''}` : '-'}</td><td>${av.date || '-'}</td><td style="text-align:right">${(av.montant_total_ht || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €</td><td>${statut}</td><td style="text-align:center">${devisInclus}</td></tr>`;
            }).join('');
          const totalHT = avenants.reduce((s, a) => s + (a.montant_total_ht || 0), 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
          const tableHtml = `<table><thead><tr><th>N°</th><th>Intitulé</th><th>Entreprise</th><th>Lot</th><th>Date</th><th style="text-align:right">Montant HT</th><th>Statut</th><th style="text-align:center">Nb Devis</th></tr></thead><tbody>${lignes}<tr style="font-weight:bold;background:#fff3e0"><td colspan="5">TOTAL</td><td style="text-align:right">${totalHT} €</td><td colspan="2"></td></tr></tbody></table>`;
          const html = generatePdfHtml({ title: 'RÉCAPITULATIF AVENANTS', subtitle: semaine, chantier, client, infoGestionbat, partenaires, tableContentHtml: tableHtml, orientation: 'landscape' });
          const pdfBytes = await getPdfBase64(html);
          if (pdfBytes) { folder.file(`recapitulatif_avenants_${nomChantier}_${semaine}.pdf`, pdfBytes); fileCount++; }
        } catch (e) { console.error('PDF récap avenants:', e); }
      }

      // 6_TS en attente (sans avenant, nommés N°LOT_ENTREPRISE_N°DEVIS)
      if (selectedDossiers['6_ts_attente']) {
        const folder = zip.folder('6_TS en attente');
        for (const devis of devisAttente) {
          if (devis.devis_pdf_url) {
            const ent = entreprises.find(e => e.id === devis.entreprise_id);
            const marche = marches.find(m => m.id === devis.marche_id || m.entreprise_id === devis.entreprise_id);
            const nomFichier = `${sanitize(marche?.numero_lot)}_${sanitize(ent?.nom)}_${sanitize(devis.numero_devis || devis.id)}`;
            const blob = await downloadFile(devis.devis_pdf_url);
            if (blob) { folder.file(`${nomFichier}.pdf`, blob); fileCount++; }
          }
        }
      }

      // 7_CIE (nommés ENTREPRISE_DESCRIPTION_MONTANT_HT)
      if (selectedDossiers['7_cie']) {
        const folder = zip.folder('7_CIE');
        for (const op of cieOps) {
          if (op.documents && Array.isArray(op.documents)) {
            const entFact = entreprises.find(e => e.id === op.entreprise_facturante_id);
            const montantHT = Math.round(op.montant_total_ht || 0);
            for (let idx = 0; idx < op.documents.length; idx++) {
              const doc = op.documents[idx];
              if (doc.url) {
                const suffix = op.documents.length > 1 ? `_${idx + 1}` : '';
                const nomFichier = `${sanitize(entFact?.nom)}_${sanitize(op.description)}_${montantHT}€HT${suffix}`;
                const ext = doc.url.toLowerCase().endsWith('.zip') ? '.zip' : '.pdf';
                const blob = await downloadFile(doc.url);
                if (blob) { folder.file(`${nomFichier}${ext}`, blob); fileCount++; }
              }
            }
          }
        }
        // Tableau PDF suivi CIE
        try {
          const lignes = cieOps.sort((a, b) => (a.date_operation || '').localeCompare(b.date_operation || ''))
            .map((op, i) => {
              const entFact = entreprises.find(e => e.id === op.entreprise_facturante_id);
              const bg = i % 2 === 0 ? '' : 'style="background:#f9f9f9"';
              const statut = op.statut === 'integre' ? '✓ Intégré' : op.statut === 'valide' ? 'Validé' : 'Brouillon';
              const repartitions = (op.repartitions || []).map(r => {
                const ent = entreprises.find(e => e.id === r.entreprise_responsable_id);
                return `${ent?.nom || '-'} (${r.pourcentage || 0}%)`;
              }).join(', ');
              return `<tr ${bg}><td>${op.date_operation || '-'}</td><td>${op.description || ''}</td><td>${entFact?.nom || '-'}</td><td style="text-align:right">${(op.montant_total_ht || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €</td><td>${repartitions}</td><td>${statut}</td></tr>`;
            }).join('');
          const totalHT = cieOps.reduce((s, op) => s + (op.montant_total_ht || 0), 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 });
          const tableHtml = `<table><thead><tr><th>Date</th><th>Description</th><th>Entreprise facturante</th><th style="text-align:right">Montant HT</th><th>Répartition</th><th>Statut</th></tr></thead><tbody>${lignes}<tr style="font-weight:bold;background:#fff3e0"><td colspan="3">TOTAL</td><td style="text-align:right">${totalHT} €</td><td colspan="2"></td></tr></tbody></table>`;
          const html = generatePdfHtml({ title: 'SUIVI C.I.E', subtitle: semaine, chantier, client, infoGestionbat, partenaires, tableContentHtml: tableHtml, orientation: 'landscape' });
          const pdfBytes = await getPdfBase64(html);
          if (pdfBytes) { folder.file(`suivi_CIE_${nomChantier}_${semaine}.pdf`, pdfBytes); fileCount++; }
        } catch (e) { console.error('PDF CIE:', e); }
      }

      // 8_Sous-Traitance
      if (selectedDossiers['8_sous_traitance']) {
        const folder = zip.folder('8_Sous-Traitance');
        for (const st of sousTraitances) {
          if (st.documents && Array.isArray(st.documents)) {
            for (const doc of st.documents) {
              if (doc.url) {
                const blob = await downloadFile(doc.url);
                if (blob) { folder.file(doc.nom || getFileName(doc.url), blob); fileCount++; }
              }
            }
          }
        }
      }

      // 9_En cours marchés (PDF uniquement)
      if (selectedDossiers['9_en_cours']) {
        const folder = zip.folder('9_En cours marchés');
        try {
          const certificats = await base44.entities.CertificatPaiement.filter({ chantier_id: chantier.id });
          const validés = certificats.filter(c => c.statut === 'valide');
          const sortedMarches = [...marches].sort((a, b) => (a.numero_lot || '').localeCompare(b.numero_lot || '', undefined, { numeric: true }));
          const lignes = sortedMarches.map((m, i) => {
            const ent = entreprises.find(e => e.id === m.entreprise_id);
            const certs = validés.filter(c => c.marche_id === m.id || (!c.marche_id && c.entreprise_id === m.entreprise_id));
            const avenantsM = avenants.filter(a => a.marche_id === m.id || (!a.marche_id && a.entreprise_id === m.entreprise_id));
            const avancementHT = certs.reduce((s, c) => s + (c.montant_ht || 0), 0);
            const avenantsHT = avenantsM.reduce((s, a) => s + (a.montant_total_ht || 0), 0);
            const baseHT = m.montant || 0;
            const totalHT = baseHT + avenantsHT;
            const pct = totalHT > 0 ? Math.round(avancementHT / totalHT * 100) : 0;
            const bg = i % 2 === 0 ? '' : 'style="background:#f9f9f9"';
            const fmt = (v) => v.toLocaleString('fr-FR', { minimumFractionDigits: 2 });
            return `<tr ${bg}><td>${m.numero_lot || '-'}</td><td>${m.intitule_lot || ''}</td><td>${ent?.nom || '-'}</td><td style="text-align:right">${fmt(baseHT)} €</td><td style="text-align:right">${fmt(avenantsHT)} €</td><td style="text-align:right;font-weight:bold">${fmt(totalHT)} €</td><td style="text-align:right;color:#1d4ed8">${fmt(avancementHT)} €</td><td style="text-align:right">${pct}%</td></tr>`;
          }).join('');
          const totalBase = sortedMarches.reduce((s, m) => s + (m.montant || 0), 0);
          const totalAven = avenants.reduce((s, a) => s + (a.montant_total_ht || 0), 0);
          const totalTotal = totalBase + totalAven;
          const totalAvanc = validés.reduce((s, c) => s + (c.montant_ht || 0), 0);
          const pctTotal = totalTotal > 0 ? Math.round(totalAvanc / totalTotal * 100) : 0;
          const fmt = (v) => v.toLocaleString('fr-FR', { minimumFractionDigits: 2 });
          const totalRow = `<tr style="font-weight:bold;background:#fff3e0"><td colspan="3">TOTAL</td><td style="text-align:right">${fmt(totalBase)} €</td><td style="text-align:right">${fmt(totalAven)} €</td><td style="text-align:right">${fmt(totalTotal)} €</td><td style="text-align:right">${fmt(totalAvanc)} €</td><td style="text-align:right">${pctTotal}%</td></tr>`;
          const tableHtml = `<table><thead><tr><th>Lot</th><th>Intitulé</th><th>Entreprise</th><th style="text-align:right">Base HT</th><th style="text-align:right">Avenants HT</th><th style="text-align:right">Total En cours HT</th><th style="text-align:right">Avancement HT</th><th style="text-align:right">%</th></tr></thead><tbody>${lignes}${totalRow}</tbody></table>`;
          const dateAuj = format(new Date(), 'dd/MM/yyyy');
          const html = generatePdfHtml({ title: 'EN COURS MARCHÉS ENTREPRISES', subtitle: `État au ${dateAuj} — ${semaine}`, chantier, client, infoGestionbat, partenaires, tableContentHtml: tableHtml, orientation: 'landscape' });
          const pdfBytes = await getPdfBase64(html);
          if (pdfBytes) { folder.file(`en_cours_marches_${nomChantier}_${semaine}.pdf`, pdfBytes); fileCount++; }
        } catch (e) { console.error('PDF en cours marchés:', e); }
      }

      if (fileCount === 0) {
        toast.warning('Aucun document trouvé pour les dossiers sélectionnés', { id: 'dl-zip' });
        return;
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `00__MCC_${nomChantier}_${semaine}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success(`ZIP généré — ${fileCount} fichier(s)`, { id: 'dl-zip' });
    } catch (error) {
      console.error('Erreur ZIP:', error);
      toast.error('Erreur lors de la création du ZIP', { id: 'dl-zip' });
    } finally {
      setDownloading(prev => ({ ...prev, [selectedChantier?.id]: false }));
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
          <FolderArchive className="w-8 h-8" />
          Téléchargement Documents Chantier
        </h1>
        <p className="text-gray-600 mt-2">
          Téléchargez les documents d'un chantier au format ZIP, par dossier sélectionné
        </p>
      </div>

      {chantiers.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            Aucun chantier disponible
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {chantiers.map(chantier => (
            <Card key={chantier.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{chantier.nom}</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">{chantier.adresse}</p>
                    <p className="text-xs text-gray-400 mt-1">Statut: {chantier.statut?.replace('_', ' ')}</p>
                  </div>
                  <Button
                    onClick={() => openDialog(chantier)}
                    disabled={downloading[chantier.id]}
                    className="bg-indigo-600 hover:bg-indigo-700 gap-2"
                  >
                    {downloading[chantier.id] ? (
                      <><Loader2 className="w-4 h-4 animate-spin" />Génération...</>
                    ) : (
                      <><Settings2 className="w-4 h-4" />Télécharger ZIP</>
                    )}
                  </Button>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>
      )}

      {/* Dialog sélection dossiers */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-indigo-600" />
              Sélectionner les dossiers à inclure
            </DialogTitle>
            <p className="text-sm text-gray-500 mt-1">
              Chantier : <strong>{selectedChantier?.nom}</strong>
            </p>
          </DialogHeader>

          <div className="space-y-1 py-2">
            <div className="flex gap-4 mb-3 text-sm">
              <button onClick={() => toggleAll(true)} className="text-indigo-600 hover:underline">Tout sélectionner</button>
              <button onClick={() => toggleAll(false)} className="text-gray-500 hover:underline">Tout désélectionner</button>
            </div>
            {DOSSIERS.map(d => (
              <div key={d.id} className="flex items-start gap-3 p-2 rounded hover:bg-gray-50">
                <Checkbox
                  id={d.id}
                  checked={selectedDossiers[d.id]}
                  onCheckedChange={() => toggleDossier(d.id)}
                  className="mt-0.5"
                />
                <div>
                  <Label htmlFor={d.id} className="font-semibold cursor-pointer text-sm">{d.label}</Label>
                  <p className="text-xs text-gray-500">{d.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button
              onClick={handleDownload}
              disabled={!Object.values(selectedDossiers).some(Boolean)}
              className="bg-indigo-600 hover:bg-indigo-700 gap-2"
            >
              <Download className="w-4 h-4" />
              Télécharger ZIP
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
