/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Building2, AlertCircle, Lock, Download, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ChantierCard from "../components/chantiers/ChantierCard";
import StatCard from "../components/dashboard/StatCard";
import { usePermissions } from "../components/common/usePermissions";
import { toast } from "sonner";

export default function Dashboard() {
  const navigate = useNavigate();
  const { hasPermission, currentUser, isAdmin } = usePermissions();
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  const canViewChantiers = hasPermission('chantiers_view');
  const canViewDashboard = hasPermission('dashboard_view');



  const { data: allChantiers } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list('-created_date'),
    initialData: [],
    enabled: canViewChantiers,
  });

  const { data: marches } = useQuery({
    queryKey: ['marches'],
    queryFn: () => base44.entities.MarcheEntreprise.list(),
    initialData: [],
    enabled: canViewChantiers,
  });

  const { data: avenants } = useQuery({
    queryKey: ['avenants'],
    queryFn: () => base44.entities.Avenant.list(),
    initialData: [],
    enabled: canViewChantiers,
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list('nom'),
    initialData: [],
    enabled: canViewChantiers,
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list('nom'),
    initialData: [],
    enabled: canViewChantiers,
  });

  const { data: membresEquipe } = useQuery({
    queryKey: ['membres-equipe'],
    queryFn: () => base44.entities.MembreEquipe.list('nom'),
    initialData: [],
    enabled: canViewChantiers,
  });

  // Filtre d'accès : les non-admins ne voient que les chantiers où ils sont membres de l'équipe
  const chantiers = useMemo(() => {
    if (!currentUser) return [];
    if (isAdmin) return allChantiers;
    const membreCourant = membresEquipe.find(m => m.email && m.email.toLowerCase() === currentUser.email?.toLowerCase());
    if (!membreCourant) return [];
    return allChantiers.filter(c => c.membres_equipe_ids && c.membres_equipe_ids.includes(membreCourant.id));
  }, [allChantiers, currentUser, isAdmin, membresEquipe]);


  const chantiersActifs = chantiers.filter(c => c.statut === 'en_cours');

  // Calcul du total des dépassements de temps
  const totalDepassements = React.useMemo(() => {
    let totalSemaines = 0;
    let totalMois = 0;
    
    chantiers.forEach(chantier => {
      if (!chantier.date_debut || !chantier.date_fin_prevue) return;
      
      const dateDebut = new Date(chantier.date_debut);
      const dateFin = new Date(chantier.date_fin_prevue);
      const diffJours = Math.floor((dateFin - dateDebut) / (1000 * 60 * 60 * 24));
      const jourSemaineFin = dateFin.getDay();
      
      const dureeInitialeSemaines = jourSemaineFin === 0 
        ? Math.ceil(diffJours / 7)
        : Math.floor(diffJours / 7);
      
      const customWeeks = chantier.planning_custom_weeks || [];
      let dureeFinaleSemaines = dureeInitialeSemaines;
      
      if (customWeeks.length > 0) {
        const addedWeeks = customWeeks.filter(w => !w.startsWith('-')).length;
        const removedWeeks = customWeeks.filter(w => w.startsWith('-')).length;
        dureeFinaleSemaines = dureeInitialeSemaines + addedWeeks - removedWeeks;
      }
      
      const depassementSemaines = dureeFinaleSemaines - dureeInitialeSemaines;
      if (depassementSemaines > 0) {
        totalSemaines += depassementSemaines;
      }
    });
    
    totalMois = Math.round((totalSemaines * 7 / 30.44) * 10) / 10;
    
    return { semaines: totalSemaines, mois: totalMois };
  }, [chantiers]);

  // Calcul du montant global : somme des montants globaux par chantier
  const montantGlobalMarches = React.useMemo(() => {
    const montantsParChantier = {};
    
    // Pour chaque chantier, calculer son montant global
    chantiers.forEach(chantier => {
      const marchesChantier = marches.filter(m => m.chantier_id === chantier.id);
      const montantBaseMarches = marchesChantier.reduce((sum, m) => sum + (m.montant || 0), 0);
      
      const avenantsChantier = avenants.filter(a => 
        a.chantier_id === chantier.id && 
        (a.statut === 'valide' || a.statut === 'signe')
      );
      const montantAvenants = avenantsChantier.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
      
      montantsParChantier[chantier.id] = montantBaseMarches + montantAvenants;
    });
    
    // Somme des montants globaux de tous les chantiers
    const total = Object.values(montantsParChantier).reduce((sum, montant) => sum + montant, 0);
    
    return total;
  }, [chantiers, marches, avenants]);

  const chantiersDepassement = chantiers.filter(c => {
    if (!c.budget_previsionnel || c.budget_previsionnel === 0) return false;
    
    const marchesChantier = marches.filter(m => m.chantier_id === c.id);
    const montantBaseMarches = marchesChantier.reduce((sum, m) => sum + (m.montant || 0), 0);
    
    const avenantsChantier = avenants.filter(a => 
      a.chantier_id === c.id && 
      (a.statut === 'valide' || a.statut === 'signe')
    );
    const montantAvenants = avenantsChantier.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
    
    const montantTotal = montantBaseMarches + montantAvenants;
    
    return montantTotal > c.budget_previsionnel;
  });

  const handleChantierClick = (chantierId) => {
    const url = new URL(window.location.origin + createPageUrl("ChantierDetails"));
    url.searchParams.set('chantierId', chantierId);
    navigate(url.pathname + url.search);
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const { data } = await base44.functions.invoke('exportDashboardData', {});
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `gestionbat-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      toast.success('Export complet réussi');
    } catch (error) {
      toast.error('Erreur lors de l\'export');
      console.error(error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/functions/importDashboardData', {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${await base44.auth.getToken()}`
        }
      });

      const result = await response.json();
      
      if (result.success) {
        toast.success(`Import réussi: ${result.results.created} créés, ${result.results.updated} mis à jour`);
        window.location.reload();
      } else {
        toast.error(result.error || 'Erreur lors de l\'import');
      }
    } catch (error) {
      toast.error('Erreur lors de l\'import');
      console.error(error);
    } finally {
      setIsImporting(false);
      event.target.value = '';
    }
  };

  if (!canViewDashboard && !canViewChantiers) {
    return (
      <div className="p-4 md:p-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 text-center">
            <Lock className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Accès restreint
            </h3>
            <p className="text-gray-500">
              Vous n'avez pas la permission d'accéder au tableau de bord. Contactez un administrateur.
            </p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Tableau de bord</h1>
            <p className="text-gray-600">Vue d'ensemble de vos projets et financements</p>
          </div>
          <div className="flex gap-2">
            <label htmlFor="import-csv">
              <Button asChild disabled={isImporting} variant="outline" className="gap-2 cursor-pointer">
                <span>
                  <Upload className="w-4 h-4" />
                  {isImporting ? 'Import...' : 'Importer données'}
                </span>
              </Button>
            </label>
            <Input
              id="import-csv"
              type="file"
              accept=".json"
              onChange={handleImport}
              className="hidden"
            />
            <Button onClick={handleExport} disabled={isExporting} variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            {isExporting ? 'Export...' : 'Exporter données'}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Montant global"
            value={`${montantGlobalMarches.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`}
            icon={TrendingUp}
            iconColor="text-orange-600"
            iconBg="bg-orange-100"
          />
          
          <StatCard
            title="Chantiers actifs"
            value={chantiersActifs.length.toString()}
            icon={Building2}
            iconColor="text-blue-600"
            iconBg="bg-blue-100"
          />
          
          <StatCard
            title="Dépassements budgétaires"
            value={chantiersDepassement.length.toString()}
            icon={AlertCircle}
            iconColor="text-red-600"
            iconBg="bg-red-100"
          />
          
          <StatCard
            title="Total des dépassements de temps"
            value={`${totalDepassements.semaines}s / ${totalDepassements.mois}m`}
            icon={AlertCircle}
            iconColor="text-orange-600"
            iconBg="bg-orange-100"
          />
        </div>

        <div className="space-y-6">
          {/* Planning des chantiers */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">Planning des chantiers</h2>
            <Card className="p-6">
              {chantiers.length === 0 ? (
                <div className="text-center text-gray-500 py-8">Aucun chantier planifié</div>
              ) : (
                <div className="space-y-3">
                  {chantiers
                    .filter(c => c.date_debut || c.date_fin_prevue)
                    .sort((a, b) => {
                      const dateA = new Date(a.date_debut || a.date_fin_prevue);
                      const dateB = new Date(b.date_debut || b.date_fin_prevue);
                      return dateA - dateB;
                    })
                    .map(chantier => {
                      const dateDebut = chantier.date_debut ? new Date(chantier.date_debut).toLocaleDateString('fr-FR') : '-';
                      const dateFin = chantier.date_fin_prevue ? new Date(chantier.date_fin_prevue).toLocaleDateString('fr-FR') : '-';
                      const isEnRetard = chantier.date_fin_prevue && new Date(chantier.date_fin_prevue) < new Date() && chantier.statut !== 'termine';
                      
                      // Calcul durée initiale (en semaines complètes uniquement, dimanche = fin de semaine)
                      let dureeInitialeSemaines = 0;
                      if (chantier.date_debut && chantier.date_fin_prevue) {
                        const dateDebut = new Date(chantier.date_debut);
                        const dateFin = new Date(chantier.date_fin_prevue);
                        const diffJours = Math.floor((dateFin - dateDebut) / (1000 * 60 * 60 * 24));
                        const jourSemaineFin = dateFin.getDay(); // 0=dimanche, 6=samedi
                        
                        // Si la date de fin tombe un dimanche (0), on compte la semaine complète
                        // Sinon, on compte uniquement les semaines complètes
                        dureeInitialeSemaines = jourSemaineFin === 0 
                          ? Math.ceil(diffJours / 7)
                          : Math.floor(diffJours / 7);
                      }
                      const dureeInitialeMois = chantier.date_debut && chantier.date_fin_prevue
                        ? Math.round((dureeInitialeSemaines * 7 / 30.44) * 10) / 10
                        : 0;
                      
                      // Calcul durée finale (basée sur les semaines personnalisées ou dates par défaut)
                      const customWeeks = chantier.planning_custom_weeks || [];
                      let dureeFinaleSemaines = dureeInitialeSemaines;
                      
                      if (customWeeks.length > 0) {
                        // Compter les semaines actives (ajoutées) et soustraire les semaines retirées
                        const addedWeeks = customWeeks.filter(w => !w.startsWith('-')).length;
                        const removedWeeks = customWeeks.filter(w => w.startsWith('-')).length;
                        dureeFinaleSemaines = dureeInitialeSemaines + addedWeeks - removedWeeks;
                      }
                      
                      const dureeFinaleMois = Math.round((dureeFinaleSemaines * 7 / 30.44) * 10) / 10;
                      
                      // Calcul dépassement (en semaines complètes uniquement)
                      const depassementSemaines = dureeFinaleSemaines - dureeInitialeSemaines;
                      const depassementMois = Math.round((dureeFinaleMois - dureeInitialeMois) * 10) / 10;
                      
                      return (
                        <div 
                          key={chantier.id}
                          className={`flex items-center justify-between p-4 rounded-lg border hover:border-orange-300 transition-colors cursor-pointer ${isEnRetard ? 'bg-red-50 border-red-200' : 'bg-gray-50'}`}
                          onClick={() => handleChantierClick(chantier.id)}
                        >
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-2">{chantier.nom}</h3>
                            <div className="grid grid-cols-3 gap-4 text-xs">
                              <div>
                                <p className="text-gray-500 font-medium">Durée initiale du chantier</p>
                                <p className="text-gray-700">
                                  {dateDebut} → {dateFin}
                                </p>
                                <p className="text-gray-600 mt-0.5">
                                  {dureeInitialeSemaines}s / {dureeInitialeMois}m
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-500 font-medium">Durée finale du chantier</p>
                                <p className="text-gray-700">
                                  {dureeFinaleSemaines}s / {dureeFinaleMois}m
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-500 font-medium">Dépassement du temps prévu</p>
                                <p className={`font-semibold ${depassementSemaines > 0 ? 'text-red-600' : depassementSemaines < 0 ? 'text-green-600' : 'text-gray-700'}`}>
                                  {depassementSemaines > 0 ? '+' : ''}{depassementSemaines}s / {depassementMois > 0 ? '+' : ''}{depassementMois}m
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                            chantier.statut === 'en_cours' ? 'bg-green-100 text-green-800' :
                            chantier.statut === 'termine' ? 'bg-gray-100 text-gray-800' :
                            chantier.statut === 'suspendu' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {chantier.statut === 'en_cours' ? 'En cours' :
                             chantier.statut === 'termine' ? 'Terminé' :
                             chantier.statut === 'suspendu' ? 'Suspendu' :
                             'En préparation'}
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </Card>
          </div>

          {chantiersDepassement.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <h2 className="text-xl font-bold text-gray-900">Alertes budgétaires</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {chantiersDepassement.map(chantier => (
                  <ChantierCard 
                    key={chantier.id}
                    chantier={chantier}
                    onClick={() => handleChantierClick(chantier.id)}
                  />
                ))}
              </div>
            </div>
          )}

          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">Chantiers actifs</h2>
            <Card className="p-6">
              {chantiersActifs.length === 0 ? (
                <div className="text-center text-gray-500 py-8">Aucun chantier actif</div>
              ) : (
                <div className="space-y-3">
                  {chantiersActifs.map(chantier => {
                    const marchesChantier = marches.filter(m => m.chantier_id === chantier.id);
                    const montantBaseMarches = marchesChantier.reduce((sum, m) => sum + (m.montant || 0), 0);
                    
                    const avenantsChantier = avenants.filter(a => 
                      a.chantier_id === chantier.id && 
                      (a.statut === 'valide' || a.statut === 'signe')
                    );
                    const montantAvenants = avenantsChantier.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
                    
                    const montantGlobal = montantBaseMarches + montantAvenants;
                    
                    // Récupérer le nom du client
                    const client = clients.find(c => c.id === chantier.client_id);
                    const nomClient = client?.nom || '-';
                    
                    // Récupérer les noms des partenaires
                    const partenairesChantier = (chantier.partenaires || [])
                      .map(p => {
                        const part = partenaires.find(pa => pa.id === p.partenaire_id);
                        return part ? `${part.nom} (${p.role || '-'})` : null;
                      })
                      .filter(Boolean);
                    
                    return (
                      <div 
                        key={chantier.id}
                        className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-orange-300 transition-colors cursor-pointer"
                        onClick={() => handleChantierClick(chantier.id)}
                      >
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{chantier.nom}</h3>
                          <div className="flex gap-4 mt-1 text-xs text-gray-600">
                            <div>
                              <span className="font-medium">Client:</span> {nomClient}
                            </div>
                            {partenairesChantier.length > 0 && (
                              <div>
                                <span className="font-medium">Partenaires:</span> {partenairesChantier.join(', ')}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-8 text-sm">
                          <div className="text-right">
                            <p className="text-gray-600">Montant marché de base</p>
                            <p className="font-semibold text-gray-900">
                              {montantBaseMarches.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-gray-600">Valeur des Avenants</p>
                            <p className="font-semibold text-gray-900">
                              {montantAvenants.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-gray-600">Montant global du marché</p>
                            <p className="font-semibold text-orange-600">
                              {montantGlobal.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}