/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Download, Upload, Database, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

const CHANTIERS_CIBLES = [
  '69290d95b6668f0ad121ce25', // SPMFG
  '690362b1510f40f8d0156aa7', // CVS
  '6903423d189b74c176442f38', // RESIDENCE ANDRE ROCHEFORT
];

export default function ExportImportDonnees() {
  const [exportData, setExportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [clearExisting, setClearExisting] = useState(false);
  const [importFile, setImportFile] = useState(null);

  const handleExport = async () => {
    setLoading(true);
    try {
      // Récupérer toutes les données
      const [
        allClients, allEntreprises, allPartenaires,
        allChantiers, allMarches, allAvenants,
        allTravauxSup, allCertificats, allSousTraitances,
        allCieOperations, membresEquipe
      ] = await Promise.all([
        base44.entities.Client.list(),
        base44.entities.Entreprise.list(),
        base44.entities.Partenaire.list(),
        base44.entities.Chantier.list(),
        base44.entities.MarcheEntreprise.list(),
        base44.entities.Avenant.list(),
        base44.entities.TravauxSupplementaire.list(),
        base44.entities.CertificatPaiement.list(),
        base44.entities.SousTraitance.list(),
        base44.entities.CieOperation.list(),
        base44.entities.MembreEquipe.list(),
      ]);

      // Filtrer les chantiers cibles
      const chantiers = allChantiers.filter(c => CHANTIERS_CIBLES.includes(c.id));

      // Filtrer les entités liées aux chantiers cibles
      const marches = allMarches.filter(m => CHANTIERS_CIBLES.includes(m.chantier_id));
      const avenants = allAvenants.filter(a => CHANTIERS_CIBLES.includes(a.chantier_id));
      const travauxSup = allTravauxSup.filter(t => CHANTIERS_CIBLES.includes(t.chantier_id));
      const certificats = allCertificats.filter(c => CHANTIERS_CIBLES.includes(c.chantier_id));
      const sousTraitances = allSousTraitances.filter(s => CHANTIERS_CIBLES.includes(s.chantier_id));
      const cieOperations = allCieOperations.filter(o => CHANTIERS_CIBLES.includes(o.chantier_id));

      // Collecter les IDs d'entreprises référencées
      const entrepriseIds = new Set([
        ...marches.map(m => m.entreprise_id),
        ...avenants.map(a => a.entreprise_id),
        ...travauxSup.map(t => t.entreprise_id),
        ...certificats.map(c => c.entreprise_id),
        ...sousTraitances.map(s => s.entreprise_principale_id),
        ...sousTraitances.map(s => s.entreprise_sous_traitant_id),
        ...cieOperations.map(o => o.entreprise_facturante_id),
        ...(cieOperations.flatMap(o => (o.repartitions || []).map(r => r.entreprise_responsable_id))),
      ].filter(Boolean));

      // Collecter les IDs clients référencés
      const clientIds = new Set([
        ...chantiers.map(c => c.client_id),
        ...chantiers.map(c => c.client_2_id),
        ...marches.map(m => m.client_id),
        ...certificats.map(c => c.client_id),
        ...travauxSup.map(t => t.client_id),
      ].filter(Boolean));

      // Collecter les IDs partenaires référencés
      const partenaireIds = new Set(
        chantiers.flatMap(c => (c.partenaires || []).map(p => p.partenaire_id)).filter(Boolean)
      );

      // Filtrer uniquement les entités réellement utilisées
      const entreprises = allEntreprises.filter(e => entrepriseIds.has(e.id));
      const clients = allClients.filter(c => clientIds.has(c.id));
      const partenaires = allPartenaires.filter(p => partenaireIds.has(p.id));

      const data = {
        export_date: new Date().toISOString(),
        app_version: "2.8.56",
        export_type: "chantiers_selection",
        chantiers_exportes: chantiers.map(c => ({ id: c.id, nom: c.nom, code_chantier: c.code_chantier })),
        stats: {
          total_records: clients.length + entreprises.length + partenaires.length + chantiers.length +
            marches.length + avenants.length + travauxSup.length + certificats.length +
            sousTraitances.length + cieOperations.length,
          entities_exported: ["Client", "Entreprise", "Partenaire", "Chantier", "MarcheEntreprise",
            "Avenant", "TravauxSupplementaire", "CertificatPaiement", "SousTraitance", "CieOperation"]
        },
        clients,
        entreprises,
        partenaires,
        chantiers,
        marches,
        avenants,
        travauxSup,
        certificats,
        sousTraitances,
        cieOperations,
      };

      setExportData(data);
      toast.success(`Export réussi : ${data.stats.total_records} enregistrements (${chantiers.length} chantiers)`);
    } catch (error) {
      toast.error("Erreur lors de l'export : " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!exportData) return;

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gestionbat-export-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Fichier téléchargé");
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);
          setImportFile(data);
          toast.success("Fichier chargé avec succès");
        } catch (error) {
          toast.error("Fichier JSON invalide");
        }
      };
      reader.readAsText(file);
    }
  };

  const handleImport = async () => {
    if (!importFile) {
      toast.error("Veuillez d'abord sélectionner un fichier");
      return;
    }

    setLoading(true);
    try {
      const response = await base44.functions.invoke('importAllData', {
        export: importFile,
        clear_existing: clearExisting
      });

      if (response.data.success) {
        toast.success(response.data.message);
        setImportFile(null);
        setClearExisting(false);
      } else {
        toast.error(response.data.error || "Erreur lors de l'import");
      }
    } catch (error) {
      toast.error("Erreur: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Export / Import des données</h1>
        <p className="text-gray-600">Gérez l'export et l'import complet de vos données pour cloner l'application</p>
      </div>

      <Alert className="mb-6 bg-blue-50 border-blue-200">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Export sélectif activé :</strong> L'export inclut uniquement les 3 chantiers ciblés (SPMFG, CVS, RÉSIDENCE ANDRÉ ROCHEFORT) avec leurs clients, entreprises, partenaires, marchés, avenants, travaux supplémentaires, certificats, sous-traitances et opérations CIE associés — IDs d'origine conservés.
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Export */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5 text-orange-600" />
              Exporter les données
            </CardTitle>
            <CardDescription>
              Exporte toutes les entités de l'application en un fichier JSON
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={handleExport}
              disabled={loading}
              className="w-full bg-orange-600 hover:bg-orange-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Export en cours...
                </>
              ) : (
                <>
                  <Database className="w-4 h-4 mr-2" />
                  Exporter toutes les données
                </>
              )}
            </Button>

            {exportData && (
              <div className="space-y-3">
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-900">
                    <strong>Export réussi :</strong><br />
                    {exportData.stats?.total_records || 0} enregistrements dans {exportData.stats?.entities_exported?.length || 0} entités<br />
                    {exportData.chantiers_exportes?.map(c => (
                      <span key={c.id} className="block text-xs mt-1">• {c.code_chantier} – {c.nom}</span>
                    ))}
                  </AlertDescription>
                </Alert>

                <Button
                  onClick={handleDownload}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Télécharger le fichier JSON
                </Button>

                <div className="text-xs text-gray-500 space-y-1">
                  <p>Date d'export : {new Date(exportData.export_date).toLocaleString('fr-FR')}</p>
                  <p>Version : {exportData.app_version}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Import */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-blue-600" />
              Importer les données
            </CardTitle>
            <CardDescription>
              Importe un fichier JSON exporté dans cette application
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-orange-400 transition-colors cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600 mb-1">
                    {importFile ? "Fichier chargé ✓" : "Cliquez pour sélectionner un fichier"}
                  </p>
                  <p className="text-xs text-gray-500">Format JSON uniquement</p>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              </label>
            </div>

            {importFile && (
              <div className="space-y-3">
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-900 text-sm">
                    Fichier prêt à être importé
                  </AlertDescription>
                </Alert>

                <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                  <Checkbox
                    id="clear"
                    checked={clearExisting}
                    onCheckedChange={setClearExisting}
                  />
                  <Label htmlFor="clear" className="text-sm cursor-pointer">
                    Supprimer les données existantes avant l'import
                  </Label>
                </div>

                <Button
                  onClick={handleImport}
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Import en cours...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Importer les données
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Alert className="mt-6 bg-red-50 border-red-200">
        <AlertCircle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-900">
          <strong>⚠️ Attention :</strong> L'import avec suppression des données existantes est irréversible. Assurez-vous d'avoir une sauvegarde avant de procéder.
        </AlertDescription>
      </Alert>
    </div>
  );
}