/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Upload, Download, FileDown, RefreshCw } from "lucide-react";
import ClientDialog from "../components/clients/ClientDialog";
import DuplicateResolutionDialog from "../components/common/DuplicateResolutionDialog";
import ClientsList from "../components/clients/ClientsList";
import SearchBar from "../components/common/SearchBar";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

export default function Clients() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const [importing, setImporting] = useState(false);
  const [duplicates, setDuplicates] = useState([]);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [resolvingDuplicates, setResolvingDuplicates] = useState(false);
  const [generatingRefs, setGeneratingRefs] = useState(false);
  
  const queryClient = useQueryClient();

  const { data: clients, isLoading } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list('nom'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Client.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      setShowDialog(false);
      setSelectedClient(null);
      toast.success("Client créé");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Client.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      setShowDialog(false);
      setSelectedClient(null);
      toast.success("Client mis à jour");
    },
  });

  const handleSubmit = (data) => {
    if (selectedClient) {
      updateMutation.mutate({ id: selectedClient.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExportList = () => {
    if (!clients || clients.length === 0) {
      toast.error("Aucun client à exporter");
      return;
    }

    const headers = ["Référence", "Nom", "Forme Juridique", "SIRET", "Ville", "Téléphone"];
    const csvContent = [
      headers.join(";"),
      ...clients.map(c => [
        c.reference || "",
        c.nom || "",
        c.forme_juridique || "",
        c.siret || "",
        c.ville || "",
        c.telephone || ""
      ].map(f => `"${f}"`).join(";"))
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = `clients_export_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateReferences = async () => {
    setGeneratingRefs(true);
    toast.loading("Attribution des références en cours...", { id: "gen-refs" });
    try {
      const res = await base44.functions.invoke("assignReferences", { entityName: "Client", prefix: "CLT" });
      if (res.data.success) {
        toast.success(res.data.message, { id: "gen-refs" });
        queryClient.invalidateQueries({ queryKey: ['clients'] });
      } else {
        throw new Error(res.data.error);
      }
    } catch (e) {
      console.error(e);
      toast.error("Erreur lors de la génération", { id: "gen-refs" });
    } finally {
      setGeneratingRefs(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      toast.info("Génération du modèle en cours...");
      const response = await base44.functions.invoke('generateClientTemplate');
      
      if (response.data.success && response.data.file_base64) {
        const byteCharacters = atob(response.data.file_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { 
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
        });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Modele_Import_Clients.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast.success("Modèle téléchargé avec succès");
      } else {
        throw new Error("Erreur lors de la génération du fichier");
      }
    } catch (error) {
      console.error("Erreur:", error);
      toast.error("Erreur lors du téléchargement du modèle");
    }
  };

  const handleImportExcel = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImporting(true);
    const toastId = toast.loading("Import en cours...");

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const response = await base44.functions.invoke('importClients', { file_url });
      
      if (response.data.success) {
        const { created, duplicates, errors } = response.data.results;
        
        if (duplicates && duplicates.length > 0) {
          setDuplicates(duplicates);
          setShowDuplicateDialog(true);
          toast.success(`Import partiel : ${created} créés. ${duplicates.length} doublons à résoudre.`, {
            id: toastId,
            duration: 5000
          });
        } else {
          toast.success(`Import terminé : ${created} créés${errors > 0 ? `, ${errors} erreurs` : ''}`, {
            id: toastId
          });
        }
        queryClient.invalidateQueries({ queryKey: ['clients'] });
      } else {
        throw new Error(response.data.error || "Erreur lors de l'import");
      }
    } catch (error) {
      console.error("Erreur import:", error);
      toast.error("Erreur lors de l'import du fichier", { id: toastId });
    } finally {
      setImporting(false);
      e.target.value = ''; 
    }
  };

  const handleResolveDuplicates = async (toUpdate) => {
    setResolvingDuplicates(true);
    try {
      // Update each client sequentially or in parallel
      await Promise.all(toUpdate.map(item => 
        base44.entities.Client.update(item.existing.id, item.new)
      ));

      toast.success(`${toUpdate.length} client(s) mis à jour`);
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      setShowDuplicateDialog(false);
      setDuplicates([]);
    } catch (error) {
      console.error("Erreur mise à jour doublons:", error);
      toast.error("Erreur lors de la mise à jour des doublons");
    } finally {
      setResolvingDuplicates(false);
    }
  };

  const filteredClients = useMemo(() => {
    if (!searchQuery) return clients;
    const query = searchQuery.toLowerCase();
    return clients.filter(c => 
      c.nom?.toLowerCase().includes(query) ||
      c.adresse_1?.toLowerCase().includes(query) ||
      c.ville?.toLowerCase().includes(query) ||
      c.siret?.toLowerCase().includes(query)
    );
  }, [clients, searchQuery]);

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Clients</h1>
            <p className="text-gray-600">
              {filteredClients.length} client{filteredClients.length > 1 ? 's' : ''} trouvé{filteredClients.length > 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleExportList}
              className="gap-2"
            >
              <FileDown className="w-4 h-4" />
              Exporter la liste
            </Button>
            <Button
              variant="ghost"
              onClick={handleGenerateReferences}
              disabled={generatingRefs}
              className="gap-2 text-xs text-gray-500"
              title="Attribuer des références manquantes"
            >
              <RefreshCw className={`w-3 h-3 ${generatingRefs ? 'animate-spin' : ''}`} />
              Générer Réf.
            </Button>
            <Button
              variant="outline"
              onClick={handleDownloadTemplate}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Modèle Excel
            </Button>
              <div className="relative">
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleImportExcel}
                  disabled={importing}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                />
                <Button 
                  variant="outline"
                  className="gap-2"
                  disabled={importing}
                >
                  <Upload className="w-4 h-4" />
                  {importing ? "Import..." : "Importer Excel"}
                </Button>
              </div>
            <Button 
              className="bg-orange-600 hover:bg-orange-700 gap-2"
              onClick={() => {
                setSelectedClient(null);
                setShowDialog(true);
              }}
            >
              <Plus className="w-5 h-5" />
              Nouveau client
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <SearchBar 
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Rechercher par nom, adresse, ville, SIRET..."
          />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
        ) : filteredClients.length === 0 && clients.length > 0 ? (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Aucun client trouvé
            </h3>
            <p className="text-gray-500 mb-4">
              Essayez de modifier vos critères de recherche
            </p>
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Aucun client enregistré
            </h3>
            <p className="text-gray-500 mb-4">
              Créez votre premier client pour commencer
            </p>
            <Button 
              className="bg-orange-600 hover:bg-orange-700 gap-2"
              onClick={() => setShowDialog(true)}
            >
              <Plus className="w-5 h-5" />
              Créer un client
            </Button>
          </div>
        ) : (
          <ClientsList 
            clients={filteredClients}
            onEdit={(client) => {
              setSelectedClient(client);
              setShowDialog(true);
            }}
          />
        )}

        <ClientDialog 
          open={showDialog}
          onOpenChange={setShowDialog}
          client={selectedClient}
          onSubmit={handleSubmit}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />

        <DuplicateResolutionDialog
          open={showDuplicateDialog}
          onOpenChange={setShowDuplicateDialog}
          duplicates={duplicates}
          onConfirm={handleResolveDuplicates}
          isUpdating={resolvingDuplicates}
        />
      </div>
    </div>
  );
}