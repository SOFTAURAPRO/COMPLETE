import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, ChevronDown, ChevronRight, HelpCircle, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function GuideUtilisateur() {
  const [openSections, setOpenSections] = useState({});

  const { data: sections, isLoading } = useQuery({
    queryKey: ["guide-utilisateur"],
    queryFn: async () => {
      const all = await base44.entities.GuideUtilisateur.list("ordre");
      return all.filter(s => s.est_visible !== false);
    },
    initialData: [],
  });

  const toggleSection = (id) => {
    setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-md">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Guide Utilisateur</h1>
            <p className="text-gray-500 text-sm mt-1">Documentation et aide à l'utilisation de GESTIONBAT</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          </div>
        ) : sections.length === 0 ? (
          <Card className="p-12 text-center">
            <HelpCircle className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Guide en cours de rédaction</h3>
            <p className="text-gray-500">Le guide utilisateur sera disponible prochainement.</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {sections.map((section, index) => (
              <Card
                key={section.id}
                className="overflow-hidden border border-gray-200 hover:border-orange-300 transition-colors"
              >
                <button
                  className="w-full text-left"
                  onClick={() => toggleSection(section.id)}
                >
                  <CardHeader className="py-4 px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="text-orange-600 border-orange-300 bg-orange-50 font-mono text-xs">
                          {String(index + 1).padStart(2, '0')}
                        </Badge>
                        <CardTitle className="text-base font-semibold text-gray-800">
                          {section.titre}
                        </CardTitle>
                      </div>
                      {openSections[section.id]
                        ? <ChevronDown className="w-5 h-5 text-orange-500 flex-shrink-0" />
                        : <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                      }
                    </div>
                  </CardHeader>
                </button>

                {openSections[section.id] && (
                  <CardContent className="px-6 pb-6 pt-0 border-t border-gray-100">
                    <div className="prose prose-sm max-w-none text-gray-700 mt-4
                      prose-headings:text-gray-800 prose-headings:font-semibold
                      prose-h2:text-lg prose-h3:text-base
                      prose-strong:text-gray-900
                      prose-ul:list-disc prose-ol:list-decimal
                      prose-li:marker:text-orange-500
                      prose-code:bg-orange-50 prose-code:text-orange-700 prose-code:px-1 prose-code:rounded
                      prose-blockquote:border-l-orange-400 prose-blockquote:text-gray-600">
                      <ReactMarkdown>{section.contenu}</ReactMarkdown>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}