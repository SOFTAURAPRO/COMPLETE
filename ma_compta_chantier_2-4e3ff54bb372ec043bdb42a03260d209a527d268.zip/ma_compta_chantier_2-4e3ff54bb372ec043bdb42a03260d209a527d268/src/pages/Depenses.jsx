import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import DepenseDialog from "../components/depenses/DepenseDialog";
import DepensesList from "../components/depenses/DepensesList";
import { Skeleton } from "@/components/ui/skeleton";

export default function Depenses() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedDepense, setSelectedDepense] = useState(null);
  const queryClient = useQueryClient();

  const { data: depenses, isLoading: loadingDepenses } = useQuery({
    queryKey: ['depenses'],
    queryFn: () => base44.entities.Depense.list('-date'),
    initialData: [],
  });

  const { data: chantiers, isLoading: loadingChantiers } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Depense.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['depenses'] });
      setShowDialog(false);
      setSelectedDepense(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Depense.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['depenses'] });
      setShowDialog(false);
      setSelectedDepense(null);
    },
  });

  const handleSubmit = (data) => {
    if (selectedDepense) {
      updateMutation.mutate({ id: selectedDepense.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const isLoading = loadingDepenses || loadingChantiers;

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Dépenses</h1>
            <p className="text-gray-600">Suivez toutes vos dépenses par chantier</p>
          </div>
          <Button 
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={() => {
              setSelectedDepense(null);
              setShowDialog(true);
            }}
          >
            <Plus className="w-5 h-5" />
            Nouvelle dépense
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        ) : (
          <DepensesList 
            depenses={depenses}
            chantiers={chantiers}
            onEdit={(depense) => {
              setSelectedDepense(depense);
              setShowDialog(true);
            }}
          />
        )}

        <DepenseDialog 
          open={showDialog}
          onOpenChange={setShowDialog}
          depense={selectedDepense}
          chantiers={chantiers}
          onSubmit={handleSubmit}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />
      </div>
    </div>
  );
}