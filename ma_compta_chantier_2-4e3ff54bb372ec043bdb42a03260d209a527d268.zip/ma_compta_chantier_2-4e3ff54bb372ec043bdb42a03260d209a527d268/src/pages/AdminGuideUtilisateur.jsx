import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, GripVertical, Eye, EyeOff, BookOpen, Lock, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "../components/common/usePermissions";
import ReactMarkdown from "react-markdown";

const EMPTY_SECTION = { titre: "", ordre: 1, contenu: "", est_visible: true };

export default function AdminGuideUtilisateur() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedSection, setSelectedSection] = useState(null);
  const [formData, setFormData] = useState(EMPTY_SECTION);
  const [preview, setPreview] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [sectionToDelete, setSectionToDelete] = useState(null);

  const queryClient = useQueryClient();
  const { isAdmin } = usePermissions();

  const { data: sections, isLoading } = useQuery({
    queryKey: ["guide-utilisateur"],
    queryFn: () => base44.entities.GuideUtilisateur.list("ordre"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.GuideUtilisateur.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guide-utilisateur"] });
      setShowDialog(false);
      toast.success("Section créée");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.GuideUtilisateur.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guide-utilisateur"] });
      setShowDialog(false);
      toast.success("Section mise à jour");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.GuideUtilisateur.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guide-utilisateur"] });
      setShowDeleteDialog(false);
      setSectionToDelete(null);
      toast.success("Section supprimée");
    },
  });

  const toggleVisibility = (section) => {
    updateMutation.mutate({ id: section.id, data: { ...section, est_visible: !section.est_visible } });
  };

  const handleEdit = (section) => {
    setSelectedSection(section);
    setFormData({ titre: section.titre, ordre: section.ordre || 1, contenu: section.contenu, est_visible: section.est_visible !== false });
    setPreview(false);
    setShowDialog(true);
  };

  const handleNew = () => {
    setSelectedSection(null);
    const nextOrdre = sections.length > 0 ? Math.max(...sections.map(s => s.ordre || 0)) + 1 : 1;
    setFormData({ ...EMPTY_SECTION, ordre: nextOrdre });
    setPreview(false);
    setShowDialog(true);
  };

  const handleSubmit = () => {
    if (!formData.titre.trim()) { toast.error("Le titre est requis"); return; }
    if (!formData.contenu.trim()) { toast.error("Le contenu est requis"); return; }
    if (selectedSection) {
      updateMutation.mutate({ id: selectedSection.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  if (!isAdmin) {
    return (
      <div className="p-4 md:p-8 min-h-screen flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <Lock className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Accès restreint</h3>
          <p className="text-gray-500">Seuls les administrateurs peuvent gérer le guide utilisateur.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-md">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gestion du Guide Utilisateur</h1>
              <p className="text-gray-500 text-sm mt-1">Créez et organisez les sections du guide</p>
            </div>
          </div>
          <Button className="bg-orange-600 hover:bg-orange-700 gap-2" onClick={handleNew}>
            <Plus className="w-5 h-5" />
            Nouvelle section
          </Button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          </div>
        ) : sections.length === 0 ? (
          <Card className="p-12 text-center">
            <BookOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Aucune section</h3>
            <p className="text-gray-500 mb-6">Commencez par créer la première section du guide.</p>
            <Button className="bg-orange-600 hover:bg-orange-700 gap-2" onClick={handleNew}>
              <Plus className="w-5 h-5" /> Créer une section
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {sections.map((section) => (
              <Card key={section.id} className={`border ${section.est_visible !== false ? 'border-gray-200' : 'border-gray-100 opacity-60'}`}>
                <CardHeader className="py-4 px-6">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <GripVertical className="w-4 h-4 text-gray-300 flex-shrink-0" />
                      <Badge variant="outline" className="text-orange-600 border-orange-300 bg-orange-50 font-mono text-xs flex-shrink-0">
                        #{section.ordre || '?'}
                      </Badge>
                      <span className="font-semibold text-gray-800 truncate">{section.titre}</span>
                      {section.est_visible === false && (
                        <Badge variant="outline" className="text-gray-400 text-xs flex-shrink-0">Masqué</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleVisibility(section)}
                        title={section.est_visible !== false ? "Masquer" : "Afficher"}
                      >
                        {section.est_visible !== false
                          ? <Eye className="w-4 h-4 text-green-600" />
                          : <EyeOff className="w-4 h-4 text-gray-400" />
                        }
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(section)}>
                        <Pencil className="w-4 h-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => { setSectionToDelete(section); setShowDeleteDialog(true); }}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 mt-1 ml-11 line-clamp-1">{section.contenu?.substring(0, 120)}...</p>
                </CardHeader>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Dialog création / édition */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedSection ? "Modifier la section" : "Nouvelle section"}</DialogTitle>
            <DialogDescription>
              Rédigez le contenu en Markdown. Utilisez ## pour les titres, **gras**, - pour les listes, etc.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-1">
                <Label>Titre *</Label>
                <Input
                  value={formData.titre}
                  onChange={e => setFormData(p => ({ ...p, titre: e.target.value }))}
                  placeholder="Ex: Gestion des chantiers"
                />
              </div>
              <div className="space-y-1">
                <Label>Ordre d'affichage</Label>
                <Input
                  type="number"
                  min={1}
                  value={formData.ordre}
                  onChange={e => setFormData(p => ({ ...p, ordre: parseInt(e.target.value) || 1 }))}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={formData.est_visible !== false}
                onCheckedChange={v => setFormData(p => ({ ...p, est_visible: v }))}
              />
              <Label>Visible par les utilisateurs</Label>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Contenu (Markdown) *</Label>
                <Button variant="ghost" size="sm" onClick={() => setPreview(p => !p)} className="text-xs gap-1">
                  {preview ? <Pencil className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  {preview ? "Éditer" : "Prévisualiser"}
                </Button>
              </div>

              {preview ? (
                <div className="border rounded-lg p-4 min-h-[300px] bg-gray-50 prose prose-sm max-w-none text-gray-700
                  prose-headings:text-gray-800 prose-strong:text-gray-900
                  prose-li:marker:text-orange-500 prose-code:bg-orange-50 prose-code:text-orange-700 prose-code:px-1 prose-code:rounded">
                  <ReactMarkdown>{formData.contenu || "*Aucun contenu à prévisualiser*"}</ReactMarkdown>
                </div>
              ) : (
                <textarea
                  className="w-full border rounded-lg p-3 text-sm font-mono min-h-[300px] resize-y focus:outline-none focus:ring-2 focus:ring-orange-500"
                  value={formData.contenu}
                  onChange={e => setFormData(p => ({ ...p, contenu: e.target.value }))}
                  placeholder={`## Introduction\n\nDécrivez ici le fonctionnement de cette section...\n\n## Étapes\n\n1. Première étape\n2. Deuxième étape\n\n**Important :** Note importante en gras.`}
                />
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Annuler</Button>
            <Button
              className="bg-orange-600 hover:bg-orange-700"
              onClick={handleSubmit}
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              {createMutation.isPending || updateMutation.isPending ? "Enregistrement..." : selectedSection ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog suppression */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              Confirmer la suppression
            </DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer la section <strong>"{sectionToDelete?.titre}"</strong> ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Annuler</Button>
            <Button
              variant="destructive"
              onClick={() => deleteMutation.mutate(sectionToDelete.id)}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Suppression..." : "Supprimer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}