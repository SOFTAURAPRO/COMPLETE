import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Megaphone } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "../components/common/usePermissions";

export default function GestionAnnonces() {
  const queryClient = useQueryClient();
  const { isAdmin } = usePermissions();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAnnonce, setEditingAnnonce] = useState(null);
  const [formData, setFormData] = useState({
    titre: "",
    message: "",
    type: "info",
    actif: true,
    date_debut: "",
    date_fin: "",
    pages_ciblees: []
  });

  const { data: annonces = [] } = useQuery({
    queryKey: ['annonces-globales-admin'],
    queryFn: () => base44.entities.AnnonceGlobale.list('-created_date'),
    enabled: isAdmin,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AnnonceGlobale.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annonces-globales-admin'] });
      queryClient.invalidateQueries({ queryKey: ['annonces-globales'] });
      toast.success("Annonce créée");
      setDialogOpen(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AnnonceGlobale.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annonces-globales-admin'] });
      queryClient.invalidateQueries({ queryKey: ['annonces-globales'] });
      toast.success("Annonce mise à jour");
      setDialogOpen(false);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AnnonceGlobale.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annonces-globales-admin'] });
      queryClient.invalidateQueries({ queryKey: ['annonces-globales'] });
      toast.success("Annonce supprimée");
    },
  });

  const resetForm = () => {
    setFormData({
      titre: "",
      message: "",
      type: "info",
      actif: true,
      date_debut: "",
      date_fin: "",
      pages_ciblees: []
    });
    setEditingAnnonce(null);
  };

  const handleEdit = (annonce) => {
    setEditingAnnonce(annonce);
    setFormData({
      titre: annonce.titre || "",
      message: annonce.message || "",
      type: annonce.type || "info",
      actif: annonce.actif !== false,
      date_debut: annonce.date_debut ? annonce.date_debut.split('T')[0] : "",
      date_fin: annonce.date_fin ? annonce.date_fin.split('T')[0] : "",
      pages_ciblees: annonce.pages_ciblees || []
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const dataToSave = {
      ...formData,
      date_debut: formData.date_debut ? new Date(formData.date_debut).toISOString() : null,
      date_fin: formData.date_fin ? new Date(formData.date_fin).toISOString() : null,
    };

    if (editingAnnonce) {
      updateMutation.mutate({ id: editingAnnonce.id, data: dataToSave });
    } else {
      createMutation.mutate(dataToSave);
    }
  };

  if (!isAdmin) {
    return (
      <div className="p-8">
        <Card className="p-12 text-center">
          <p className="text-gray-500">Accès réservé aux administrateurs</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Gestion des annonces</h1>
            <p className="text-gray-600">Diffuser des messages à tous les utilisateurs</p>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="gap-2">
            <Plus className="w-4 h-4" />
            Nouvelle annonce
          </Button>
        </div>

        <div className="space-y-4">
          {annonces.length === 0 ? (
            <Card className="p-12 text-center">
              <Megaphone className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">Aucune annonce créée</p>
            </Card>
          ) : (
            annonces.map((annonce) => (
              <Card key={annonce.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                  <div className="flex items-center gap-3">
                    <div className={`px-2 py-1 rounded text-xs font-medium ${
                      annonce.type === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                      annonce.type === 'success' ? 'bg-green-100 text-green-800' :
                      annonce.type === 'error' ? 'bg-red-100 text-red-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {annonce.type}
                    </div>
                    <CardTitle className="text-lg">{annonce.titre}</CardTitle>
                    {annonce.actif ? (
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Actif</span>
                    ) : (
                      <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">Inactif</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={() => handleEdit(annonce)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => deleteMutation.mutate(annonce.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap mb-3">{annonce.message}</p>
                  <div className="flex gap-4 text-xs text-gray-500">
                    {annonce.date_debut && (
                      <span>Début: {new Date(annonce.date_debut).toLocaleDateString('fr-FR')}</span>
                    )}
                    {annonce.date_fin && (
                      <span>Fin: {new Date(annonce.date_fin).toLocaleDateString('fr-FR')}</span>
                    )}
                    {annonce.pages_ciblees && annonce.pages_ciblees.length > 0 && (
                      <span>Pages: {annonce.pages_ciblees.join(', ')}</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingAnnonce ? "Modifier l'annonce" : "Nouvelle annonce"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Titre *</Label>
                <Input
                  value={formData.titre}
                  onChange={(e) => setFormData({ ...formData, titre: e.target.value })}
                  placeholder="Titre de l'annonce"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Message *</Label>
                <Textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Message détaillé"
                  rows={4}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Avertissement</SelectItem>
                      <SelectItem value="success">Succès</SelectItem>
                      <SelectItem value="error">Erreur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Statut</Label>
                  <div className="flex items-center space-x-2 h-10">
                    <Switch
                      checked={formData.actif}
                      onCheckedChange={(checked) => setFormData({ ...formData, actif: checked })}
                    />
                    <span className="text-sm">{formData.actif ? 'Actif' : 'Inactif'}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date de début (optionnel)</Label>
                  <Input
                    type="date"
                    value={formData.date_debut}
                    onChange={(e) => setFormData({ ...formData, date_debut: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Date de fin (optionnel)</Label>
                  <Input
                    type="date"
                    value={formData.date_fin}
                    onChange={(e) => setFormData({ ...formData, date_fin: e.target.value })}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Annuler
                </Button>
                <Button type="submit">
                  {editingAnnonce ? "Mettre à jour" : "Créer"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}