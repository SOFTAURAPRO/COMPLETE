import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import MarcheDialog from "../components/marches/MarcheDialog";
import MarchesList from "../components/marches/MarchesList";
import { Skeleton } from "@/components/ui/skeleton";

export default function MarchesEntreprises() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedMarche, setSelectedMarche] = useState(null);
  const queryClient = useQueryClient();

  const { data: marches, isLoading: loadingMarches } = useQuery({
    queryKey: ['marches'],
    queryFn: () => base44.entities.MarcheEntreprise.list('-date'),
    initialData: [],
  });

  const { data: chantiers, isLoading: loadingChantiers } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MarcheEntreprise.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['marches'] });
      setShowDialog(false);
      setSelectedMarche(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MarcheEntreprise.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['marches'] });
      setShowDialog(false);
      setSelectedMarche(null);
    },
  });

  const handleSubmit = (data) => {
    if (selectedMarche) {
      updateMutation.mutate({ id: selectedMarche.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const isLoading = loadingMarches || loadingChantiers;

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Marchés entreprises</h1>
            <p className="text-gray-600">Suivez tous vos marchés par chantier</p>
          </div>
          <Button 
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={() => {
              setSelectedMarche(null);
              setShowDialog(true);
            }}
          >
            <Plus className="w-5 h-5" />
            Nouveau marché
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        ) : (
          <MarchesList 
            marches={marches}
            chantiers={chantiers}
            onEdit={(marche) => {
              setSelectedMarche(marche);
              setShowDialog(true);
            }}
          />
        )}

        <MarcheDialog 
          open={showDialog}
          onOpenChange={setShowDialog}
          marche={selectedMarche}
          chantiers={chantiers}
          onSubmit={handleSubmit}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />
      </div>
    </div>
  );
}