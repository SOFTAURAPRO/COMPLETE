import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Building, MapPin, Phone, FileText, Briefcase, Upload, X, Image, Download, FileDown, RefreshCw, Printer } from "lucide-react";
import { getFichePartenaireHtml } from "@/components/templates/FichePartenaireTemplate";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import DuplicateResolutionDialog from "../components/common/DuplicateResolutionDialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import SearchBar from "../components/common/SearchBar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";

const MISSIONS = [
  "Architecte",
  "Maître d'œuvre",
  "BE Accessibilité",
  "BE Acoustique",
  "BE Agencement",
  "BE Eau",
  "BE Éclairage",
  "BE Thermique et Fluides",
  "BE Géotechnique",
  "BE Paysagiste",
  "TCE",
  "BE VRD",
  "BE Structure",
  "Programmiste",
  "Bureau de Contrôle",
  "Géomètre",
  "OPC",
  "SPS",
  "Urbaniste"
];

import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContactsTab from "../components/common/ContactsTab";

function PartenaireDialog({ open, onOpenChange, partenaire, onSubmit, isLoading }) {
  const [formData, setFormData] = React.useState({
    reference: "",
    nom: "",
    forme_juridique: "",
    missions: [],
    logo_url: "",
    adresse_1: "",
    adresse_2: "",
    code_postal: "",
    ville: "",
    telephone: "",
    siret: "",
    contacts: []
  });

  const [uploadingLogo, setUploadingLogo] = React.useState(false);

  React.useEffect(() => {
    if (partenaire) {
      setFormData({
        reference: partenaire.reference || "",
        nom: partenaire.nom || "",
        forme_juridique: partenaire.forme_juridique || "",
        missions: partenaire.missions || (partenaire.mission ? [partenaire.mission] : []),
        logo_url: partenaire.logo_url || "",
        adresse_1: partenaire.adresse_1 || "",
        adresse_2: partenaire.adresse_2 || "",
        code_postal: partenaire.code_postal || "",
        ville: partenaire.ville || "",
        telephone: partenaire.telephone || "",
        siret: partenaire.siret || "",
        contacts: partenaire.contacts || []
      });
    } else {
      // Fetch next reference
      if (open) {
        base44.functions.invoke("getNextReference", { entityName: "Partenaire", prefix: "PAR" })
          .then(res => {
            if (res.data && res.data.nextReference) {
              setFormData(prev => ({ ...prev, reference: res.data.nextReference }));
            }
          });
      }
      setFormData({
        reference: "",
        nom: "",
        forme_juridique: "",
        missions: [],
        logo_url: "",
        adresse_1: "",
        adresse_2: "",
        code_postal: "",
        ville: "",
        telephone: "",
        siret: "",
        contacts: []
      });
    }
  }, [partenaire, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      mission: formData.missions[0] || "" // Legacy support
    });
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, logo_url: file_url });
      toast.success("Logo téléchargé");
    } catch (error) {
      console.error("Erreur lors du téléchargement:", error);
      toast.error("Erreur lors du téléchargement du logo");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleRemoveLogo = () => {
    setFormData({ ...formData, logo_url: "" });
  };

  const getFileName = (url) => {
    if (!url) return "";
    return url.split('/').pop().split('?')[0];
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {partenaire ? "Modifier le partenaire" : "Nouveau partenaire"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="general" className="w-full mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="general">Général</TabsTrigger>
              <TabsTrigger value="contacts">Interlocuteurs</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4 py-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reference">Référence</Label>
                  <Input
                    id="reference"
                    value={formData.reference}
                    readOnly
                    className="bg-gray-100 text-gray-500"
                    placeholder="Génération auto..."
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="nom">Nom du partenaire *</Label>
                  <Input
                    id="nom"
                    value={formData.nom}
                    onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                    placeholder="Ex: Cabinet d'Architecture XYZ"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="forme_juridique">Forme Juridique</Label>
                  <Select
                    value={formData.forme_juridique}
                    onValueChange={(value) => setFormData({ ...formData, forme_juridique: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Forme" />
                    </SelectTrigger>
                    <SelectContent>
                      {["SA", "SAS", "SARL", "EURL", "SASU", "SCOP", "EI", "SARL UNIPERSONNELLE"].map(forme => (
                        <SelectItem key={forme} value={forme}>{forme}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Missions</Label>
                <div className="border rounded-md p-3 max-h-48 overflow-y-auto space-y-2">
                  {MISSIONS.map(mission => (
                    <div key={mission} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`mission-${mission}`} 
                        checked={formData.missions.includes(mission)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({ ...formData, missions: [...formData.missions, mission] });
                          } else {
                            setFormData({ ...formData, missions: formData.missions.filter(m => m !== mission) });
                          }
                        }}
                      />
                      <Label htmlFor={`mission-${mission}`} className="cursor-pointer font-normal">
                        {mission}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Logo</Label>
                {formData.logo_url ? (
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    <img 
                      src={formData.logo_url} 
                      alt="Logo partenaire" 
                      className="w-16 h-16 object-contain"
                    />
                    <span className="text-sm flex-1 truncate">{getFileName(formData.logo_url)}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={handleRemoveLogo}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="relative">
                    <Input
                      type="file"
                      accept=".png,.jpg,.jpeg,.svg"
                      onChange={handleLogoUpload}
                      disabled={uploadingLogo}
                      className="cursor-pointer"
                    />
                    {uploadingLogo && <p className="text-xs text-gray-500 mt-1">Téléchargement...</p>}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_1">Adresse ligne 1</Label>
                <Input
                  id="adresse_1"
                  value={formData.adresse_1}
                  onChange={(e) => setFormData({ ...formData, adresse_1: e.target.value })}
                  placeholder="Numéro et nom de rue"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_2">Adresse ligne 2</Label>
                <Input
                  id="adresse_2"
                  value={formData.adresse_2}
                  onChange={(e) => setFormData({ ...formData, adresse_2: e.target.value })}
                  placeholder="Complément d'adresse"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="code_postal">Code postal</Label>
                  <Input
                    id="code_postal"
                    value={formData.code_postal}
                    onChange={(e) => setFormData({ ...formData, code_postal: e.target.value })}
                    placeholder="75000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ville">Ville</Label>
                  <Input
                    id="ville"
                    value={formData.ville}
                    onChange={(e) => setFormData({ ...formData, ville: e.target.value })}
                    placeholder="Paris"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telephone">Téléphone</Label>
                  <Input
                    id="telephone"
                    value={formData.telephone}
                    onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                    placeholder="01 23 45 67 89"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="siret">SIRET</Label>
                  <Input
                    id="siret"
                    value={formData.siret}
                    onChange={(e) => setFormData({ ...formData, siret: e.target.value })}
                    placeholder="123 456 789 00012"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="contacts">
              <ContactsTab 
                contacts={formData.contacts} 
                onChange={(newContacts) => setFormData({ ...formData, contacts: newContacts })} 
              />
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Annuler
            </Button>
            <Button 
              type="submit" 
              className="bg-orange-600 hover:bg-orange-700"
              disabled={isLoading}
            >
              {isLoading ? "Enregistrement..." : partenaire ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Partenaires() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedPartenaire, setSelectedPartenaire] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [importing, setImporting] = useState(false);
  const [duplicates, setDuplicates] = useState([]);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [resolvingDuplicates, setResolvingDuplicates] = useState(false);
  const [generatingRefs, setGeneratingRefs] = useState(false);
  
  const queryClient = useQueryClient();

  const { data: partenaires, isLoading } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list('nom'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Partenaire.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partenaires'] });
      setShowDialog(false);
      setSelectedPartenaire(null);
      toast.success("Partenaire créé");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Partenaire.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partenaires'] });
      setShowDialog(false);
      setSelectedPartenaire(null);
      toast.success("Partenaire mis à jour");
    },
  });

  const handleSubmit = (data) => {
    if (selectedPartenaire) {
      updateMutation.mutate({ id: selectedPartenaire.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (partenaire) => {
    setSelectedPartenaire(partenaire);
    setShowDialog(true);
  };

  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const handleExportList = () => {
    if (!partenaires || partenaires.length === 0) {
      toast.error("Aucun partenaire à exporter");
      return;
    }

    const headers = ["Référence", "Nom", "Missions", "Forme Juridique", "SIRET", "Ville", "Téléphone"];
    const csvContent = [
      headers.join(";"),
      ...partenaires.map(p => [
        p.reference || "",
        p.nom || "",
        (p.missions || [p.mission]).join(", ") || "",
        p.forme_juridique || "",
        p.siret || "",
        p.ville || "",
        p.telephone || ""
      ].map(f => `"${f}"`).join(";"))
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = `partenaires_export_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateReferences = async () => {
    setGeneratingRefs(true);
    toast.loading("Attribution des références en cours...", { id: "gen-refs" });
    try {
      const res = await base44.functions.invoke("assignReferences", { entityName: "Partenaire", prefix: "PAR" });
      if (res.data.success) {
        toast.success(res.data.message, { id: "gen-refs" });
        queryClient.invalidateQueries({ queryKey: ['partenaires'] });
      } else {
        throw new Error(res.data.error);
      }
    } catch (e) {
      console.error(e);
      toast.error("Erreur lors de la génération", { id: "gen-refs" });
    } finally {
      setGeneratingRefs(false);
    }
  };

  const handlePrint = async (partenaire) => {
    const toastId = toast.loading("Génération de la fiche...");
    try {
      const logoGestionbat = infoGestionbat && infoGestionbat.logo_url 
        ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" class="logo" />` 
        : '<div style="font-weight: bold; color: #f97316;">GESTIONBAT</div>';

      const htmlContent = getFichePartenaireHtml(partenaire, logoGestionbat);

      const response = await base44.functions.invoke('htmlToPdf', {
        html_content: htmlContent,
        css: ''
      });

      if (response.data && response.data.success && response.data.pdf_base64) {
        const byteCharacters = atob(response.data.pdf_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Fiche_Partenaire_${partenaire.nom.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success("Fiche téléchargée", { id: toastId });
      } else {
        throw new Error("Erreur conversion PDF");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erreur lors de la génération de la fiche", { id: toastId });
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      toast.info("Génération du modèle en cours...");
      const response = await base44.functions.invoke('generatePartenaireTemplate');
      
      if (response.data.success && response.data.file_base64) {
        const byteCharacters = atob(response.data.file_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { 
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
        });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Modele_Import_Partenaires.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast.success("Modèle téléchargé avec succès");
      } else {
        throw new Error("Erreur lors de la génération du fichier");
      }
    } catch (error) {
      console.error("Erreur:", error);
      toast.error("Erreur lors du téléchargement du modèle");
    }
  };

  const handleImportExcel = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImporting(true);
    const toastId = toast.loading("Import en cours...");

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const response = await base44.functions.invoke('importPartenaires', { file_url });
      
      if (response.data.success) {
        const { created, duplicates, errors } = response.data.results;
        
        if (duplicates && duplicates.length > 0) {
          setDuplicates(duplicates);
          setShowDuplicateDialog(true);
          toast.success(`Import partiel : ${created} créés. ${duplicates.length} doublons à résoudre.`, {
            id: toastId,
            duration: 5000
          });
        } else {
          toast.success(`Import terminé : ${created} créés${errors > 0 ? `, ${errors} erreurs` : ''}`, {
            id: toastId
          });
        }
        queryClient.invalidateQueries({ queryKey: ['partenaires'] });
      } else {
        throw new Error(response.data.error || "Erreur lors de l'import");
      }
    } catch (error) {
      console.error("Erreur import:", error);
      toast.error("Erreur lors de l'import du fichier", { id: toastId });
    } finally {
      setImporting(false);
      e.target.value = ''; 
    }
  };

  const handleResolveDuplicates = async (toUpdate) => {
    setResolvingDuplicates(true);
    try {
      await Promise.all(toUpdate.map(item => 
        base44.entities.Partenaire.update(item.existing.id, item.new)
      ));

      toast.success(`${toUpdate.length} partenaire(s) mis à jour`);
      queryClient.invalidateQueries({ queryKey: ['partenaires'] });
      setShowDuplicateDialog(false);
      setDuplicates([]);
    } catch (error) {
      console.error("Erreur mise à jour doublons:", error);
      toast.error("Erreur lors de la mise à jour des doublons");
    } finally {
      setResolvingDuplicates(false);
    }
  };

  const filteredPartenaires = React.useMemo(() => {
    if (!searchQuery) return partenaires;
    
    const query = searchQuery.toLowerCase();
    return partenaires.filter(p => 
      p.nom?.toLowerCase().includes(query) ||
      p.mission?.toLowerCase().includes(query) ||
      p.siret?.toLowerCase().includes(query) ||
      p.ville?.toLowerCase().includes(query) ||
      p.telephone?.toLowerCase().includes(query)
    );
  }, [partenaires, searchQuery]);

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Partenaires</h1>
            <p className="text-gray-600">
              {filteredPartenaires.length} partenaire{filteredPartenaires.length > 1 ? 's' : ''} trouvé{filteredPartenaires.length > 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleExportList}
              className="gap-2"
            >
              <FileDown className="w-4 h-4" />
              Exporter la liste
            </Button>
            <Button
              variant="ghost"
              onClick={handleGenerateReferences}
              disabled={generatingRefs}
              className="gap-2 text-xs text-gray-500"
              title="Attribuer des références manquantes"
            >
              <RefreshCw className={`w-3 h-3 ${generatingRefs ? 'animate-spin' : ''}`} />
              Générer Réf.
            </Button>
            <Button
              variant="outline"
              onClick={handleDownloadTemplate}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Modèle Excel
            </Button>
            <div className="relative">
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleImportExcel}
                disabled={importing}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
              />
              <Button 
                variant="outline"
                className="gap-2"
                disabled={importing}
              >
                <Upload className="w-4 h-4" />
                {importing ? "Import..." : "Importer Excel"}
              </Button>
            </div>
            <Button 
              className="bg-orange-600 hover:bg-orange-700 gap-2"
              onClick={() => {
                setSelectedPartenaire(null);
                setShowDialog(true);
              }}
            >
              <Plus className="w-5 h-5" />
              Nouveau partenaire
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <SearchBar 
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Rechercher par nom, mission, SIRET, ville, téléphone..."
          />
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        ) : filteredPartenaires.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm">
            <Building className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {searchQuery ? "Aucun partenaire trouvé" : "Aucun partenaire"}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchQuery 
                ? "Essayez de modifier vos critères de recherche" 
                : "Ajoutez votre premier partenaire pour commencer"}
            </p>
            {!searchQuery && (
              <div className="flex justify-center gap-2">
                <div className="relative">
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleImportExcel}
                    disabled={importing}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                  />
                  <Button 
                    variant="outline"
                    className="gap-2"
                    disabled={importing}
                  >
                    <Upload className="w-4 h-4" />
                    Importer Excel
                  </Button>
                </div>
                <Button 
                  className="bg-orange-600 hover:bg-orange-700 gap-2"
                  onClick={() => setShowDialog(true)}
                >
                  <Plus className="w-5 h-5" />
                  Nouveau partenaire
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPartenaires.map(partenaire => (
              <Card 
                key={partenaire.id}
                className="hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => handleEdit(partenaire)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="absolute top-3 right-3 flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 bg-white/80 hover:bg-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePrint(partenaire);
                        }}
                        title="Imprimer la fiche"
                      >
                        <Printer className="w-4 h-4 text-gray-600" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-3 flex-1 pr-8">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center overflow-hidden flex-shrink-0">
                        {partenaire.logo_url ? (
                          <img 
                            src={partenaire.logo_url} 
                            alt={partenaire.nom}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Building className="w-6 h-6 text-white" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-xl font-bold text-gray-900 truncate flex items-center gap-2 flex-wrap">
                          {partenaire.nom}
                          {partenaire.reference && (
                            <Badge variant="secondary" className="text-xs">
                              {partenaire.reference}
                            </Badge>
                          )}
                          {partenaire.forme_juridique && (
                            <span className="text-xs font-normal text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                              {partenaire.forme_juridique}
                            </span>
                          )}
                        </CardTitle>
                        {(partenaire.missions?.length > 0 || partenaire.mission) && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {(partenaire.missions && partenaire.missions.length > 0 ? partenaire.missions : [partenaire.mission]).filter(Boolean).map((m, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                <Briefcase className="w-3 h-3 mr-1" />
                                {m}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {partenaire.adresse_1 && (
                      <div className="flex items-start gap-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        <div>
                          <p>{partenaire.adresse_1}</p>
                          {partenaire.adresse_2 && <p>{partenaire.adresse_2}</p>}
                          {(partenaire.code_postal || partenaire.ville) && (
                            <p>{partenaire.code_postal} {partenaire.ville}</p>
                          )}
                        </div>
                      </div>
                    )}

                    {partenaire.telephone && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Phone className="w-4 h-4" />
                        <span>{partenaire.telephone}</span>
                      </div>
                    )}

                    {partenaire.siret && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <FileText className="w-4 h-4" />
                        <span>SIRET: {partenaire.siret}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <PartenaireDialog 
          open={showDialog}
          onOpenChange={setShowDialog}
          partenaire={selectedPartenaire}
          onSubmit={handleSubmit}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />

        <DuplicateResolutionDialog
          open={showDuplicateDialog}
          onOpenChange={setShowDuplicateDialog}
          duplicates={duplicates}
          onConfirm={handleResolveDuplicates}
          isUpdating={resolvingDuplicates}
        />
      </div>
    </div>
  );
}