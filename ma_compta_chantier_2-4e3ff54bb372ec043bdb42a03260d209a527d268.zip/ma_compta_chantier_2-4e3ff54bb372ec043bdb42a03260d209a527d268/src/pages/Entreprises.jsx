/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Upload, Download, FileDown, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import EntrepriseDialog from "../components/entreprises/EntrepriseDialog";
import EntreprisesList from "../components/entreprises/EntreprisesList";
import SearchBar from "../components/common/SearchBar";
import DuplicateResolutionDialog from "../components/common/DuplicateResolutionDialog";
import { Skeleton } from "@/components/ui/skeleton";

export default function Entreprises() {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedEntreprise, setSelectedEntreprise] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [importing, setImporting] = useState(false);
  const [duplicates, setDuplicates] = useState([]);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [resolvingDuplicates, setResolvingDuplicates] = useState(false);
  const [generatingRefs, setGeneratingRefs] = useState(false);
  const queryClient = useQueryClient();

  const { data: entreprises, isLoading } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list('nom'),
    initialData: [],
  });

  const { data: marchesEntreprises } = useQuery({
    queryKey: ['marches-entreprises'],
    queryFn: () => base44.entities.MarcheEntreprise.list('nom'),
    initialData: [],
  });

  const { data: chantiers } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list('nom'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Entreprise.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['entreprises'] });
      setShowDialog(false);
      setSelectedEntreprise(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Entreprise.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['entreprises'] });
      setShowDialog(false);
      setSelectedEntreprise(null);
    },
  });

  const handleSubmit = (data) => {
    if (selectedEntreprise) {
      updateMutation.mutate({ id: selectedEntreprise.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExportList = () => {
    if (!entreprises || entreprises.length === 0) {
      toast.error("Aucune entreprise à exporter");
      return;
    }

    const headers = ["Référence", "Nom", "Forme Juridique", "SIRET", "Ville", "Téléphone", "Représentant"];
    const csvContent = [
      headers.join(";"),
      ...entreprises.map(e => [
        e.reference || "",
        e.nom || "",
        e.forme_juridique || "",
        e.siret || "",
        e.ville || "",
        e.telephone || "",
        `${e.representant_nom || ""} ${e.representant_prenom || ""}`.trim()
      ].map(f => `"${f}"`).join(";"))
    ].join("\n");

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = `entreprises_export_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateReferences = async () => {
    setGeneratingRefs(true);
    toast.loading("Attribution des références en cours...", { id: "gen-refs" });
    try {
      const res = await base44.functions.invoke("assignReferences", { entityName: "Entreprise", prefix: "ENT" });
      if (res.data.success) {
        toast.success(res.data.message, { id: "gen-refs" });
        queryClient.invalidateQueries({ queryKey: ['entreprises'] });
      } else {
        throw new Error(res.data.error);
      }
    } catch (e) {
      console.error(e);
      toast.error("Erreur lors de la génération", { id: "gen-refs" });
    } finally {
      setGeneratingRefs(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      toast.info("Génération du modèle en cours...");
      const response = await base44.functions.invoke('generateEntrepriseTemplate');
      
      if (response.data.success && response.data.file_base64) {
        const byteCharacters = atob(response.data.file_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { 
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
        });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Modele_Import_Entreprises.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast.success("Modèle téléchargé avec succès");
      } else {
        throw new Error("Erreur lors de la génération du fichier");
      }
    } catch (error) {
      console.error("Erreur:", error);
      toast.error("Erreur lors du téléchargement du modèle");
    }
  };

  const handleImportExcel = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImporting(true);
    const toastId = toast.loading("Import en cours...");

    try {
      // 1. Upload du fichier
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // 2. Appel de la fonction d'import
      const response = await base44.functions.invoke('importEntreprises', { file_url });
      
      if (response.data.success) {
        const { created, duplicates, errors } = response.data.results;
        
        if (duplicates && duplicates.length > 0) {
          setDuplicates(duplicates);
          setShowDuplicateDialog(true);
          toast.success(`Import partiel : ${created} créés. ${duplicates.length} doublons à résoudre.`, {
            id: toastId,
            duration: 5000
          });
        } else {
          toast.success(`Import terminé : ${created} créés${errors > 0 ? `, ${errors} erreurs` : ''}`, {
            id: toastId
          });
        }
        queryClient.invalidateQueries({ queryKey: ['entreprises'] });
      } else {
        throw new Error(response.data.error || "Erreur lors de l'import");
      }
    } catch (error) {
      console.error("Erreur import:", error);
      toast.error("Erreur lors de l'import du fichier", { id: toastId });
    } finally {
      setImporting(false);
      e.target.value = ''; // Reset input
    }
  };

  const handleResolveDuplicates = async (toUpdate) => {
    setResolvingDuplicates(true);
    try {
      await Promise.all(toUpdate.map(item => 
        base44.entities.Entreprise.update(item.existing.id, item.new)
      ));

      toast.success(`${toUpdate.length} entreprise(s) mise(s) à jour`);
      queryClient.invalidateQueries({ queryKey: ['entreprises'] });
      setShowDuplicateDialog(false);
      setDuplicates([]);
    } catch (error) {
      console.error("Erreur mise à jour doublons:", error);
      toast.error("Erreur lors de la mise à jour des doublons");
    } finally {
      setResolvingDuplicates(false);
    }
  };

  // Filtrage avec recherche
  const filteredEntreprises = useMemo(() => {
    if (!searchQuery) return entreprises;

    const query = searchQuery.toLowerCase();
    return entreprises.filter(e =>
      e.nom?.toLowerCase().includes(query) ||
      e.siret?.toLowerCase().includes(query) ||
      e.ville?.toLowerCase().includes(query) ||
      e.adresse_1?.toLowerCase().includes(query) ||
      e.representant_nom?.toLowerCase().includes(query) ||
      e.representant_prenom?.toLowerCase().includes(query)
    );
  }, [entreprises, searchQuery]);

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Entreprises</h1>
            <p className="text-gray-600">
              {filteredEntreprises.length} entreprise{filteredEntreprises.length > 1 ? 's' : ''} trouvée{filteredEntreprises.length > 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleExportList}
              className="gap-2"
            >
              <FileDown className="w-4 h-4" />
              Exporter la liste
            </Button>
            <Button
              variant="ghost"
              onClick={handleGenerateReferences}
              disabled={generatingRefs}
              className="gap-2 text-xs text-gray-500"
              title="Attribuer des références manquantes"
            >
              <RefreshCw className={`w-3 h-3 ${generatingRefs ? 'animate-spin' : ''}`} />
              Générer Réf.
            </Button>
            <Button
              variant="outline"
              onClick={handleDownloadTemplate}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Modèle Excel
            </Button>
            <div className="relative">
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleImportExcel}
                disabled={importing}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
              />
              <Button 
                variant="outline"
                className="gap-2"
                disabled={importing}
              >
                <Upload className="w-4 h-4" />
                {importing ? "Import..." : "Importer Excel"}
              </Button>
            </div>
            <Button 
              className="bg-orange-600 hover:bg-orange-700 gap-2"
              onClick={() => {
                setSelectedEntreprise(null);
                setShowDialog(true);
              }}
            >
              <Plus className="w-5 h-5" />
              Nouvelle entreprise
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <SearchBar 
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Rechercher par nom, SIRET, ville, représentant..."
          />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
        ) : filteredEntreprises.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Aucune entreprise trouvée
            </h3>
            <p className="text-gray-500 mb-4">
              {searchQuery 
                ? "Essayez de modifier votre recherche"
                : "Ajoutez votre première entreprise pour commencer"}
            </p>
            {!searchQuery && (
              <div className="flex justify-center gap-2">
                <div className="relative">
                  <input
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleImportExcel}
                    disabled={importing}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                  />
                  <Button 
                    variant="outline"
                    className="gap-2"
                    disabled={importing}
                  >
                    <Upload className="w-4 h-4" />
                    Importer Excel
                  </Button>
                </div>
                <Button 
                  className="bg-orange-600 hover:bg-orange-700 gap-2"
                  onClick={() => setShowDialog(true)}
                >
                  <Plus className="w-5 h-5" />
                  Créer une entreprise
                </Button>
              </div>
            )}
          </div>
        ) : (
          <EntreprisesList 
            entreprises={filteredEntreprises}
            marchesEntreprises={marchesEntreprises}
            chantiers={chantiers}
            onEdit={(entreprise) => {
              setSelectedEntreprise(entreprise);
              setShowDialog(true);
            }}
          />
        )}

        <EntrepriseDialog 
          open={showDialog}
          onOpenChange={setShowDialog}
          entreprise={selectedEntreprise}
          onSubmit={handleSubmit}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />

        <DuplicateResolutionDialog
          open={showDuplicateDialog}
          onOpenChange={setShowDuplicateDialog}
          duplicates={duplicates}
          onConfirm={handleResolveDuplicates}
          isUpdating={resolvingDuplicates}
        />
      </div>
    </div>
  );
}