import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, CheckCircle2, RefreshCw, Wrench } from "lucide-react";
import { toast } from "sonner";

const ENTITY_TYPES = [
  { key: "MarcheEntreprise", label: "Marchés entreprises", descField: "intitule_lot" },
  { key: "CertificatPaiement", label: "Certificats de paiement", descField: "numero" },
  { key: "TravauxSupplementaire", label: "Travaux supplémentaires", descField: "intitule_devis" },
  { key: "Avenant", label: "Avenants", descField: "intitule" },
  { key: "SousTraitance", label: "Sous-traitance", descField: "travaux_effectues" },
  { key: "CieOperation", label: "C.I.E Opérations", descField: "description" },
];

export default function ReconciliationChantier() {
  const [chantiers, setChantiers] = useState([]);
  const [orphans, setOrphans] = useState({}); // { entityKey: [records] }
  const [loading, setLoading] = useState(true);
  const [corrections, setCorrections] = useState({}); // { recordId: chantierId }
  const [saving, setSaving] = useState(false);
  const [savedCount, setSavedCount] = useState(0);

  const chantierIds = useMemo(() => new Set(chantiers.map(c => c.id)), [chantiers]);

  const loadData = async () => {
    setLoading(true);
    setSavedCount(0);
    setCorrections({});
    try {
      const allChantiers = await base44.entities.Chantier.list();
      setChantiers(allChantiers);
      const ids = new Set(allChantiers.map(c => c.id));

      const results = {};
      await Promise.all(
        ENTITY_TYPES.map(async ({ key }) => {
          const records = await base44.entities[key].list();
          results[key] = records.filter(r => !r.chantier_id || !ids.has(r.chantier_id));
        })
      );
      setOrphans(results);
    } catch (err) {
      toast.error("Erreur lors du chargement : " + err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const totalOrphans = Object.values(orphans).reduce((s, arr) => s + arr.length, 0);

  const handleSetCorrection = (recordId, chantierId) => {
    setCorrections(prev => ({ ...prev, [recordId]: chantierId }));
  };

  // Auto-match: if chantier_id looks like a code_chantier (e.g. "CHT-0001")
  const handleAutoMatch = () => {
    const newCorrections = { ...corrections };
    let matched = 0;
    Object.values(orphans).forEach(records => {
      records.forEach(record => {
        if (corrections[record.id]) return;
        // Try to match chantier_id as a code_chantier
        const byCode = chantiers.find(c => c.code_chantier === record.chantier_id);
        // Or try to match by nom
        if (byCode) {
          newCorrections[record.id] = byCode.id;
          matched++;
        }
      });
    });
    setCorrections(newCorrections);
    toast.success(`${matched} correspondance(s) automatique(s) trouvée(s)`);
  };

  const handleSaveAll = async () => {
    const entries = Object.entries(corrections);
    if (entries.length === 0) {
      toast.error("Aucune correction à enregistrer");
      return;
    }
    setSaving(true);
    try {
      let count = 0;
      for (const { key } of ENTITY_TYPES) {
        const records = orphans[key] || [];
        await Promise.all(
          records
            .filter(r => corrections[r.id])
            .map(r => base44.entities[key].update(r.id, { chantier_id: corrections[r.id] }))
        );
        count += records.filter(r => corrections[r.id]).length;
      }
      setSavedCount(count);
      toast.success(`${count} enregistrement(s) corrigé(s)`);
      await loadData();
    } catch (err) {
      toast.error("Erreur lors de la sauvegarde : " + err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center gap-3 text-gray-500">
        <RefreshCw className="w-5 h-5 animate-spin" />
        Chargement des données…
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Wrench className="w-6 h-6 text-orange-600" />
            Réconciliation des chantiers
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Relier les entités orphelines au bon chantier via le code chantier
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={loadData} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Recharger
          </Button>
          <Button variant="outline" onClick={handleAutoMatch} className="gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            Auto-correspondance
          </Button>
          <Button
            onClick={handleSaveAll}
            disabled={saving || Object.keys(corrections).length === 0}
            className="bg-orange-600 hover:bg-orange-700 gap-2"
          >
            {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
            Enregistrer les corrections ({Object.keys(corrections).length})
          </Button>
        </div>
      </div>

      {totalOrphans === 0 ? (
        <Card className="p-12 text-center">
          <CheckCircle2 className="w-12 h-12 mx-auto text-green-500 mb-3" />
          <h3 className="text-lg font-semibold text-gray-700">Tout est cohérent !</h3>
          <p className="text-gray-500 text-sm mt-1">Aucune entité orpheline détectée.</p>
        </Card>
      ) : (
        <>
          <Card className="bg-orange-50 border-orange-200">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 shrink-0" />
              <span className="text-sm text-orange-900">
                <strong>{totalOrphans} entité(s) orpheline(s)</strong> détectée(s) avec un <code>chantier_id</code> manquant ou invalide.
                {savedCount > 0 && <span className="ml-2 text-green-700 font-semibold">✓ {savedCount} corrigée(s) lors de la dernière sauvegarde.</span>}
              </span>
            </CardContent>
          </Card>

          <Tabs defaultValue={ENTITY_TYPES.find(e => (orphans[e.key] || []).length > 0)?.key || ENTITY_TYPES[0].key}>
            <TabsList className="flex flex-wrap h-auto gap-1">
              {ENTITY_TYPES.map(({ key, label }) => {
                const count = (orphans[key] || []).length;
                return (
                  <TabsTrigger key={key} value={key} className="gap-2">
                    {label}
                    {count > 0 && (
                      <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">{count}</Badge>
                    )}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {ENTITY_TYPES.map(({ key, label, descField }) => {
              const records = orphans[key] || [];
              return (
                <TabsContent key={key} value={key} className="mt-4">
                  {records.length === 0 ? (
                    <Card className="p-8 text-center">
                      <CheckCircle2 className="w-8 h-8 mx-auto text-green-500 mb-2" />
                      <p className="text-gray-500 text-sm">Aucun enregistrement orphelin dans {label}.</p>
                    </Card>
                  ) : (
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base">{label} — {records.length} orphelin(s)</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-gray-50">
                              <TableHead>ID</TableHead>
                              <TableHead>Description</TableHead>
                              <TableHead>chantier_id actuel</TableHead>
                              <TableHead>Assigner au chantier</TableHead>
                              <TableHead>Statut</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {records.map(record => {
                              const corrected = corrections[record.id];
                              const chantierChoisi = corrected ? chantiers.find(c => c.id === corrected) : null;
                              return (
                                <TableRow key={record.id} className={corrected ? "bg-green-50" : ""}>
                                  <TableCell className="font-mono text-xs text-gray-500 max-w-[100px] truncate">
                                    {record.id}
                                  </TableCell>
                                  <TableCell className="max-w-[180px] truncate text-sm">
                                    {record[descField] || "—"}
                                  </TableCell>
                                  <TableCell className="font-mono text-xs text-red-600">
                                    {record.chantier_id || <span className="text-gray-400 italic">vide</span>}
                                  </TableCell>
                                  <TableCell>
                                    <Select
                                      value={corrected || ""}
                                      onValueChange={(v) => handleSetCorrection(record.id, v)}
                                    >
                                      <SelectTrigger className="w-64">
                                        <SelectValue placeholder="Sélectionner le chantier…" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {chantiers.map(c => (
                                          <SelectItem key={c.id} value={c.id}>
                                            {c.code_chantier ? `[${c.code_chantier}] ` : ""}{c.nom}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </TableCell>
                                  <TableCell>
                                    {corrected ? (
                                      <Badge className="bg-green-100 text-green-700 border-green-200">
                                        ✓ {chantierChoisi?.code_chantier || "Assigné"}
                                      </Badge>
                                    ) : (
                                      <Badge className="bg-red-100 text-red-700 border-red-200">
                                        Non assigné
                                      </Badge>
                                    )}
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              );
            })}
          </Tabs>
        </>
      )}
    </div>
  );
}