import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Lock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import PlanningChantiers from "../components/chantiers/PlanningChantiers";
import { usePermissions } from "../components/common/usePermissions";

export default function PlanningChantiersPage() {
  const navigate = useNavigate();
  const { hasPermission } = usePermissions();

  const canViewChantiers = hasPermission('chantiers_view');

  const { data: chantiers, isLoading } = useQuery({
    queryKey: ['chantiers'],
    queryFn: () => base44.entities.Chantier.list('-created_date'),
    initialData: [],
    enabled: canViewChantiers,
  });

  const handleChantierClick = (chantierId) => {
    const url = new URL(window.location.origin + createPageUrl("ChantierDetails"));
    url.searchParams.set('chantierId', chantierId);
    navigate(url.pathname + url.search);
  };

  if (!canViewChantiers) {
    return (
      <div className="p-4 md:p-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 text-center">
            <Lock className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Accès restreint
            </h3>
            <p className="text-gray-500">
              Vous n'avez pas la permission de consulter le planning. Contactez un administrateur.
            </p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Planning des chantiers</h1>
          <p className="text-gray-600">Gérez et visualisez le planning de vos chantiers</p>
        </div>

        {isLoading ? (
          <Card className="p-12 text-center">
            <p className="text-gray-500">Chargement...</p>
          </Card>
        ) : (
          <PlanningChantiers 
            chantiers={chantiers} 
            onChantierClick={handleChantierClick}
          />
        )}
      </div>
    </div>
  );
}