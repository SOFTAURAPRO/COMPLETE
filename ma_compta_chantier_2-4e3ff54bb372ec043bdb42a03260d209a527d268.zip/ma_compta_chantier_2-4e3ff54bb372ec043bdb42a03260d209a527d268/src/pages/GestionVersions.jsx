import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Trash2, Tag, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function GestionVersions() {
  const [showForm, setShowForm] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [versionToDelete, setVersionToDelete] = useState(null);
  const [formData, setFormData] = useState({ numero: "", titre: "", notes: "", est_publiee: false });

  const queryClient = useQueryClient();

  const { data: versions = [], isLoading } = useQuery({
    queryKey: ["versions"],
    queryFn: () => base44.entities.Version.list("-created_date"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Version.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["versions"] });
      setShowForm(false);
      setFormData({ numero: "", titre: "", notes: "", est_publiee: false });
      toast.success("Version créée");
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Version.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["versions"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Version.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["versions"] });
      toast.success("Version supprimée");
    },
  });

  const handlePublishToggle = (version) => {
    const newState = !version.est_publiee;
    updateMutation.mutate({ id: version.id, data: { ...version, est_publiee: newState } });
    toast.success(newState ? "Version publiée — les utilisateurs seront notifiés" : "Version dépubliée");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des versions</h1>
          <p className="text-gray-500 text-sm mt-1">
            Publiez des notes de version pour informer les utilisateurs en temps réel
          </p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-orange-600 hover:bg-orange-700 gap-2">
          <Plus className="w-4 h-4" />
          Nouvelle version
        </Button>
      </div>

      {isLoading && <p className="text-gray-400 text-sm">Chargement...</p>}

      {!isLoading && versions.length === 0 && (
        <Card className="p-12 text-center">
          <Tag className="w-12 h-12 mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500">Aucune version créée</p>
          <p className="text-gray-400 text-sm mt-1">Créez votre première version pour notifier les utilisateurs</p>
        </Card>
      )}

      {versions.map((version) => (
        <Card
          key={version.id}
          className={version.est_publiee ? "border-orange-200 bg-orange-50/30" : ""}
        >
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3 flex-wrap">
                <Tag className="w-4 h-4 text-orange-600 shrink-0" />
                <CardTitle className="text-base">
                  v{version.numero} — {version.titre}
                </CardTitle>
                {version.est_publiee ? (
                  <Badge className="bg-green-100 text-green-800 border-green-200 border">
                    Publiée
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-gray-500">
                    Brouillon
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs text-gray-400">
                  {format(new Date(version.created_date), "dd/MM/yyyy", { locale: fr })}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePublishToggle(version)}
                  className={`gap-1 text-xs ${
                    version.est_publiee
                      ? "text-gray-600"
                      : "text-orange-600 border-orange-200 hover:bg-orange-50"
                  }`}
                  disabled={updateMutation.isPending}
                >
                  {version.est_publiee ? (
                    <><EyeOff className="w-3 h-3" /> Dépublier</>
                  ) : (
                    <><Eye className="w-3 h-3" /> Publier</>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => { setVersionToDelete(version); setShowDeleteDialog(true); }}
                  className="text-red-400 hover:text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          {version.notes && (
            <CardContent className="pt-0">
              <p className="text-sm text-gray-600 whitespace-pre-line">{version.notes}</p>
            </CardContent>
          )}
        </Card>
      ))}

      {/* Formulaire création */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nouvelle version</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Numéro de version *</Label>
                <Input
                  placeholder="ex: 2.9.0"
                  value={formData.numero}
                  onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Titre *</Label>
                <Input
                  placeholder="ex: Amélioration des certificats"
                  value={formData.titre}
                  onChange={(e) => setFormData({ ...formData, titre: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Notes de version</Label>
              <Textarea
                placeholder="Décrivez les nouveautés, corrections...&#10;• Nouvelle fonctionnalité X&#10;• Correction du bug Y"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="h-32"
              />
            </div>
            <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg border border-orange-100">
              <Switch
                checked={formData.est_publiee}
                onCheckedChange={(val) => setFormData({ ...formData, est_publiee: val })}
              />
              <div>
                <Label className="text-sm font-medium">Publier immédiatement</Label>
                <p className="text-xs text-gray-500">Notifie tous les utilisateurs connectés en temps réel</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" type="button" onClick={() => setShowForm(false)}>
                Annuler
              </Button>
              <Button
                type="submit"
                className="bg-orange-600 hover:bg-orange-700"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Création..." : "Créer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirmation suppression */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cette version ?</AlertDialogTitle>
            <AlertDialogDescription>Cette action est irréversible.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setVersionToDelete(null)}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (versionToDelete) {
                  deleteMutation.mutate(versionToDelete.id);
                  setShowDeleteDialog(false);
                  setVersionToDelete(null);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}