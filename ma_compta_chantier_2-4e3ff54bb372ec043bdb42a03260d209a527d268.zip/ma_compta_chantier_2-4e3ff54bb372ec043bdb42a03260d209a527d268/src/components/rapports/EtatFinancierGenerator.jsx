import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Download, FileText } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { generatePdfHtml } from "@/components/templates/PdfExportGenerator";

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 10 }, (_, i) => CURRENT_YEAR - 5 + i);

export default function EtatFinancierGenerator({ chantierId }) {
  const [selectedSections, setSelectedSections] = useState({
    marches: true,
    certificats: true,
    sousTraitants: true,
    devis: true,
    cie: true
  });

  const [dateReference, setDateReference] = useState(new Date().toISOString().split('T')[0]);
  const [generating, setGenerating] = useState(false);

  const { data: chantier } = useQuery({
    queryKey: ['chantier', chantierId],
    queryFn: async () => {
      const chantiers = await base44.entities.Chantier.list();
      return chantiers.find(c => c.id === chantierId);
    },
    enabled: !!chantierId,
  });

  const { data: marches } = useQuery({
    queryKey: ['marches', chantierId],
    queryFn: async () => {
      const all = await base44.entities.MarcheEntreprise.list();
      return all.filter(m => m.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: avenants } = useQuery({
    queryKey: ['avenants', chantierId],
    queryFn: async () => {
      const all = await base44.entities.Avenant.list();
      return all.filter(a => a.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: certificats } = useQuery({
    queryKey: ['certificats', chantierId],
    queryFn: async () => {
      const all = await base44.entities.CertificatPaiement.list('-date_situation');
      return all.filter(c => c.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: devis } = useQuery({
    queryKey: ['travaux-sup', chantierId],
    queryFn: async () => {
      const all = await base44.entities.TravauxSupplementaire.list('-date_devis');
      return all.filter(d => d.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: cieOperations } = useQuery({
    queryKey: ['cie-operations', chantierId],
    queryFn: async () => {
      const ops = await base44.entities.CieOperation.filter({ chantier_id: chantierId }, 'date_operation', 100);
      return ops.filter(op => op.statut !== 'brouillon');
    },
    initialData: [],
  });

  const { data: entreprises } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: [],
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: [],
  });

  const toggleSection = (section) => {
    setSelectedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleGenerate = async () => {
    if (!Object.values(selectedSections).some(v => v)) {
      toast.error("Sélectionnez au moins une section");
      return;
    }

    setGenerating(true);

    try {
      const dateRef = new Date(dateReference);
      const moisRef = (dateRef.getMonth() + 1).toString().padStart(2, '0');
      const anneeRef = dateRef.getFullYear().toString();

      let tableContentHtml = '';

      // 1. SECTION MARCHÉS ACTUALISÉS
      if (selectedSections.marches) {
        const marchesData = marches.map(marche => {
          const entreprise = entreprises.find(e => e.id === marche.entreprise_id);
          const avenantsMarche = avenants.filter(a => 
            a.entreprise_id === marche.entreprise_id && 
            (a.statut === 'signe' || a.statut === 'en_signature') &&
            new Date(a.date) <= dateRef
          );
          const montantAvenants = avenantsMarche.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
          const montantActualise = (marche.montant || 0) + montantAvenants;

          return {
            lot: marche.numero_lot || 'N/A',
            entreprise: entreprise?.nom || 'N/A',
            montantInitial: marche.montant || 0,
            montantAvenants,
            montantActualise
          };
        });

        const totalMarcheInitial = marchesData.reduce((sum, m) => sum + m.montantInitial, 0);
        const totalAvenants = marchesData.reduce((sum, m) => sum + m.montantAvenants, 0);
        const totalActualise = marchesData.reduce((sum, m) => sum + m.montantActualise, 0);

        tableContentHtml += `
          <div style="page-break-before: auto; margin-bottom: 30px;">
            <h2 style="font-size: 14pt; font-weight: bold; color: #f97316; margin-bottom: 15px; border-bottom: 2px solid #f97316; padding-bottom: 5px;">
              1. MARCHÉS ACTUALISÉS AU ${format(dateRef, "dd/MM/yyyy", { locale: fr })}
            </h2>
            <table>
              <thead>
                <tr>
                  <th style="width: 10%; text-align: left;">Lot</th>
                  <th style="width: 40%; text-align: left;">Entreprise</th>
                  <th style="width: 18%; text-align: right;">Marché Initial</th>
                  <th style="width: 18%; text-align: right;">Avenants</th>
                  <th style="width: 14%; text-align: right;">Montant Actualisé</th>
                </tr>
              </thead>
              <tbody>
                ${marchesData.map(m => `
                  <tr>
                    <td style="font-weight: bold;">${m.lot}</td>
                    <td>${m.entreprise}</td>
                    <td style="text-align: right;">${m.montantInitial.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                    <td style="text-align: right;">${m.montantAvenants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                    <td style="text-align: right; font-weight: bold; color: #f97316;">${m.montantActualise.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                  </tr>
                `).join('')}
                <tr class="total-row">
                  <td colspan="2"><strong>TOTAL GÉNÉRAL</strong></td>
                  <td style="text-align: right;"><strong>${totalMarcheInitial.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                  <td style="text-align: right;"><strong>${totalAvenants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                  <td style="text-align: right;"><strong>${totalActualise.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        `;
      }

      // 2. SECTION CERTIFICATS DE PAIEMENT
      if (selectedSections.certificats) {
        const certsValides = certificats.filter(c => c.statut === 'valide' && new Date(c.date_situation || c.date_facture) <= dateRef);
        
        // Créer une entrée pour chaque marché (toutes les entreprises)
        const certsRows = marches.map(marche => {
          const entreprise = entreprises.find(e => e.id === marche.entreprise_id);
          const certsEntreprise = certsValides.filter(c => c.entreprise_id === marche.entreprise_id);
          const certMoisCourant = certsEntreprise.filter(c => c.mois === moisRef && c.annee === anneeRef);
          const montantMois = certMoisCourant.reduce((sum, c) => sum + (c.montant_ht || 0), 0);
          const montantCumule = certsEntreprise.reduce((sum, c) => sum + (c.montant_ht || 0), 0);

          return {
            lot: marche.numero_lot || 'N/A',
            entreprise: entreprise?.nom || 'N/A',
            montantMois,
            montantCumule
          };
        });

        // Trier par numéro de lot
        certsRows.sort((a, b) => {
          const lotA = a.lot === 'N/A' ? '999' : a.lot;
          const lotB = b.lot === 'N/A' ? '999' : b.lot;
          return lotA.localeCompare(lotB, undefined, { numeric: true });
        });

        const totalCertsMois = certsRows.reduce((sum, r) => sum + r.montantMois, 0);
        const totalCertsCumule = certsRows.reduce((sum, r) => sum + r.montantCumule, 0);

        tableContentHtml += `
          <div style="page-break-before: auto; margin-bottom: 30px;">
            <h2 style="font-size: 14pt; font-weight: bold; color: #f97316; margin-bottom: 15px; border-bottom: 2px solid #f97316; padding-bottom: 5px;">
              2. CERTIFICATS DE PAIEMENT
            </h2>
            <table>
              <thead>
                <tr>
                  <th style="width: 10%; text-align: left;">Lot</th>
                  <th style="width: 50%; text-align: left;">Entreprise</th>
                  <th style="width: 20%; text-align: right;">${MOIS_LABELS[moisRef]} ${anneeRef}</th>
                  <th style="width: 20%; text-align: right;">Cumulé</th>
                </tr>
              </thead>
              <tbody>
                ${certsRows.map(r => `
                 <tr>
                   <td style="font-weight: bold;">${r.lot}</td>
                   <td>${r.entreprise}</td>
                   <td style="text-align: right;">${r.montantMois > 0 ? r.montantMois.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : ''}</td>
                   <td style="text-align: right; font-weight: bold;">${r.montantCumule > 0 ? r.montantCumule.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : ''}</td>
                 </tr>
                `).join('')}
                <tr class="total-row">
                  <td colspan="2"><strong>TOTAL</strong></td>
                  <td style="text-align: right;"><strong>${totalCertsMois.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                  <td style="text-align: right;"><strong>${totalCertsCumule.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        `;
      }

      // 3. SECTION PAIEMENTS SOUS-TRAITANTS
      if (selectedSections.sousTraitants) {
        const paiementsST = [];
        certificats.filter(c => c.statut === 'valide' && new Date(c.date_situation || c.date_facture) <= dateRef).forEach(cert => {
          (cert.paiements_sous_traitants || []).forEach(pst => {
            paiementsST.push({
              entrepriseId: pst.entreprise_id,
              montant: pst.montant_ht,
              mois: cert.mois,
              annee: cert.annee
            });
          });
        });

        const stByEntreprise = {};
        paiementsST.forEach(pst => {
          if (!stByEntreprise[pst.entrepriseId]) {
            stByEntreprise[pst.entrepriseId] = { montantMois: 0, montantCumule: 0 };
          }
          if (pst.mois === moisRef && pst.annee === anneeRef) {
            stByEntreprise[pst.entrepriseId].montantMois += pst.montant;
          }
          stByEntreprise[pst.entrepriseId].montantCumule += pst.montant;
        });

        const stRows = Object.entries(stByEntreprise).map(([entrepriseId, data]) => {
          const entreprise = entreprises.find(e => e.id === entrepriseId);
          return {
            entreprise: entreprise?.nom || 'N/A',
            montantMois: data.montantMois,
            montantCumule: data.montantCumule
          };
        });

        const totalSTMois = stRows.reduce((sum, r) => sum + r.montantMois, 0);
        const totalSTCumule = stRows.reduce((sum, r) => sum + r.montantCumule, 0);

        tableContentHtml += `
          <div style="page-break-before: auto; margin-bottom: 30px;">
            <h2 style="font-size: 14pt; font-weight: bold; color: #f97316; margin-bottom: 15px; border-bottom: 2px solid #f97316; padding-bottom: 5px;">
              3. PAIEMENTS SOUS-TRAITANTS
            </h2>
            ${stRows.length === 0 ? '<p style="color: #999; font-style: italic;">Aucun paiement sous-traitant</p>' : `
            <table>
              <thead>
                <tr>
                  <th style="width: 60%; text-align: left;">Entreprise</th>
                  <th style="width: 20%; text-align: right;">${MOIS_LABELS[moisRef]} ${anneeRef}</th>
                  <th style="width: 20%; text-align: right;">Cumulé</th>
                </tr>
              </thead>
              <tbody>
                ${stRows.map(r => `
                  <tr>
                    <td>${r.entreprise}</td>
                    <td style="text-align: right;">${r.montantMois.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                    <td style="text-align: right; font-weight: bold;">${r.montantCumule.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                  </tr>
                `).join('')}
                <tr class="total-row">
                  <td><strong>TOTAL</strong></td>
                  <td style="text-align: right;"><strong>${totalSTMois.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                  <td style="text-align: right;"><strong>${totalSTCumule.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
              </tbody>
            </table>
            `}
          </div>
        `;
      }

      // 4. SECTION DEVIS SUPPLÉMENTAIRES
      if (selectedSections.devis) {
        const devisParStatut = {
          brouillon: [],
          valide: [],
          integre_avenant: []
        };

        devis.filter(d => new Date(d.date_devis) <= dateRef).forEach(d => {
          devisParStatut[d.statut]?.push(d);
        });

        const groupByLot = (devisList) => {
          const grouped = {};
          devisList.forEach(d => {
            const marche = marches.find(m => m.id === d.marche_id);
            const lot = marche?.numero_lot || 'N/A';
            if (!grouped[lot]) grouped[lot] = [];
            grouped[lot].push(d);
          });
          return grouped;
        };

        const buildDevisTable = (title, devisList, color) => {
          if (devisList.length === 0) return '';
          
          const byLot = groupByLot(devisList);
          let html = `
            <h3 style="font-size: 11pt; font-weight: bold; color: ${color}; margin: 15px 0 10px 0;">
              ${title} (${devisList.length})
            </h3>
            <table>
              <thead>
                <tr>
                  <th style="width: 8%; text-align: left;">Lot</th>
                  <th style="width: 30%; text-align: left;">Entreprise</th>
                  <th style="width: 37%; text-align: left;">Intitulé</th>
                  <th style="width: 10%; text-align: center;">Type</th>
                  <th style="width: 15%; text-align: right;">Montant HT</th>
                </tr>
              </thead>
              <tbody>
          `;

          Object.entries(byLot).forEach(([lot, lotDevis]) => {
            lotDevis.forEach((d, idx) => {
              const entreprise = entreprises.find(e => e.id === d.entreprise_id);
              html += `
                <tr>
                  ${idx === 0 ? `<td style="font-weight: bold;" rowspan="${lotDevis.length}">${lot}</td>` : ''}
                  <td>${entreprise?.nom || 'N/A'}</td>
                  <td style="font-size: 8pt;">${d.intitule_devis}</td>
                  <td style="text-align: center;"><span style="background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 8pt;">${d.type_devis}</span></td>
                  <td style="text-align: right; font-weight: bold; color: ${color};">${d.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                </tr>
              `;
            });
          });

          const total = devisList.reduce((sum, d) => sum + (d.montant_ht || 0), 0);
          html += `
                <tr class="total-row">
                  <td colspan="4"><strong>TOTAL ${title.toUpperCase()}</strong></td>
                  <td style="text-align: right;"><strong>${total.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
              </tbody>
            </table>
          `;
          return html;
        };

        tableContentHtml += `
          <div style="page-break-before: auto; margin-bottom: 30px;">
            <h2 style="font-size: 14pt; font-weight: bold; color: #f97316; margin-bottom: 15px; border-bottom: 2px solid #f97316; padding-bottom: 5px;">
              4. DEVIS SUPPLÉMENTAIRES
            </h2>
            ${buildDevisTable('Devis intégrés à avenant', devisParStatut.integre_avenant, '#10b981')}
            ${buildDevisTable('Devis validés en attente', devisParStatut.valide, '#3b82f6')}
            ${buildDevisTable('Devis en attente de validation', devisParStatut.brouillon, '#f59e0b')}
          </div>
        `;
      }

      // 5. SECTION CIE
      if (selectedSections.cie) {
        const cieRows = cieOperations.filter(op => new Date(op.date_operation) <= dateRef).map(op => {
          const entrepriseFacturante = entreprises.find(e => e.id === op.entreprise_facturante_id);
          const repartitionsStr = (op.repartitions || []).map(r => {
            const ent = entreprises.find(e => e.id === r.entreprise_responsable_id);
            return `${ent?.nom || 'N/A'} (${r.pourcentage}%)`;
          }).join(', ');

          const isMoisCourant = new Date(op.date_operation).getMonth() === dateRef.getMonth() && 
                                new Date(op.date_operation).getFullYear() === dateRef.getFullYear();

          return {
            date: format(new Date(op.date_operation), "dd/MM/yyyy", { locale: fr }),
            description: op.description,
            facturante: entrepriseFacturante?.nom || 'N/A',
            responsables: repartitionsStr,
            montant: op.montant_total_ht,
            isMoisCourant
          };
        });

        const totalCieMois = cieRows.filter(r => r.isMoisCourant).reduce((sum, r) => sum + r.montant, 0);
        const totalCieCumule = cieRows.reduce((sum, r) => sum + r.montant, 0);

        tableContentHtml += `
          <div style="page-break-before: auto; margin-bottom: 30px;">
            <h2 style="font-size: 14pt; font-weight: bold; color: #f97316; margin-bottom: 15px; border-bottom: 2px solid #f97316; padding-bottom: 5px;">
              5. COMPTES INTER-ENTREPRISES (C.I.E)
            </h2>
            ${cieRows.length === 0 ? '<p style="color: #999; font-style: italic;">Aucune opération CIE</p>' : `
            <table>
              <thead>
                <tr>
                  <th style="width: 10%; text-align: left;">Date</th>
                  <th style="width: 30%; text-align: left;">Description</th>
                  <th style="width: 20%; text-align: left;">Facturant</th>
                  <th style="width: 25%; text-align: left;">Responsables</th>
                  <th style="width: 15%; text-align: right;">Montant HT</th>
                </tr>
              </thead>
              <tbody>
                ${cieRows.map(r => `
                  <tr>
                    <td>${r.date}</td>
                    <td style="font-size: 9pt;">${r.description}</td>
                    <td>${r.facturante}</td>
                    <td style="font-size: 8pt;">${r.responsables}</td>
                    <td style="text-align: right; font-weight: bold;">${r.montant.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
                  </tr>
                `).join('')}
                <tr class="total-row">
                  <td colspan="4"><strong>TOTAL ${MOIS_LABELS[moisRef]} ${anneeRef}</strong></td>
                  <td style="text-align: right;"><strong>${totalCieMois.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
                <tr class="total-row">
                  <td colspan="4"><strong>TOTAL CUMULÉ</strong></td>
                  <td style="text-align: right;"><strong>${totalCieCumule.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
                </tr>
              </tbody>
            </table>
            `}
          </div>
        `;
      }

      const client = clients.find(c => c.id === chantier?.client_id);
      const htmlContent = generatePdfHtml({
        title: "ÉTAT FINANCIER GÉNÉRAL",
        subtitle: `Situation au ${format(dateRef, "dd MMMM yyyy", { locale: fr })}`,
        chantier,
        client,
        infoGestionbat,
        partenaires,
        tableContentHtml,
        orientation: "portrait"
      });

      toast.loading("Conversion en PDF...", {
        description: "Génération du rapport en cours",
        id: "etat-financier",
      });

      const response = await base44.functions.invoke('htmlToPdf', {
        html_content: htmlContent,
        css: ''
      });

      if (response.data?.success && response.data.pdf_base64) {
        const byteCharacters = atob(response.data.pdf_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        const nomChantier = (chantier?.nom || 'chantier').replace(/[^a-z0-9]/gi, '_');
        link.download = `Etat_Financier_${nomChantier}_${format(dateRef, "yyyy-MM")}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        toast.success("Rapport généré", {
          description: "L'état financier a été téléchargé",
          id: "etat-financier",
        });
      } else {
        throw new Error("La conversion PDF a échoué");
      }
    } catch (error) {
      console.error("Erreur génération:", error);
      toast.error("Erreur", {
        description: error.message || "Erreur lors de la génération",
        id: "etat-financier",
      });
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-orange-600" />
          État Financier Général
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label>Date de référence</Label>
          <Input
            type="date"
            value={dateReference}
            onChange={(e) => setDateReference(e.target.value)}
          />
          <p className="text-xs text-gray-500">
            Le rapport inclura toutes les données jusqu'à cette date
          </p>
        </div>

        <div className="space-y-3">
          <Label className="text-base font-semibold">Sections à inclure</Label>
          <div className="space-y-3 border rounded-lg p-4 bg-gray-50">
            <div className="flex items-center gap-3">
              <Checkbox
                id="section-marches"
                checked={selectedSections.marches}
                onCheckedChange={() => toggleSection('marches')}
              />
              <Label htmlFor="section-marches" className="cursor-pointer font-normal">
                1. Marchés actualisés (montants initiaux + avenants)
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="section-certificats"
                checked={selectedSections.certificats}
                onCheckedChange={() => toggleSection('certificats')}
              />
              <Label htmlFor="section-certificats" className="cursor-pointer font-normal">
                2. Certificats de paiement (par mois et cumulés)
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="section-st"
                checked={selectedSections.sousTraitants}
                onCheckedChange={() => toggleSection('sousTraitants')}
              />
              <Label htmlFor="section-st" className="cursor-pointer font-normal">
                3. Paiements sous-traitants (par mois et cumulés)
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="section-devis"
                checked={selectedSections.devis}
                onCheckedChange={() => toggleSection('devis')}
              />
              <Label htmlFor="section-devis" className="cursor-pointer font-normal">
                4. Devis supplémentaires (par statut et par lot)
              </Label>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="section-cie"
                checked={selectedSections.cie}
                onCheckedChange={() => toggleSection('cie')}
              />
              <Label htmlFor="section-cie" className="cursor-pointer font-normal">
                5. Comptes Inter-Entreprises (mois et cumulé)
              </Label>
            </div>
          </div>
        </div>

        <Button
          className="w-full bg-orange-600 hover:bg-orange-700 gap-2"
          onClick={handleGenerate}
          disabled={generating || !chantierId}
        >
          <Download className="w-4 h-4" />
          {generating ? "Génération en cours..." : "Générer l'état financier"}
        </Button>
      </CardContent>
    </Card>
  );
}