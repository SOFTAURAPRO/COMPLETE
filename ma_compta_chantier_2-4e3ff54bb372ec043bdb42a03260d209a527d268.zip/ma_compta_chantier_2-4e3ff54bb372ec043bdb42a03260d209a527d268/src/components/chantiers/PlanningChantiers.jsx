import React, { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function PlanningChantiers({ chantiers, onChantierClick }) {
  const queryClient = useQueryClient();
  const [startWeekOffset, setStartWeekOffset] = useState(0);
  const weeksToShow = 26; // 6 mois

  const { data: membresEquipe } = useQuery({
    queryKey: ['membres-equipe'],
    queryFn: () => base44.entities.MembreEquipe.list('nom'),
    initialData: [],
  });

  // Calcul de la semaine de début et fin
  const getWeekData = useMemo(() => {
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Lundi
    startOfWeek.setDate(startOfWeek.getDate() + (startWeekOffset * 7));
    
    const weeks = [];
    for (let i = 0; i < weeksToShow; i++) {
      const weekStart = new Date(startOfWeek);
      weekStart.setDate(startOfWeek.getDate() + (i * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      
      weeks.push({
        start: weekStart,
        end: weekEnd,
        label: `S${getWeekNumber(weekStart)}`
      });
    }
    return weeks;
  }, [startWeekOffset]);

  function getWeekNumber(date) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  }

  function calculateChantierDuration(chantier) {
    if (!chantier.date_debut || !chantier.date_fin_prevue) {
      return { weeks: 0, months: 0 };
    }
    
    const start = new Date(chantier.date_debut);
    const end = new Date(chantier.date_fin_prevue);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.ceil(diffDays / 7);
    const months = Math.round((diffDays / 30.44) * 10) / 10;
    
    return { weeks, months };
  }

  function isWeekActive(chantier, week) {
    const dateDebut = chantier.date_debut ? new Date(chantier.date_debut) : null;
    const dateFin = chantier.date_fin_prevue ? new Date(chantier.date_fin_prevue) : null;
    
    // Vérifier si des semaines ont été personnalisées
    const customWeeks = chantier.planning_custom_weeks || [];
    const weekKey = `${week.start.getFullYear()}-W${getWeekNumber(week.start)}`;
    
    // Si personnalisé, retourner la valeur personnalisée
    if (customWeeks.includes(weekKey)) {
      return true;
    }
    if (customWeeks.includes(`-${weekKey}`)) {
      return false;
    }
    
    // Sinon, vérifier selon les dates
    if (!dateDebut || !dateFin) return false;
    
    return week.start <= dateFin && week.end >= dateDebut;
  }

  const updateWeekMutation = useMutation({
    mutationFn: async ({ chantierId, weekKey, isActive }) => {
      const chantier = chantiers.find(c => c.id === chantierId);
      const customWeeks = chantier.planning_custom_weeks || [];
      
      let newCustomWeeks;
      if (isActive) {
        // Ajouter la semaine
        newCustomWeeks = [...customWeeks.filter(w => w !== `-${weekKey}`), weekKey];
      } else {
        // Retirer la semaine
        newCustomWeeks = [...customWeeks.filter(w => w !== weekKey), `-${weekKey}`];
      }
      
      return base44.entities.Chantier.update(chantierId, {
        planning_custom_weeks: newCustomWeeks
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chantiers'] });
    },
    onError: () => {
      toast.error("Erreur lors de la mise à jour");
    }
  });

  const handleCellClick = (chantier, week) => {
    const isActive = isWeekActive(chantier, week);
    const weekKey = `${week.start.getFullYear()}-W${getWeekNumber(week.start)}`;
    updateWeekMutation.mutate({ 
      chantierId: chantier.id, 
      weekKey, 
      isActive: !isActive 
    });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900">Planning des chantiers</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setStartWeekOffset(startWeekOffset - 4)}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setStartWeekOffset(0)}
          >
            Aujourd'hui
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setStartWeekOffset(startWeekOffset + 4)}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-max">
          {/* En-tête des années */}
          <div className="flex mb-1">
            <div className="w-64 flex-shrink-0"></div>
            <div className="w-12 flex-shrink-0"></div>
            {(() => {
              let lastYear = null;
              let yearSpan = 0;
              const yearHeaders = [];
              
              getWeekData.forEach((week, idx) => {
                const currentYear = week.start.getFullYear();
                if (currentYear !== lastYear) {
                  if (lastYear !== null) {
                    yearHeaders.push({ year: lastYear, span: yearSpan });
                  }
                  lastYear = currentYear;
                  yearSpan = 1;
                } else {
                  yearSpan++;
                }
                
                if (idx === getWeekData.length - 1) {
                  yearHeaders.push({ year: lastYear, span: yearSpan });
                }
              });
              
              return yearHeaders.map((header, idx) => (
                <div 
                  key={idx} 
                  className="text-center border-b border-gray-300 pb-1"
                  style={{ width: `${header.span * 48}px` }}
                >
                  <span className="text-sm font-bold text-gray-700">{header.year}</span>
                </div>
              ));
            })()}
          </div>

          {/* En-tête des semaines */}
          <div className="flex mb-2">
            <div className="w-64 flex-shrink-0"></div>
            <div className="w-12 flex-shrink-0"></div>
            {getWeekData.map((week, idx) => (
              <div key={idx} className="w-12 flex-shrink-0 text-center">
                <div className="text-xs font-medium text-gray-600">{week.label}</div>
                <div className="text-xs text-gray-400">
                  {week.start.getDate()}/{week.start.getMonth() + 1}
                </div>
              </div>
            ))}
          </div>

          {/* Lignes des chantiers */}
          {chantiers.length === 0 ? (
            <div className="text-center text-gray-500 py-8">Aucun chantier</div>
          ) : (
            chantiers.map(chantier => {
              const duration = calculateChantierDuration(chantier);
              // Trouver le conducteur de travaux
              const conducteurId = (chantier.membres_equipe_ids || []).find(membreId => {
                const membre = membresEquipe.find(m => m.id === membreId);
                return membre?.fonctions?.some(f => f.type === "Conducteur de travaux");
              });
              const conducteur = membresEquipe.find(m => m.id === conducteurId);
              const nomConducteur = conducteur ? `${conducteur.prenom} ${conducteur.nom}` : '';
              
              return (
                <div key={chantier.id} className="flex mb-1 items-center group">
                  <div 
                    className="w-64 flex-shrink-0 pr-2 cursor-pointer hover:text-orange-600"
                    onClick={() => onChantierClick?.(chantier.id)}
                  >
                    {nomConducteur && (
                      <p className="text-xs text-orange-600 font-medium mb-0.5">{nomConducteur}</p>
                    )}
                    <p className="font-semibold text-sm text-gray-900 truncate">
                      {chantier.nom}
                    </p>
                    <p className="text-xs text-gray-500">
                      {chantier.date_debut ? new Date(chantier.date_debut).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) : '-'} 
                      {' → '}
                      {chantier.date_fin_prevue ? new Date(chantier.date_fin_prevue).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) : '-'}
                    </p>
                  </div>
                  <div className="w-12 flex-shrink-0 text-center">
                    {duration.weeks > 0 && (
                      <>
                        <p className="text-xs font-medium text-gray-700">{duration.weeks}s</p>
                        <p className="text-xs text-gray-500">{duration.months}m</p>
                      </>
                    )}
                  </div>
                  {getWeekData.map((week, idx) => {
                    const isActive = isWeekActive(chantier, week);
                    return (
                      <div
                        key={idx}
                        className={`w-12 h-10 flex-shrink-0 border cursor-pointer transition-colors ${
                          isActive 
                            ? 'bg-orange-500 hover:bg-orange-600 border-orange-600' 
                            : 'bg-gray-100 hover:bg-gray-200 border-gray-200'
                        }`}
                        onClick={() => handleCellClick(chantier, week)}
                      />
                    );
                  })}
                </div>
              );
            })
          )}
        </div>
      </div>
    </Card>
  );
}