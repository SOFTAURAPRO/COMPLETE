import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, Layers } from "lucide-react";

export default function TranchesSection({ tranches = [], onChange }) {
  const nbTranches = tranches.length;

  const handleNbChange = (n) => {
    const nb = Math.max(0, Math.min(10, parseInt(n) || 0));
    if (nb === nbTranches) return;
    if (nb > nbTranches) {
      const nouvelles = [];
      for (let i = nbTranches + 1; i <= nb; i++) {
        nouvelles.push({ numero: i, libelle: `Tranche ${i}`, date_debut: "", date_fin: "" });
      }
      onChange([...tranches, ...nouvelles]);
    } else {
      onChange(tranches.slice(0, nb));
    }
  };

  const handleChange = (idx, field, value) => {
    const updated = tranches.map((t, i) => i === idx ? { ...t, [field]: value } : t);
    onChange(updated);
  };

  const handleAdd = () => {
    const num = nbTranches + 1;
    onChange([...tranches, { numero: num, libelle: `Tranche ${num}`, date_debut: "", date_fin: "" }]);
  };

  const handleRemove = (idx) => {
    const updated = tranches.filter((_, i) => i !== idx).map((t, i) => ({ ...t, numero: i + 1 }));
    onChange(updated);
  };

  return (
    <div className="space-y-4 border-t pt-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-blue-600" />
          <Label className="text-base font-semibold">Tranches de travaux</Label>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-sm text-gray-600">Nombre de tranches :</Label>
          <Input
            type="number"
            min="0"
            max="10"
            value={nbTranches}
            onChange={(e) => handleNbChange(e.target.value)}
            className="w-20 h-8 text-center"
          />
          <Button type="button" variant="outline" size="sm" onClick={handleAdd} className="gap-1">
            <Plus className="w-3 h-3" />
            Ajouter
          </Button>
        </div>
      </div>

      {tranches.length === 0 && (
        <p className="text-sm text-gray-400 italic">Aucune tranche définie – le marché sera traité sans découpage par tranche.</p>
      )}

      {tranches.length > 0 && (
        <div className="space-y-3">
          {tranches.map((tranche, idx) => (
            <Card key={idx} className="p-4 border-blue-100 bg-blue-50/30">
              <div className="flex gap-3 items-end">
                <div className="w-8 flex items-center justify-center">
                  <span className="text-sm font-bold text-blue-700 bg-blue-100 rounded-full w-7 h-7 flex items-center justify-center">
                    {tranche.numero}
                  </span>
                </div>
                <div className="flex-1 space-y-1">
                  <Label className="text-xs">Libellé</Label>
                  <Input
                    value={tranche.libelle}
                    onChange={(e) => handleChange(idx, 'libelle', e.target.value)}
                    placeholder={`Tranche ${tranche.numero}`}
                    className="h-8"
                  />
                </div>
                <div className="w-36 space-y-1">
                  <Label className="text-xs">Date début</Label>
                  <Input
                    type="date"
                    value={tranche.date_debut || ""}
                    onChange={(e) => handleChange(idx, 'date_debut', e.target.value)}
                    className="h-8"
                  />
                </div>
                <div className="w-36 space-y-1">
                  <Label className="text-xs">Date fin</Label>
                  <Input
                    type="date"
                    value={tranche.date_fin || ""}
                    onChange={(e) => handleChange(idx, 'date_fin', e.target.value)}
                    className="h-8"
                  />
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemove(idx)}
                  className="text-red-500 h-8 w-8"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}