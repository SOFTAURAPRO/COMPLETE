import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Layers } from "lucide-react";

export default function TranchesMontantSection({ tranches = [], tranchesMontants = [], montantTotal = 0, onChange }) {
  if (tranches.length === 0) return null;

  const getVal = (num) => {
    const found = tranchesMontants.find(t => t.tranche_numero === num);
    return found ? found.montant_ht : "";
  };

  const handleChange = (tranche, value) => {
    const existing = tranchesMontants.filter(t => t.tranche_numero !== tranche.numero);
    onChange([...existing, {
      tranche_numero: tranche.numero,
      tranche_libelle: tranche.libelle,
      montant_ht: parseFloat(value) || 0
    }]);
  };

  const totalSaisi = tranchesMontants.reduce((s, t) => s + (t.montant_ht || 0), 0);
  const ecart = montantTotal - totalSaisi;

  return (
    <div className="space-y-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
      <div className="flex items-center gap-2">
        <Layers className="w-4 h-4 text-blue-600" />
        <Label className="text-sm font-semibold text-blue-900">Répartition par tranche (HT)</Label>
      </div>

      <div className="space-y-2">
        {tranches.map((tranche) => (
          <div key={tranche.numero} className="flex items-center gap-3">
            <span className="w-28 text-xs font-medium text-blue-700 truncate" title={tranche.libelle}>
              {tranche.libelle}
            </span>
            <Input
              type="number"
              step="0.01"
              value={getVal(tranche.numero)}
              onChange={(e) => handleChange(tranche, e.target.value)}
              placeholder="0,00"
              className="h-8 flex-1"
            />
            <span className="text-xs text-gray-500 w-4">€</span>
          </div>
        ))}
      </div>

      <div className="flex justify-between text-xs pt-2 border-t border-blue-200">
        <span className="text-gray-600">Total saisi :</span>
        <span className={`font-semibold ${Math.abs(ecart) < 0.01 ? 'text-green-700' : 'text-orange-600'}`}>
          {totalSaisi.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
          {Math.abs(ecart) >= 0.01 && (
            <span className="ml-2 text-orange-500">
              (écart : {ecart > 0 ? '+' : ''}{ecart.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €)
            </span>
          )}
        </span>
      </div>
    </div>
  );
}