import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContactsTab from "../common/ContactsTab";

const CORPS_ETAT_DISPONIBLES = [
  "Agencement",
  "Ascenseur",
  "Bureau d’études (tous corps d’état)",
  "Charpente",
  "Charpente bois",
  "Charpente métallique",
  "Cloisonnement",
  "Couverture zinc",
  "Démolition / désamiantage",
  "Électricité cfo / cfa",
  "Espaces verts",
  "Étanchéité",
  "Fondations spéciales",
  "Gros œuvre",
  "Isolation flocage",
  "Menuiserie extérieures bois",
  "Menuiseries extérieures pvc",
  "Menuiseries intérieures",
  "Metallerie",
  "Nettoyage",
  "Peinture",
  "Plomberie VMC CVC",
  "Ravalement",
  "Rénovation multi corps d’état",
  "Réseaux humides (eau, assainissement)",
  "Revêtements de sol durs",
  "Revêtements de sol souples",
  "Serrurerie",
  "Terrassement / vrd"
];

export default function EntrepriseDialog({ open, onOpenChange, entreprise, onSubmit, isLoading }) {
  const [formData, setFormData] = useState({
    nom: "",
    forme_juridique: "",
    adresse_1: "",
    adresse_2: "",
    code_postal: "",
    ville: "",
    reference: "",
    telephone: "",
    siret: "",
    representant_civilite: "Monsieur",
    representant_nom: "",
    representant_prenom: "",
    representant_qualite: "",
    corps_etat: [],
    contact_ao: {
      civilite: "Monsieur",
      nom: "",
      prenom: "",
      email: "",
      telephone: "",
      portable: ""
    },
    contact_comptabilite: {
      civilite: "Monsieur",
      nom: "",
      prenom: "",
      email: "",
      telephone: ""
    },
    contacts: []
    });

  const [newCorpsEtat, setNewCorpsEtat] = useState("");

  useEffect(() => {
    if (entreprise) {
      setFormData({
        nom: entreprise.nom || "",
        forme_juridique: entreprise.forme_juridique || "",
        adresse_1: entreprise.adresse_1 || "",
        adresse_2: entreprise.adresse_2 || "",
        code_postal: entreprise.code_postal || "",
        ville: entreprise.ville || "",
        telephone: entreprise.telephone || "",
        siret: entreprise.siret || "",
        representant_civilite: entreprise.representant_civilite || "Monsieur",
        representant_nom: entreprise.representant_nom || "",
        representant_prenom: entreprise.representant_prenom || "",
        representant_qualite: entreprise.representant_qualite || "",
        corps_etat: entreprise.corps_etat || [],
        contact_ao: entreprise.contact_ao || {
          civilite: "Monsieur",
          nom: "",
          prenom: "",
          email: "",
          telephone: "",
          portable: ""
        },
        contact_comptabilite: entreprise.contact_comptabilite || {
          civilite: "Monsieur",
          nom: "",
          prenom: "",
          email: "",
          telephone: ""
        },
        contacts: entreprise.contacts || []
        });
    } else {
      setFormData({
        reference: "",
        nom: "",
        forme_juridique: "",
        adresse_1: "",
        adresse_2: "",
        code_postal: "",
        ville: "",
        telephone: "",
        siret: "",
        representant_civilite: "Monsieur",
        representant_nom: "",
        representant_prenom: "",
        representant_qualite: "",
        corps_etat: [],
        contact_ao: {
          civilite: "Monsieur",
          nom: "",
          prenom: "",
          email: "",
          telephone: "",
          portable: ""
        },
        contact_comptabilite: {
          civilite: "Monsieur",
          nom: "",
          prenom: "",
          email: "",
          telephone: ""
        },
        contacts: []
        });

      // Fetch next reference if opening for creation
      if (open) {
        base44.functions.invoke("getNextReference", { entityName: "Entreprise", prefix: "ENT" })
          .then(res => {
            if (res.data && res.data.nextReference) {
              setFormData(prev => ({ ...prev, reference: res.data.nextReference }));
            }
          });
      }
    }
  }, [entreprise, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleAddCorpsEtat = () => {
    if (newCorpsEtat && !formData.corps_etat.includes(newCorpsEtat)) {
      setFormData({
        ...formData,
        corps_etat: [...formData.corps_etat, newCorpsEtat]
      });
      setNewCorpsEtat("");
    }
  };

  const handleRemoveCorpsEtat = (corps) => {
    setFormData({
      ...formData,
      corps_etat: formData.corps_etat.filter(c => c !== corps)
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {entreprise ? "Modifier l'entreprise" : "Nouvelle entreprise"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">Général</TabsTrigger>
              <TabsTrigger value="corps-etat">Corps d'état</TabsTrigger>
              <TabsTrigger value="contacts">Interlocuteurs</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4 py-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reference">Référence</Label>
                  <Input
                    id="reference"
                    value={formData.reference}
                    readOnly
                    className="bg-gray-100 text-gray-500"
                    placeholder="Génération auto..."
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="nom">Nom de l'entreprise *</Label>
                  <Input
                    id="nom"
                    value={formData.nom}
                    onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                    placeholder="Ex: BTP Construction"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="forme_juridique">Forme Juridique</Label>
                  <Select
                    value={formData.forme_juridique}
                    onValueChange={(value) => setFormData({ ...formData, forme_juridique: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Forme" />
                    </SelectTrigger>
                    <SelectContent>
                      {["SA", "SAS", "SARL", "EURL", "SASU", "SCOP", "EI", "SARL UNIPERSONNELLE"].map(forme => (
                        <SelectItem key={forme} value={forme}>{forme}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_1">Adresse ligne 1</Label>
                <Input
                  id="adresse_1"
                  value={formData.adresse_1}
                  onChange={(e) => setFormData({ ...formData, adresse_1: e.target.value })}
                  placeholder="Numéro et nom de rue"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_2">Adresse ligne 2</Label>
                <Input
                  id="adresse_2"
                  value={formData.adresse_2}
                  onChange={(e) => setFormData({ ...formData, adresse_2: e.target.value })}
                  placeholder="Complément d'adresse"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="code_postal">Code postal</Label>
                  <Input
                    id="code_postal"
                    value={formData.code_postal}
                    onChange={(e) => setFormData({ ...formData, code_postal: e.target.value })}
                    placeholder="75000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ville">Ville</Label>
                  <Input
                    id="ville"
                    value={formData.ville}
                    onChange={(e) => setFormData({ ...formData, ville: e.target.value })}
                    placeholder="Paris"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telephone">Téléphone</Label>
                  <Input
                    id="telephone"
                    value={formData.telephone}
                    onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                    placeholder="01 23 45 67 89"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="siret">SIRET</Label>
                  <Input
                    id="siret"
                    value={formData.siret}
                    onChange={(e) => setFormData({ ...formData, siret: e.target.value })}
                    placeholder="123 456 789 00012"
                  />
                </div>
              </div>

              {/* Section Représentant */}
              <div className="space-y-4 border-t pt-4">
                <h3 className="font-semibold text-gray-900">Représentée par</h3>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="representant_civilite">Civilité</Label>
                    <Select
                      value={formData.representant_civilite}
                      onValueChange={(value) => setFormData({ ...formData, representant_civilite: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Mademoiselle">Mademoiselle</SelectItem>
                        <SelectItem value="Madame">Madame</SelectItem>
                        <SelectItem value="Monsieur">Monsieur</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="representant_nom">Nom</Label>
                    <Input
                      id="representant_nom"
                      value={formData.representant_nom}
                      onChange={(e) => setFormData({ ...formData, representant_nom: e.target.value })}
                      placeholder="Nom"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="representant_prenom">Prénom</Label>
                    <Input
                      id="representant_prenom"
                      value={formData.representant_prenom}
                      onChange={(e) => setFormData({ ...formData, representant_prenom: e.target.value })}
                      placeholder="Prénom"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="representant_qualite">Qualité</Label>
                  <Input
                    id="representant_qualite"
                    value={formData.representant_qualite}
                    onChange={(e) => setFormData({ ...formData, representant_qualite: e.target.value })}
                    placeholder="Ex: Gérant, Directeur, Président"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="corps-etat" className="space-y-4 py-4">
              <div className="space-y-3">
                <Label>Corps d'état de l'entreprise</Label>
                <div className="flex gap-2">
                  <Select
                    value={newCorpsEtat}
                    onValueChange={setNewCorpsEtat}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Sélectionner un corps d'état" />
                    </SelectTrigger>
                    <SelectContent>
                      {CORPS_ETAT_DISPONIBLES.map(corps => (
                        <SelectItem key={corps} value={corps}>{corps}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    onClick={handleAddCorpsEtat}
                    disabled={!newCorpsEtat}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Ajouter
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2 mt-3">
                  {formData.corps_etat.map((corps, index) => (
                    <Badge key={index} variant="outline" className="gap-2 px-3 py-1">
                      {corps}
                      <X
                        className="w-3 h-3 cursor-pointer"
                        onClick={() => handleRemoveCorpsEtat(corps)}
                      />
                    </Badge>
                  ))}
                </div>

                {formData.corps_etat.length === 0 && (
                  <p className="text-sm text-gray-500 italic">Aucun corps d'état ajouté</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="contacts">
              <ContactsTab 
                contacts={formData.contacts} 
                onChange={(newContacts) => setFormData({ ...formData, contacts: newContacts })} 
              />
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Annuler
            </Button>
            <Button 
              type="submit" 
              className="bg-orange-600 hover:bg-orange-700"
              disabled={isLoading}
            >
              {isLoading ? "Enregistrement..." : entreprise ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}