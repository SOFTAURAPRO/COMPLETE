import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Building, MapPin, Phone, User, Printer, HardHat } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getFicheEntrepriseHtml } from "@/components/templates/FicheEntrepriseTemplate";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export default function EntreprisesList({ entreprises, marchesEntreprises = [], chantiers = [], onEdit }) {
  // Pour chaque entreprise, trouver les chantiers où elle a un marché
  const chantiersByEntreprise = useMemo(() => {
    const map = {};
    marchesEntreprises.forEach(m => {
      if (!m.entreprise_id) return;
      if (!map[m.entreprise_id]) map[m.entreprise_id] = new Set();
      if (m.chantier_id) map[m.entreprise_id].add(m.chantier_id);
    });
    return map;
  }, [marchesEntreprises]);

  const chantiersById = useMemo(() => {
    const map = {};
    chantiers.forEach(c => { map[c.id] = c; });
    return map;
  }, [chantiers]);
  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const handlePrint = async (entreprise) => {
    const toastId = toast.loading("Génération de la fiche...");
    try {
      const logoGestionbat = infoGestionbat && infoGestionbat.logo_url 
        ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" class="logo" />` 
        : '<div style="font-weight: bold; color: #f97316;">GESTIONBAT</div>';

      const htmlContent = getFicheEntrepriseHtml(entreprise, logoGestionbat);

      const response = await base44.functions.invoke('htmlToPdf', {
        html_content: htmlContent,
        css: ''
      });

      if (response.data && response.data.success && response.data.pdf_base64) {
        const byteCharacters = atob(response.data.pdf_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Fiche_Entreprise_${entreprise.nom.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success("Fiche téléchargée", { id: toastId });
      } else {
        throw new Error("Erreur conversion PDF");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erreur lors de la génération de la fiche", { id: toastId });
    }
  };
  if (entreprises.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Building className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucune entreprise enregistrée
        </h3>
        <p className="text-gray-500">
          Ajoutez votre première entreprise pour commencer
        </p>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {entreprises.map((entreprise) => (
        <Card key={entreprise.id} className="p-6 hover:shadow-lg transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Building className="w-6 h-6 text-orange-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-gray-900 mb-1 truncate">
                  {entreprise.nom}
                </h3>
                <div className="flex gap-2 flex-wrap">
                  {entreprise.reference && (
                    <Badge variant="secondary" className="text-xs">
                      {entreprise.reference}
                    </Badge>
                  )}
                  {entreprise.siret && (
                    <Badge variant="outline" className="text-xs">
                      SIRET: {entreprise.siret}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-1 flex-shrink-0">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handlePrint(entreprise)}
                title="Imprimer la fiche"
              >
                <Printer className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onEdit(entreprise)}
                title="Modifier"
              >
                <Pencil className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2 text-sm text-gray-600">
            {(entreprise.adresse_1 || entreprise.ville) && (
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <div>
                  {entreprise.adresse_1 && <div>{entreprise.adresse_1}</div>}
                  {entreprise.adresse_2 && <div>{entreprise.adresse_2}</div>}
                  {(entreprise.code_postal || entreprise.ville) && (
                    <div>
                      {entreprise.code_postal} {entreprise.ville}
                    </div>
                  )}
                </div>
              </div>
            )}

            {entreprise.telephone && (
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>{entreprise.telephone}</span>
              </div>
            )}

            {(entreprise.representant_nom || entreprise.representant_prenom) && (
              <div className="flex items-start gap-2 pt-2 border-t mt-2">
                <User className="w-4 h-4 mt-0.5 flex-shrink-0 text-orange-600" />
                <div>
                  <p className="text-xs text-gray-500 mb-1">Représentée par:</p>
                  <p className="font-medium text-gray-900">
                    {entreprise.representant_civilite} {entreprise.representant_prenom} {entreprise.representant_nom}
                  </p>
                  {entreprise.representant_qualite && (
                    <p className="text-xs text-gray-500 italic">{entreprise.representant_qualite}</p>
                  )}
                </div>
              </div>
            )}

            {/* Chantiers associés */}
            {(() => {
              const ids = chantiersByEntreprise[entreprise.id];
              if (!ids || ids.size === 0) return null;
              const chantiersListe = [...ids].map(id => chantiersById[id]).filter(Boolean);
              if (chantiersListe.length === 0) return null;
              return (
                <div className="flex items-start gap-2 pt-2 border-t mt-2">
                  <HardHat className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Chantier{chantiersListe.length > 1 ? 's' : ''} :</p>
                    <div className="flex flex-wrap gap-1">
                      {chantiersListe.map(c => (
                        <Badge key={c.id} className="text-xs bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100">
                          {c.nom}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </Card>
      ))}
    </div>
  );
}