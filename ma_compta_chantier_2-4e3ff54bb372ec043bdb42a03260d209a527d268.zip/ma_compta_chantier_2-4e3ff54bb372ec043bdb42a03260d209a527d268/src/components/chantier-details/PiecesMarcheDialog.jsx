import React, { useState, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FolderOpen, Upload, Trash2, ExternalLink, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function PiecesMarcheDialog({ open, onOpenChange, chantier }) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();

  // On stocke les pièces dans chantier.pieces_marche (tableau de { nom, url })
  const documents = chantier?.pieces_marche || [];

  const updateMutation = useMutation({
    mutationFn: (newDocs) =>
      base44.entities.Chantier.update(chantier.id, { pieces_marche: newDocs }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chantier", chantier.id] });
      queryClient.invalidateQueries({ queryKey: ["chantiers"] });
    },
  });

  const uploadFiles = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    const toastId = "upload-pieces-marche";
    toast.loading(`Upload de ${files.length} fichier(s)...`, { id: toastId });

    try {
      const uploaded = [];
      for (const file of Array.from(files)) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploaded.push({ nom: file.name, url: file_url });
      }
      const newDocs = [...documents, ...uploaded];
      await updateMutation.mutateAsync(newDocs);
      toast.success(`${uploaded.length} fichier(s) ajouté(s)`, { id: toastId });
    } catch (err) {
      toast.error("Erreur lors de l'upload", { id: toastId, description: err.message });
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = (e) => {
    uploadFiles(e.target.files);
    e.target.value = null;
  };

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault();
      setIsDragging(false);
      uploadFiles(e.dataTransfer.files);
    },
    [documents]
  );

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => setIsDragging(false);

  const handleDelete = async (index) => {
    const newDocs = documents.filter((_, i) => i !== index);
    await updateMutation.mutateAsync(newDocs);
    toast.success("Document supprimé");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-orange-600" />
            Pièces du marché
          </DialogTitle>
          <DialogDescription>
            Documents techniques du chantier : {chantier?.nom}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Zone drag & drop */}
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
            className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer transition-colors
              ${isDragging ? "border-orange-500 bg-orange-50" : "border-gray-300 bg-gray-50 hover:bg-gray-100"}
              ${uploading ? "opacity-50 pointer-events-none" : ""}`}
          >
            <Upload className={`w-8 h-8 mb-2 ${isDragging ? "text-orange-500" : "text-gray-400"}`} />
            <p className="text-sm text-gray-600 font-medium">
              {uploading ? "Upload en cours..." : "Glisser-déposer ou cliquer"}
            </p>
            <p className="text-xs text-gray-400 mt-1">PDF, images — plusieurs fichiers acceptés</p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.png,.jpg,.jpeg"
              className="hidden"
              onChange={handleFileChange}
              disabled={uploading}
            />
          </div>

          {/* Liste des documents */}
          {documents.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-2">Aucune pièce de marché pour ce chantier</p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {documents.map((doc, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between gap-2 p-2 bg-gray-50 rounded-lg border"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <CheckCircle className="w-4 h-4 text-green-500 shrink-0" />
                    <span className="text-sm text-gray-700 truncate">{doc.nom || "Document"}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <a
                      href={doc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1 rounded hover:bg-blue-100 text-blue-600"
                      title="Ouvrir"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => handleDelete(index)}
                      className="p-1 rounded hover:bg-red-100 text-red-500"
                      title="Supprimer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}