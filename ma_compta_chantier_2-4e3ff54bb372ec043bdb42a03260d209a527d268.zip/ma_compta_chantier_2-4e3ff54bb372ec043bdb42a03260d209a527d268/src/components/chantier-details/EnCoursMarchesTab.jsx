/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building, Download, Loader2, Calendar } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { generatePdfHtml } from "@/components/templates/PdfExportGenerator";
import { toast } from "sonner";
import { useInfoGestionbat } from "@/components/common/useInfoGestionbat";

export default function EnCoursMarchesTab({ chantierId }) {
  const { data: marches, isLoading } = useQuery({
    queryKey: ['marches', chantierId],
    queryFn: async () => {
      try {
        const allMarches = await base44.entities.MarcheEntreprise.filter({ chantier_id: chantierId }, 'numero_lot', 100);
        if (!Array.isArray(allMarches)) return [];
        return [...allMarches].sort((a, b) => {
          const valA = a?.numero_lot || "";
          const valB = b?.numero_lot || "";
          return valA.localeCompare(valB, undefined, { numeric: true });
        });
      } catch (error) {
        console.error("Erreur lors du chargement des marchés:", error);
        return [];
      }
    },
    initialData: []
  });

  const { data: avenants } = useQuery({
    queryKey: ['avenants', chantierId],
    queryFn: async () => {
      const allAvenants = await base44.entities.Avenant.list();
      return allAvenants.filter(a => a.chantier_id === chantierId);
    },
    initialData: []
  });

  const { data: certificats } = useQuery({
    queryKey: ['certificats', chantierId],
    queryFn: async () => {
      const allCertificats = await base44.entities.CertificatPaiement.list();
      return allCertificats.filter(c => c.chantier_id === chantierId && c.statut === 'valide');
    },
    initialData: []
  });

  const { data: entreprises } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: []
  });

  const { data: chantier } = useQuery({
    queryKey: ['chantier', chantierId],
    queryFn: () => base44.entities.Chantier.get(chantierId),
    enabled: !!chantierId
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
    initialData: []
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: []
  });

  const { data: sousTraitances } = useQuery({
    queryKey: ['sous_traitances', chantierId],
    queryFn: async () => {
      const all = await base44.entities.SousTraitance.filter({ chantier_id: chantierId });
      return Array.isArray(all) ? all : [];
    },
    initialData: []
  });

  const { infoGestionbat } = useInfoGestionbat();
  const [generatingPDF, setGeneratingPDF] = useState(false);
  const [dateEtat, setDateEtat] = useState(format(new Date(), "yyyy-MM-dd"));

  const getEntrepriseName = (entrepriseId) => {
    const entreprise = entreprises.find(e => e.id === entrepriseId);
    return entreprise?.nom || "Entreprise inconnue";
  };

  // Récupère les certificats pour un lot (marche_id en priorité, fallback entreprise_id)
  const getCertsForLot = (marcheId, entrepriseId) => {
    return certificats.filter(c => 
      c.marche_id === marcheId || (!c.marche_id && c.entreprise_id === entrepriseId)
    );
  };

  const getMontantAvenants = (marcheId, entrepriseId) => {
    return avenants
      .filter(a => a.marche_id === marcheId || (!a.marche_id && a.entreprise_id === entrepriseId))
      .reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
  };

  // Montant avancement = somme des montant_ht des certificats validés pour ce lot
  const getMontantAvancement = (marcheId, entrepriseId) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => sum + (c.montant_ht || 0), 0);
  };

  // Acompte = somme des demandes_acompte - remboursements_acompte pour ce lot
  const getMontantAcompte = (marcheId, entrepriseId) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => sum + (c.demande_acompte || 0) - (c.remboursement_acompte || 0), 0);
  };

  // Révision = non stockée pour l'instant, retourne 0
  const getMontantRevision = () => 0;

  const getMontantPenalitesByCategorie = (marcheId, entrepriseId, categorie) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => {
        const pen = (c.penalites_appliquees || []).filter(p => (p.categorie || 'penalite') === categorie);
        const total = pen.reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0);
        return sum + total;
      }, 0);
  };

  const getMontantPenalites = (marcheId, entrepriseId) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => {
        const penalites = c.penalites_appliquees?.reduce((pSum, p) => pSum + (parseFloat(p.montant_calcule) || 0), 0) || 0;
        const remboursement = c.remboursement_penalites || 0;
        return sum + penalites - remboursement;
      }, 0);
  };

  // Légende : récupère les motifs uniques de pénalités / retenues pour tous les lots
  const getLegendePenalitesRetenues = () => {
    const penalitesMap = {};
    const retenuesMap = {};
    certificats.filter(c => c.chantier_id === chantierId).forEach(c => {
      (c.penalites_appliquees || []).forEach(p => {
        if (!p.type_penalite) return;
        const cat = p.categorie || 'penalite';
        if (cat === 'retenue') {
          if (!retenuesMap[p.type_penalite]) retenuesMap[p.type_penalite] = p;
        } else {
          if (!penalitesMap[p.type_penalite]) penalitesMap[p.type_penalite] = p;
        }
      });
    });
    return { penalites: Object.values(penalitesMap), retenues: Object.values(retenuesMap) };
  };

  const getMontantCautions = (marche) => {
    if (!marche.cautions || !Array.isArray(marche.cautions)) return 0;
    return marche.cautions.reduce((sum, c) => sum + (c.montant || 0), 0);
  };

  const getMontantRetenueGarantieTTC = (marcheId, entrepriseId) => {
    const marche = marches.find(m => m.id === marcheId);
    const aCaution = !!(marche?.a_caution && marche?.cautions?.length > 0);
    if (aCaution) return 0;
    const tva = marche?.taux_tva || 20;
    const totalCautions = (marche?.cautions || []).reduce((s, c) => s + (c.montant || 0), 0);
    const cumulTTC = getCertsForLot(marcheId, entrepriseId).reduce((sum, c) => {
      const montantAvecAcompte = (c.montant_ht || 0) + (c.demande_acompte || 0) - (c.remboursement_acompte || 0);
      return sum + montantAvecAcompte * (1 + tva / 100);
    }, 0);
    return Math.max(0, cumulTTC * 0.05 - totalCautions);
  };

  // CIE = montant_cie des certificats du lot
  const getMontantCIE = (marcheId, entrepriseId) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => sum + (c.montant_cie || 0), 0);
  };

  const getMontantProrata = () => 0;
  const getMontantRetenueBonneFin = () => 0;

  // Paiement sous-traitant HT pour ce lot
  const getMontantSousTraitant = (marcheId, entrepriseId) => {
    return getCertsForLot(marcheId, entrepriseId)
      .reduce((sum, c) => {
        const pst = c.paiements_sous_traitants?.reduce((s, p) => s + (p.montant_ht || 0), 0) || 0;
        return sum + pst;
      }, 0);
  };

  // Vérifie si l'entreprise principale a un contrat de sous-traitance soumis à TVA pour ce lot
  const hasSousTraitanceSoumiseTVA = (entrepriseId, marcheId) => {
    const marche = marches.find(m => m.id === marcheId);
    return sousTraitances.some(st => 
      st.entreprise_principale_id === entrepriseId && 
      st.soumis_a_tva !== false &&
      (!st.numero_lot || st.numero_lot === marche?.numero_lot)
    );
  };

  const fmt = (val) => val !== 0 ? val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-';
  const fmtAlways = (val) => val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';

  const handleExportCSV = () => {
    if (marches.length === 0) return;

    const headers = [
      "N° Lot", "Intitulé", "Entreprise",
      "Montant Base HT", "Montant Avenants HT", "Montant Total En cours HT",
      "Montant Avancement HT", "Acompte", "Révision",
      "Montant Caution TTC", "Montant Caution HT", "Retenue de Garantie",
      "Montant Pénalités", "Montant C.I.E", "Montant Prorata",
      "Retenue bonne fin de chantier", "Paiement sous-traitant",
      "Net à payer au DGD", "Net à payer fin GPA"
    ];

    const rows = marches.map(marche => {
      const baseHT = marche.montant || 0;
      const avenantsHT = getMontantAvenants(marche.id, marche.entreprise_id);
      const totalHT = baseHT + avenantsHT;
      const cautionTTC = getMontantCautions(marche);
      const diviseurTVA = (marche.taux_tva || 20) === 10 ? 1.10 : 1.20;
      const cautionHT = cautionTTC / diviseurTVA;
      const avancement = getMontantAvancement(marche.id, marche.entreprise_id);
      const acompte = getMontantAcompte(marche.id, marche.entreprise_id);
      const revision = getMontantRevision();
      const penalites = getMontantPenalites(marche.id, marche.entreprise_id);
      const rg = getMontantRetenueGarantieTTC(marche.id, marche.entreprise_id);
      const cie = getMontantCIE(marche.id, marche.entreprise_id);
      const prorata = getMontantProrata();
      const bonneFin = getMontantRetenueBonneFin();
      const sousTraitant = getMontantSousTraitant(marche.id, marche.entreprise_id);
      const entName = getEntrepriseName(marche.entreprise_id);

      return [
        marche.numero_lot || "",
        `"${(marche.intitule_lot || "").replace(/"/g, '""')}"`,
        `"${(entName || "").replace(/"/g, '""')}"`,
        baseHT.toFixed(2), avenantsHT.toFixed(2), totalHT.toFixed(2),
        avancement.toFixed(2), acompte.toFixed(2), revision.toFixed(2),
        cautionTTC.toFixed(2), cautionHT.toFixed(2), rg.toFixed(2),
        penalites.toFixed(2), cie.toFixed(2), prorata.toFixed(2),
        bonneFin.toFixed(2), sousTraitant.toFixed(2),
        "0.00", "0.00"
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `export_encours_marches_${chantierId}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = async () => {
    if (marches.length === 0) return;
    setGeneratingPDF(true);
    toast.loading("Génération du PDF...", { id: "encours-pdf" });

    try {
      const fmtPdf = (val) => val !== 0
        ? val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'
        : '-';
      const fmtPdfAlways = (val) =>
        val.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';

      const lignes = marches.map(marche => {
        const tva = marche.taux_tva || 20;
        const baseHT = marche.montant || 0;
        const avenantsHT = getMontantAvenants(marche.id, marche.entreprise_id);
        const totalHT = baseHT + avenantsHT;
        const cautionTTC = getMontantCautions(marche);
        const diviseurTVAPdf = tva === 10 ? 1.10 : 1.20;
        const cautionHT = cautionTTC / diviseurTVAPdf;
        const avancement = getMontantAvancement(marche.id, marche.entreprise_id);
        const acompte = getMontantAcompte(marche.id, marche.entreprise_id);
        const penalites = getMontantPenalites(marche.id, marche.entreprise_id);
        const rgTTCVal = getMontantRetenueGarantieTTC(marche.id, marche.entreprise_id);
        const rg = rgTTCVal / diviseurTVAPdf;
        const cie = getMontantCIE(marche.id, marche.entreprise_id) / diviseurTVAPdf;
        const sousTraitant = getMontantSousTraitant(marche.id, marche.entreprise_id);
        const entName = getEntrepriseName(marche.entreprise_id);
        const rowBg = marches.indexOf(marche) % 2 === 0 ? '' : 'style="background-color:#f9f9f9"';

        return `
          <tr ${rowBg}>
            <td>${marche.numero_lot || "-"}</td>
            <td>${marche.intitule_lot}</td>
            <td>${entName}</td>
            <td class="text-right">${fmtPdfAlways(baseHT)}</td>
            <td class="text-right">${fmtPdfAlways(avenantsHT)}</td>
            <td class="text-right font-bold">${fmtPdfAlways(totalHT)}</td>
            <td class="text-right">${avancement !== 0 ? fmtPdfAlways(avancement) : '0,00 €'}</td>
            <td class="text-right">${fmtPdf(acompte)}</td>
            <td class="text-right">-</td>
            <td class="text-right">${cautionTTC > 0 ? fmtPdfAlways(cautionTTC) : '-'}</td>
            <td class="text-right">${cautionHT > 0 ? fmtPdfAlways(cautionHT) : '-'}</td>
            <td class="text-right">${fmtPdf(rg)}</td>
            <td class="text-right">${fmtPdf(penalites)}</td>
            <td class="text-right">${fmtPdf(cie)}</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">${fmtPdf(sousTraitant)}</td>
          </tr>
        `;
      }).join('');

      const tableContentHtml = `
        <table>
          <thead>
            <tr>
              <th>Lot</th>
              <th>Intitulé</th>
              <th>Entreprise</th>
              <th class="text-right">Base HT</th>
              <th class="text-right">Avenants HT</th>
              <th class="text-right">Total En cours HT</th>
              <th class="text-right">Avancement</th>
              <th class="text-right">Acompte</th>
              <th class="text-right">Révision</th>
              <th class="text-right">Caution TTC</th>
              <th class="text-right">Caution HT</th>
              <th class="text-right">Retenue Garantie</th>
              <th class="text-right">Pénalités</th>
              <th class="text-right">C.I.E</th>
              <th class="text-right">Prorata</th>
              <th class="text-right">Retenue Bonne Fin</th>
              <th class="text-right">Trav. S-Traitant</th>
            </tr>
          </thead>
          <tbody>${lignes}</tbody>
        </table>
      `;

      const dateEtatFormatee = format(new Date(dateEtat + 'T00:00:00'), "dd/MM/yyyy", { locale: fr });
      const htmlContent = generatePdfHtml({
        title: "EN COURS MARCHÉS ENTREPRISES",
        subtitle: `État au ${dateEtatFormatee}`,
        chantier,
        client: clients.find(c => c.id === chantier?.client_id),
        infoGestionbat,
        partenaires,
        tableContentHtml,
        orientation: "landscape",
        customFooterDate: dateEtatFormatee,
      });

      const response = await base44.functions.invoke('htmlToPdf', { html_content: htmlContent });

      if (response.data && response.data.success && response.data.pdf_base64) {
        const link = document.createElement('a');
        link.href = `data:application/pdf;base64,${response.data.pdf_base64}`;
        link.download = `encours_marches_${chantier?.nom?.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast.success("PDF généré avec succès", { id: "encours-pdf" });
      } else {
        throw new Error("Erreur conversion PDF");
      }
    } catch (error) {
      console.error("Erreur export PDF:", error);
      toast.error("Erreur lors de la génération du PDF", { id: "encours-pdf" });
    } finally {
      setGeneratingPDF(false);
    }
  };

  if (isLoading) {
    return <div className="text-center p-8">Chargement...</div>;
  }

  if (marches.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Building className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">Aucun marché enregistré</h3>
        <p className="text-gray-500">Ce tableau récapitulatif sera rempli une fois des marchés créés.</p>
      </Card>
    );
  }

  // Helper pour cellule fusionnée (rowSpan=2)
  const thMerged = (label) => (
    <th className="px-2 py-3 text-right text-xs font-semibold whitespace-nowrap border-l border-white/30" rowSpan={2}>{label}</th>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">En-cours Marchés Entreprises</h2>
          <p className="text-sm text-gray-600 mt-1">Tableau récapitulatif général</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-gray-500" />
            <Label className="text-sm text-gray-600 whitespace-nowrap">Date d'état :</Label>
            <Input
              type="date"
              value={dateEtat}
              onChange={(e) => setDateEtat(e.target.value)}
              className="w-40 h-8 text-sm"
            />
          </div>
          <Button variant="outline" onClick={handleExportCSV} className="gap-2">
            <Download className="w-4 h-4" /> CSV
          </Button>
          <Button variant="outline" onClick={handleExportPDF} disabled={generatingPDF} className="gap-2">
            {generatingPDF ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />} PDF
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-orange-600 text-white">
                <th className="px-2 py-2 text-left font-semibold whitespace-nowrap">N° Lot</th>
                <th className="px-2 py-2 text-left font-semibold whitespace-nowrap min-w-[130px]">Intitulé</th>
                <th className="px-2 py-2 text-left font-semibold whitespace-nowrap min-w-[130px]">Entreprise</th>
                <th className="px-2 py-2 text-center font-semibold whitespace-nowrap">Type</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Montant Base</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Montant Avenants</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Montant Total En cours</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Montant Avancement</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Acompte</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Révision</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Montant Caution</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Retenue de Garantie</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Pénalités</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Retenues</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Montant C.I.E</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Montant Prorata</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Retenue Bonne Fin</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Paiement Sous-Traitant</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap border-l border-white/30">Net à payer DGD</th>
                <th className="px-2 py-2 text-right font-semibold whitespace-nowrap">Net à payer Fin GPA</th>
              </tr>

            </thead>
            <tbody>
              {marches.map((marche, index) => {
                const tva = marche.taux_tva || 20;
                const baseHT = marche.montant || 0;
                const baseTTC = baseHT * (1 + tva / 100);
                const avenantsHT = getMontantAvenants(marche.id, marche.entreprise_id);
                const avenantsTTC = avenantsHT * (1 + tva / 100);
                const totalHT = baseHT + avenantsHT;
                const totalTTC = baseTTC + avenantsTTC;
                const avancementHT = getMontantAvancement(marche.id, marche.entreprise_id);
                const avancementTTC = avancementHT * (1 + tva / 100);
                const acompte = getMontantAcompte(marche.id, marche.entreprise_id);
                const revision = getMontantRevision();
                const cautionTTC = getMontantCautions(marche);
                const diviseurTVA = tva === 10 ? 1.10 : 1.20;
                const cautionHT = cautionTTC / diviseurTVA;
                const rgTTCVal = getMontantRetenueGarantieTTC(marche.id, marche.entreprise_id);
                const rg = rgTTCVal / diviseurTVA;
                const penalitesTTC = getMontantPenalitesByCategorie(marche.id, marche.entreprise_id, 'penalite');
                const penalites = penalitesTTC / diviseurTVA;
                const retenuesTotalTTC = getMontantPenalitesByCategorie(marche.id, marche.entreprise_id, 'retenue');
                const retenues = retenuesTotalTTC / diviseurTVA;
                const cieTTC = getMontantCIE(marche.id, marche.entreprise_id);
                const cie = cieTTC / diviseurTVA;
                const prorataTTC = getMontantProrata();
                const prorata = prorataTTC / diviseurTVA;
                const bonneFinTTC = getMontantRetenueBonneFin();
                const bonneFin = bonneFinTTC / diviseurTVA;
                const sousTraitant = getMontantSousTraitant(marche.id, marche.entreprise_id);
                const stSoumiseTVA = hasSousTraitanceSoumiseTVA(marche.entreprise_id, marche.id);
                const sousTraitantTTC = stSoumiseTVA ? sousTraitant * (1 + tva / 100) : null;

                const acompteTTC = acompte * (1 + tva / 100);
                const revisionTTC = revision * (1 + tva / 100);
                const rgTTC = rgTTCVal; // déjà en TTC

                return (
                  <React.Fragment key={marche.id || index}>
                    {/* Ligne HT */}
                    <tr className="border-b border-gray-100">
                      <td rowSpan={2} className="px-2 py-2 border-r align-middle bg-white">
                        {marche.numero_lot ? <span className="font-mono font-bold text-gray-700">{marche.numero_lot}</span> : <span className="text-gray-400">-</span>}
                      </td>
                      <td rowSpan={2} className="px-2 py-2 font-medium text-gray-900 border-r align-middle bg-white">{marche.intitule_lot}</td>
                      <td rowSpan={2} className="px-2 py-2 text-gray-700 border-r align-middle bg-white">{getEntrepriseName(marche.entreprise_id)}</td>
                      <td className="px-2 py-2 text-center font-bold text-gray-500 bg-white">HT</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmtAlways(baseHT)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmtAlways(avenantsHT)}</td>
                      <td className="px-2 py-2 text-right font-bold text-gray-900 bg-white">{fmtAlways(totalHT)}</td>
                      <td className="px-2 py-2 text-right text-blue-600 bg-white border-l">{fmtAlways(avancementHT)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmt(acompte)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmt(revision)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white border-l">{cautionHT > 0 ? fmtAlways(cautionHT) : '-'}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmt(rg)}</td>
                      <td className="px-2 py-2 text-right text-red-600 bg-white border-l">{fmt(penalites)}</td>
                      <td className="px-2 py-2 text-right text-amber-700 bg-white">{fmt(retenues)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white border-l">{fmt(cie)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmt(prorata)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white">{fmt(bonneFin)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white border-l">{fmt(sousTraitant)}</td>
                      <td className="px-2 py-2 text-right text-green-700 bg-white border-l">-</td>
                      <td className="px-2 py-2 text-right text-green-700 bg-white">-</td>
                    </tr>
                    {/* Ligne TTC */}
                    <tr className="border-b border-gray-300">
                      <td className="px-2 py-2 text-center font-bold text-orange-600 bg-orange-50">TTC</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-50">{fmtAlways(baseTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-50">{fmtAlways(avenantsTTC)}</td>
                      <td className="px-2 py-2 text-right font-bold text-orange-700 bg-orange-50">{fmtAlways(totalTTC)}</td>
                      <td className="px-2 py-2 text-right text-blue-700 bg-orange-50 border-l">{fmtAlways(avancementTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50">{fmt(acompteTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50">{fmt(revisionTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50 border-l">{cautionTTC > 0 ? fmtAlways(cautionTTC) : '-'}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50">{fmt(rgTTC)}</td>
                      <td className="px-2 py-2 text-right text-red-500 bg-orange-50 border-l">{fmt(penalitesTTC)}</td>
                      <td className="px-2 py-2 text-right text-amber-600 bg-orange-50">{fmt(retenuesTotalTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50 border-l">{fmt(cieTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50">{fmt(prorataTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50">{fmt(bonneFinTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-600 bg-orange-50 border-l">{sousTraitantTTC !== null ? fmt(sousTraitantTTC) : '-'}</td>
                      <td className="px-2 py-2 text-right text-green-600 bg-orange-50 border-l">-</td>
                      <td className="px-2 py-2 text-right text-green-600 bg-orange-50">-</td>
                    </tr>
                  </React.Fragment>
                );
              })}

              {/* Totaux */}
              {(() => {
                const totalBaseHT = marches.reduce((sum, m) => sum + (m.montant || 0), 0);
                const totalBaseTTC = marches.reduce((sum, m) => sum + (m.montant || 0) * (1 + (m.taux_tva || 20) / 100), 0);
                const totalAvenantsHT = marches.reduce((sum, m) => sum + getMontantAvenants(m.id, m.entreprise_id), 0);
                const totalAvenantsTTC = marches.reduce((sum, m) => sum + getMontantAvenants(m.id, m.entreprise_id) * (1 + (m.taux_tva || 20) / 100), 0);
                const totalCoursHT = totalBaseHT + totalAvenantsHT;
                const totalCoursTTC = totalBaseTTC + totalAvenantsTTC;
                const totalAvancementHT = marches.reduce((sum, m) => sum + getMontantAvancement(m.id, m.entreprise_id), 0);
                const totalAvancementTTC = marches.reduce((sum, m) => sum + getMontantAvancement(m.id, m.entreprise_id) * (1 + (m.taux_tva || 20) / 100), 0);
                const totalAcompte = marches.reduce((sum, m) => sum + getMontantAcompte(m.id, m.entreprise_id), 0);
                const totalCautionTTC = marches.reduce((sum, m) => sum + getMontantCautions(m), 0);
                const totalCautionHT = marches.reduce((sum, m) => {
                  const tvaM = m.taux_tva || 20;
                  const div = tvaM === 10 ? 1.10 : 1.20;
                  return sum + getMontantCautions(m) / div;
                }, 0);
                const totalRGTTCVal = marches.reduce((sum, m) => sum + getMontantRetenueGarantieTTC(m.id, m.entreprise_id), 0);
                const totalRG = marches.reduce((sum, m) => {
                  const tvaM = m.taux_tva || 20;
                  const div = tvaM === 10 ? 1.10 : 1.20;
                  return sum + getMontantRetenueGarantieTTC(m.id, m.entreprise_id) / div;
                }, 0);
                const totalPenalitesTTC = marches.reduce((sum, m) => sum + getMontantPenalitesByCategorie(m.id, m.entreprise_id, 'penalite'), 0);
                const totalPenalites = marches.reduce((sum, m) => {
                  const div = (m.taux_tva || 20) === 10 ? 1.10 : 1.20;
                  return sum + getMontantPenalitesByCategorie(m.id, m.entreprise_id, 'penalite') / div;
                }, 0);
                const totalRetenuesTotalTTC = marches.reduce((sum, m) => sum + getMontantPenalitesByCategorie(m.id, m.entreprise_id, 'retenue'), 0);
                const totalRetenuesTotal = marches.reduce((sum, m) => {
                  const div = (m.taux_tva || 20) === 10 ? 1.10 : 1.20;
                  return sum + getMontantPenalitesByCategorie(m.id, m.entreprise_id, 'retenue') / div;
                }, 0);
                const totalCIETTC = marches.reduce((sum, m) => sum + getMontantCIE(m.id, m.entreprise_id), 0);
                const totalCIE = marches.reduce((sum, m) => {
                  const div = (m.taux_tva || 20) === 10 ? 1.10 : 1.20;
                  return sum + getMontantCIE(m.id, m.entreprise_id) / div;
                }, 0);
                const totalSousTraitant = marches.reduce((sum, m) => sum + getMontantSousTraitant(m.id, m.entreprise_id), 0);
                const totalSousTraitantTTC = marches.reduce((sum, m) => {
                  if (!hasSousTraitanceSoumiseTVA(m.entreprise_id, m.id)) return sum;
                  const tvaM = m.taux_tva || 20;
                  return sum + getMontantSousTraitant(m.id, m.entreprise_id) * (1 + tvaM / 100);
                }, 0);

                const totalAcompteTTC = totalAcompte * 1.2;
                const totalRGTTC = totalRGTTCVal; // déjà en TTC

                return (
                  <>
                    <tr className="bg-orange-100 border-t-2 border-orange-600 font-bold">
                      <td colSpan={3} rowSpan={2} className="px-2 py-3 text-right text-gray-900 uppercase align-middle text-xs">TOTAUX</td>
                      <td className="px-2 py-2 text-center text-gray-500 bg-white text-xs">HT</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">{fmtAlways(totalBaseHT)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">{fmtAlways(totalAvenantsHT)}</td>
                      <td className="px-2 py-2 text-right text-orange-700 bg-white whitespace-nowrap">{fmtAlways(totalCoursHT)}</td>
                      <td className="px-2 py-2 text-right text-blue-700 bg-white whitespace-nowrap border-l">{fmtAlways(totalAvancementHT)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">{fmt(totalAcompte)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap border-l">{totalCautionHT > 0 ? fmtAlways(totalCautionHT) : '-'}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-white whitespace-nowrap">{fmt(totalRG)}</td>
                      <td className="px-2 py-2 text-right text-red-700 bg-white whitespace-nowrap border-l">{fmt(totalPenalites)}</td>
                      <td className="px-2 py-2 text-right text-amber-700 bg-white whitespace-nowrap">{fmt(totalRetenuesTotal)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap border-l">{fmt(totalCIE)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-white whitespace-nowrap border-l">{fmt(totalSousTraitant)}</td>
                      <td className="px-2 py-2 text-right text-green-700 bg-white whitespace-nowrap border-l">-</td>
                      <td className="px-2 py-2 text-right text-green-700 bg-white whitespace-nowrap">-</td>
                    </tr>
                    <tr className="bg-orange-200 border-b-2 border-orange-600 font-bold">
                      <td className="px-2 py-2 text-center text-orange-700 bg-orange-100 text-xs">TTC</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-orange-100 whitespace-nowrap">{fmtAlways(totalBaseTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-900 bg-orange-100 whitespace-nowrap">{fmtAlways(totalAvenantsTTC)}</td>
                      <td className="px-2 py-2 text-right text-orange-800 bg-orange-100 whitespace-nowrap">{fmtAlways(totalCoursTTC)}</td>
                      <td className="px-2 py-2 text-right text-blue-800 bg-orange-100 whitespace-nowrap border-l">{fmtAlways(totalAvancementTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap">{fmt(totalAcompteTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap border-l">{totalCautionTTC > 0 ? fmtAlways(totalCautionTTC) : '-'}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap">{fmt(totalRGTTC)}</td>
                      <td className="px-2 py-2 text-right text-red-600 bg-orange-100 whitespace-nowrap border-l">{fmt(totalPenalitesTTC)}</td>
                      <td className="px-2 py-2 text-right text-amber-600 bg-orange-100 whitespace-nowrap">{fmt(totalRetenuesTotalTTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap border-l">{fmt(totalCIETTC)}</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap">-</td>
                      <td className="px-2 py-2 text-right text-gray-700 bg-orange-100 whitespace-nowrap border-l">{fmt(totalSousTraitantTTC)}</td>
                      <td className="px-2 py-2 text-right text-green-600 bg-orange-100 whitespace-nowrap border-l">-</td>
                      <td className="px-2 py-2 text-right text-green-600 bg-orange-100 whitespace-nowrap">-</td>
                    </tr>
                  </>
                );
              })()}
            </tbody>
          </table>
        </div>
      </div>

      {/* Légende pénalités et retenues */}
      {(() => {
        const { penalites: legPen, retenues: legRet } = getLegendePenalitesRetenues();
        if (legPen.length === 0 && legRet.length === 0) return null;
        return (
          <div className="bg-white border rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide">Détail des pénalités et retenues appliquées</h3>
            {legPen.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-red-700 mb-2">Pénalités :</p>
                <div className="space-y-1">
                  {legPen.map((p, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <span className="inline-block w-2 h-2 rounded-full bg-red-500 mt-1 shrink-0"></span>
                      <span className="font-medium text-gray-800">{p.type_penalite}</span>
                      {p.base && <span className="text-gray-500">— Base : {p.base}</span>}
                      {p.valeur != null && <span className="text-gray-500">— {p.valeur} {p.unite || '€'}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {legRet.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-amber-700 mb-2">Retenues diverses :</p>
                <div className="space-y-1">
                  {legRet.map((p, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <span className="inline-block w-2 h-2 rounded-full bg-amber-500 mt-1 shrink-0"></span>
                      <span className="font-medium text-gray-800">{p.type_penalite}</span>
                      {p.base && <span className="text-gray-500">— Base : {p.base}</span>}
                      {p.valeur != null && <span className="text-gray-500">— {p.valeur} {p.unite || '€'}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
}