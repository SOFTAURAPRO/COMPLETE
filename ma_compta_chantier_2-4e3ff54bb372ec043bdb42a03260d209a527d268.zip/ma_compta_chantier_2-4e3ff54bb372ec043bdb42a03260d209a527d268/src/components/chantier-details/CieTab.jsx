import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, FileText, Calculator, Download, Loader2 } from "lucide-react";
import CieDialog from "../../components/cie/CieDialog";
import CieList from "../../components/cie/CieList";
import SearchBar from "../common/SearchBar";
import { toast } from "sonner";
import { usePermissions } from "../common/usePermissions";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { getCiePdfTemplate } from "@/components/templates/CiePdfTemplate";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useInfoGestionbat } from "@/components/common/useInfoGestionbat";

export default function CieTab({ chantierId }) {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedOp, setSelectedOp] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [opToDelete, setOpToDelete] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  const queryClient = useQueryClient();
  // Using permissions similar to Marches (assuming if you can edit financial stuff you can do CIE)
  const { canViewMarches, canEditMarches } = usePermissions(); 
  const canManageCie = canEditMarches; 

  const { data: operations, isLoading } = useQuery({
    queryKey: ['cie-operations', chantierId],
    queryFn: async () => {
      try {
        // Fetch all operations for this chantier
        const ops = await base44.entities.CieOperation.filter({ chantier_id: chantierId }, 'date_operation', 100);
        return ops.sort((a, b) => new Date(b.date_operation) - new Date(a.date_operation));
      } catch (error) {
        console.error("Erreur chargement CIE:", error);
        return [];
      }
    },
    initialData: [],
    enabled: !!chantierId
  });

  const { data: entreprises } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: [],
  });

  const { data: marches } = useQuery({
    queryKey: ['marches', chantierId],
    queryFn: async () => {
        try {
            const allMarches = await base44.entities.MarcheEntreprise.filter({ chantier_id: chantierId }, 'numero_lot', 100);
            return allMarches;
        } catch (error) {
            console.error(error);
            return [];
        }
    },
    initialData: [],
    enabled: !!chantierId
  });

  const { data: chantier } = useQuery({
    queryKey: ['chantier', chantierId],
    queryFn: () => base44.entities.Chantier.get(chantierId),
    enabled: !!chantierId
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: []
  });

  const { infoGestionbat } = useInfoGestionbat();

  // Filtrer les entreprises présentes sur le chantier
  const entreprisesChantier = React.useMemo(() => {
    const entrepriseIds = new Set(marches.map(m => m.entreprise_id));
    return entreprises.filter(e => entrepriseIds.has(e.id));
  }, [marches, entreprises]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CieOperation.create({ ...data, chantier_id: chantierId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cie-operations'] });
      setShowDialog(false);
      setSelectedOp(null);
      toast.success("Opération C.I.E créée");
    },
    onError: (err) => toast.error("Erreur: " + err.message)
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CieOperation.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cie-operations'] });
      setShowDialog(false);
      setSelectedOp(null);
      toast.success("Opération mise à jour");
    },
    onError: (err) => toast.error("Erreur: " + err.message)
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CieOperation.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cie-operations'] });
      toast.success("Opération supprimée");
    },
    onError: (err) => toast.error("Erreur: " + err.message)
  });

  const handleSubmit = (data) => {
    if (selectedOp) {
        updateMutation.mutate({ id: selectedOp.id, data });
    } else {
        createMutation.mutate(data);
    }
  };

  const handleStatusChange = (op, newStatus) => {
    updateMutation.mutate({ 
        id: op.id, 
        data: { ...op, statut: newStatus } 
    });
  };

  const handleDelete = (op) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer cette opération ?")) {
        deleteMutation.mutate(op.id);
    }
  };

  const filteredOps = operations.filter(op => 
    op.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    op.montant_total_ht.toString().includes(searchQuery)
  );

  // Stats
  const totalCredit = filteredOps.reduce((sum, op) => sum + (op.montant_total_ht || 0), 0);
  const totalValide = filteredOps.filter(op => op.statut === 'valide' || op.statut === 'integre').reduce((sum, op) => sum + (op.montant_total_ht || 0), 0);

  const handleExportCSV = () => {
    if (filteredOps.length === 0) {
      toast.error("Aucune donnée à exporter");
      return;
    }

    const headers = ["Date", "Description", "Entreprise Créditrice", "Montant Total HT", "Statut", "Répartition"];
    
    const rows = filteredOps.map(op => {
      const creditrice = entreprises.find(e => e.id === op.entreprise_facturante_id)?.nom || "Inconnue";
      const repartitionDetails = op.repartitions?.map(r => {
        const entName = entreprises.find(e => e.id === r.entreprise_responsable_id)?.nom || "Inconnue";
        return `${entName}: ${r.montant_ht_attribue?.toFixed(2)}€ (${r.pourcentage}%)`;
      }).join("; ");

      return [
        op.date_operation,
        `"${(op.description || "").replace(/"/g, '""')}"`,
        `"${(creditrice || "").replace(/"/g, '""')}"`,
        (op.montant_total_ht || 0).toFixed(2),
        op.statut,
        `"${(repartitionDetails || "").replace(/"/g, '""')}"`
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `export_cie_${chantierId}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = async () => {
    if (filteredOps.length === 0) {
        toast.error("Aucune donnée à exporter");
        return;
    }

    setIsExporting(true);
    try {
        // Préparer les données pour le template
        const logoClient = chantier?.logo_client_url 
            ? `<img src="${chantier.logo_client_url}" alt="Logo Client" style="max-width: 150px; max-height: 70px; object-fit: contain;" />` 
            : '';

        const partenairesList = chantier?.partenaires || [];
        const partenairesData = partenairesList.map(p => {
            const partenaire = partenaires?.find(part => part.id === p.partenaire_id);
            if (!partenaire) return null;
            return { nom: partenaire.nom, role: (p.role || '').toLowerCase() };
        }).filter(Boolean);

        const architecte = partenairesData.find(p => p.role.includes('architecte'));
        const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
        
        const partenairesOrdonnes = [];
        if (architecte) partenairesOrdonnes.push(architecte.nom);
        partenairesOrdonnes.push(infoGestionbat?.nom_entreprise || 'GESTIONBAT');
        autresPartenaires.forEach(p => partenairesOrdonnes.push(p.nom));
        
        const partenairesString = partenairesOrdonnes.join(" / ");
        const dateFormatee = format(new Date(), "dd/MM/yyyy", { locale: fr });

        const htmlContent = getCiePdfTemplate({
            chantier,
            operations: filteredOps,
            entreprises,
            totalCredit,
            totalValide,
            logoClient,
            infoGestionbat,
            partenairesString,
            dateFormatee
        });

        const res = await base44.functions.invoke("htmlToPdf", { html_content: htmlContent });
        
        if (res.data && res.data.success && res.data.pdf_base64) {
            const link = document.createElement('a');
            link.href = `data:application/pdf;base64,${res.data.pdf_base64}`;
            link.download = `Suivi_CIE_${chantier?.nom || 'Chantier'}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            toast.success("PDF généré avec succès");
        } else {
            throw new Error(res.data?.error || "Erreur inconnue");
        }

    } catch (error) {
        console.error("Erreur PDF:", error);
        toast.error("Erreur lors de la génération du PDF");
    } finally {
        setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Compte Inter-Entreprises (C.I.E)</h2>
          <p className="text-sm text-gray-600 mt-1">
            Gérez les répartitions de frais entre entreprises (nettoyage, réparations, etc.)
          </p>
        </div>
        {canManageCie && (
            <Button 
                className="bg-orange-600 hover:bg-orange-700 gap-2"
                onClick={() => { setSelectedOp(null); setShowDialog(true); }}
            >
                <Plus className="w-5 h-5" />
                Nouvelle Opération
            </Button>
        )}
        <Button variant="outline" onClick={handleExportCSV} className="gap-2">
            <FileText className="w-4 h-4" />
            CSV
        </Button>
        <Button variant="outline" onClick={handleExportPDF} disabled={isExporting} className="gap-2">
            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            PDF
        </Button>
      </div>

      <div className="flex gap-4 items-center">
         <SearchBar 
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Rechercher une opération..."
            className="flex-1"
         />
         <div className="bg-orange-50 text-orange-800 px-4 py-2 rounded-lg border border-orange-100 text-sm font-medium">
            Total Engagé: {totalCredit.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} € HT
         </div>
      </div>

      <Alert className="bg-blue-50 border-blue-100 text-blue-800">
        <Calculator className="w-4 h-4" />
        <AlertDescription className="text-xs ml-2">
            Les montants validés seront automatiquement proposés en déduction/crédit lors de la création des prochains certificats de paiement.
        </AlertDescription>
      </Alert>

      <CieList 
        operations={filteredOps}
        entreprises={entreprises}
        onEdit={(op) => { setSelectedOp(op); setShowDialog(true); }}
        onDelete={handleDelete}
        onStatusChange={handleStatusChange}
      />

      {canManageCie && (
        <CieDialog 
            open={showDialog}
            onOpenChange={setShowDialog}
            operation={selectedOp}
            chantierId={chantierId}
            entreprises={entreprisesChantier}
            onSubmit={handleSubmit}
            isLoading={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}