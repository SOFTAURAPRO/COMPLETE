/** 
© Alice MINARD – Créatrice originale
Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
Mise à disposition pour usage interne chez GestionBat le 03 mars 2026 (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
Ce logiciel a été initié, conçu et développé par Alice MINARD.
Il est protégé par le droit d'auteur français. Toute reproduction, modification ou exploitation
au-delà de l'usage interne chez GestionBat nécessite un accord écrit préalable de l'autrice.
*/

import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Download, FileText, Pencil, Trash2, Upload, X, Building, FolderOpen, Lock, LockOpen, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription } from
"@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle } from
"@/components/ui/alert-dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger } from
"@/components/ui/accordion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mergePdfsWithDocuments } from '@/components/utils/pdfMerger';
import PdfPreviewDialog from '@/components/common/PdfPreviewDialog';
import CertificatsVueGlobale from '@/components/certificats/CertificatsVueGlobale';
import CertificatFormDialog from '@/components/certificats/CertificatFormDialog';
import CertificatsEnvoyesMOE from '@/components/certificats/CertificatsEnvoyesMOE';
import { generateCertificatStandardHtml } from '@/components/templates/CertificatStandardTemplate';
import { generateCertificatGiboireHtml } from '@/components/templates/CertificatGiboireTemplate';
import { generateCertificatCisnHtml } from '@/components/templates/CertificatCisnTemplate';
import ImportSituationsDialog from '@/components/certificats/ImportSituationsDialog';
import { computeNetAPayer } from '@/components/certificats/computeNetAPayer';

// ── IDs clients avec templates dédiés ────────────────────────────────────────
const CLIENT_GIBOIRE_ID = '69ac57f5960806dc553edf27'; // CLT-0003 — trame Giboire
const CLIENT_CISN_ID    = '69a6086c7fc8485aae2d7542'; // CLT-0001 — trame CISN

/**
 * Retourne la fonction de génération HTML adaptée au client du certificat.
 * - Client Giboire → generateCertificatGiboireHtml
 * - Client CISN   → generateCertificatCisnHtml
 * - Autres        → generateCertificatStandardHtml
 */
function selectTemplateGenerator(clientId) {
  if (clientId === CLIENT_GIBOIRE_ID) return generateCertificatGiboireHtml;
  if (clientId === CLIENT_CISN_ID)    return generateCertificatCisnHtml;
  return generateCertificatStandardHtml;
}

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 10 }, (_, i) => CURRENT_YEAR - 5 + i);

export default function CertificatsTab({ chantierId }) {
  const [showDialog, setShowDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedCertificat, setSelectedCertificat] = useState(null);
  const [certificatToDelete, setCertificatToDelete] = useState(null);
  const [uploadingPDF, setUploadingPDF] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [viewMode, setViewMode] = useState("by-entreprise");
  const [mainTab, setMainTab] = useState("certificats");
  const [showClotureDialog, setShowClotureDialog] = useState(false);
  const [clotureData, setClotureData] = useState({
    mois: (new Date().getMonth() + 1).toString().padStart(2, '0'),
    annee: new Date().getFullYear().toString()
  });
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [previewPdfBase64, setPreviewPdfBase64] = useState(null);
  const [previewFileName, setPreviewFileName] = useState("");
  const [previewDownloadAction, setPreviewDownloadAction] = useState(null);
  const [showImportDialog, setShowImportDialog] = useState(false);

  const [formData, setFormData] = useState({
    numero: "",
    mois: "",
    annee: CURRENT_YEAR.toString(),
    client_id: "",
    marche_id: "",
    entreprise_id: "",
    date_situation: "",
    numero_facture: "",
    date_facture: "",
    montant_ht: "",
    montant_ht_base: "",
    montant_ht_avenants: "",
    demande_acompte: 0,
    remboursement_acompte: 0,
    facture_pdf_url: "",
    statut: "brouillon",
    notes: "",
    paiements_sous_traitants: [],
    penalites_appliquees: [],
    remboursement_penalites: 0,
    montant_cie: 0,
    details_cie: []
  });

  const queryClient = useQueryClient();

  const { data: currentUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });
  const isAdmin = currentUser?.role === 'admin';

  const { data: certificats, isLoading } = useQuery({
    queryKey: ['certificats', chantierId],
    queryFn: async () => {
      const allCertificats = await base44.entities.CertificatPaiement.list('-numero');
      return allCertificats.filter(c => c.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: chantier } = useQuery({
    queryKey: ['chantier', chantierId],
    queryFn: async () => {
      const chantiers = await base44.entities.Chantier.list();
      return chantiers.find(c => c.id === chantierId);
    },
    enabled: !!chantierId,
  });

  const { data: marches } = useQuery({
    queryKey: ['marches', chantierId],
    queryFn: async () => {
      const allMarches = await base44.entities.MarcheEntreprise.list();
      return allMarches.filter(m => m.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: avenants } = useQuery({
    queryKey: ['avenants', chantierId],
    queryFn: async () => {
      const allAvenants = await base44.entities.Avenant.list();
      return allAvenants.filter(a => a.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: entreprises } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: [],
  });

  const { data: cieOperations } = useQuery({
    queryKey: ['cie-operations', chantierId],
    queryFn: async () => {
      const ops = await base44.entities.CieOperation.list();
      return ops.filter(op => op.chantier_id === chantierId && op.statut !== 'brouillon');
    },
    initialData: [],
    enabled: !!chantierId
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: [],
  });

  const { data: sousTraitances } = useQuery({
    queryKey: ['sous-traitance', chantierId],
    queryFn: async () => {
      const allSousTraitances = await base44.entities.SousTraitance.list();
      return allSousTraitances.filter(s => s.chantier_id === chantierId);
    },
    initialData: [],
    enabled: !!chantierId,
  });

  const entreprisesSousTraitantesIds = useMemo(() => {
    return [...new Set(sousTraitances.map(st => st.entreprise_sous_traitant_id))];
  }, [sousTraitances]);

  const entreprisesSousTraitantes = useMemo(() => {
    return entreprises.filter(e => entreprisesSousTraitantesIds.includes(e.id));
  }, [entreprises, entreprisesSousTraitantesIds]);

  const entreprisesAvecMarche = useMemo(() => {
    const entrepriseIds = [...new Set(marches.map(m => m.entreprise_id))];
    return entreprises.filter(e => entrepriseIds.includes(e.id));
  }, [marches, entreprises]);

  // Résolution robuste : cherche un marché par id d'abord, puis par numero_lot+chantier comme fallback
  const findMarche = (cert) => {
    if (cert.marche_id) {
      const byId = marches.find(m => m.id === cert.marche_id);
      if (byId) return byId;
    }
    // Fallback : cherche par entreprise_id (code métier)
    return marches.find(m => m.entreprise_id === cert.entreprise_id) || null;
  };

  // Résolution robuste entreprise : par id d'abord, puis par nom via marché
  const findEntreprise = (cert, marche) => {
    if (cert.entreprise_id) {
      const byId = entreprises.find(e => e.id === cert.entreprise_id);
      if (byId) return byId;
    }
    if (marche?.entreprise_id) {
      return entreprises.find(e => e.id === marche.entreprise_id) || null;
    }
    return null;
  };

  // Filtre les avenants d'un marché : par marche_id, numero_lot, ou entreprise_id en fallback
  const filterAvenantsForMarche = (m, avList) => {
    if (!m) return [];
    return avList.filter(a =>
      a.chantier_id === chantierId &&
      (
        (m.id && a.marche_id === m.id) ||
        (m.numero_lot && a.numero_lot === m.numero_lot) ||
        (!a.marche_id && !a.numero_lot && m.entreprise_id && a.entreprise_id === m.entreprise_id)
      ) &&
      (a.statut === 'valide' || a.statut === 'signe')
    );
  };

  const certificatsParLot = useMemo(() => {
    const grouped = {};
    
    certificats.forEach(cert => {
      const marche = findMarche(cert);
      // Clé de groupement : numero_lot du marché si dispo, sinon marche_id, sinon entreprise_id
      const groupKey = marche?.numero_lot || cert.marche_id || cert.entreprise_id;
      if (!groupKey) return;

      if (!grouped[groupKey]) {
        const entreprise = findEntreprise(cert, marche);
        
        let montantMarcheTotal = 0;
        if (marche) {
          montantMarcheTotal = marche.montant || 0;
          const avenantsLot = filterAvenantsForMarche(marche, avenants);
          montantMarcheTotal += avenantsLot.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
        }

        grouped[groupKey] = {
          groupKey,
          entreprise,
          marche,
          certificats: [],
          montantTotal: 0,
          montantValide: 0,
          montantMarcheTotal
        };
      }
      
      grouped[groupKey].certificats.push(cert);
      grouped[groupKey].montantTotal += cert.montant_ht || 0;
      
      if (cert.statut === 'valide') {
        grouped[groupKey].montantValide += cert.montant_ht || 0;
      }
    });

    return Object.values(grouped).sort((a, b) => 
      (a.marche?.numero_lot || '').localeCompare(b.marche?.numero_lot || '', undefined, { numeric: true })
    );
  }, [certificats, entreprises, marches, avenants]);

  const createMutation = useMutation({
    mutationFn: async (data) => {
      let numero = data.numero;
      if (!numero) {
        const certificatsPourLot = certificats.filter(c => c.marche_id === data.marche_id);
        numero = (certificatsPourLot.length + 1).toString().padStart(2, '0');
      }
      return base44.entities.CertificatPaiement.create({
        ...data,
        chantier_id: chantierId,
        numero: numero
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      setShowDialog(false);
      resetForm();
      toast.success("Certificat créé", {
        description: "Le certificat de paiement a été créé avec succès",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CertificatPaiement.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      setShowDialog(false);
      resetForm();
      toast.success("Situation mise à jour", {
        description: "La situation a été mise à jour avec succès",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CertificatPaiement.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      toast.success("Situation supprimée", {
        description: "La situation a été supprimée avec succès",
      });
    },
  });

  const validateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CertificatPaiement.update(id, { ...data, statut: "valide" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      toast.success("Situation validée", {
        description: "La situation a été validée",
      });
    },
  });

  const annulerClotureMutation = useMutation({
    mutationFn: (certId) => base44.entities.CertificatPaiement.update(certId, { est_cloture: false, donnees_figees: null }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      toast.success("Clôture annulée", { description: "Le certificat peut à nouveau être modifié." });
    },
    onError: (error) => {
      toast.error("Erreur", { description: error.message });
    }
  });

  const clotureMutation = useMutation({
    mutationFn: async ({ mois, annee }) => {
      const certsToClose = certificats.filter(c => 
        c.mois === mois && 
        c.annee === annee && 
        c.statut === 'valide' && 
        !c.est_cloture
      );

      if (certsToClose.length === 0) {
        throw new Error("Aucun certificat validé à clôturer pour cette période");
      }

      const promises = certsToClose.map(async (cert) => {
      const marche = cert.marche_id
        ? marches.find(m => m.id === cert.marche_id)
        : marches.find(m => m.entreprise_id === cert.entreprise_id);
      const entreprise = entreprises.find(e => e.id === cert.entreprise_id);
      const avenantsDeLEntreprise = filterAvenantsForMarche(marche, avenants);
        
        const donneesFigees = {
          marcheSnapshot: marche,
          avenantsSnapshot: avenantsDeLEntreprise,
          entrepriseSnapshot: entreprise,
        };

        return base44.entities.CertificatPaiement.update(cert.id, {
          est_cloture: true,
          donnees_figees: JSON.stringify(donneesFigees)
        });
      });

      return Promise.all(promises);
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      setShowClotureDialog(false);
      toast.success(`${results.length} certificats clôturés`, {
        description: "Les certificats ont été figés avec succès.",
      });
    },
    onError: (error) => {
      toast.error("Erreur lors de la clôture", {
        description: error.message
      });
    }
  });

  const resetForm = () => {
    setFormData({
      numero: "",
      mois: "",
      annee: CURRENT_YEAR.toString(),
      marche_id: "",
      entreprise_id: "",
      date_situation: "",
      numero_facture: "",
      date_facture: "",
      montant_ht: "",
      montant_ht_base: "",
      montant_ht_avenants: "",
      demande_acompte: 0,
      remboursement_acompte: 0,
      facture_pdf_url: "",
      factures_urls: [],
      statut: "brouillon",
      notes: "",
      paiements_sous_traitants: [],
      penalites_appliquees: [],
      remboursement_penalites: 0,
      is_remboursement_rg: false,
      deblocage_rg: 0
    });
    setSelectedCertificat(null);
  };

  const handleEdit = (cert) => {
    setSelectedCertificat(cert);
    
    let marcheId = cert.marche_id || "";
    if (!marcheId && cert.entreprise_id) {
      const marcheTrouve = marches.find(m => m.entreprise_id === cert.entreprise_id);
      if (marcheTrouve) {
        marcheId = marcheTrouve.id;
      }
    }

    setFormData({
      numero: cert.numero || "",
      mois: cert.mois || "",
      annee: cert.annee || CURRENT_YEAR.toString(),
      client_id: cert.client_id || "",
      marche_id: marcheId,
      entreprise_id: cert.entreprise_id || "",
      date_situation: cert.date_situation || "",
      numero_facture: cert.numero_facture || "",
      date_facture: cert.date_facture || "",
      montant_ht: cert.montant_ht != null ? cert.montant_ht.toString() : "",
      montant_ht_base: cert.montant_ht_base != null ? cert.montant_ht_base.toString() : "",
      montant_ht_avenants: cert.montant_ht_avenants != null ? cert.montant_ht_avenants.toString() : "",
      demande_acompte: cert.demande_acompte || 0,
      remboursement_acompte: cert.remboursement_acompte || 0,
      facture_pdf_url: cert.facture_pdf_url || "",
      factures_urls: cert.factures_urls || (cert.facture_pdf_url ? [cert.facture_pdf_url] : []),
      statut: cert.statut || "brouillon",
      notes: cert.notes || "",
      paiements_sous_traitants: cert.paiements_sous_traitants || [],
      penalites_appliquees: cert.penalites_appliquees || [],
      remboursement_penalites: cert.remboursement_penalites || 0,
      is_remboursement_rg: cert.is_remboursement_rg || false,
      deblocage_rg: cert.deblocage_rg || 0
    });
    setShowDialog(true);
  };

  const handleDelete = (cert) => {
    setCertificatToDelete(cert);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (certificatToDelete) {
      deleteMutation.mutate(certificatToDelete.id);
      setShowDeleteDialog(false);
      setCertificatToDelete(null);
    }
  };

  const handleValidate = (cert) => {
    validateMutation.mutate({ id: cert.id, data: cert });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const pendingCIE = getPendingCIE(formData.entreprise_id, selectedCertificat?.id);
    const montantCIE = pendingCIE.reduce((sum, item) => sum + (item.type === 'credit' ? item.montant : -item.montant), 0);

    const montantHTTotal = parseFloat(formData.montant_ht) || 0;
    const montantHTBase = parseFloat(formData.montant_ht_base) || 0;
    const montantHTAvenants = parseFloat(formData.montant_ht_avenants) || 0;
    
    // Calcul du montant_rg à enregistrer
    const marche = marches.find(m => m.id === formData.marche_id);
    const tauxTVA = marche?.taux_tva || 20;
    const montantTTC = montantHTTotal * (1 + tauxTVA / 100);
    const cautions = marche?.cautions || [];
    const hasCalcMonthCaution = cautions.some(c => {
      const cautionDate = c.date_reception?.substring(0, 10) || c.date_ajout?.substring(0, 10);
      const sitMonth = `${formData.annee}-${String(formData.mois).padStart(2, '0')}`;
      return cautionDate && cautionDate.substring(0, 7) === sitMonth;
    });
    const montantRG = hasCalcMonthCaution ? 0 : montantTTC * 0.05;

    const dataToSubmit = {
      ...formData,
      client_id: formData.client_id || chantier.client_id,
      montant_ht: montantHTTotal,
      montant_ht_base: montantHTBase,
      montant_ht_avenants: montantHTAvenants,
      demande_acompte: parseFloat(formData.demande_acompte) || 0,
      remboursement_acompte: parseFloat(formData.remboursement_acompte) || 0,
      montant_rg: montantRG,
      paiements_sous_traitants: formData.paiements_sous_traitants.map(p => ({
        entreprise_id: p.entreprise_id,
        montant_ht: parseFloat(p.montant_ht) || 0
      })),
      penalites_appliquees: formData.penalites_appliquees.map(p => ({
        categorie: p.categorie || 'penalite',
        type_penalite: p.type_penalite,
        base: p.base,
        valeur: parseFloat(p.valeur) || 0,
        nombre: parseFloat(p.nombre) || 0,
        valeur_minimum: parseFloat(p.valeur_minimum) || 0,
        utiliser_valeur_minimum: p.utiliser_valeur_minimum || false,
        is_montant_libre: p.is_montant_libre || false,
        montant_libre: parseFloat(p.montant_libre) || 0,
        montant_calcule: parseFloat(p.montant_calcule) || 0
      })),
      remboursement_penalites: parseFloat(formData.remboursement_penalites) || 0,
      montant_cie: montantCIE,
      details_cie: pendingCIE,
      is_remboursement_rg: formData.is_remboursement_rg || false,
      deblocage_rg: parseFloat(formData.deblocage_rg) || 0,
      remboursement_rg: parseFloat(formData.remboursement_rg) || 0
    };

    if (selectedCertificat) {
      updateMutation.mutate({ id: selectedCertificat.id, data: dataToSubmit });
    } else {
      createMutation.mutate(dataToSubmit);
    }
  };

  const handlePDFUpload = async (e, isMultiple = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPDF(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      if (isMultiple) {
        const newUrls = [...(formData.factures_urls || []), file_url];
        setFormData({ 
          ...formData, 
          factures_urls: newUrls,
          facture_pdf_url: newUrls[0] || file_url
        });
      } else {
        setFormData({ ...formData, facture_pdf_url: file_url });
      }
      
      toast.success("Fichier téléchargé", {
        description: "La facture a été téléchargée avec succès",
      });
    } catch (error) {
      console.error("Erreur lors du téléchargement:", error);
      toast.error("Erreur", {
        description: "Erreur lors du téléchargement du fichier",
      });
    } finally {
      setUploadingPDF(false);
    }
  };

  const getEntrepriseName = (entrepriseId) => {
    const entreprise = entreprises.find(e => e.id === entrepriseId);
    return entreprise?.nom || "Non spécifié";
  };

  const getFileName = (url) => {
    if (!url) return "";
    return url.split('/').pop().split('?')[0];
  };

  const getPendingCIE = (entrepriseId, currentCertificatId = null) => {
    if (!entrepriseId || !cieOperations) return [];
    
    const pending = [];
    
    cieOperations.forEach(op => {
        let type = null;
        let montant = 0;

        if (op.entreprise_facturante_id === entrepriseId) {
            type = 'credit';
            montant = op.montant_total_ht;
        } else {
            const repartition = op.repartitions?.find(r => r.entreprise_responsable_id === entrepriseId);
            if (repartition) {
                type = 'debit';
                montant = repartition.montant_ht_attribue;
            }
        }

        if (!type) return;

        const isAlreadyUsed = certificats.some(cert => {
            if (cert.id === currentCertificatId) return false;
            return cert.details_cie?.some(d => d.operation_id === op.id && d.type === type);
        });

        if (!isAlreadyUsed) {
            pending.push({
                operation_id: op.id,
                description: op.description,
                montant: montant,
                type: type
            });
        }
    });
    
    return pending;
  };

  const currentCIEAmount = useMemo(() => {
    if (!formData.entreprise_id) return 0;
    const pending = getPendingCIE(formData.entreprise_id, selectedCertificat?.id);
    return pending.reduce((sum, item) => sum + (item.type === 'credit' ? item.montant : -item.montant), 0);
  }, [formData.entreprise_id, cieOperations, certificats, selectedCertificat]);

  const handleAddSousTraitant = () => {
    if (formData.paiements_sous_traitants.length < 10) {
      setFormData({ ...formData, paiements_sous_traitants: [...formData.paiements_sous_traitants, { entreprise_id: "", montant_ht: "" }] });
    }
  };

  const handleRemoveSousTraitant = (index) => {
    setFormData({ ...formData, paiements_sous_traitants: formData.paiements_sous_traitants.filter((_, i) => i !== index) });
  };

  const handleUpdateSousTraitant = (index, field, value) => {
    const newPaiements = [...formData.paiements_sous_traitants];
    newPaiements[index] = { ...newPaiements[index], [field]: value };
    setFormData({ ...formData, paiements_sous_traitants: newPaiements });
  };

  const handleAddPenalite = () => {
    if (chantier?.penalites && chantier.penalites.length > 0) {
      const p = chantier.penalites[0];
      setFormData({ ...formData, penalites_appliquees: [...formData.penalites_appliquees, { type_penalite: p.type_penalite, base: p.base, valeur: p.valeur, nombre: "0", valeur_minimum: p.valeur_minimum, utiliser_valeur_minimum: false, montant_calcule: 0 }] });
    } else {
      toast.error("Pénalités non définies", { description: "Veuillez définir des pénalités dans les paramètres du chantier d'abord." });
    }
  };

  const handleRemovePenalite = (index) => {
    setFormData({ ...formData, penalites_appliquees: formData.penalites_appliquees.filter((_, i) => i !== index) });
  };

  const handleUpdatePenalite = (index, field, value) => {
    const newPenalites = [...formData.penalites_appliquees];
    newPenalites[index] = { ...newPenalites[index], [field]: value };

    if (field === 'type_penalite') {
      const pc = chantier?.penalites?.find(p => p.type_penalite === value);
      if (pc) {
        // Préserver la catégorie choisie manuellement si déjà définie, sinon prendre celle du chantier
        const categorieActuelle = newPenalites[index].categorie;
        newPenalites[index] = { 
          ...newPenalites[index], 
          type_penalite: pc.type_penalite, 
          base: pc.base, 
          valeur: pc.valeur, 
          valeur_minimum: pc.valeur_minimum, 
          mode_calcul: pc.mode_calcul,
          categorie: categorieActuelle || pc.categorie || 'penalite'
        };
      }
    }

    const pen = newPenalites[index];
    const TVA = 1.2;
    if (pen.is_montant_libre) {
      newPenalites[index].montant_calcule = parseFloat(pen.montant_libre) || 0;
    } else if (['nombre', 'utiliser_valeur_minimum', 'type_penalite', 'is_montant_libre'].includes(field)) {
      let montantHT = 0;
      const mode = pen.mode_calcul;
      if (mode === 'pourcentage_marche') {
        montantHT = (parseFloat(pen.valeur) || 0) / 100 * montantNouveauMarcheHT;
      } else if (mode === 'montant_fixe') {
        montantHT = parseFloat(pen.valeur) || 0;
      } else {
        montantHT = (parseFloat(pen.nombre) || 0) * (parseFloat(pen.valeur) || 0);
      }
      if (pen.utiliser_valeur_minimum && montantHT * TVA < (parseFloat(pen.valeur_minimum) || 0)) montantHT = (parseFloat(pen.valeur_minimum) || 0) / TVA;
      newPenalites[index].montant_calcule = montantHT * TVA; // Stocké en TTC
    }
    // Recalcul si montant_libre change
    if (field === 'montant_libre') {
      newPenalites[index].montant_calcule = parseFloat(value) || 0;
    }

    setFormData({ ...formData, penalites_appliquees: newPenalites });
  };

  const montantTotalPenalites = useMemo(() => {
    return formData.penalites_appliquees.reduce((sum, p) => sum + (parseFloat(p.montant_calcule) || 0), 0) - (parseFloat(formData.remboursement_penalites) || 0);
  }, [formData.penalites_appliquees, formData.remboursement_penalites]);

  const montantTotalPenalitesPrecedentes = useMemo(() => {
    if (!formData.marche_id) return 0;
    const numeroActuel = formData.numero ? parseInt(formData.numero) : Math.max(0, ...certificats.filter(c => c.marche_id === formData.marche_id).map(c => parseInt(c.numero) || 0)) + 1;
    return certificats.filter(c => c.marche_id === formData.marche_id && c.statut === 'valide' && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) < numeroActuel)
      .reduce((sum, c) => sum + (c.penalites_appliquees?.reduce((pSum, p) => pSum + (parseFloat(p.montant_calcule) || 0), 0) || 0) - (c.remboursement_penalites || 0), 0);
  }, [formData.marche_id, formData.numero, certificats, selectedCertificat]);

  const montantCumuleSituationsPrecedentes = useMemo(() => {
    if (!formData.marche_id) return 0;
    const numeroActuel = formData.numero ? parseInt(formData.numero) : Math.max(0, ...certificats.filter(c => c.marche_id === formData.marche_id).map(c => parseInt(c.numero) || 0)) + 1;
    const certsPrecedents = certificats.filter(c => c.marche_id === formData.marche_id && c.statut === 'valide' && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) < numeroActuel).sort((a, b) => parseInt(b.numero || 0) - parseInt(a.numero || 0));
    if (certsPrecedents.length === 0) return 0;
    const dernierCP = certsPrecedents[0];
    return certificats.filter(c => c.marche_id === formData.marche_id && c.statut === 'valide' && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) <= parseInt(dernierCP.numero || 0))
      .reduce((sum, c) => sum + (c.montant_ht || 0) + (c.demande_acompte || 0) - (c.remboursement_acompte || 0), 0);
  }, [formData.marche_id, formData.numero, certificats, selectedCertificat]);

  const montantCumuleMarcheBasePrecedentes = useMemo(() => {
    if (!formData.marche_id) return 0;
    const numeroActuel = formData.numero ? parseInt(formData.numero) : Math.max(0, ...certificats.filter(c => c.marche_id === formData.marche_id).map(c => parseInt(c.numero) || 0)) + 1;
    return certificats.filter(c => c.marche_id === formData.marche_id && c.statut === 'valide' && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) < numeroActuel)
      .reduce((sum, c) => sum + (c.montant_ht_base || 0), 0);
  }, [formData.marche_id, formData.numero, certificats, selectedCertificat]);

  const montantCumuleAvenantsPrecedentes = useMemo(() => {
    if (!formData.marche_id) return 0;
    const numeroActuel = formData.numero ? parseInt(formData.numero) : Math.max(0, ...certificats.filter(c => c.marche_id === formData.marche_id).map(c => parseInt(c.numero) || 0)) + 1;
    return certificats.filter(c => c.marche_id === formData.marche_id && c.statut === 'valide' && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) < numeroActuel)
      .reduce((sum, c) => sum + (c.montant_ht_avenants || 0), 0);
  }, [formData.marche_id, formData.numero, certificats, selectedCertificat]);

  const montantNouveauMarcheHT = useMemo(() => {
    if (!formData.marche_id) return 0;
    const m = marches.find(x => x.id === formData.marche_id);
    if (!m) return 0;
    const avenantsLot = filterAvenantsForMarche(m, avenants);
    return (m.montant || 0) + avenantsLot.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0);
  }, [formData.marche_id, marches, avenants, chantierId]);

  const handlePreviewCP = async (cert) => {
    setPreviewing(true);
    try {
      const client = clients.find(c => c.id === cert.client_id) || clients.find(c => c.id === chantier?.client_id);
      let marche = findMarche(cert);
      let entreprise = findEntreprise(cert, marche);
      let avenantsDeLEntreprise;
      if (cert.est_cloture && cert.donnees_figees) {
        try { const snap = JSON.parse(cert.donnees_figees); if (snap.marcheSnapshot) marche = snap.marcheSnapshot; if (snap.entrepriseSnapshot) entreprise = snap.entrepriseSnapshot; if (snap.avenantsSnapshot) avenantsDeLEntreprise = snap.avenantsSnapshot; } catch(e) {}
      }
      if (!avenantsDeLEntreprise) {
      const al = await base44.entities.Avenant.list();
      avenantsDeLEntreprise = al.filter(a => 
        a.chantier_id === chantierId && 
        (
          (marche?.id && a.marche_id === marche.id) ||
          (marche?.numero_lot && a.numero_lot === marche.numero_lot) ||
          (!a.marche_id && !a.numero_lot && marche?.entreprise_id && a.entreprise_id === marche.entreprise_id)
        ) && 
        (a.statut === 'valide' || a.statut === 'signe')
      );
      }
      const tauxTVA = marche?.taux_tva || chantier?.taux_tva?.[0] || 20;
      // Groupement des situations précédentes par marche_id
      const situationsPrecedentes = certificats.filter(c => {
      const cMarche = findMarche(c);
      return (marche?.numero_lot && cMarche?.numero_lot === marche.numero_lot) 
        && c.statut === 'valide' && c.id !== cert.id && parseInt(c.numero) < parseInt(cert.numero);
      });
      const contratsSousTraitance = sousTraitances.filter(st => 
      st.numero_lot === marche?.numero_lot && st.statut !== 'suspendu'
      );
      const generateHtmlPreview = selectTemplateGenerator(cert.client_id || chantier?.client_id);
      const htmlContent = generateHtmlPreview({ certificat: cert, chantier, client, entreprise, marche, situationsPrecedentes, avenantsDeLEntreprise, paiementsSousTraitants: cert.paiements_sous_traitants || [], contratsSousTraitance, penalitesAppliquees: cert.penalites_appliquees || [], infoGestionbat, partenaires, entreprises, tauxTVA, logoMoeUrl: infoGestionbat?.logo_url || null, logoClientUrl: client?.logo_client_url || chantier?.logo_client_url || null });
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      window.open(URL.createObjectURL(blob), '_blank');
      toast.success("Prévisualisation ouverte");
      if (cert.statut === 'brouillon') { await base44.entities.CertificatPaiement.update(cert.id, { statut: 'valide' }); queryClient.invalidateQueries({ queryKey: ['certificats'] }); }
    } catch (error) {
      toast.error("Erreur", { description: error.message });
    } finally { setPreviewing(false); }
  };

  const buildFileName = (cert, marche, entreprise, ext) => {
    const clientId = cert.client_id || chantier?.client_id;
    const annee = (cert.annee || '0000').toString().slice(-2);
    const mois  = (cert.mois || '00').toString().padStart(2, '0');
    const clean = (str) => (str || '')
      .toUpperCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, '')
      .replace(/[^A-Z0-9]/g, '');

    // Règle de nommage spécifique Giboire : NOM_CHANTIER_ENTREPRISE_AAMM
    if (clientId === CLIENT_GIBOIRE_ID) {
      const chantierClean = clean(chantier?.nom || 'CHANTIER');
      const entrepriseClean = clean(entreprise?.nom || 'ENTREPRISE');
      return `${chantierClean}_${entrepriseClean}_${annee}_${mois}.${ext}`;
    }

    // Règle standard
    const marcheEffectif = marche || marches.find(m => m.entreprise_id === cert.entreprise_id);
    const lotNumber = (marcheEffectif?.numero_lot || "00").toString().padStart(2, '0');
    const cpNumber  = (cert.numero || "00").toString().padStart(2, '0');
    const entrepriseClean = clean(entreprise?.nom || 'ENTREPRISE');
    return `${lotNumber}_CP${cpNumber}_${entrepriseClean}_${annee}_${mois}.${ext}`;
  };

  const handleExportCP = async (cert) => {
    setExporting(true);
    try {
      // Résolution du client : cert.client_id > chantier.client_id > chantier.client_2_id
      const clientCert = clients.find(c => c.id === cert.client_id);
      const clientPrincipal = clients.find(c => c.id === chantier?.client_id);
      const clientSecondaire = clients.find(c => c.id === chantier?.client_2_id);
      const client = clientCert || clientPrincipal || clientSecondaire;
      // Trame : chercher dans tous les clients associés au chantier
      const trameCertificat = clientCert?.trame_certificat_url 
        || clientPrincipal?.trame_certificat_url 
        || clientSecondaire?.trame_certificat_url 
        || chantier?.trame_certificats_url;
      console.log('[CP Export] client résolu:', client?.nom, '| trame:', trameCertificat ? '✅ trouvée' : '❌ absente', '| clientCert:', clientCert?.nom, '| clientPrincipal:', clientPrincipal?.nom);
      let marche = findMarche(cert);
      let entreprise = findEntreprise(cert, marche);
      let avenantsDeLEntreprise;
      if (cert.est_cloture && cert.donnees_figees) {
        try { const snap = JSON.parse(cert.donnees_figees); if (snap.marcheSnapshot) marche = snap.marcheSnapshot; if (snap.entrepriseSnapshot) entreprise = snap.entrepriseSnapshot; if (snap.avenantsSnapshot) avenantsDeLEntreprise = snap.avenantsSnapshot; } catch(e) {}
      }
      if (!avenantsDeLEntreprise) {
        const al = await base44.entities.Avenant.list();
        avenantsDeLEntreprise = al.filter(a => 
          a.chantier_id === chantierId && 
          (
            (marche?.id && a.marche_id === marche.id) ||
            (marche?.numero_lot && a.numero_lot === marche.numero_lot) ||
            (!a.marche_id && !a.numero_lot && marche?.entreprise_id && a.entreprise_id === marche.entreprise_id)
          ) && 
          (a.statut === 'valide' || a.statut === 'signe')
        );
      }
      const tauxTVA = marche?.taux_tva || chantier?.taux_tva?.[0] || 20;
      // Situations précédentes : groupement par numero_lot (code métier)
      const situationsPrecedentes = certificats.filter(c => {
        const cMarche = findMarche(c);
        return (marche?.numero_lot && cMarche?.numero_lot === marche.numero_lot)
          && c.statut === 'valide' && c.id !== cert.id && parseInt(c.numero) < parseInt(cert.numero);
      });
      const paiementsST = cert.paiements_sous_traitants || [];
      const effectiveClientId = cert.client_id || chantier?.client_id;

      if (trameCertificat) {
        try {
          toast.loading("Génération en cours...", { id: "certificat-generation" });
          const montantMarcheBase = marche?.montant || 0;
          const montantTotalAvenantsHT = avenantsDeLEntreprise.reduce((sum, av) => sum + (av.montant_total_ht || 0), 0);
          const nouveauMontantMarcheHT = montantMarcheBase + montantTotalAvenantsHT;
          const nouveauMontantMarcheTTC = nouveauMontantMarcheHT * (1 + tauxTVA / 100);
          
          // Calculs séparés base/avenants
          const montantCumulePrecedentHTBase = situationsPrecedentes.reduce((sum, c) => sum + (c.montant_ht_base || 0), 0);
          const montantCumulePrecedentHTAvenants = situationsPrecedentes.reduce((sum, c) => sum + (c.montant_ht_avenants || 0), 0);
          const montantCumulePrecedentHT = situationsPrecedentes.reduce((sum, c) => sum + (c.montant_ht || 0), 0);
          
          const montantCumuleTotalHTBase = montantCumulePrecedentHTBase + (cert.montant_ht_base || 0);
          const montantCumuleTotalHTAvenants = montantCumulePrecedentHTAvenants + (cert.montant_ht_avenants || 0);
          const montantCumuleTotalHT = montantCumulePrecedentHT + cert.montant_ht;
          const montantCumuleTotalTTC = montantCumuleTotalHT * (1 + tauxTVA / 100);
          
          // Pourcentages d'avancement séparés
          const pourcentageAvancementBase = montantMarcheBase > 0 ? ((montantCumuleTotalHTBase / montantMarcheBase) * 100).toFixed(2) : 0;
          const pourcentageAvancementAvenants = montantTotalAvenantsHT > 0 ? ((montantCumuleTotalHTAvenants / montantTotalAvenantsHT) * 100).toFixed(2) : 0;
          
          const montantTVA = cert.montant_ht * (tauxTVA / 100);
          const montantTTC = cert.montant_ht + montantTVA;
          const montantCumulePrecedentTTC = montantCumulePrecedentHT * (1 + tauxTVA / 100);
          const montantTVAPrecedent = montantCumulePrecedentHT * (tauxTVA / 100);
          const montantTVACumule = montantCumuleTotalHT * (tauxTVA / 100);
          
          // Retenues détaillées — on utilise computeNetAPayer pour cohérence totale
          const allCertsForExport = [...situationsPrecedentes, cert].sort((a, b) => parseInt(a.numero || 0) - parseInt(b.numero || 0));
          const { netAPayer, rg: retentionGarantieSituation, totalRetenues: retenuesTotalSituation } = computeNetAPayer(cert, allCertsForExport, marche);

          const certTotalPenalties = cert.penalites_appliquees?.reduce((sum, p) => sum + (parseFloat(p.montant_calcule) || 0), 0) || 0;
          const penalitesPrecedentes = situationsPrecedentes.reduce((sum, c) => sum + (c.penalites_appliquees?.reduce((pSum, p) => pSum + (parseFloat(p.montant_calcule) || 0), 0) || 0), 0);
          const penalitesCumulees = penalitesPrecedentes + certTotalPenalties;

          // RG cumulée/précédente (pour les colonnes du tableau)
          const { rg: rgPrec } = situationsPrecedentes.length > 0
            ? computeNetAPayer(situationsPrecedentes[situationsPrecedentes.length - 1], allCertsForExport, marche)
            : { rg: 0 };
          // On calcule la RG cumulée en sommant la RG de chaque situation précédente + celle du cert
          const retentionGarantiePrecedent = situationsPrecedentes.reduce((sum, c) => {
            const { rg } = computeNetAPayer(c, allCertsForExport, marche);
            return sum + rg;
          }, 0);
          const retentionGarantieCumulee = retentionGarantiePrecedent + retentionGarantieSituation;

          const retenuesTotalPrecedent = retentionGarantiePrecedent + penalitesPrecedentes;
          const retenuesTotalCumulee = retentionGarantieCumulee + penalitesCumulees + (cert.montant_cie || 0);

          const totalSousTraitantsTTC = paiementsST.reduce((sum, p) => sum + (parseFloat(p.montant_ht) || 0) * (1 + tauxTVA / 100), 0);
          const netAPayerEntreprise = netAPayer - totalSousTraitantsTTC;

          const data = {
            "{{NUMERO_CP}}": cert.numero, "{{MOIS}}": MOIS_LABELS[cert.mois], "{{ANNEE}}": cert.annee,
            "{{DATE_SITUATION}}": cert.date_situation && new Date(cert.date_situation).toString() !== 'Invalid Date' ? format(new Date(cert.date_situation), "dd/MM/yyyy", { locale: fr }) : '',
            "{{DATE_GENERATION}}": format(new Date(), "dd/MM/yyyy", { locale: fr }),
            "{{CHANTIER_NOM}}": chantier?.nom || '', "{{CHANTIER_ADRESSE}}": chantier?.adresse || '', "{{CHANTIER_CODE_POSTAL}}": chantier?.code_postal || '', "{{CHANTIER_VILLE}}": chantier?.ville || '',
            "{{CLIENT_NOM}}": client?.nom || '', "{{CLIENT_ADRESSE_1}}": client?.adresse_1 || '', "{{CLIENT_CODE_POSTAL}}": client?.code_postal || '', "{{CLIENT_VILLE}}": client?.ville || '', "{{CLIENT_SIRET}}": client?.siret || '',
            "{{ENTREPRISE_NOM}}": entreprise?.nom || '', "{{ENTREPRISE_ADRESSE_1}}": entreprise?.adresse_1 || '', "{{ENTREPRISE_CODE_POSTAL}}": entreprise?.code_postal || '', "{{ENTREPRISE_VILLE}}": entreprise?.ville || '', "{{ENTREPRISE_SIRET}}": entreprise?.siret || '',
            "{{NUMERO_LOT}}": marche?.numero_lot || '', "{{INTITULE_LOT}}": marche?.intitule_lot || '',
            
            // Montants du marché
            "{{MONTANT_MARCHE_BASE_HT}}": montantMarcheBase.toFixed(2).replace('.', ','), 
            "{{MONTANT_MARCHE_BASE_TTC}}": (montantMarcheBase * (1 + tauxTVA / 100)).toFixed(2).replace('.', ','),
            "{{MONTANT_AVENANT_CUMULE_HT}}": montantTotalAvenantsHT.toFixed(2).replace('.', ','),
            "{{NOUVEAU_MONTANT_MARCHE_HT}}": nouveauMontantMarcheHT.toFixed(2).replace('.', ','), 
            "{{NOUVEAU_MONTANT_MARCHE_TTC}}": nouveauMontantMarcheTTC.toFixed(2).replace('.', ','),
            
            // Marché cautionné
            "{{MARCHE_CAUTIONNE}}": marche?.a_caution ? "Oui" : "Non", 
            "{{CAUTION_REFERENCE}}": marche?.cautions?.map(c => c.reference).join(' + ') || '', 
            "{{CAUTION_MONTANT}}": (marche?.cautions?.reduce((sum, c) => sum + (c.montant || 0), 0) || 0).toFixed(2).replace('.', ','),
            
            // Montants de la situation
            "{{MONTANT_SITUATION_HT}}": cert.montant_ht.toFixed(2).replace('.', ','), 
            "{{MONTANT_SITUATION_BASE_HT}}": (cert.montant_ht_base || 0).toFixed(2).replace('.', ','), 
            "{{MONTANT_SITUATION_AVENANT_HT}}": (cert.montant_ht_avenants || 0).toFixed(2).replace('.', ','),
            
            // TVA
            "{{MONTANT_TVA}}": montantTVA.toFixed(2).replace('.', ','), 
            "{{MONTANT_TOTAL_SITUATION_TVA}}": montantTVA.toFixed(2).replace('.', ','),
            "{{TAUX_TVA}}": tauxTVA.toString(), 
            "{{MONTANT_SITUATION_TTC}}": montantTTC.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_SITUATION_TTC}}": montantTTC.toFixed(2).replace('.', ','),
            
            // Avancements - Montants cumulés et précédents
            "{{POURCENTAGE_AVANCEMENT_BASE}}": pourcentageAvancementBase + ' %',
            "{{MONTANT_CUMULE_BASE_HT}}": montantCumuleTotalHTBase.toFixed(2).replace('.', ','), 
            "{{MONTANT_BASE_PRECEDENT_HT}}": montantCumulePrecedentHTBase.toFixed(2).replace('.', ','),
            
            "{{POURCENTAGE_AVANCEMENT_AVENANTS}}": pourcentageAvancementAvenants + ' %',
            "{{MONTANT_CUMULE_AVENANT_HT}}": montantCumuleTotalHTAvenants.toFixed(2).replace('.', ','), 
            "{{MONTANT_AVENANT_PRECEDENT_HT}}": montantCumulePrecedentHTAvenants.toFixed(2).replace('.', ','),
            
            "{{POURCENTAGE_AVANCEMENT}}": ((montantCumuleTotalHT / nouveauMontantMarcheHT) * 100).toFixed(2) + ' %',
            "{{MONTANT_CUMULE_HT}}": montantCumuleTotalHT.toFixed(2).replace('.', ','), 
            "{{MONTANT_PRECEDENT_HT}}": montantCumulePrecedentHT.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_CUMULE_HT}}": montantCumuleTotalHT.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_PRECEDENT_HT}}": montantCumulePrecedentHT.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_SITUATION_HT}}": cert.montant_ht.toFixed(2).replace('.', ','),
            
            "{{MONTANT_CUMULE_TTC}}": montantCumuleTotalTTC.toFixed(2).replace('.', ','), 
            "{{MONTANT_PRECEDENT_TTC}}": montantCumulePrecedentTTC.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_CUMULE_TTC}}": montantCumuleTotalTTC.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_PRECEDENT_TTC}}": montantCumulePrecedentTTC.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_CUMULE_TVA}}": montantTVACumule.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_PRECEDENT_TVA}}": montantTVAPrecedent.toFixed(2).replace('.', ','),
            
            // Retenues
            "{{RETENUE_GARANTIE_CUMULE}}": retentionGarantieCumulee.toFixed(2).replace('.', ','),
            "{{RETENUE_GARANTIE_PRECEDENT}}": retentionGarantiePrecedent.toFixed(2).replace('.', ','),
            "{{RETENUE_GARANTIE}}": retentionGarantieSituation.toFixed(2).replace('.', ','),
            
            "{{RETENUE_PENALITES_CUMULE}}": penalitesCumulees.toFixed(2).replace('.', ','),
            "{{RETENUE_PENALITES_PRECEDENT}}": penalitesPrecedentes.toFixed(2).replace('.', ','),
            "{{RETENUE_PENALITES_SITUATION}}": certTotalPenalties.toFixed(2).replace('.', ','),
            "{{MONTANT_PENALITES}}": certTotalPenalties.toFixed(2).replace('.', ','),
            
            "{{RETENUE_AUTRES_CUMULE}}": (cert.montant_cie || 0).toFixed(2).replace('.', ','),
            "{{RETENUE_AUTRES_PRECEDENT}}": "0,00",
            "{{RETENUE_AUTRES_SITUATION}}": (cert.montant_cie || 0).toFixed(2).replace('.', ','),
            "{{MONTANT_CIE}}": (cert.montant_cie || 0).toFixed(2).replace('.', ','),
            
            "{{RETENUES_TOTAL_CUMULE}}": retenuesTotalCumulee.toFixed(2).replace('.', ','),
            "{{RETENUE_TOTAL_PRECEDENT}}": retenuesTotalPrecedent.toFixed(2).replace('.', ','),
            "{{RETENUE_TOTAL_SITUATION}}": retenuesTotalSituation.toFixed(2).replace('.', ','),
            "{{TOTAL_DEDUCTIONS}}": retenuesTotalSituation.toFixed(2).replace('.', ','),
            
            // Net à payer
            "{{NET_A_PAYER}}": netAPayer.toFixed(2).replace('.', ','), 
            "{{NET_A_PAYER_ENTREPRISE}}": netAPayerEntreprise.toFixed(2).replace('.', ','),
            
            // Reste à payer
            "{{RESTE_A_PAYER_HT}}": (nouveauMontantMarcheHT - montantCumuleTotalHT).toFixed(2).replace('.', ','), 
            "{{RESTE_A_PAYER_TTC}}": (nouveauMontantMarcheTTC - montantCumuleTotalTTC).toFixed(2).replace('.', ','),
            
            // Info GESTIONBAT
            "{{GESTIONBAT_NOM}}": infoGestionbat?.nom_entreprise || 'GESTIONBAT', 
            "{{GESTIONBAT_ADRESSE}}": infoGestionbat?.adresse || '', 
            "{{GESTIONBAT_CODE_POSTAL}}": infoGestionbat?.code_postal || '', 
            "{{GESTIONBAT_VILLE}}": infoGestionbat?.ville || '', 
            "{{GESTIONBAT_TELEPHONE}}": infoGestionbat?.telephone || '', 
            "{{GESTIONBAT_SIRET}}": infoGestionbat?.siret || '',
          };
          // Avenants
          avenantsDeLEntreprise?.forEach((av, i) => { 
            data[`{{AVENANT_${i+1}_NUMERO}}`] = av.numero; 
            data[`{{AVENANT_${i+1}_HT}}`] = (av.montant_total_ht || 0).toFixed(2).replace('.', ','); 
            data[`{{AVENANT_${i+1}_TTC}}`] = ((av.montant_total_ht || 0) * (1 + tauxTVA / 100)).toFixed(2).replace('.', ','); 
          });
          
          // Sous-traitants
          paiementsST?.forEach((st, i) => { 
            const ste = entreprises.find(e => e.id === st.entreprise_id); 
            data[`{{ST_${i+1}_NOM}}`] = ste?.nom || ''; 
            data[`{{ST_${i+1}_MONTANT_HT}}`] = (parseFloat(st.montant_ht) || 0).toFixed(2).replace('.', ','); 
            data[`{{ST_${i+1}_MONTANT_TTC}}`] = ((parseFloat(st.montant_ht) || 0) * (1 + tauxTVA / 100)).toFixed(2).replace('.', ','); 
          });
          
          // Historique des 18 situations : net à payer TTC de chaque CP individuel
          // Calcul progressif de la RG cumulée (sans filtre date caution) pour cohérence
          // avec le NET_A_PAYER produit au moment de la génération de chaque CP
          const allCertsSorted = [...situationsPrecedentes, cert].sort((a, b) => parseInt(a.numero || 0) - parseInt(b.numero || 0));
          const toursLotCautions = marche?.cautions || [];
          const pad2 = (n) => String(n).padStart(2, "0");
          let cumulTTCHisto = 0;
          for (let i = 1; i <= 18; i++) {
            const certSit = allCertsSorted.find(c => parseInt(c.numero || 0) === i);
            if (certSit) {
              const htSit = (certSit.montant_ht_base || 0) + (certSit.montant_ht_avenants || 0) > 0
                ? (certSit.montant_ht_base || 0) + (certSit.montant_ht_avenants || 0)
                : (certSit.montant_ht || 0);
              const ttcSit = htSit * (1 + tauxTVA / 100);

              // Cautions reçues JUSQU'AU mois de cette situation seulement
              const sitYear = parseInt(certSit.annee || new Date().getFullYear());
              const sitMonth = parseInt(certSit.mois || 1);
              const dernierJourSit = `${sitYear}-${pad2(sitMonth)}-${pad2(new Date(sitYear, sitMonth, 0).getDate())}`;
              const getCautionDate = (c) => c.date_reception?.substring(0, 10) || c.date_ajout?.substring(0, 10) || dernierJourSit;
              const cautionsAvantSit = toursLotCautions
                .filter(c => getCautionDate(c) < `${sitYear}-${pad2(sitMonth)}-01`)
                .reduce((s, c) => s + (c.montant || 0), 0);
              const cautionsJusquASit = toursLotCautions
                .filter(c => getCautionDate(c) <= dernierJourSit)
                .reduce((s, c) => s + (c.montant || 0), 0);

              const rgAvantSit = Math.max(0, cumulTTCHisto * 0.05 - cautionsAvantSit);
              cumulTTCHisto += ttcSit;
              const rgApresSit = Math.max(0, cumulTTCHisto * 0.05 - cautionsJusquASit);
              // RG peut être négative (remboursement) — ne pas bloquer à 0
              const rgSit = rgApresSit - rgAvantSit;
              const penSit = (certSit.penalites_appliquees || []).reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0) - (certSit.remboursement_penalites || 0);
              const cieSit = certSit.montant_cie || 0;
              const deblocageSit = certSit.deblocage_rg || 0;
              const netSit = ttcSit - rgSit - penSit - cieSit + deblocageSit;
              data[`{{MONTANT_NET_PAYE_SITUATION_${i}_TTC}}`] = netSit.toFixed(2).replace('.', ',');
            } else {
              data[`{{MONTANT_NET_PAYE_SITUATION_${i}_TTC}}`] = "0,00";
            }
          }
          const response = await base44.functions.invoke('fillExcelTemplate', { template_url: trameCertificat, data });
          // Le service externe retourne { filled_excel_base64: "..." }, gérons les deux formats
          const rawBase64 = response.data.file_base64;
          const base64String = typeof rawBase64 === 'string' ? rawBase64 : (rawBase64?.filled_excel_base64 || null);
          if (response.data.success && base64String) {
            const byteArray = new Uint8Array(atob(base64String).split('').map(c => c.charCodeAt(0)));
            const blob = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = buildFileName(cert, marche, entreprise, 'xlsx'); document.body.appendChild(link); link.click(); document.body.removeChild(link);
            toast.success("✅ Certificat généré !", { id: "certificat-generation" }); setExporting(false); return;
          } else throw new Error("La réponse de l'API ne contient pas de fichier");
        } catch (apiError) { toast.error("⚠️ Échec du remplissage automatique", { description: "Génération du PDF standard...", id: "certificat-generation" }); }
      }

      // Sous-traitance : résolution par numero_lot (code métier)
      const contratsSousTraitance = sousTraitances.filter(st => st.numero_lot === marche?.numero_lot && st.statut !== 'suspendu');
      const generateHtmlExport = selectTemplateGenerator(effectiveClientId);
      const htmlContent = generateHtmlExport({ certificat: cert, chantier, client, entreprise, marche, situationsPrecedentes, avenantsDeLEntreprise, paiementsSousTraitants: paiementsST, contratsSousTraitance, penalitesAppliquees: cert.penalites_appliquees || [], infoGestionbat, partenaires, entreprises, tauxTVA, logoMoeUrl: infoGestionbat?.logo_url || null, logoClientUrl: client?.logo_client_url || chantier?.logo_client_url || null });
      toast.loading("Conversion en PDF...", { id: "certificat-generation" });
      const response = await base44.functions.invoke('htmlToPdf', { html_content: htmlContent, css: '' });
      if (response.data?.success && response.data.pdf_base64) {
        const factureUrls = cert.factures_urls && cert.factures_urls.length > 0 ? cert.factures_urls : (cert.facture_pdf_url ? [cert.facture_pdf_url] : []);
        const pdfFinal = await mergePdfsWithDocuments(response.data.pdf_base64, factureUrls, "certificat-generation");
        toast.dismiss("certificat-generation");
        const byteArray = new Uint8Array(atob(pdfFinal).split('').map(c => c.charCodeAt(0)));
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = buildFileName(cert, marche, entreprise, 'pdf'); document.body.appendChild(link); link.click(); document.body.removeChild(link);
        toast.success("✅ Certificat téléchargé !", { description: cert.facture_pdf_url ? "Certificat et facture fusionnés" : "Le PDF a été téléchargé" });
        if (cert.statut === 'brouillon') { await base44.entities.CertificatPaiement.update(cert.id, { statut: 'valide' }); queryClient.invalidateQueries({ queryKey: ['certificats'] }); }
      } else throw new Error(response.data?.error || "La conversion PDF a échoué");
    } catch (error) {
      toast.error("Erreur", { description: error.message, id: "certificat-generation" });
    } finally { setExporting(false); }
  };

  const handleUploadFacturesGlobale = async (cert, files) => {
    if (!files || files.length === 0) return;
    setUploadingPDF(true);
    try {
      const uploadedUrls = [];
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploadedUrls.push(file_url);
      }
      const existingUrls = cert.factures_urls && cert.factures_urls.length > 0
        ? cert.factures_urls
        : (cert.facture_pdf_url ? [cert.facture_pdf_url] : []);
      const newUrls = [...existingUrls, ...uploadedUrls];
      await base44.entities.CertificatPaiement.update(cert.id, {
        factures_urls: newUrls,
        facture_pdf_url: newUrls[0] || cert.facture_pdf_url
      });
      queryClient.invalidateQueries({ queryKey: ['certificats'] });
      toast.success(`${uploadedUrls.length} facture(s) ajoutée(s)`);
    } catch (error) {
      toast.error("Erreur upload", { description: error.message });
    } finally {
      setUploadingPDF(false);
    }
  };

  const handleRemoveFactureGlobale = async (cert, idx) => {
    const existingUrls = cert.factures_urls && cert.factures_urls.length > 0
      ? cert.factures_urls
      : (cert.facture_pdf_url ? [cert.facture_pdf_url] : []);
    const newUrls = existingUrls.filter((_, i) => i !== idx);
    await base44.entities.CertificatPaiement.update(cert.id, {
      factures_urls: newUrls,
      facture_pdf_url: newUrls[0] || ''
    });
    queryClient.invalidateQueries({ queryKey: ['certificats'] });
    toast.success("Facture supprimée");
  };

  const handleExportSuivi = async () => {
    if (certificats.length === 0) { toast.error("Aucune donnée", { description: "Aucun certificat à exporter" }); return; }
    setExporting(true);
    try {
      const certificatsValides = certificats.filter(c => c.statut === "valide");
      const periodesUniques = [...new Set(certificatsValides.map(c => `${c.annee}-${c.mois}`))].sort();
      const allMarcheIds = [...new Set([...marches.map(m => m.id), ...certificatsValides.map(c => c.marche_id).filter(Boolean)])];
      const lotsData = allMarcheIds.map(marcheId => {
        const marche = marches.find(m => m.id === marcheId);
        const ent = entreprises.find(e => e.id === marche?.entreprise_id);
        const avenantsLot = avenants.filter(a => (a.marche_id === marcheId || (!a.marche_id && a.entreprise_id === marche?.entreprise_id)) && (a.statut === 'valide' || a.statut === 'signe'));
        return { marcheId, nom: ent?.nom || "Entreprise inconnue", intitule_lot: marche?.intitule_lot || '', numero_lot: marche?.numero_lot || '', montantMarche: (marche?.montant || 0) + avenantsLot.reduce((sum, a) => sum + (a.montant_total_ht || 0), 0) };
      }).sort((a, b) => a.numero_lot.localeCompare(b.numero_lot, undefined, { numeric: true }));

      const matrixData = lotsData.map(lot => {
        const rowData = { entreprise: lot.nom, intitule_lot: lot.intitule_lot, numero_lot: lot.numero_lot, montantMarche: lot.montantMarche, totaux: 0 };
        periodesUniques.forEach(periode => {
          const [annee, mois] = periode.split('-');
          const certsForPeriode = certificatsValides.filter(c => (c.marche_id === lot.marcheId || (!c.marche_id && c.entreprise_id === marches.find(m => m.id === lot.marcheId)?.entreprise_id)) && c.annee === annee && c.mois === mois);
          const netHT = certsForPeriode.reduce((sum, cert) => sum + (cert.montant_ht || 0) - (cert.penalites_appliquees?.reduce((pSum, p) => pSum + (parseFloat(p.montant_calcule) || 0), 0) || 0), 0);
          rowData[periode] = certsForPeriode.length > 0 ? netHT : 0;
          rowData.totaux += rowData[periode];
        });
        return rowData;
      });

      const columnTotals = {}; let grandTotal = 0;
      periodesUniques.forEach(p => { columnTotals[p] = matrixData.reduce((sum, row) => sum + (row[p] || 0), 0); grandTotal += columnTotals[p]; });
      const totalMontantMarches = matrixData.reduce((sum, row) => sum + row.montantMarche, 0);
      const pctAvancementGlobal = totalMontantMarches > 0 ? ((grandTotal / totalMontantMarches) * 100).toFixed(1) : '-';

      const clientPourLogo = clients.find(c => c.id === chantier?.client_id) || clients.find(c => c.id === chantier?.client_2_id);
      const logoClientUrl = clientPourLogo?.logo_client_url || chantier?.logo_client_url;
      const logoClient = logoClientUrl ? `<img src="${logoClientUrl}" alt="" style="max-width:150px;max-height:70px;object-fit:contain;">` : '';
      const logoGestionbat = infoGestionbat?.logo_url ? `<img src="${infoGestionbat.logo_url}" alt="" style="max-width:150px;max-height:70px;object-fit:contain;">` : '<p style="font-weight:bold;color:#f97316;font-size:16pt;">GESTIONBAT</p>';
      const partenairesData = (chantier?.partenaires || []).map(p => { const part = partenaires.find(x => x.id === p.partenaire_id); return part ? { nom: part.nom, role: (p.role || '').toLowerCase() } : null; }).filter(Boolean);
      const architecte = partenairesData.find(p => p.role.includes('architecte'));
      const partenairesOrdonnes = []; if (architecte) partenairesOrdonnes.push(architecte.nom); partenairesOrdonnes.push(infoGestionbat?.nom_entreprise || 'GESTIONBAT'); partenairesData.filter(p => !p.role.includes('architecte')).forEach(p => partenairesOrdonnes.push(p.nom));

      // Calcul des cumulatifs par lot pour les % d'avancement
      const htmlContent = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Récapitulatif Avancements</title><style>@page{size:A4 landscape;margin:1cm}body{font-family:'Calibri',Arial,sans-serif;font-size:8pt;margin:0;padding:10px;padding-bottom:55px;color:#000}.header-container{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.header-logo-left,.header-logo-right{flex:0 0 150px;width:150px;text-align:center}.header-center{flex:1;text-align:center}.header-chantier-nom{font-size:13pt;font-weight:bold;color:#f97316;text-transform:uppercase}.doc-title-row{text-align:center;margin-bottom:12px;padding-top:10px;border-top:2px solid #f97316}.doc-title-row h1{font-size:13pt;font-weight:bold;text-transform:uppercase}table{width:100%;border-collapse:collapse;font-size:7pt}th{background-color:#f97316;color:white;padding:4px 3px;text-align:center;font-weight:bold;border:1px solid #e86710}td{padding:3px;border:1px solid #ddd;line-height:1.4}tr{page-break-inside:avoid}tr:nth-child(even){background-color:#f9f9f9}.total-row{font-size:6pt;font-weight:bold;background-color:#ffe0b2!important;border-top:2px solid #f97316;page-break-inside:avoid}.pct-mens{display:block;font-size:5.5pt;color:#777;margin-top:1px}.pct-cum{display:block;font-size:5.5pt;color:#f97316;font-weight:bold}.footer{position:fixed;bottom:0;left:0;right:0;height:45px;font-size:7pt;color:#666;background:white}.footer-line{border-top:1px solid #ccc;margin:0 1cm 5px 1cm}.footer-content{display:flex;justify-content:space-between;padding:0 1cm}@media print{body{padding-bottom:55px}.footer{position:fixed;bottom:0}}</style></head><body>
      <div class="header-container"><div class="header-logo-left">${logoClient}</div><div class="header-center"><div class="header-chantier-nom">${chantier?.nom || ''}</div><div>${chantier?.adresse || ''}</div></div><div class="header-logo-right">${logoGestionbat}</div></div>
      <div class="doc-title-row"><h1>Récapitulatif Avancements</h1><p>Récapitulatif des situations validées (Net HT)</p></div>
      <table><thead><tr><th style="text-align:left;width:50px">N° Lot</th><th style="text-align:left;width:130px">Intitulé</th><th style="text-align:left;width:130px">Entreprise</th><th style="text-align:right;width:100px">Montant marché HT</th>${periodesUniques.map(p => { const [a, m] = p.split('-'); return '<th style="text-align:center;min-width:70px">' + MOIS_LABELS[m]?.substring(0,3) + ' ' + a + '</th>'; }).join('')}<th style="text-align:right;width:110px">Total avancement</th><th style="text-align:right;width:70px">%Avancement</th></tr></thead>
      <tbody>${matrixData.map(row => { const pct = row.montantMarche > 0 ? ((row.totaux / row.montantMarche) * 100).toFixed(1) : '-'; let cumulatif = 0; const cells = periodesUniques.map(p => { const montantP = row[p] || 0; if (montantP > 0) cumulatif += montantP; const pctMens = row.montantMarche > 0 && montantP > 0 ? ((montantP / row.montantMarche) * 100).toFixed(1) : null; const pctCum = row.montantMarche > 0 && cumulatif > 0 ? ((cumulatif / row.montantMarche) * 100).toFixed(1) : null; return '<td style="text-align:right">' + (montantP > 0 ? montantP.toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €' : '-') + (pctMens ? '<span class="pct-mens">' + pctMens + ' % mens.</span><span class="pct-cum">' + pctCum + ' % cum.</span>' : '') + '</td>'; }).join(''); return '<tr><td style="font-weight:bold">' + (row.numero_lot || '-') + '</td><td>' + (row.intitule_lot || '-') + '</td><td>' + row.entreprise + '</td><td style="text-align:right">' + row.montantMarche.toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €</td>' + cells + '<td style="text-align:right;font-weight:bold;background-color:#fff3e0">' + row.totaux.toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €</td><td style="text-align:right;font-weight:bold;color:#f97316">' + pct + (pct !== '-' ? ' %' : '') + '</td></tr>'; }).join('')}
      ${(() => { let cumTot = 0; const totalCells = periodesUniques.map(p => { cumTot += columnTotals[p]; const pctMens = totalMontantMarches > 0 && columnTotals[p] > 0 ? ((columnTotals[p]/totalMontantMarches)*100).toFixed(1) : null; const pctCum = totalMontantMarches > 0 && cumTot > 0 ? ((cumTot/totalMontantMarches)*100).toFixed(1) : null; return '<td style="text-align:right;font-weight:bold">' + columnTotals[p].toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €' + (pctMens ? '<span class="pct-mens">' + pctMens + ' % mens.</span><span class="pct-cum">' + pctCum + ' % cum.</span>' : '') + '</td>'; }).join(''); return '<tr class="total-row"><td></td><td></td><td>TOTAL GÉNÉRAL</td><td style="text-align:right">' + totalMontantMarches.toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €</td>' + totalCells + '<td style="text-align:right">' + grandTotal.toLocaleString('fr-FR', {minimumFractionDigits:2}) + ' €</td><td style="text-align:right">' + pctAvancementGlobal + (pctAvancementGlobal !== '-' ? ' %' : '') + '</td></tr>'; })()}
      </tbody></table>
      <div class="footer"><div class="footer-line"></div><div class="footer-content"><div>${partenairesOrdonnes.join(' / ')}</div><div>Page 1</div><div>${format(new Date(), 'dd/MM/yyyy', { locale: fr })}</div></div></div>
      </body></html>`;

      toast.loading("Conversion en PDF...", { id: "export-suivi" });
      const response = await base44.functions.invoke('htmlToPdf', { html_content: htmlContent, css: '' });
      if (response.data?.success && response.data.pdf_base64) {
        const byteArray = new Uint8Array(atob(response.data.pdf_base64).split('').map(c => c.charCodeAt(0)));
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `recapitulatif_avancements_${(chantier?.nom || 'chantier').replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.pdf`; document.body.appendChild(link); link.click(); document.body.removeChild(link);
        toast.success("Export réussi", { id: "export-suivi" });
      } else throw new Error(response.data?.error || "La conversion PDF a échoué");
    } catch (error) {
      toast.error("Erreur", { description: error.message });
    } finally { setExporting(false); }
  };

  const renderCertificatRow = (cert) => (
    <TableRow key={cert.id} className="hover:bg-gray-50">
      <TableCell className="font-mono font-semibold">{cert.numero}</TableCell>
      <TableCell className="font-medium">{MOIS_LABELS[cert.mois]} {cert.annee}</TableCell>
      <TableCell>{cert.date_facture && new Date(cert.date_facture).toString() !== 'Invalid Date' ? format(new Date(cert.date_facture), "dd/MM/yyyy", { locale: fr }) : 'Date non définie'}</TableCell>
      <TableCell className="font-semibold text-orange-600">
        {(cert.montant_ht || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
        {cert.is_remboursement_rg && <span className="ml-1 text-xs bg-emerald-100 text-emerald-700 border border-emerald-300 rounded px-1 font-semibold">RG</span>}
      </TableCell>
      <TableCell>{cert.facture_pdf_url ? (<a href={cert.facture_pdf_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center gap-1"><FileText className="w-4 h-4" />PDF</a>) : (<span className="text-gray-400">-</span>)}</TableCell>
      <TableCell>
        <div className="flex gap-2">
          <Badge className={cert.statut === "valide" ? "bg-green-100 text-green-800 border-green-200 border" : "bg-yellow-100 text-yellow-800 border-yellow-200 border"}>{cert.statut === "valide" ? "Validé" : "Brouillon"}</Badge>
          {cert.est_cloture && (<Badge className="bg-gray-100 text-gray-800 border-gray-200 border flex items-center gap-1"><Lock className="w-3 h-3" /> Clôturé</Badge>)}
        </div>
      </TableCell>
      <TableCell>
        <div className="flex gap-1 flex-wrap">
          {cert.statut === "brouillon" && !cert.est_cloture && (<Button variant="ghost" size="icon" onClick={() => handleValidate(cert)} title="Valider"><Badge className="w-4 h-4 bg-green-600" /></Button>)}
          {cert.statut === "valide" && (<><Button variant="ghost" size="icon" onClick={() => handlePreviewCP(cert)} title="Prévisualiser" disabled={previewing}><Eye className="w-4 h-4 text-blue-600" /></Button><Button variant="ghost" size="icon" onClick={() => handleExportCP(cert)} title="Télécharger PDF" disabled={exporting}><Download className="w-4 h-4 text-green-600" /></Button></>)}
          {!cert.est_cloture && (<><Button variant="ghost" size="icon" onClick={() => handleEdit(cert)} title="Modifier"><Pencil className="w-4 h-4" /></Button><Button variant="ghost" size="icon" onClick={() => handleDelete(cert)} title="Supprimer"><Trash2 className="w-4 h-4 text-red-500" /></Button></>)}
          {cert.est_cloture && isAdmin && (<Button variant="ghost" size="icon" onClick={() => annulerClotureMutation.mutate(cert.id)} title="Annuler la clôture" disabled={annulerClotureMutation.isPending}><LockOpen className="w-4 h-4 text-orange-500" /></Button>)}
        </div>
      </TableCell>
    </TableRow>
  );

  return (
    <div className="space-y-6">
      {/* Onglets principaux */}
      <div className="flex gap-2 border-b">
        <button
          onClick={() => setMainTab("certificats")}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            mainTab === "certificats"
              ? "border-orange-500 text-orange-600"
              : "border-transparent text-gray-500 hover:text-gray-700"
          }`}
        >
          Certificats de paiement
        </button>
        <button
          onClick={() => setMainTab("envoyes")}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            mainTab === "envoyes"
              ? "border-orange-500 text-orange-600"
              : "border-transparent text-gray-500 hover:text-gray-700"
          }`}
        >
          CP Envoyés MOE
        </button>
      </div>

      {mainTab === "envoyes" && (
        <CertificatsEnvoyesMOE chantierId={chantierId} />
      )}

      {mainTab === "certificats" && <>
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Certificats de paiement</h2>
          <p className="text-sm text-gray-600 mt-1">
            Gestion des situations mensuelles
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button 
            variant="outline"
            className="gap-2 border-orange-200 text-orange-700 hover:bg-orange-50"
            onClick={() => setShowClotureDialog(true)}
          >
            <Lock className="w-4 h-4" />
            Clôturer le mois
          </Button>
          {certificats.length > 0 && (
            <Button 
              variant="outline"
              className="gap-2"
              onClick={handleExportSuivi}
              disabled={exporting}
            >
              <Download className="w-4 h-4" />
              Récapitulatif avancements
            </Button>
          )}
          <Button
            variant="outline"
            className="gap-2 border-green-200 text-green-700 hover:bg-green-50"
            onClick={() => setShowImportDialog(true)}
          >
            <Upload className="w-4 h-4" />
            Import Excel
          </Button>
          <Button 
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={() => {
              resetForm();
              setShowDialog(true);
            }}
          >
            <Plus className="w-5 h-5" />
            Nouvelle situation
          </Button>
        </div>
      </div>

      {certificats.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">
            Aucune situation enregistrée
          </h3>
          <p className="text-gray-500">
            Ajoutez votre première situation mensuelle pour commencer
          </p>
        </Card>
      ) : (
        <>
          <Tabs value={viewMode} onValueChange={setViewMode} className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="by-entreprise" className="gap-2">
                <FolderOpen className="w-4 h-4" />
                Par lot
              </TabsTrigger>
              <TabsTrigger value="all" className="gap-2">
                <FileText className="w-4 h-4" />
                Vue globale
              </TabsTrigger>
            </TabsList>

            <TabsContent value="by-entreprise" className="space-y-4 mt-6">
              {certificatsParLot.length === 0 ? (
                <Card className="p-8 text-center">
                  <p className="text-gray-500">Aucun certificat disponible</p>
                </Card>
              ) : (
                <Accordion type="multiple" className="space-y-4">
                  {certificatsParLot.map((groupe) => (
                    <AccordionItem 
                      key={groupe.groupKey} 
                      value={groupe.groupKey}
                      className="border rounded-lg overflow-hidden bg-white shadow-sm"
                    >
                      <AccordionTrigger className="px-6 py-4 hover:bg-gray-50 hover:no-underline">
                        <div className="flex items-center justify-between w-full pr-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                              <Building className="w-5 h-5 text-orange-600" />
                            </div>
                            <div className="text-left">
                              <h3 className="font-semibold text-lg text-gray-900 flex items-center gap-2 flex-wrap">
                                {groupe.marche?.numero_lot ? <span className="text-orange-600">Lot {groupe.marche.numero_lot}</span> : null}
                                {groupe.marche?.intitule_lot || groupe.entreprise?.nom || 'Lot non spécifié'}
                                {groupe.marche?.numero_marche && (
                                  <span className="text-xs font-mono bg-orange-100 text-orange-700 border border-orange-200 rounded px-1.5 py-0.5">
                                    Marché N°{groupe.marche.numero_marche}
                                  </span>
                                )}
                              </h3>
                              <p className="text-sm text-gray-500">
                                {groupe.entreprise?.nom} • {groupe.certificats.length} situation{groupe.certificats.length > 1 ? 's' : ''} • 
                                {groupe.certificats.filter(c => c.statut === 'valide').length} validée{groupe.certificats.filter(c => c.statut === 'valide').length > 1 ? 's' : ''}
                              </p>
                            </div>
                          </div>
                          <div className="text-right mr-2">
                            <div className="flex gap-8 text-right items-end">
                                <div>
                                    <p className="text-sm text-gray-500">Montant marché</p>
                                    <p className="text-xl font-bold text-gray-700">
                                    {groupe.montantMarcheTotal.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                                    </p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Montant cumulé validé</p>
                                    <p className="text-2xl font-bold text-orange-600">
                                    {groupe.montantValide.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                                    </p>
                                    {groupe.montantTotal !== groupe.montantValide && (
                                    <p className="text-xs text-gray-400">
                                        Total : {groupe.montantTotal.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                                    </p>
                                    )}
                                </div>
                            </div>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-0 pb-0">
                        <div className="border-t">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-gray-50">
                                <TableHead>N° CP</TableHead>
                                <TableHead>Période</TableHead>
                                <TableHead>Date facture</TableHead>
                                <TableHead>Montant HT</TableHead>
                                <TableHead>Facture</TableHead>
                                <TableHead>Statut</TableHead>
                                <TableHead className="w-24">Actions</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {groupe.certificats.map(cert => renderCertificatRow(cert))}
                            </TableBody>
                          </Table>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </TabsContent>

            <TabsContent value="all" className="mt-6">
              <CertificatsVueGlobale
                certificats={certificats}
                marches={marches}
                avenants={avenants}
                getEntrepriseName={getEntrepriseName}
                handlePreviewCP={handlePreviewCP}
                handleExportCP={handleExportCP}
                handleEdit={handleEdit}
                handleDelete={handleDelete}
                handleValidate={handleValidate}
                previewing={previewing}
                exporting={exporting}
                handleUploadFactures={handleUploadFacturesGlobale}
                handleRemoveFacture={handleRemoveFactureGlobale}
                getFileName={getFileName}
                uploadingPDF={uploadingPDF}
              />
            </TabsContent>
          </Tabs>
        </>
      )}
      </>}

      <CertificatFormDialog
        showDialog={showDialog} setShowDialog={setShowDialog}
        selectedCertificat={selectedCertificat} handleSubmit={handleSubmit}
        formData={formData} setFormData={setFormData}
        chantier={chantier} clients={clients} marches={marches} entreprises={entreprises}
        entreprisesSousTraitantes={entreprisesSousTraitantes}
        createMutation={createMutation} updateMutation={updateMutation}
        uploadingPDF={uploadingPDF} handlePDFUpload={handlePDFUpload}
        handleAddSousTraitant={handleAddSousTraitant} handleRemoveSousTraitant={handleRemoveSousTraitant} handleUpdateSousTraitant={handleUpdateSousTraitant}
        handleAddPenalite={handleAddPenalite} handleRemovePenalite={handleRemovePenalite} handleUpdatePenalite={handleUpdatePenalite}
        montantCumuleSituationsPrecedentes={montantCumuleSituationsPrecedentes}
        montantCumuleMarcheBasePrecedentes={montantCumuleMarcheBasePrecedentes}
        montantCumuleAvenantsPrecedentes={montantCumuleAvenantsPrecedentes}
        montantNouveauMarcheHT={montantNouveauMarcheHT}
        montantTotalPenalites={montantTotalPenalites} montantTotalPenalitesPrecedentes={montantTotalPenalitesPrecedentes}
        currentCIEAmount={currentCIEAmount} getPendingCIE={getPendingCIE}
        resetForm={resetForm} getFileName={getFileName}
        avenants={avenants} certificats={certificats}
      />

      <ImportSituationsDialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
        chantierId={chantierId}
        marches={marches}
        entreprises={entreprises}
        chantier={chantier}
        clients={clients}
        tranches={chantier?.tranches || []}
        onImportSuccess={() => queryClient.invalidateQueries({ queryKey: ['certificats'] })}
      />

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer cette situation ? Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCertificatToDelete(null)}>
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showClotureDialog} onOpenChange={setShowClotureDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Clôturer le mois</DialogTitle>
            <DialogDescription>
              Cette action figera tous les certificats validés du mois sélectionné. 
              Ils ne pourront plus être modifiés et ne seront plus affectés par les nouveaux avenants.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label>Mois</Label>
              <Select
                value={clotureData.mois}
                onValueChange={(val) => setClotureData({...clotureData, mois: val})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(MOIS_LABELS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Année</Label>
              <Select
                value={clotureData.annee}
                onValueChange={(val) => setClotureData({...clotureData, annee: val})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {YEARS.map(year => (
                    <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowClotureDialog(false)}>
              Annuler
            </Button>
            <Button 
              className="bg-orange-600 hover:bg-orange-700 gap-2"
              onClick={() => clotureMutation.mutate(clotureData)}
              disabled={clotureMutation.isPending}
            >
              {clotureMutation.isPending ? "Clôture..." : <><Lock className="w-4 h-4" /> Clôturer</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}