import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Download, FileText, Pencil, Trash2, X, CheckSquare, Square, Building, Upload, FileCheck, Filter, Eye, FileSpreadsheet } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";
import { getAvenantHtmlTemplate } from "@/components/templates/AvenantHtmlTemplate";
import { generatePdfHtml } from "@/components/templates/PdfExportGenerator";
import { mergePdfsWithDocuments } from '@/components/utils/pdfMerger';
import PdfPreviewDialog from '@/components/common/PdfPreviewDialog';
import DevisTab from '@/components/travaux-sup/DevisTab';
import SuiviFinancierTab from '@/components/travaux-sup/SuiviFinancierTab';
import AvenantsListSection from '@/components/travaux-sup/AvenantsListSection';
import ImportDevisDialog from '@/components/travaux-sup/ImportDevisDialog';
import { exportDevisExcel, exportAvenantsExcel } from '@/components/travaux-sup/exportUtils';
import * as XLSX from "xlsx";

const statutColors = {
  brouillon: "bg-yellow-100 text-yellow-800 border-yellow-200",
  valide: "bg-green-100 text-green-800 border-green-200",
  integre_avenant: "bg-blue-100 text-blue-800 border-blue-200"
};

const statutLabels = {
  brouillon: "Brouillon",
  valide: "Validé",
  integre_avenant: "Intégré à avenant"
};

const TYPE_DEVIS_OPTIONS = ["TMA", "TS"];
const ORIGINE_DEVIS_OPTIONS = ["Aléas chantier", "Demande MOA", "Anomalie conception"];

export default function TravauxSupTab({ chantierId }) {
  // ⚠️ COMPOSANT FIGÉ v2.7.6 FINAL - NE PAS MODIFIER SANS VALIDATION
  // - Export PDF Suivi Financier : Logo CLIENT à gauche, Logo GESTIONBAT à droite
  // - Footer PDF : Architecte / GESTIONBAT / Autres partenaires (ordre strict)
  // - Toasts : Tous les appels toast.* sont figés et standardisés
  // - Template d'avenant PDF : Fallback figé avec HTML instructions Ctrl+P
  // ========================================================================

  const [showDevisDialog, setShowDevisDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showAvenantDialog, setShowAvenantDialog] = useState(false);
  const [showDeleteAvenantDialog, setShowDeleteAvenantDialog] = useState(false);
  const [selectedDevis, setSelectedDevis] = useState(null);
  const [selectedAvenant, setSelectedAvenant] = useState(null);
  const [devisToDelete, setDevisToDelete] = useState(null);
  const [avenantToDelete, setAvenantToDelete] = useState(null);
  const [selectedDevisIds, setSelectedDevisIds] = useState([]);
  const [uploadingPDF, setUploadingPDF] = useState(false);
  const [generatingAvenant, setGeneratingAvenant] = useState(false);
  const [activeTab, setActiveTab] = useState("devis");

  const [generatingAvenantPDF, setGeneratingAvenantPDF] = useState(false);
  const [previewingAvenant, setPreviewingAvenant] = useState(false);
  const [filterEntreprise, setFilterEntreprise] = useState("all");
  const [filterStatut, setFilterStatut] = useState("all");
  const [highlightedAvenantId, setHighlightedAvenantId] = useState(null);
  const [openAccordionItems, setOpenAccordionItems] = useState([]);
  
  // Prévisualisation PDF
  const [showPreviewDialog, setShowPreviewDialog] = useState(false);
  const [previewPdfBase64, setPreviewPdfBase64] = useState(null);
  const [previewFileName, setPreviewFileName] = useState("");
  const [previewDownloadAction, setPreviewDownloadAction] = useState(null);

  const [formData, setFormData] = useState({
    marche_id: "",
    entreprise_id: "",
    client_id: "",
    numero_devis: "",
    date_devis: "",
    intitule_devis: "",
    montant_ht: "",
    type_devis: "TS",
    tranche_numero: "",
    origine_devis: "",
    devis_pdf_url: "",
    statut: "brouillon",
    notes: ""
  });

  const queryClient = useQueryClient();

  const { data: devis, isLoading: loadingDevis } = useQuery({
    queryKey: ['travaux-sup', chantierId],
    queryFn: async () => {
      const allDevis = await base44.entities.TravauxSupplementaire.list('-date_devis');
      return allDevis.filter(d => d.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: avenants, isLoading: loadingAvenants } = useQuery({
    queryKey: ['avenants', chantierId],
    queryFn: async () => {
      const allAvenants = await base44.entities.Avenant.list('-numero');
      return allAvenants.filter(a => a.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: chantier } = useQuery({
    queryKey: ['chantier', chantierId],
    queryFn: async () => {
      const chantiers = await base44.entities.Chantier.list();
      return chantiers.find(c => c.id === chantierId);
    },
    enabled: !!chantierId,
  });

  const { data: marches } = useQuery({
    queryKey: ['marches', chantierId],
    queryFn: async () => {
      const allMarches = await base44.entities.MarcheEntreprise.list();
      return allMarches.filter(m => m.chantier_id === chantierId);
    },
    initialData: [],
  });

  const { data: entreprises } = useQuery({
    queryKey: ['entreprises'],
    queryFn: () => base44.entities.Entreprise.list(),
    initialData: [],
  });

  const { data: clients } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
    initialData: [],
  });

  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const { data: membresEquipe } = useQuery({
    queryKey: ['membresEquipe'],
    queryFn: () => base44.entities.MembreEquipe.list(),
    initialData: [],
  });

  const { data: partenaires } = useQuery({
    queryKey: ['partenaires'],
    queryFn: () => base44.entities.Partenaire.list(),
    initialData: [],
  });

  const entreprisesAvecMarche = useMemo(() => {
    const entrepriseIds = [...new Set(marches.map(m => m.entreprise_id))];
    return entreprises.filter(e => entrepriseIds.includes(e.id));
  }, [marches, entreprises]);

  // Tableau de suivi financier
  const suiviFinancier = useMemo(() => {
    const grouped = {};

    // Grouper par marché (lot) pour séparer les lots d'une même entreprise
    marches.forEach(marche => {
      const key = marche.id;
      const entreprise = entreprises.find(e => e.id === marche.entreprise_id);
      grouped[key] = {
        marcheId: marche.id,
        entrepriseId: marche.entreprise_id,
        entreprise: entreprise,
        numero_lot: marche.numero_lot || null,
        intitule_lot: marche.intitule_lot || null,
        montant_marche_initial: marche.montant || 0,
        avenants: []
      };
    });

    // Ajouter tous les avenants au bon marché
    avenants.forEach(avenant => {
      const key = avenant.marche_id
        ? avenant.marche_id
        : marches.find(m => m.entreprise_id === avenant.entreprise_id)?.id;
      if (key && grouped[key]) {
        grouped[key].avenants.push({
          id: avenant.id,
          numero: avenant.numero,
          intitule: avenant.intitule || "",
          montant: avenant.montant_total_ht || 0
        });
      }
    });

    return Object.values(grouped).map(item => ({
      ...item,
      montant_total_avenants: item.avenants.reduce((sum, a) => sum + (a.montant || 0), 0),
      montant_total_final: item.montant_marche_initial + item.avenants.reduce((sum, a) => sum + (a.montant || 0), 0)
    })).sort((a, b) => {
      const lotA = a.numero_lot || '';
      const lotB = b.numero_lot || '';
      if (lotA !== lotB) return lotA.localeCompare(lotB, undefined, { numeric: true });
      return (a.entreprise?.nom || '').localeCompare(b.entreprise?.nom || '');
    });
  }, [marches, avenants, entreprises]);

  // Regrouper les avenants par marché (lot) avec filtres
  const avenantParEntreprise = useMemo(() => {
    let filteredAvenants = avenants;

    // Appliquer le filtre par entreprise
    if (filterEntreprise !== "all") {
      filteredAvenants = filteredAvenants.filter(a => a.entreprise_id === filterEntreprise);
    }

    // Appliquer le filtre par statut
    if (filterStatut !== "all") {
      filteredAvenants = filteredAvenants.filter(a => a.statut === filterStatut);
    }

    const grouped = {};

    filteredAvenants.forEach(avenant => {
      // Grouper par marché (marche_id) pour séparer les lots d'une même entreprise
      const groupKey = avenant.marche_id || avenant.entreprise_id;
      if (!grouped[groupKey]) {
        const entreprise = entreprises.find(e => e.id === avenant.entreprise_id);
        const marche = avenant.marche_id
          ? marches.find(m => m.id === avenant.marche_id)
          : marches.find(m => m.entreprise_id === avenant.entreprise_id);
        grouped[groupKey] = {
          groupKey,
          entrepriseId: avenant.entreprise_id,
          entreprise: entreprise,
          marche: marche,
          numero_lot: marche?.numero_lot || null,
          avenants: [],
          montantTotal: 0,
          montantValide: 0
        };
      }

      grouped[groupKey].avenants.push(avenant);
      grouped[groupKey].montantTotal += avenant.montant_total_ht || 0;
      grouped[groupKey].montantValide += avenant.montant_total_ht || 0;
    });

    return Object.values(grouped).sort((a, b) => {
      const lotA = a.numero_lot || '';
      const lotB = b.numero_lot || '';
      if (lotA !== lotB) return lotA.localeCompare(lotB, undefined, { numeric: true });
      return (a.entreprise?.nom || '').localeCompare(b.entreprise?.nom || '');
    });
  }, [avenants, entreprises, marches, filterEntreprise, filterStatut]);

  // Nouvelle fonction pour naviguer vers un avenant spécifique
  const navigateToAvenant = (avenantId) => {
    const avenant = avenants.find(a => a.id === avenantId);
    if (!avenant) return;

    // Basculer vers l'onglet Avenants
    setActiveTab("avenants");

    // Réinitialiser les filtres pour afficher tous les avenants
    setFilterEntreprise("all");
    setFilterStatut("all");

    // Ouvrir l'accordéon du marché correspondant
    const groupKey = avenant.marche_id || avenant.entreprise_id;
    setOpenAccordionItems(prev => {
      if (prev.includes(groupKey)) {
        return prev;
      }
      return [groupKey];
    });

    // Mettre en surbrillance l'avenant
    setHighlightedAvenantId(avenantId);

    // Scroll après un court délai pour laisser le temps à l'accordéon de s'ouvrir
    setTimeout(() => {
      const element = document.getElementById(`avenant-${avenantId}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 300);

    // Retirer le surbrillance après 3 secondes
    setTimeout(() => {
      setHighlightedAvenantId(null);
    }, 3000);
  };

  // ⚠️ TOASTS FIGÉS v2.7.6 - NE PAS MODIFIER
  // Tous les appels toast.* sont standardisés et figés
  // ================================================

  const createDevisMutation = useMutation({
    mutationFn: async (data) => {
      return base44.entities.TravauxSupplementaire.create({
        ...data,
        chantier_id: chantierId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
      setShowDevisDialog(false);
      resetForm();
      toast.success("Devis créé", {
        description: "Le devis a été créé avec succès",
      });
    },
  });

  const updateDevisMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TravauxSupplementaire.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
      setShowDevisDialog(false);
      resetForm();
      toast.success("Devis mis à jour", {
        description: "Le devis a été mis à jour avec succès",
      });
    },
  });

  const deleteDevisMutation = useMutation({
    mutationFn: (id) => base44.entities.TravauxSupplementaire.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
      toast.success("Devis supprimé", {
        description: "Le devis a été supprimé avec succès",
      });
    },
  });

  const createAvenantMutation = useMutation({
    mutationFn: async (data) => {
      // Numérotation par marché (lot) pour éviter les conflits entre lots d'une même entreprise
      const avenantsPourMarche = data.marche_id
        ? avenants.filter(a => a.marche_id === data.marche_id)
        : avenants.filter(a => a.entreprise_id === data.entreprise_id && !a.marche_id);
      const nextNumero = (avenantsPourMarche.length + 1).toString().padStart(2, '0');

      // Générer un intitulé basé sur les devis
      const devisAssocies = devis.filter(d => selectedDevisIds.includes(d.id));
      const intitule = devisAssocies.length > 0 
        ? devisAssocies.map(d => d.intitule_devis).join(", ")
        : "Avenant";

      return base44.entities.Avenant.create({
        ...data,
        chantier_id: chantierId,
        numero: nextNumero,
        intitule: intitule,
        statut: "en_preparation"
      });
    },
    onSuccess: (newAvenant) => {
      const updatePromises = selectedDevisIds.map(devisId =>
        base44.entities.TravauxSupplementaire.update(devisId, {
          avenant_id: newAvenant.id,
          statut: 'integre_avenant'
        })
      );

      Promise.all(updatePromises).then(() => {
        queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
        queryClient.invalidateQueries({ queryKey: ['avenants'] });
        setShowAvenantDialog(false);
        setSelectedDevisIds([]);

        // Naviguer vers l'onglet avenants et ouvrir l'accordéon du nouvel avenant
        const groupKey = newAvenant.marche_id || newAvenant.entreprise_id;
        setFilterEntreprise("all");
        setFilterStatut("all");
        setActiveTab("avenants");
        setOpenAccordionItems([groupKey]);
        setHighlightedAvenantId(newAvenant.id);
        setTimeout(() => {
          const element = document.getElementById(`avenant-${newAvenant.id}`);
          if (element) element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 400);
        setTimeout(() => setHighlightedAvenantId(null), 3500);

        toast.success("Avenant créé et comptabilisé", {
          description: `L'avenant N°${newAvenant.numero} a été créé avec succès`,
        });
      });
    },
  });

  const updateAvenantMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Avenant.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['avenants'] });
      setShowAvenantDialog(false);
      setSelectedAvenant(null);
      toast.success("Avenant mis à jour", {
        description: "L'avenant a été mis à jour avec succès",
      });
    },
  });

  const deleteAvenantMutation = useMutation({
    mutationFn: async (avenantId) => {
      const avenant = avenants.find(a => a.id === avenantId);

      if (avenant && avenant.devis_ids && avenant.devis_ids.length > 0) {
        const updatePromises = avenant.devis_ids.map(devisId =>
          base44.entities.TravauxSupplementaire.update(devisId, {
            avenant_id: null,
            statut: 'brouillon'
          })
        );
        await Promise.all(updatePromises);
      }

      return await base44.entities.Avenant.delete(avenantId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
      queryClient.invalidateQueries({ queryKey: ['avenants'] });
      toast.success("Avenant supprimé", {
        description: "L'avenant a été supprimé et les devis ont été remis en brouillon",
      });
      setShowDeleteAvenantDialog(false);
      setAvenantToDelete(null);
    },
    onError: (error) => {
      console.error("Erreur lors de la suppression:", error);
      toast.error("Erreur", {
        description: `Impossible de supprimer l'avenant: ${error.message}`,
      });
      setShowDeleteAvenantDialog(false);
      setAvenantToDelete(null);
    },
  });

  const updateAvenantStatutMutation = useMutation({
    mutationFn: ({ id, statut }) => base44.entities.Avenant.update(id, { statut }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['avenants'] });
      toast.success("Statut mis à jour", {
        description: "Le statut de l'avenant a été mis à jour avec succès",
        duration: 3000,
      });
    },
  });

  const uploadAvenantSigneMutation = useMutation({
    mutationFn: async ({ id, file }) => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      return base44.entities.Avenant.update(id, { avenant_signe_url: file_url, statut: 'signe' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['avenants'] });
      toast.success("Avenant signé importé", { description: "Le statut a été automatiquement passé à 'Signé'", duration: 3000 });
    },
  });

  // ⚠️ FIN SECTION TOASTS FIGÉS
  // ================================================

  const resetForm = () => {
    setFormData({
      marche_id: "",
      entreprise_id: "",
      numero_devis: "",
      date_devis: "",
      intitule_devis: "",
      montant_ht: "",
      type_devis: "TS",
      tranche_numero: "",
      origine_devis: "",
      devis_pdf_url: "",
      statut: "brouillon",
      notes: ""
    });
    setSelectedDevis(null);
  };

  const handleEdit = (devisItem) => {
    setSelectedDevis(devisItem);
    
    // Tentative de retrouver le marché associé si marche_id n'est pas présent
    let marcheId = devisItem.marche_id || "";
    if (!marcheId && devisItem.entreprise_id) {
      const marcheTrouve = marches.find(m => m.entreprise_id === devisItem.entreprise_id);
      if (marcheTrouve) {
        marcheId = marcheTrouve.id;
      }
    }

    setFormData({
      marche_id: marcheId,
      entreprise_id: devisItem.entreprise_id || "",
      client_id: devisItem.client_id || "",
      numero_devis: devisItem.numero_devis || "",
      date_devis: devisItem.date_devis ? format(new Date(devisItem.date_devis), "yyyy-MM-dd") : "",
      intitule_devis: devisItem.intitule_devis || "",
      montant_ht: devisItem.montant_ht ? String(devisItem.montant_ht) : "",
      type_devis: devisItem.type_devis || "TS",
      tranche_numero: devisItem.tranche_numero != null ? String(devisItem.tranche_numero) : "",
      origine_devis: devisItem.origine_devis || "",
      devis_pdf_url: devisItem.devis_pdf_url || "",
      statut: devisItem.statut || "brouillon",
      notes: devisItem.notes || ""
    });
    setShowDevisDialog(true);
  };

  const handleDeleteAvenant = (avenantId) => {
    const avenant = avenants.find(a => a.id === avenantId);
    setAvenantToDelete(avenant);
    setShowDeleteAvenantDialog(true);
  };

  const handleChangeStatutAvenant = (avenantId, newStatut) => {
    updateAvenantStatutMutation.mutate({ id: avenantId, statut: newStatut });
  };

  const handleUploadAvenantSigne = async (avenantId, e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    uploadAvenantSigneMutation.mutate({ id: avenantId, file });
  };

  const getStatutColor = (statut) => {
    switch (statut) {
      case 'en_preparation':
        return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'en_signature':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'signe':
        return 'bg-green-100 text-green-800 border-green-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getStatutLabel = (statut) => {
    switch (statut) {
      case 'en_preparation':
        return 'En préparation';
      case 'en_signature':
        return 'En signature';
      case 'signe':
        return 'Signé';
      default:
        return statut;
    }
  };

  const handleDelete = (devisItem) => {
    setDevisToDelete(devisItem);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (devisToDelete) {
      deleteDevisMutation.mutate(devisToDelete.id);
      setShowDeleteDialog(false);
      setDevisToDelete(null);
    }
  };

  const confirmDeleteAvenant = () => {
    if (avenantToDelete && avenantToDelete.id) {
      deleteAvenantMutation.mutate(avenantToDelete.id);
    } else {
      console.error("Avenant à supprimer non défini.");
      toast.error("Erreur", {
        description: "Avenant non trouvé",
      });
      setShowDeleteAvenantDialog(false);
      setAvenantToDelete(null);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    e.stopPropagation();

    // Validation supplémentaire
    if (!formData.entreprise_id) {
      toast.error("Veuillez sélectionner une entreprise");
      return;
    }
    if (!formData.date_devis) {
      toast.error("Veuillez saisir une date");
      return;
    }
    if (!formData.intitule_devis || !formData.intitule_devis.trim()) {
      toast.error("Veuillez saisir un intitulé");
      return;
    }
    if (!formData.montant_ht || formData.montant_ht === "") {
      toast.error("Veuillez saisir un montant");
      return;
    }
    if (!formData.type_devis) {
      toast.error("Veuillez sélectionner un type de devis");
      return;
    }

    const dataToSubmit = {
      ...formData,
      montant_ht: parseFloat(formData.montant_ht) || 0,
      numero_devis: formData.numero_devis || null,
      tranche_numero: formData.tranche_numero ? parseFloat(formData.tranche_numero) : null,
      client_id: formData.client_id || chantier.client_id
    };

    if (selectedDevis) {
      updateDevisMutation.mutate({ id: selectedDevis.id, data: dataToSubmit });
    } else {
      createDevisMutation.mutate(dataToSubmit);
    }
  };

  const handlePDFUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingPDF(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, devis_pdf_url: file_url });
      toast.success("Fichier téléchargé", {
        description: "Le devis a été téléchargé avec succès",
      });
    } catch (error) {
      console.error("Erreur lors du téléchargement:", error);
      toast.error("Erreur", {
        description: "Erreur lors du téléchargement du fichier",
      });
    } finally {
      setUploadingPDF(false);
    }
  };

  const handleToggleDevisSelection = (devisId) => {
    const devisItem = devis.find(d => d.id === devisId);
    if (devisItem && devisItem.statut === 'integre_avenant') {
      return;
    }

    setSelectedDevisIds(prev =>
      prev.includes(devisId)
        ? prev.filter(id => id !== devisId)
        : [...prev, devisId]
    );
  };

  const handleCreateAvenant = () => {
    if (selectedDevisIds.length === 0) {
      toast.error("Aucun devis sélectionné", {
        description: "Veuillez sélectionner au moins un devis",
      });
      return;
    }

    const selectedDevisData = devis.filter(d => selectedDevisIds.includes(d.id));
    const entrepriseIds = [...new Set(selectedDevisData.map(d => d.entreprise_id))];

    if (entrepriseIds.length > 1) {
      toast.error("Erreur", {
        description: "Tous les devis sélectionnés doivent être de la même entreprise",
      });
      return;
    }

    setSelectedAvenant(null);
    setShowAvenantDialog(true);
  };

  const confirmCreateAvenant = () => {
    const selectedDevisData = devis.filter(d => selectedDevisIds.includes(d.id));
    const montantTotal = selectedDevisData.reduce((sum, d) => sum + (d.montant_ht || 0), 0);
    const entrepriseId = selectedDevisData[0].entreprise_id;
    // Résoudre marche_id depuis le devis, ou depuis le marché de l'entreprise en fallback
    const marcheId = selectedDevisData[0].marche_id ||
      marches.find(m => m.entreprise_id === entrepriseId)?.id || "";

    const avenantData = {
      entreprise_id: entrepriseId,
      marche_id: marcheId,
      date: new Date().toISOString().split('T')[0],
      devis_ids: selectedDevisIds,
      montant_total_ht: montantTotal
    };

    createAvenantMutation.mutate(avenantData);
  };

  // ⚠️ EXPORT PDF SUIVI FINANCIER FIGÉ v2.7.6 FINAL
  // Structure STRICTE : Logo CLIENT (gauche) + Logo GESTIONBAT (droite)
  // Footer : Architecte / GESTIONBAT / Autres partenaires
  // Template HTML avec fallback Ctrl+P instructions
  // NE PAS MODIFIER SANS VALIDATION
  // =========================================================================
  const handleExportSuiviFinancier = async () => {
    if (suiviFinancier.length === 0) {
      toast.error("Aucune donnée", {
        description: "Aucune donnée à exporter",
      });
      return;
    }

    // ✅ Récupération des partenaires avec ordre : Architecte / GESTIONBAT / Autres
    const partenairesList = chantier?.partenaires || [];
    const partenairesData = partenairesList
      .map(p => {
        const partenaire = partenaires.find(part => part.id === p.partenaire_id);
        if (!partenaire) return null;
        return {
          nom: partenaire.nom,
          role: (p.role || '').toLowerCase()
        };
      })
      .filter(p => p !== null);
    
    const architecte = partenairesData.find(p => p.role.includes('architecte'));
    const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
    
    const partenairesOrdonnes = [];
    if (architecte) {
      partenairesOrdonnes.push(architecte.nom);
    }
    partenairesOrdonnes.push(infoGestionbat?.nom_entreprise || 'GESTIONBAT');
    autresPartenaires.forEach(p => partenairesOrdonnes.push(p.nom));
    
    const partenairesString = partenairesOrdonnes.join(" / ");

    const dateFormatee = format(new Date(), "dd/MM/yyyy", { locale: fr });

    const logoClient = chantier?.logo_client_url
      ? `<img src="${chantier.logo_client_url}" alt="Logo Client" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
      : '<p style="font-weight: bold; color: #1e40af; font-size: 12pt;">' + (clients.find(c => c.id === chantier?.client_id)?.nom || 'CLIENT') + '</p>';

    const logoGestionbat = infoGestionbat && infoGestionbat.logo_url
      ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
      : '<p style="font-weight: bold; color: #f97316; font-size: 12pt;">GESTIONBAT</p>';

    const getStatutBadge = (statut) => {
      const badges = {
        'en_preparation': '<span style="display: inline-block; padding: 3px 6px; background: #e5e7eb; color: #374151; border-radius: 3px; font-size: 8pt; font-weight: 300; margin-right: 5px;">EP</span>',
        'en_signature': '<span style="display: inline-block; padding: 3px 6px; background: #e5e7eb; color: #374151; border-radius: 3px; font-size: 8pt; font-weight: 300; margin-right: 5px;">ES</span>',
        'signe': '<span style="display: inline-block; padding: 3px 6px; background: #e5e7eb; color: #374151; border-radius: 3px; font-size: 8pt; font-weight: 300; margin-right: 5px;">S</span>'
      };
      return badges[statut] || '';
    };

    const lignesTableau = suiviFinancier.map(item => {
      const lignesAvenants = item.avenants.length === 0
        ? '<span style="color: #999; font-style: italic; font-size: 9pt;">Aucun avenant</span>'
        : item.avenants.map(av => {
            const avenantData = avenants.find(a => a.id === av.id);
            const statutBadge = avenantData ? getStatutBadge(avenantData.statut) : '';
            return `
            <div style="font-size: 9pt; margin: 2px 0;">
              ${statutBadge}<span style="font-weight: 600;">Avenant N°${av.numero}</span>${av.intitule ? ` - ${av.intitule}` : ''}: ${av.montant.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
            </div>
          `;
          }).join('') + (item.avenants.length > 0 ? `
            <div style="margin-top: 5px; font-weight: 600; font-size: 9pt; color: #f97316;">
              Total avenants: ${item.montant_total_avenants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
            </div>
          ` : '');

      return `
        <tr class="enterprise-row" style="page-break-inside: avoid; page-break-after: auto;">
          <td><strong>${item.numero_lot ? `Lot ${item.numero_lot} – ` : ''}${item.entreprise?.nom || 'Non spécifié'}</strong></td>
          <td style="text-align: right;">${item.montant_marche_initial.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
          <td>${lignesAvenants}</td>
          <td style="text-align: right; font-weight: 600; color: #f97316;">
            ${item.montant_total_final.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
          </td>
        </tr>
      `;
    }).join('');

    const totalMarcheInitial = suiviFinancier.reduce((sum, item) => sum + item.montant_marche_initial, 0);
    const totalAvenants = suiviFinancier.reduce((sum, item) => sum + item.montant_total_avenants, 0);
    const totalFinal = suiviFinancier.reduce((sum, item) => sum + item.montant_total_final, 0);

    const tableContentHtml = `
      <table>
        <thead>
          <tr>
            <th style="width: 30%;">Entreprise</th>
            <th style="width: 20%; text-align: right;">Marché Initial HT</th>
            <th style="width: 30%;">Avenants</th>
            <th style="width: 20%; text-align: right;">Montant Final HT</th>
          </tr>
        </thead>
        <tbody>
          ${lignesTableau}
          <tr class="total-row" style="page-break-inside: avoid;">
            <td><strong>TOTAL</strong></td>
            <td style="text-align: right;">
              <strong>${totalMarcheInitial.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong>
            </td>
            <td style="text-align: right;">
              <strong>${totalAvenants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong>
            </td>
            <td style="text-align: right;">
              <strong>${totalFinal.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong>
            </td>
          </tr>
        </tbody>
      </table>
      <div style="margin-top: 15px; padding: 8px; background: #f9fafb; border-radius: 4px; font-size: 8pt;">
        <strong>Légende :</strong> 
        <span style="margin-left: 8px;">EP : En préparation</span>
        <span style="margin-left: 8px;">ES : En signature</span>
        <span style="margin-left: 8px;">S : Signé</span>
      </div>
    `;

    const htmlContent = generatePdfHtml({
      title: "RÉCAPITULATIF AVENANTS",
      subtitle: `État au ${dateFormatee}`,
      chantier,
      client: clients.find(c => c.id === chantier?.client_id),
      infoGestionbat,
      partenaires,
      tableContentHtml,
      orientation: "landscape",
      withPageNumbers: true
    });

    toast.info("Conversion en PDF...", {
      description: "Génération du fichier PDF en cours",
    });

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      const response = await base44.functions.invoke('htmlToPdf', {
        html_content: htmlContent,
        css: ''
      });

      clearTimeout(timeoutId);

      if (response.data && response.data.success && response.data.pdf_base64) {
        const byteCharacters = atob(response.data.pdf_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        const nomChantier = (chantier?.nom || 'chantier').replace(/[^a-z0-9]/gi, '_');
        link.download = `recapitulatif_avenants_${nomChantier}_${Date.now()}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        toast.success("PDF généré", {
          description: "Le récapitulatif avenants a été téléchargé en PDF",
        });
      } else {
        throw new Error("La conversion PDF a échoué");
      }
    } catch (pdfError) {
      console.error("Erreur conversion PDF, fallback sur HTML:", pdfError);
      
      const htmlAvecInstructions = htmlContent.replace(
        '</body>',
        `
        <div style="position: fixed; top: 10px; left: 10px; right: 10px; background: #fff3cd; border: 2px solid #ffc107; padding: 15px; border-radius: 5px; z-index: 9999;">
          <h3 style="margin: 0 0 10px 0; color: #856404;">⚠️ Instructions pour générer le PDF</h3>
          <ol style="margin: 0; padding-left: 20px; color: #856404;">
            <li>Ouvrez ce fichier dans votre navigateur</li>
            <li>Appuyez sur <strong>Ctrl + P</strong> (Windows) ou <strong>Cmd + P</strong> (Mac)</li>
            <li>Sélectionnez <strong>"Enregistrer au format PDF"</strong></li>
            <li>Choisissez <strong>Paysage</strong> comme orientation</li>
            <li>Cliquez sur <strong>Enregistrer</strong></li>
          </ol>
        </div>
        </body>`
      );
      
      const blob = new Blob([htmlAvecInstructions], { type: 'text/html;charset=utf-8' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.href = url;
      const nomChantier = (chantier?.nom || 'chantier').replace(/[^a-z0-9]/gi, '_');
      link.download = `recapitulatif_avenants_${nomChantier}_${Date.now()}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.warning("Fichier HTML téléchargé", {
        description: "La conversion PDF a échoué. Utilisez Ctrl+P pour créer le PDF.",
      });
    }
  };
  // ⚠️ FIN EXPORT PDF SUIVI FINANCIER FIGÉ v2.7.6
  // =========================================================================

  const getEntrepriseName = (entrepriseId) => {
    const entreprise = entreprises.find(e => e.id === entrepriseId);
    return entreprise?.nom || "Non spécifié";
  };

  const getFileName = (url) => {
    if (!url) return "";
    return url.split('/').pop().split('?')[0];
  };

  // Télécharger le modèle Excel pour import de devis
  const handleDownloadTemplate = () => {
    const tranches = chantier?.tranches || [];
    const headers = ["date_devis", "numero_devis", "entreprise_nom", "intitule_devis", "type_devis", "origine_devis", "montant_ht", "tranche_numero"];
    const exempleRow = [
      new Date().toISOString().split("T")[0],
      "DEV-2024-001",
      "Nom de l'entreprise (exact ou partiel)",
      "Intitulé du devis",
      "TS",
      "Aléas chantier",
      "1500.00",
      tranches.length > 0 ? tranches[0].numero : ""
    ];
    const ws = XLSX.utils.aoa_to_sheet([headers, exempleRow]);
    ws["!cols"] = headers.map(() => ({ wch: 28 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Devis");
    if (tranches.length > 0) {
      const refRows = [["tranche_numero", "libelle"], ...tranches.map(t => [t.numero, t.libelle || `Tranche ${t.numero}`])];
      const wsRef = XLSX.utils.aoa_to_sheet(refRows);
      wsRef["!cols"] = [{ wch: 18 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, wsRef, "Référence Phases");
    }
    XLSX.writeFile(wb, "modele_import_devis.xlsx");
  };

  const handleExportDevisExcel = () => {
    const ok = exportDevisExcel({ devis, avenants, chantier, getEntrepriseName });
    if (!ok) { toast.error("Aucun devis à exporter"); return; }
    toast.success("Export devis téléchargé");
  };

  const handleExportAvenantsExcel = () => {
    const ok = exportAvenantsExcel({ avenants, marches, devis, chantier, getEntrepriseName });
    if (!ok) { toast.error("Aucun avenant à exporter"); return; }
    toast.success("Export avenants téléchargé");
  };

  // Prévisualisation HTML de l'avenant
  const handlePreviewAvenant = async (avenant) => {
    setSelectedAvenant(avenant);
    setPreviewingAvenant(true);

    try {
      const entreprise = entreprises.find(e => e.id === avenant.entreprise_id);
      const client = clients.find(c => c.id === chantier?.client_id);
      // Préférer marche_id de l'avenant pour éviter les conflits multi-lots
      const marche = avenant.marche_id
        ? marches.find(m => m.id === avenant.marche_id)
        : marches.find(m => m.entreprise_id === avenant.entreprise_id);

      // Récupérer les devis associés à l'avenant
      const devisAssocies = (avenant.devis_ids || [])
        .map(devisId => devis.find(d => d.id === devisId))
        .filter(d => d !== undefined);

      // Calculer les montants de tous les avenants précédents (même marché)
      const avenantsPrecedents = avenants
        .filter(a => {
          const memeMarche = avenant.marche_id
            ? a.marche_id === avenant.marche_id
            : a.entreprise_id === avenant.entreprise_id;
          return memeMarche && parseInt(a.numero) < parseInt(avenant.numero);
        })
        .sort((a, b) => parseInt(a.numero) - parseInt(b.numero));

      const montantMarcheBase = marche?.montant || 0;
      const tauxTVA = marche?.taux_tva || chantier?.taux_tva?.[0] || 20;

      const logoGestionbat = infoGestionbat && infoGestionbat.logo_url
        ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
        : '<p style="font-weight: bold; color: #f97316; font-size: 16pt;">GESTIONBAT</p>';

      const logoClient = chantier?.logo_client_url
        ? `<img src="${chantier.logo_client_url}" alt="Logo Client" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
        : '';

      const partenairesList = chantier?.partenaires || [];
      const partenairesData = partenairesList
        .map(p => {
          const partenaire = partenaires.find(part => part.id === p.partenaire_id);
          if (!partenaire) return null;
          return {
            nom: partenaire.nom,
            role: (p.role || '').toLowerCase()
          };
        })
        .filter(p => p !== null);
      
      const architecte = partenairesData.find(p => p.role.includes('architecte'));
      const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
      
      const partenairesOrdonnes = [];
      if (architecte) {
        partenairesOrdonnes.push(architecte.nom);
      }
      partenairesOrdonnes.push(infoGestionbat?.nom_entreprise || 'GESTIONBAT');
      autresPartenaires.forEach(p => partenairesOrdonnes.push(p.nom));
      
      const partenairesString = partenairesOrdonnes.join(" / ");

      const htmlContent = getAvenantHtmlTemplate({
        avenant,
        chantier,
        client,
        entreprise,
        marche,
        devisAssocies,
        avenantsPrecedents,
        montantMarcheBase,
        tauxTVA,
        infoGestionbat,
        logoClient,
        logoGestionbat,
        partenairesString
      });

      // Ouvrir l'HTML dans un nouvel onglet
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      
      if (avenant.statut === 'en_preparation') {
        await base44.entities.Avenant.update(avenant.id, { statut: 'en_signature' });
        queryClient.invalidateQueries({ queryKey: ['avenants'] });
        toast.success("Prévisualisation ouverte", {
          description: "L'avenant s'ouvre dans un nouvel onglet. Statut mis à jour: En signature",
        });
      } else {
        toast.success("Prévisualisation ouverte", {
          description: "L'avenant s'ouvre dans un nouvel onglet",
        });
      }

    } catch (error) {
      console.error("Erreur lors de la prévisualisation:", error);
      toast.error("Erreur", {
        description: "Erreur lors de la prévisualisation de l'avenant",
      });
    } finally {
      setPreviewingAvenant(false);
      setSelectedAvenant(null);
    }
  };

  // Génération PDF de l'avenant avec fusion
  const handleEditAvenant = async (avenant) => {
    setSelectedAvenant(avenant);
    setGeneratingAvenantPDF(true);

    try {
      const entreprise = entreprises.find(e => e.id === avenant.entreprise_id);
      const client = clients.find(c => c.id === chantier?.client_id);
      // Préférer marche_id de l'avenant pour éviter les conflits multi-lots
      const marche = avenant.marche_id
        ? marches.find(m => m.id === avenant.marche_id)
        : marches.find(m => m.entreprise_id === avenant.entreprise_id);

      // Récupérer les devis associés à l'avenant (uniquement ceux qui existent encore)
      const devisAssocies = (avenant.devis_ids || [])
        .map(devisId => devis.find(d => d.id === devisId))
        .filter(d => d !== undefined);

      // Calculer les montants de tous les avenants précédents (même marché)
      const avenantsPrecedents = avenants
        .filter(a => {
          const memeMarche = avenant.marche_id
            ? a.marche_id === avenant.marche_id
            : a.entreprise_id === avenant.entreprise_id;
          return memeMarche && parseInt(a.numero) < parseInt(avenant.numero);
        })
        .sort((a, b) => parseInt(a.numero) - parseInt(b.numero));

      // Calculer le montant du marché de base
      const montantMarcheBase = marche?.montant || 0;
      const tauxTVA = marche?.taux_tva || chantier?.taux_tva?.[0] || 20;

      // ✅ PRIORITÉ : Trame client, sinon trame chantier
      const trameAvenant = client?.trame_avenant_url || chantier?.trame_avenants_url;
      
      if (trameAvenant) {
        try {
          toast.loading("Génération en cours...", {
            description: "Remplissage automatique de la trame d'avenant",
            id: "avenant-generation",
          });

          // Calculer le montant cumulé des avenants précédents
          const montantTotalAvenantsPrecedentsHT = avenantsPrecedents.reduce((sum, av) => sum + (av.montant_total_ht || 0), 0);
          const montantTotalAvenantsPrecedentsTTC = montantTotalAvenantsPrecedentsHT * (1 + tauxTVA / 100);
          const nouveauMontantMarcheHT = montantMarcheBase + montantTotalAvenantsPrecedentsHT + avenant.montant_total_ht;
          const nouveauMontantMarcheTTC = nouveauMontantMarcheHT * (1 + tauxTVA / 100);

          // Préparer les données pour remplir la trame
          const data = {
            "{{NUMERO_AVENANT}}": avenant.numero,
            "{{DATE_AVENANT}}": format(new Date(avenant.date), "dd/MM/yyyy", { locale: fr }),
            "{{DATE_GENERATION}}": format(new Date(), "dd/MM/yyyy", { locale: fr }),
            "{{CHANTIER_NOM}}": chantier?.nom || '',
            "{{CHANTIER_ADRESSE}}": chantier?.adresse || '',
            "{{CLIENT_NOM}}": client?.nom || '',
            "{{CLIENT_ADRESSE_1}}": client?.adresse_1 || '',
            "{{CLIENT_ADRESSE_2}}": client?.adresse_2 || '',
            "{{CLIENT_CODE_POSTAL}}": client?.code_postal || '',
            "{{CLIENT_VILLE}}": client?.ville || '',
            "{{CLIENT_SIRET}}": client?.siret || '',
            "{{ENTREPRISE_NOM}}": entreprise?.nom || '',
            "{{ENTREPRISE_ADRESSE_1}}": entreprise?.adresse_1 || '',
            "{{ENTREPRISE_ADRESSE_2}}": entreprise?.adresse_2 || '',
            "{{ENTREPRISE_CODE_POSTAL}}": entreprise?.code_postal || '',
            "{{ENTREPRISE_VILLE}}": entreprise?.ville || '',
            "{{ENTREPRISE_SIRET}}": entreprise?.siret || '',
            "{{ENTREPRISE_REPRESENTANT_CIVILITE}}": entreprise?.representant_civilite || '',
            "{{ENTREPRISE_REPRESENTANT_PRENOM}}": entreprise?.representant_prenom || '',
            "{{ENTREPRISE_REPRESENTANT_NOM}}": entreprise?.representant_nom || '',
            "{{ENTREPRISE_REPRESENTANT_QUALITE}}": entreprise?.representant_qualite || '',
            "{{NUMERO_LOT}}": marche?.numero_lot || '',
            "{{INTITULE_LOT}}": marche?.intitule_lot || '',
            "{{MONTANT_TOTAL_HT}}": avenant.montant_total_ht.toFixed(2).replace('.', ','),
            "{{MONTANT_TOTAL_TTC}}": (avenant.montant_total_ht * (1 + tauxTVA / 100)).toFixed(2).replace('.', ','),
            "{{TAUX_TVA}}": tauxTVA.toString(),
            "{{NB_DEVIS}}": devisAssocies.length.toString(),
            "{{MARCHE_BASE_HT}}": montantMarcheBase.toFixed(2).replace('.', ','),
            "{{MARCHE_BASE_TTC}}": (montantMarcheBase * (1 + tauxTVA / 100)).toFixed(2).replace('.', ','),
            "{{TOTAL_AVENANTS_PRECEDENTS_HT}}": montantTotalAvenantsPrecedentsHT.toFixed(2).replace('.', ','),
            "{{TOTAL_AVENANTS_PRECEDENTS_TTC}}": montantTotalAvenantsPrecedentsTTC.toFixed(2).replace('.', ','),
            "{{NOUVEAU_MONTANT_MARCHE_HT}}": nouveauMontantMarcheHT.toFixed(2).replace('.', ','),
            "{{NOUVEAU_MONTANT_MARCHE_TTC}}": nouveauMontantMarcheTTC.toFixed(2).replace('.', ','),
            ...devisAssocies.reduce((acc, d, index) => {
              const i = index + 1;
              acc[`{{DEVIS_${i}_NUMERO}}`] = d.numero_devis || `No.${i}`;
              acc[`{{DEVIS_${i}_DATE}}`] = format(new Date(d.date_devis), "dd/MM/yyyy", { locale: fr });
              acc[`{{DEVIS_${i}_INTITULE}}`] = d.intitule_devis;
              acc[`{{DEVIS_${i}_TYPE}}`] = d.type_devis;
              acc[`{{DEVIS_${i}_ORIGINE}}`] = d.origine_devis || 'N/A';
              acc[`{{DEVIS_${i}_MONTANT_HT}}`] = d.montant_ht.toFixed(2).replace('.', ',');
              acc[`{{DEVIS_${i}_MONTANT_TTC}}`] = (d.montant_ht * (1 + tauxTVA / 100)).toFixed(2).replace('.', ',');
              return acc;
            }, {}),
            ...avenantsPrecedents.reduce((acc, av, index) => {
              const i = index + 1;
              acc[`{{AVENANT_PREC_${i}_NUMERO}}`] = av.numero;
              acc[`{{AVENANT_PREC_${i}_HT}}`] = av.montant_total_ht.toFixed(2).replace('.', ',');
              acc[`{{AVENANT_PREC_${i}_TTC}}`] = (av.montant_total_ht * (1 + tauxTVA / 100)).toFixed(2).replace('.', ',');
              return acc;
            }, {}),
            "{{GESTIONBAT_NOM}}": infoGestionbat?.nom_entreprise || 'GESTIONBAT',
            "{{GESTIONBAT_ADRESSE}}": infoGestionbat?.adresse || '',
            "{{GESTIONBAT_CODE_POSTAL}}": infoGestionbat?.code_postal || '',
            "{{GESTIONBAT_VILLE}}": infoGestionbat?.ville || '',
            "{{GESTIONBAT_TELEPHONE}}": infoGestionbat?.telephone || '',
            "{{GESTIONBAT_SIRET}}": infoGestionbat?.siret || '',
          };

          const response = await base44.functions.invoke('fillExcelTemplate', {
            template_url: trameAvenant,
            data: data
          });

          if (response.data.success && response.data.file_base64) {
            const byteCharacters = atob(response.data.file_base64);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const numeroLot = marche?.numero_lot || 'XX';
            const nomEntreprise = entreprise?.nom?.replace(/[^a-z0-9]/gi, '_').toUpperCase() || 'ENTREPRISE';
            const fileName = `${numeroLot}_${nomEntreprise}_AVT ${avenant.numero}.xlsx`;
            
            // Pour Excel, téléchargement direct (pas de prévisualisation)
            const blob = new Blob([byteArray], {
              type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.href = url;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            if (avenant.statut === 'en_preparation') {
              await base44.entities.Avenant.update(avenant.id, { statut: 'en_signature' });
              queryClient.invalidateQueries({ queryKey: ['avenants'] });
              toast.success("Avenant généré automatiquement !", {
                description: "Fichier Excel téléchargé avec succès. Statut mis à jour: En signature",
                duration: 6000,
                id: "avenant-generation",
              });
            } else {
              toast.success("Avenant généré automatiquement !", {
                description: "Fichier Excel téléchargé avec succès",
                duration: 6000,
                id: "avenant-generation",
              });
            }
            setGeneratingAvenantPDF(false);
            setSelectedAvenant(null);
            return;

          } else {
            throw new Error("La réponse de l'API ne contient pas de fichier");
          }

        } catch (apiError) {
          console.error("Erreur lors du remplissage automatique:", apiError);
          toast.error("Échec du remplissage automatique", {
            description: "Génération du PDF standard...",
            id: "avenant-generation",
          });
        }
      }

      // Fallback : génération PDF si pas de trame ou échec
      const logoGestionbat = infoGestionbat && infoGestionbat.logo_url
        ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
        : '<p style="font-weight: bold; color: #f97316; font-size: 16pt;">GESTIONBAT</p>';

      const logoClient = chantier?.logo_client_url
        ? `<img src="${chantier.logo_client_url}" alt="Logo Client" style="max-width: 150px; max-height: 80px; object-fit: contain;" />`
        : '';

      // Construction du footer standardisé
      const partenairesList = chantier?.partenaires || [];
      const partenairesData = partenairesList
        .map(p => {
          const partenaire = partenaires.find(part => part.id === p.partenaire_id);
          if (!partenaire) return null;
          return {
            nom: partenaire.nom,
            role: (p.role || '').toLowerCase()
          };
        })
        .filter(p => p !== null);
      
      const architecte = partenairesData.find(p => p.role.includes('architecte'));
      const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
      
      const partenairesOrdonnes = [];
      if (architecte) {
        partenairesOrdonnes.push(architecte.nom);
      }
      partenairesOrdonnes.push(infoGestionbat?.nom_entreprise || 'GESTIONBAT');
      autresPartenaires.forEach(p => partenairesOrdonnes.push(p.nom));
      
      const partenairesString = partenairesOrdonnes.join(" / ");

      const htmlContent = getAvenantHtmlTemplate({
        avenant,
        chantier,
        client: clients.find(c => c.id === chantier?.client_id),
        entreprise,
        marche,
        devisAssocies,
        avenantsPrecedents,
        montantMarcheBase,
        tauxTVA,
        infoGestionbat,
        logoClient,
        logoGestionbat,
        partenairesString
      });

      // Convertir HTML en PDF via la fonction backend AVEC FALLBACK
      try {
        toast.loading("Conversion en PDF...", {
          description: "Génération du fichier PDF en cours",
          id: "avenant-generation",
        });

        // Tentative de conversion avec timeout de 30 secondes
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);

        const response = await base44.functions.invoke('htmlToPdf', {
          html_content: htmlContent,
          css: ''
        });

        clearTimeout(timeoutId);

        if (response.data && response.data.success && response.data.pdf_base64) {
          // Fusion avec les devis PDF si présents
          const devisPdfs = devisAssocies
            .filter(d => d.devis_pdf_url)
            .map(d => d.devis_pdf_url);

          const finalPdfBase64 = await mergePdfsWithDocuments(
            response.data.pdf_base64,
            devisPdfs,
            "avenant-generation"
          );

          toast.dismiss("avenant-generation");
          
          // Préparer le nom de fichier et télécharger directement
          const numeroLot = marche?.numero_lot || 'XX';
          const nomEntreprise = entreprise?.nom?.replace(/[^a-z0-9]/gi, '_').toUpperCase() || 'ENTREPRISE';
          const fileName = `${numeroLot}_${nomEntreprise}_AVT ${avenant.numero}.pdf`;
          
          const byteCharacters = atob(finalPdfBase64);
          const byteNumbers = new Array(byteCharacters.length);
          for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          const blob = new Blob([byteArray], { type: 'application/pdf' });
          
          const link = document.createElement('a');
          const url = URL.createObjectURL(blob);
          link.href = url;
          link.download = fileName;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          
          if (avenant.statut === 'en_preparation') {
            await base44.entities.Avenant.update(avenant.id, { statut: 'en_signature' });
            queryClient.invalidateQueries({ queryKey: ['avenants'] });
            toast.success("✅ Avenant téléchargé !", {
              description: devisPdfs.length > 0 ? `PDF fusionné avec ${devisPdfs.length} devis. Statut mis à jour: En signature` : "Le PDF a été téléchargé. Statut mis à jour: En signature",
            });
          } else {
            toast.success("✅ Avenant téléchargé !", {
              description: devisPdfs.length > 0 ? `PDF fusionné avec ${devisPdfs.length} devis` : "Le PDF a été téléchargé",
            });
          }
        } else {
          throw new Error("La conversion PDF a échoué");
        }
      } catch (pdfError) {
        // ⚠️ Si la conversion PDF échoue → fallback HTML avec instructions
        console.error("Erreur conversion PDF, fallback sur HTML:", pdfError);
        
        // Ajouter des instructions pour l'utilisateur dans le HTML
        const htmlAvecInstructions = htmlContent.replace(
          '</body>',
          `
          <div style="position: fixed; top: 10px; left: 10px; right: 10px; background: #fff3cd; border: 2px solid #ffc107; padding: 15px; border-radius: 5px; z-index: 9999;">
            <h3 style="margin: 0 0 10px 0; color: #856404;">⚠️ Instructions pour générer le PDF</h3>
            <ol style="margin: 0; padding-left: 20px; color: #856404;">
              <li>Ouvrez ce fichier dans votre navigateur</li>
              <li>Appuyez sur <strong>Ctrl + P</strong> (Windows) ou <strong>Cmd + P</strong> (Mac)</li>
              <li>Sélectionnez <strong>"Enregistrer au format PDF"</strong></li>
              <li>Choisissez <strong>Portrait</strong> comme orientation</li>
              <li>Cliquez sur <strong>Enregistrer</strong></li>
            </ol>
          </div>
          </body>`
        );
        
        const blob = new Blob([htmlAvecInstructions], { type: 'text/html;charset=utf-8' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        const numeroLot = marche?.numero_lot || 'XX';
        const nomEntreprise = entreprise?.nom?.replace(/[^a-z0-9]/gi, '_').toUpperCase() || 'ENTREPRISE';
        link.download = `${numeroLot}_${nomEntreprise}_AVT ${avenant.numero}.html`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        toast.success("⚠️ Fichier HTML téléchargé", {
          description: "La conversion PDF a échoué. Ouvrez le fichier HTML et utilisez Ctrl+P pour créer le PDF.",
          duration: 8000,
          id: "avenant-generation",
        });
      }

    } catch (error) {
      console.error("Erreur lors de la génération:", error);
      toast.error("Erreur", {
        description: "Erreur lors de la génération de l'avenant",
      });
    } finally {
      setGeneratingAvenantPDF(false);
      setSelectedAvenant(null);
    }
  };

  const devisNonIntegres = devis.filter(d => d.statut !== 'integre_avenant');
  const selectedDevisData = devis.filter(d => selectedDevisIds.includes(d.id));
  const montantTotalSelection = selectedDevisData.reduce((sum, d) => sum + (d.montant_ht || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Travaux Supplémentaires & Avenants</h2>
          <p className="text-sm text-gray-600 mt-1">
            Gestion des devis et avenants
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            className="gap-2"
            onClick={handleDownloadTemplate}
          >
            <Download className="w-4 h-4" />
            Modèle Excel
          </Button>
          <Button
            variant="outline"
            className="gap-2 border-green-300 text-green-700 hover:bg-green-50"
            onClick={() => setShowImportDialog(true)}
          >
            <FileSpreadsheet className="w-4 h-4" />
            Importer Excel
          </Button>
          <Button variant="outline" className="gap-2 border-blue-300 text-blue-700 hover:bg-blue-50" onClick={handleExportDevisExcel} disabled={!devis.length}>
            <Download className="w-4 h-4" />
            Exporter devis
          </Button>
          <Button variant="outline" className="gap-2 border-purple-300 text-purple-700 hover:bg-purple-50" onClick={handleExportAvenantsExcel} disabled={!avenants.length}>
            <Download className="w-4 h-4" />
            Exporter avenants
          </Button>
          <Button
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={() => {
              resetForm();
              setShowDevisDialog(true);
            }}
          >
            <Plus className="w-5 h-5" />
            Nouveau devis
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="devis">Devis</TabsTrigger>
          <TabsTrigger value="avenants">Avenants</TabsTrigger>
          <TabsTrigger value="suivi">Récapitulatif avenants</TabsTrigger>
        </TabsList>

        {/* Onglet Devis */}
        <TabsContent value="devis" className="space-y-6">
          <DevisTab
            devis={devis}
            avenants={avenants}
            selectedDevisIds={selectedDevisIds}
            montantTotalSelection={montantTotalSelection}
            onToggleSelection={handleToggleDevisSelection}
            onSelectAll={(checked) => {
              if (checked) {
                setSelectedDevisIds(devisNonIntegres.map(d => d.id));
              } else {
                setSelectedDevisIds([]);
              }
            }}
            onClearSelection={() => setSelectedDevisIds([])}
            onCreateAvenant={handleCreateAvenant}
            onEdit={handleEdit}
            onDelete={handleDelete}
            navigateToAvenant={navigateToAvenant}
            getEntrepriseName={getEntrepriseName}
            devisNonIntegres={devisNonIntegres}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ['travaux-sup'] })}
          />
        </TabsContent>

        {/* Onglet Avenants */}
        <TabsContent value="avenants" className="space-y-6">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div className="flex gap-3 flex-wrap">
              {/* Entreprise Filter */}
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={filterEntreprise} onValueChange={setFilterEntreprise}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Toutes les entreprises" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Toutes les entreprises</SelectItem>
                    {entreprisesAvecMarche.map(e => (
                      <SelectItem key={e.id} value={e.id}>{e.nom}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Statut Filter */}
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={filterStatut} onValueChange={setFilterStatut}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Tous les statuts" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les statuts</SelectItem>
                    <SelectItem value="en_preparation">📋 En préparation</SelectItem>
                    <SelectItem value="en_signature">📝 En signature</SelectItem>
                    <SelectItem value="signe">✅ Signé</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={() => {
                if (selectedDevisIds.length > 0) {
                  handleCreateAvenant();
                } else {
                  setActiveTab("devis");
                  toast.info("Sélectionnez des devis", { description: "Cochez les devis à intégrer dans l'avenant puis cliquez sur 'Éditer l'avenant'" });
                }
              }}
              disabled={devis.filter(d => d.statut !== 'integre_avenant').length === 0}
              className="bg-orange-600 hover:bg-orange-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              {selectedDevisIds.length > 0 ? `Créer l'avenant (${selectedDevisIds.length} devis)` : "Créer un avenant"}
            </Button>
          </div>

          <AvenantsListSection
            avenants={avenants}
            loadingAvenants={loadingAvenants}
            avenantParEntreprise={avenantParEntreprise}
            openAccordionItems={openAccordionItems}
            setOpenAccordionItems={setOpenAccordionItems}
            highlightedAvenantId={highlightedAvenantId}
            devis={devis}
            getStatutColor={getStatutColor}
            getStatutLabel={getStatutLabel}
            handlePreviewAvenant={handlePreviewAvenant}
            handleEditAvenant={handleEditAvenant}
            handleDeleteAvenant={handleDeleteAvenant}
            handleChangeStatutAvenant={handleChangeStatutAvenant}
            handleUploadAvenantSigne={handleUploadAvenantSigne}
            uploadAvenantSigneMutation={uploadAvenantSigneMutation}
            handleEdit={handleEdit}
            previewingAvenant={previewingAvenant}
            generatingAvenantPDF={generatingAvenantPDF}
          />
        </TabsContent>

        {/* Onglet Suivi Financier */}
        <TabsContent value="suivi" className="space-y-6">
          <SuiviFinancierTab
            suiviFinancier={suiviFinancier}
            avenants={avenants}
            onExport={handleExportSuiviFinancier}
            navigateToAvenant={navigateToAvenant}
          />
        </TabsContent>
      </Tabs>

      {/* Dialog Nouveau/Modifier Devis */}
      <Dialog open={showDevisDialog} onOpenChange={(open) => {
        setShowDevisDialog(open);
        if (!open) {
          resetForm();
        }
      }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedDevis ? "Modifier le devis" : "Nouveau devis"}
            </DialogTitle>
            <DialogDescription>
              Saisissez les informations du devis
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} id="devis-form">
            <div className="space-y-4 py-4">
              {chantier?.client_2_id && (
                <div className="space-y-2">
                  <Label htmlFor="client_id">Client Facturé *</Label>
                  <Select
                    value={formData.client_id || chantier.client_id}
                    onValueChange={(value) => setFormData({ ...formData, client_id: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner le client" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.filter(c => c.id === chantier.client_id || c.id === chantier.client_2_id).map(client => (
                        <SelectItem key={client.id} value={client.id}>
                          {client.nom}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="marche_id">Marché / Entreprise *</Label>
                <Select
                  value={formData.marche_id}
                  onValueChange={(value) => {
                    const marcheSelectionne = marches.find(m => m.id === value);
                    const entrepriseId = marcheSelectionne ? marcheSelectionne.entreprise_id : "";
                    setFormData({ 
                      ...formData, 
                      marche_id: value,
                      entreprise_id: entrepriseId
                    });
                  }}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner le lot et l'entreprise" />
                  </SelectTrigger>
                  <SelectContent>
                    {marches.map(marche => {
                      const entreprise = entreprises.find(e => e.id === marche.entreprise_id);
                      return (
                        <SelectItem key={marche.id} value={marche.id}>
                          {marche.numero_lot ? `Lot ${marche.numero_lot} - ` : ''}{entreprise?.nom || 'Entreprise inconnue'}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="numero_devis">Numéro du devis</Label>
                  <Input
                    id="numero_devis"
                    type="text"
                    value={formData.numero_devis}
                    onChange={(e) => setFormData({ ...formData, numero_devis: e.target.value })}
                    placeholder="Ex: DEV-2024-001, 123, A1B2..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Numéro du devis fourni par l'entreprise
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="date_devis">Date du devis *</Label>
                  <Input
                    id="date_devis"
                    type="date"
                    value={formData.date_devis}
                    onChange={(e) => setFormData({ ...formData, date_devis: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="intitule_devis">Intitulé du devis *</Label>
                <Input
                  id="intitule_devis"
                  value={formData.intitule_devis}
                  onChange={(e) => setFormData({ ...formData, intitule_devis: e.target.value })}
                  placeholder="Description des travaux"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="montant_ht">Montant HT (€) *</Label>
                  <Input
                    id="montant_ht"
                    type="number"
                    step="0.01"
                    value={formData.montant_ht}
                    onChange={(e) => setFormData({ ...formData, montant_ht: e.target.value })}
                    placeholder="0.00 (négatif pour moins-value)"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type_devis">Type de devis *</Label>
                  <Select
                    value={formData.type_devis}
                    onValueChange={(value) => setFormData({ ...formData, type_devis: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TMA">TMA (Travaux Modificatifs Acquéreurs)</SelectItem>
                      <SelectItem value="TS">TS (Travaux Supplémentaires)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Phase (tranche) du chantier */}
              {chantier?.tranches?.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="tranche_numero">Phase du chantier</Label>
                  <Select
                    value={formData.tranche_numero || ""}
                    onValueChange={(value) => setFormData({ ...formData, tranche_numero: value === "none" ? "" : value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner une phase" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Aucune phase</SelectItem>
                      {chantier.tranches.map(t => (
                        <SelectItem key={t.numero} value={String(t.numero)}>
                          Phase {t.numero}{t.libelle ? ` – ${t.libelle}` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="origine_devis">Origine du devis</Label>
                <Select
                  value={formData.origine_devis}
                  onValueChange={(value) => setFormData({ ...formData, origine_devis: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner l'origine" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Aucune</SelectItem>
                    <SelectItem value="Aléas chantier">Aléas chantier</SelectItem>
                    <SelectItem value="Demande MOA">Demande MOA</SelectItem>
                    <SelectItem value="Anomalie conception">Anomalie conception</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Devis PDF</Label>
                {formData.devis_pdf_url ? (
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    <FileText className="w-5 h-5 text-orange-600" />
                    <a
                      href={formData.devis_pdf_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm flex-1 truncate text-blue-600 hover:underline"
                    >
                      {getFileName(formData.devis_pdf_url)}
                    </a>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setFormData({ ...formData, devis_pdf_url: "" })}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="relative">
                    <Input
                      type="file"
                      accept=".pdf"
                      onChange={handlePDFUpload}
                      disabled={uploadingPDF}
                      className="cursor-pointer"
                    />
                    {uploadingPDF && <p className="text-xs text-gray-500 mt-1">Téléchargement...</p>}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Notes supplémentaires..."
                  rows={3}
                />
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowDevisDialog(false);
                  resetForm();
                }}
                disabled={createDevisMutation.isPending || updateDevisMutation.isPending}
              >
                Annuler
              </Button>
              <Button
                type="submit"
                className="bg-orange-600 hover:bg-orange-700"
                disabled={createDevisMutation.isPending || updateDevisMutation.isPending || uploadingPDF}
              >
                {createDevisMutation.isPending || updateDevisMutation.isPending
                  ? "Enregistrement..."
                  : selectedDevis ? "Mettre à jour" : "Créer"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog Confirmation Suppression */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer ce devis ? Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDevisToDelete(null)}>
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog Confirmation Création Avenant */}
      <AlertDialog open={showAvenantDialog} onOpenChange={setShowAvenantDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Créer un avenant</AlertDialogTitle>
            <AlertDialogDescription>
              Vous allez créer un avenant à partir de {selectedDevisIds.length} devis sélectionné{selectedDevisIds.length > 1 ? 's' : ''}.
              <br /><br />
              <strong>Montant total:</strong> {montantTotalSelection.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT
              <br />
              <strong>Entreprise:</strong> {selectedDevisData.length > 0 ? getEntrepriseName(selectedDevisData[0].entreprise_id) : ''}
              <br /><br />
              Les devis seront marqués comme "Intégrés à avenant" et ne pourront plus être modifiés.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowAvenantDialog(false)}>Annuler</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmCreateAvenant}
              className="bg-blue-600 hover:bg-blue-700"
              disabled={createAvenantMutation.isPending}
            >
              {createAvenantMutation.isPending ? "Création..." : "Créer l'avenant"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog Import Excel */}
      <ImportDevisDialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
        marches={marches}
        entreprises={entreprises}
        clients={clients}
        chantier={chantier}
        onImportSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['travaux-sup'] });
        }}
      />

      {/* Dialog Confirmation Suppression Avenant */}
      <AlertDialog open={showDeleteAvenantDialog} onOpenChange={setShowDeleteAvenantDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer l'avenant N°{avenantToDelete?.numero} ?
              <br /><br />
              Les devis associés seront remis en statut "Brouillon" et pourront à nouveau être modifiés ou inclus dans un autre avenant.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setAvenantToDelete(null);
              setShowDeleteAvenantDialog(false);
            }}>
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteAvenant}
              className="bg-red-600 hover:bg-red-700"
              disabled={deleteAvenantMutation.isPending}
            >
              {deleteAvenantMutation.isPending ? "Suppression..." : "Supprimer"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}