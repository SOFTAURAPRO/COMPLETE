import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

/**
 * Fusionne un PDF de base avec des PDFs additionnels (factures, devis, etc.)
 * 
 * @param {string} basePdfBase64 - Le PDF de base en base64
 * @param {string[]} additionalPdfUrls - URLs des PDFs à fusionner
 * @param {string} toastId - ID du toast pour les updates
 * @returns {Promise<string>} - Le PDF fusionné en base64
 */
export async function mergePdfsWithDocuments(basePdfBase64, additionalPdfUrls, toastId = "pdf-merge") {
  if (!additionalPdfUrls || additionalPdfUrls.length === 0) {
    return basePdfBase64;
  }

  const nbDocuments = additionalPdfUrls.length;
  toast.loading(`Fusion avec ${nbDocuments} document${nbDocuments > 1 ? 's' : ''}...`, {
    description: "Assemblage des PDFs",
    id: toastId,
  });

  try {
    const fusionResponse = await base44.functions.invoke('mergePdfs', {
      pdfs: [basePdfBase64, ...additionalPdfUrls]
    });

    if (fusionResponse.data && fusionResponse.data.success && fusionResponse.data.merged_pdf_base64) {
      return fusionResponse.data.merged_pdf_base64;
    } else {
      throw new Error("La fusion a échoué");
    }
  } catch (error) {
    console.error("Erreur fusion PDF:", error);
    toast.warning("Fusion impossible", {
      description: "Le document sera téléchargé sans les pièces jointes",
      id: toastId,
    });
    return basePdfBase64;
  }
}