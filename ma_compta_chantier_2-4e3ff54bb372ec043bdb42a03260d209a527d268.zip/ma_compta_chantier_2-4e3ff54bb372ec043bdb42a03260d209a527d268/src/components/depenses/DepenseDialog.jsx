import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const categories = [
  { value: "materiaux", label: "Matériaux" },
  { value: "main_oeuvre", label: "Main d'œuvre" },
  { value: "equipement", label: "Équipement" },
  { value: "sous_traitance", label: "Sous-traitance" },
  { value: "transport", label: "Transport" },
  { value: "administratif", label: "Administratif" },
  { value: "autres", label: "Autres" }
];

export default function DepenseDialog({ open, onOpenChange, depense, chantiers, onSubmit, isLoading }) {
  const [formData, setFormData] = useState({
    chantier_id: "",
    date: new Date().toISOString().split('T')[0],
    categorie: "materiaux",
    description: "",
    fournisseur: "",
    montant: "",
    numero_facture: "",
    statut_paiement: "en_attente",
    notes: ""
  });

  useEffect(() => {
    if (depense) {
      setFormData({
        chantier_id: depense.chantier_id || "",
        date: depense.date || "",
        categorie: depense.categorie || "materiaux",
        description: depense.description || "",
        fournisseur: depense.fournisseur || "",
        montant: depense.montant || "",
        numero_facture: depense.numero_facture || "",
        statut_paiement: depense.statut_paiement || "en_attente",
        notes: depense.notes || ""
      });
    } else {
      setFormData({
        chantier_id: chantiers.length > 0 ? chantiers[0].id : "",
        date: new Date().toISOString().split('T')[0],
        categorie: "materiaux",
        description: "",
        fournisseur: "",
        montant: "",
        numero_facture: "",
        statut_paiement: "en_attente",
        notes: ""
      });
    }
  }, [depense, open, chantiers]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      montant: parseFloat(formData.montant) || 0
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {depense ? "Modifier la dépense" : "Nouvelle dépense"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="chantier_id">Chantier *</Label>
              <Select
                value={formData.chantier_id}
                onValueChange={(value) => setFormData({ ...formData, chantier_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un chantier" />
                </SelectTrigger>
                <SelectContent>
                  {chantiers.map(chantier => (
                    <SelectItem key={chantier.id} value={chantier.id}>
                      {chantier.nom}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="categorie">Catégorie *</Label>
                <Select
                  value={formData.categorie}
                  onValueChange={(value) => setFormData({ ...formData, categorie: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Ex: Achat de ciment"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fournisseur">Fournisseur</Label>
                <Input
                  id="fournisseur"
                  value={formData.fournisseur}
                  onChange={(e) => setFormData({ ...formData, fournisseur: e.target.value })}
                  placeholder="Nom du fournisseur"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="montant">Montant (€) *</Label>
                <Input
                  id="montant"
                  type="number"
                  step="0.01"
                  value={formData.montant}
                  onChange={(e) => setFormData({ ...formData, montant: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="numero_facture">N° Facture</Label>
                <Input
                  id="numero_facture"
                  value={formData.numero_facture}
                  onChange={(e) => setFormData({ ...formData, numero_facture: e.target.value })}
                  placeholder="Ex: F-2024-001"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="statut_paiement">Statut paiement</Label>
                <Select
                  value={formData.statut_paiement}
                  onValueChange={(value) => setFormData({ ...formData, statut_paiement: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en_attente">En attente</SelectItem>
                    <SelectItem value="paye">Payé</SelectItem>
                    <SelectItem value="partiel">Partiel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Notes supplémentaires..."
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Annuler
            </Button>
            <Button 
              type="submit" 
              className="bg-orange-600 hover:bg-orange-700"
              disabled={isLoading}
            >
              {isLoading ? "Enregistrement..." : depense ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}