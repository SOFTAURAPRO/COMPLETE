import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Pencil, Package, Users, Wrench, Truck, FileText } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const categorieIcons = {
  materiaux: Package,
  main_oeuvre: Users,
  equipement: Wrench,
  sous_traitance: Users,
  transport: Truck,
  administratif: FileText,
  autres: FileText
};

const categorieLabels = {
  materiaux: "Matériaux",
  main_oeuvre: "Main d'œuvre",
  equipement: "Équipement",
  sous_traitance: "Sous-traitance",
  transport: "Transport",
  administratif: "Administratif",
  autres: "Autres"
};

const categorieColors = {
  materiaux: "bg-blue-100 text-blue-800 border-blue-200",
  main_oeuvre: "bg-green-100 text-green-800 border-green-200",
  equipement: "bg-purple-100 text-purple-800 border-purple-200",
  sous_traitance: "bg-yellow-100 text-yellow-800 border-yellow-200",
  transport: "bg-orange-100 text-orange-800 border-orange-200",
  administratif: "bg-pink-100 text-pink-800 border-pink-200",
  autres: "bg-gray-100 text-gray-800 border-gray-200"
};

const statutColors = {
  en_attente: "bg-yellow-100 text-yellow-800 border-yellow-200",
  paye: "bg-green-100 text-green-800 border-green-200",
  partiel: "bg-orange-100 text-orange-800 border-orange-200"
};

const statutLabels = {
  en_attente: "En attente",
  paye: "Payé",
  partiel: "Partiel"
};

export default function DepensesList({ depenses, chantiers, onEdit }) {
  const getChantierName = (chantierId) => {
    const chantier = chantiers.find(c => c.id === chantierId);
    return chantier?.nom || "Chantier inconnu";
  };

  if (depenses.length === 0) {
    return (
      <Card className="p-12 text-center">
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucune dépense enregistrée
        </h3>
        <p className="text-gray-500">
          Ajoutez votre première dépense pour commencer le suivi
        </p>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead>Date</TableHead>
              <TableHead>Chantier</TableHead>
              <TableHead>Catégorie</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Fournisseur</TableHead>
              <TableHead>Montant</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {depenses.map((depense) => {
              const Icon = categorieIcons[depense.categorie] || FileText;
              return (
                <TableRow key={depense.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">
                    {format(new Date(depense.date), "dd/MM/yyyy", { locale: fr })}
                  </TableCell>
                  <TableCell>
                    <span className="text-sm font-medium text-gray-700">
                      {getChantierName(depense.chantier_id)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge className={`${categorieColors[depense.categorie]} border gap-1`}>
                      <Icon className="w-3 h-3" />
                      {categorieLabels[depense.categorie]}
                    </Badge>
                  </TableCell>
                  <TableCell>{depense.description}</TableCell>
                  <TableCell className="text-sm text-gray-600">
                    {depense.fournisseur || "-"}
                  </TableCell>
                  <TableCell className="font-semibold text-orange-600">
                    {depense.montant.toLocaleString("fr-FR")} €
                  </TableCell>
                  <TableCell>
                    <Badge className={`${statutColors[depense.statut_paiement]} border`}>
                      {statutLabels[depense.statut_paiement]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(depense)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}