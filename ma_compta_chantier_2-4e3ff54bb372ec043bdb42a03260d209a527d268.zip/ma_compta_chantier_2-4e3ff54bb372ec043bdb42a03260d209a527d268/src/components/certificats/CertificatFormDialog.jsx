import React, { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Plus, X, Upload, Pencil, Trash2, Check } from "lucide-react";
import TranchesHtSection from "./TranchesHtSection";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";

function NotePrecedenteRow({ cert }) {
  const [editing, setEditing] = useState(false);
  const [noteValue, setNoteValue] = useState(cert.notes || "");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await base44.entities.CertificatPaiement.update(cert.id, { notes: noteValue });
    setSaving(false);
    setEditing(false);
  };

  const handleDelete = async () => {
    setSaving(true);
    await base44.entities.CertificatPaiement.update(cert.id, { notes: "" });
    setSaving(false);
  };

  if (!cert.notes && !editing) return null;

  return (
    <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-medium text-gray-500">CP N°{cert.numero} — {MOIS_LABELS[cert.mois]} {cert.annee}</span>
        <div className="flex gap-1">
          {!editing && (
            <>
              <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setNoteValue(cert.notes || ""); setEditing(true); }}>
                <Pencil className="w-3 h-3 text-gray-500" />
              </Button>
              <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={handleDelete} disabled={saving}>
                <Trash2 className="w-3 h-3 text-red-400" />
              </Button>
            </>
          )}
          {editing && (
            <>
              <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={handleSave} disabled={saving}>
                <Check className="w-3 h-3 text-green-600" />
              </Button>
              <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditing(false)}>
                <X className="w-3 h-3 text-gray-400" />
              </Button>
            </>
          )}
        </div>
      </div>
      {editing ? (
        <Textarea value={noteValue} onChange={(e) => setNoteValue(e.target.value)} rows={2} className="text-xs" />
      ) : (
        <p className="text-gray-700 whitespace-pre-wrap">{cert.notes}</p>
      )}
    </div>
  );
}

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 10 }, (_, i) => CURRENT_YEAR - 5 + i);

export default function CertificatFormDialog({
  showDialog, setShowDialog, selectedCertificat, handleSubmit,
  formData, setFormData, chantier, clients, marches, entreprises,
  entreprisesSousTraitantes, createMutation, updateMutation,
  uploadingPDF, handlePDFUpload,
  handleAddSousTraitant, handleRemoveSousTraitant, handleUpdateSousTraitant,
  handleAddPenalite, handleRemovePenalite, handleUpdatePenalite,
  montantCumuleSituationsPrecedentes, montantCumuleMarcheBasePrecedentes, montantCumuleAvenantsPrecedentes,
  montantNouveauMarcheHT, montantTotalPenalites, montantTotalPenalitesPrecedentes,
  currentCIEAmount, getPendingCIE, resetForm, getFileName,
  tauxTVA = 20,
  avenants = [],
  certificats = [],
}) {
  // Tranches du chantier
  const tranchesChantier = chantier?.tranches || [];
  const fileInputRef = useRef(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const marchesTries = [...(marches || [])].sort((a, b) => {
    const numA = a.numero_lot || '';
    const numB = b.numero_lot || '';
    return numA.localeCompare(numB, undefined, { numeric: true });
  });

  const facturesUrls = formData.factures_urls?.length > 0
    ? formData.factures_urls
    : (formData.facture_pdf_url ? [formData.facture_pdf_url] : []);

  const handleAddFacture = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    for (const file of Array.from(files)) {
      await handlePDFUpload({ target: { files: [file] } }, true);
    }
  };

  const handleDropFacture = async (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      for (const file of Array.from(files)) {
        await handlePDFUpload({ target: { files: [file] } }, true);
      }
    }
  };

  const handleRemoveFacture = (idx) => {
    const newUrls = facturesUrls.filter((_, i) => i !== idx);
    setFormData({
      ...formData,
      factures_urls: newUrls,
      facture_pdf_url: newUrls[0] || ""
    });
  };

  // Marché sélectionné
  const marcheSelectionne = marches?.find(m => m.id === formData.marche_id);
  const penalitesChantier = chantier?.penalites || [];

  // Calcul du cumul des RG et du remboursement automatique
  const computeRGRembursement = () => {
    if (!marcheSelectionne || !formData.mois) return { rgCumul: 0, rembursement: 0, hasCalcMonthCaution: false };
    
    const cautions = marcheSelectionne.cautions || [];
    const sitYear = parseInt(formData.annee || new Date().getFullYear());
    const sitMonth = parseInt(formData.mois || 1);
    const pad = (n) => String(n).padStart(2, '0');
    const premierJourMoisStr = `${sitYear}-${pad(sitMonth)}-01`;
    const dernierJourMoisStr = `${sitYear}-${pad(sitMonth)}-${pad(new Date(sitYear, sitMonth, 0).getDate())}`;
    
    const getDateCautionStr = (c) => {
      if (c.date_reception) return c.date_reception.substring(0, 10);
      if (c.date_ajout) return c.date_ajout.substring(0, 10);
      return premierJourMoisStr;
    };
    
    // Cautions reçues jusqu'au dernier jour du mois courant
    const cautionJusquACeMois = cautions
      .filter(c => getDateCautionStr(c) <= dernierJourMoisStr)
      .reduce((s, c) => s + (c.montant || 0), 0);
    
    // Cumul RG des situations précédentes : somme des montant_rg enregistrés
    const numeroActuel = formData.numero ? parseInt(formData.numero) : Math.max(0, ...certificats.filter(c => c.marche_id === formData.marche_id).map(c => parseInt(c.numero) || 0)) + 1;
    const certsPrecedents = certificats.filter(c => 
      c.marche_id === formData.marche_id && 
      c.statut === 'valide' && 
      c.id !== selectedCertificat?.id && 
      parseInt(c.numero || 0) < numeroActuel
    );
    
    // Vérifier si une RG a déjà été remboursée dans un CP précédent
    const rgAlreadyReimbursed = certsPrecedents.some(c => (c.remboursement_rg || 0) > 0);
    
    const rgCumul = rgAlreadyReimbursed ? 0 : certsPrecedents.reduce((sum, c) => sum + (c.montant_rg || 0), 0);
    
    // Remboursement = cumul RG si caution reçue ce mois ET RG pas encore remboursée
    const hasCalcMonthCaution = cautions.some(c => {
      const cautionDate = getDateCautionStr(c);
      return cautionDate >= premierJourMoisStr && cautionDate <= dernierJourMoisStr;
    });
    
    return { 
      rgCumul, 
      rembursement: (hasCalcMonthCaution && !rgAlreadyReimbursed) ? rgCumul : 0,
      hasCalcMonthCaution: hasCalcMonthCaution && !rgAlreadyReimbursed
    };
  };

  const { rgCumul, rembursement: autoRembursement, hasCalcMonthCaution } = computeRGRembursement();

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{selectedCertificat ? "Modifier la situation" : "Nouvelle situation"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">

            {/* Numéro, Mois, Année */}
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>N° Situation</Label>
                <Input
                  value={formData.numero || ""}
                  onChange={(e) => setFormData({ ...formData, numero: e.target.value })}
                  placeholder="01"
                />
              </div>
              <div className="space-y-2">
                <Label>Mois *</Label>
                <Select value={formData.mois} onValueChange={(v) => setFormData({ ...formData, mois: v })}>
                  <SelectTrigger><SelectValue placeholder="Mois" /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(MOIS_LABELS).map(([key, label]) => (
                      <SelectItem key={key} value={key}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Année *</Label>
                <Select value={formData.annee} onValueChange={(v) => setFormData({ ...formData, annee: v })}>
                  <SelectTrigger><SelectValue placeholder="Année" /></SelectTrigger>
                  <SelectContent>
                    {YEARS.map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Marché */}
            <div className="space-y-2">
              <Label>Marché (Lot) *</Label>
              <Select
                value={formData.marche_id}
                onValueChange={(v) => {
                  const m = marches?.find(x => x.id === v);
                  setFormData({ ...formData, marche_id: v, entreprise_id: m?.entreprise_id || formData.entreprise_id });
                }}
              >
                <SelectTrigger><SelectValue placeholder="Sélectionner un marché" /></SelectTrigger>
                <SelectContent>
                  {marchesTries.map(m => {
                    const ent = entreprises?.find(e => e.id === m.entreprise_id);
                    return (
                      <SelectItem key={m.id} value={m.id}>
                        Lot {m.numero_lot} – {m.intitule_lot}{ent ? ` (${ent.nom})` : ''}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* Rappel montant marché + avenants */}
            {marcheSelectionne && (
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-lg text-sm">
                <div className="text-center">
                  <p className="text-xs text-gray-500 mb-0.5">Marché de base HT</p>
                  <p className="font-bold text-gray-800">
                    {(marcheSelectionne.montant || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </p>
                </div>
                <div className="text-center border-x border-slate-200">
                  <p className="text-xs text-gray-500 mb-0.5">Avenants HT</p>
                  <p className="font-bold text-blue-700">
                    {avenants
                      .filter(a => a.marche_id === formData.marche_id)
                      .reduce((s, a) => s + (a.montant_total_ht || 0), 0)
                      .toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-gray-500 mb-0.5">Total marché HT</p>
                  <p className="font-bold text-orange-700">
                    {montantNouveauMarcheHT.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </p>
                </div>
              </div>
            )}

            {/* Numéro facture, Date facture */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>N° Facture</Label>
                <Input
                  value={formData.numero_facture || ""}
                  onChange={(e) => setFormData({ ...formData, numero_facture: e.target.value })}
                  placeholder="FA-2024-001"
                />
              </div>
              <div className="space-y-2">
                <Label>Date Facture</Label>
                <Input
                  type="date"
                  value={formData.date_facture || ""}
                  onChange={(e) => setFormData({ ...formData, date_facture: e.target.value })}
                />
              </div>
            </div>

            {/* Montants HT */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Montant HT Marché de base (€) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.montant_ht_base ?? ""}
                  onChange={(e) => {
                    const base = parseFloat(e.target.value) || 0;
                    const av = parseFloat(formData.montant_ht_avenants) || 0;
                    setFormData({ ...formData, montant_ht_base: e.target.value, montant_ht: base + av });
                  }}
                  placeholder="0,00"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Montant HT Avenants (€)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.montant_ht_avenants ?? ""}
                  onChange={(e) => {
                    const av = parseFloat(e.target.value) || 0;
                    const base = parseFloat(formData.montant_ht_base) || 0;
                    setFormData({ ...formData, montant_ht_avenants: e.target.value, montant_ht: base + av });
                  }}
                  placeholder="0,00"
                />
              </div>
            </div>

            {/* Saisie par tranche */}
            {tranchesChantier.length > 0 && formData.marche_id && (
              <TranchesHtSection
                tranches={tranchesChantier}
                marchesTrancheMontants={marcheSelectionne?.tranches_montants || []}
                montantsParTranche={formData.montants_par_tranche || []}
                onChange={(newTranches) => {
                  const totalBase = newTranches.reduce((s, t) => s + (t.montant_ht_base || 0), 0);
                  const totalAv = newTranches.reduce((s, t) => s + (t.montant_ht_avenants || 0), 0);
                  setFormData({
                    ...formData,
                    montants_par_tranche: newTranches,
                    montant_ht_base: totalBase,
                    montant_ht_avenants: totalAv,
                    montant_ht: totalBase + totalAv
                  });
                }}
              />
            )}

            {/* Tableau récapitulatif avancement */}
            {formData.marche_id && (
              <div className="rounded-lg border border-orange-200 bg-orange-50 overflow-hidden">
                <div className="px-3 py-2 bg-orange-100 border-b border-orange-200">
                  <span className="text-xs font-semibold text-orange-800 uppercase tracking-wide">Récapitulatif avancement</span>
                </div>
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-orange-100 text-orange-900">
                      <th className="text-left px-3 py-1.5 font-semibold">Élément</th>
                      <th className="text-right px-3 py-1.5 font-semibold">Montant marché HT</th>
                      <th className="text-right px-3 py-1.5 font-semibold">Montant marché TTC</th>
                      <th className="text-right px-3 py-1.5 font-semibold">Cumul précédent HT</th>
                      <th className="text-right px-3 py-1.5 font-semibold">Situation HT</th>
                      <th className="text-right px-3 py-1.5 font-semibold">Nouveau cumul HT</th>
                      <th className="text-right px-3 py-1.5 font-semibold">% Avancement</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      const marcheSelectionne = marches?.find(m => m.id === formData.marche_id);
                      const montantMarcheBase = marcheSelectionne?.montant || 0;
                      const tauxTVAMarche = marcheSelectionne?.taux_tva || tauxTVA || 20;
                      const sitBase = parseFloat(formData.montant_ht_base) || 0;
                      const sitAv = parseFloat(formData.montant_ht_avenants) || 0;
                      const sitTotal = sitBase + sitAv;
                      const montantAvenantsMarche = montantNouveauMarcheHT - montantMarcheBase;
                      const cumBase = montantCumuleMarcheBasePrecedentes + sitBase;
                      const cumAv = montantCumuleAvenantsPrecedentes + sitAv;
                      const cumTotal = montantCumuleSituationsPrecedentes + sitTotal;
                      const pctBase = montantMarcheBase > 0 ? ((cumBase / montantMarcheBase) * 100).toFixed(1) : '-';
                      const pctAv = montantAvenantsMarche > 0 ? ((cumAv / montantAvenantsMarche) * 100).toFixed(1) : '-';
                      const pctTotal = montantNouveauMarcheHT > 0 ? ((cumTotal / montantNouveauMarcheHT) * 100).toFixed(1) : '-';
                      const fmt = (v) => v.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
                      const fmtTTC = (v) => (v * (1 + tauxTVAMarche / 100)).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';

                      // Tranches du chantier
                      const tranches = chantier?.tranches || [];
                      // Avenants liés à ce marché
                      const avenantsDuMarche = (avenants || []).filter(a => a.marche_id === formData.marche_id);

                      return <>
                        {/* Marché de base global */}
                        <tr className="border-t border-orange-100 font-semibold bg-orange-50">
                          <td className="px-3 py-1.5 text-gray-800">
                            Marché de Base
                            <span className="ml-2 text-xs font-normal text-gray-500">HT {fmt(montantMarcheBase)} — TTC {fmtTTC(montantMarcheBase)}</span>
                          </td>
                          <td className="px-3 py-1.5 text-right font-mono">{fmt(montantMarcheBase)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-gray-600">{fmtTTC(montantMarcheBase)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-gray-500">{fmt(montantCumuleMarcheBasePrecedentes)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-orange-700 font-semibold">{fmt(sitBase)}</td>
                          <td className="px-3 py-1.5 text-right font-mono font-semibold">{fmt(cumBase)}</td>
                          <td className="px-3 py-1.5 text-right font-semibold text-orange-700">{pctBase !== '-' ? pctBase + ' %' : '-'}</td>
                        </tr>

                        {/* Phases (tranches) du marché de base */}
                        {tranches.length > 0 && tranches.map(t => {
                          const trancheMontant = marcheSelectionne?.tranches_montants?.find(tm => tm.tranche_numero === t.numero);
                          const montantBasePhase = trancheMontant?.montant_ht || 0;

                          // Situation courante pour cette phase
                          const trancheFormData = (formData.montants_par_tranche || []).find(tp => tp.tranche_numero === t.numero);
                          const sitBasePhase = trancheFormData?.montant_ht_base || 0;
                          const sitAvPhase = trancheFormData?.montant_ht_avenants || 0;
                          const sitTotalPhase = sitBasePhase + sitAvPhase;

                          // Cumul précédent pour cette phase (depuis les certificats validés précédents)
                          const numeroActuelCert = formData.numero ? parseInt(formData.numero) : 9999;
                          const certsPrecedents = (certificats || []).filter(c =>
                            c.marche_id === formData.marche_id &&
                            c.statut === 'valide' &&
                            c.id !== selectedCertificat?.id &&
                            parseInt(c.numero || 0) < numeroActuelCert
                          );
                          const cumulPrecedentPhase = certsPrecedents.reduce((sum, c) => {
                            const tp = (c.montants_par_tranche || []).find(tp => tp.tranche_numero === t.numero);
                            return sum + (tp ? (tp.montant_ht_base || 0) + (tp.montant_ht_avenants || 0) : 0);
                          }, 0);

                          const nouveauCumulPhase = cumulPrecedentPhase + sitTotalPhase;
                          const pctPhase = montantBasePhase > 0 ? ((nouveauCumulPhase / montantBasePhase) * 100).toFixed(1) : null;

                          return (
                            <tr key={t.numero} className="border-t border-orange-50 bg-white">
                              <td className="px-3 py-1 text-gray-600 pl-6 text-xs">
                                Phase {t.numero}{t.libelle ? ` – ${t.libelle}` : ''}
                              </td>
                              <td className="px-3 py-1 text-right font-mono text-gray-600 text-xs">{montantBasePhase > 0 ? fmt(montantBasePhase) : '-'}</td>
                              <td className="px-3 py-1 text-right font-mono text-gray-500 text-xs">{montantBasePhase > 0 ? fmtTTC(montantBasePhase) : '-'}</td>
                              <td className="px-3 py-1 text-right font-mono text-gray-400 text-xs">{cumulPrecedentPhase > 0 ? fmt(cumulPrecedentPhase) : '-'}</td>
                              <td className="px-3 py-1 text-right font-mono text-orange-600 text-xs font-semibold">{sitTotalPhase > 0 ? fmt(sitTotalPhase) : '-'}</td>
                              <td className="px-3 py-1 text-right font-mono text-xs">{nouveauCumulPhase > 0 ? fmt(nouveauCumulPhase) : '-'}</td>
                              <td className="px-3 py-1 text-right text-xs font-semibold text-orange-700">
                                {pctPhase !== null ? `${pctPhase} %` : '-'}
                              </td>
                            </tr>
                          );
                        })}

                        {/* Avenants par phase */}
                        {avenantsDuMarche.length > 0 && (
                          <tr className="border-t border-blue-100 bg-blue-50">
                            <td colSpan={7} className="px-3 py-1 text-xs font-semibold text-blue-800">Avenants</td>
                          </tr>
                        )}
                        {avenantsDuMarche.map(av => (
                          <tr key={av.id} className="border-t border-blue-50 bg-white">
                            <td className="px-3 py-1 text-gray-600 pl-6">
                              Avenant N°{av.numero}
                              {av.intitule ? ` – ${av.intitule}` : ''}
                            </td>
                            <td className="px-3 py-1 text-right font-mono text-blue-700">{fmt(av.montant_total_ht || 0)}</td>
                            <td className="px-3 py-1 text-right font-mono text-blue-600">{fmtTTC(av.montant_total_ht || 0)}</td>
                            <td colSpan={4} className="px-3 py-1 text-gray-400"></td>
                          </tr>
                        ))}

                        {/* Ligne Avenants totaux */}
                        <tr className="border-t border-orange-100">
                          <td className="px-3 py-1.5 text-gray-700">Total Avenants</td>
                          <td className="px-3 py-1.5 text-right font-mono">{fmt(montantAvenantsMarche)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-gray-600">{fmtTTC(montantAvenantsMarche)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-gray-500">{fmt(montantCumuleAvenantsPrecedentes)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-orange-700 font-semibold">{fmt(sitAv)}</td>
                          <td className="px-3 py-1.5 text-right font-mono font-semibold">{fmt(cumAv)}</td>
                          <td className="px-3 py-1.5 text-right font-semibold text-orange-700">{pctAv !== '-' ? pctAv + ' %' : '-'}</td>
                        </tr>

                        {/* Total général */}
                        <tr className="border-t-2 border-orange-300 bg-orange-100 font-bold">
                          <td className="px-3 py-1.5">TOTAL MARCHÉ</td>
                          <td className="px-3 py-1.5 text-right font-mono">{fmt(montantNouveauMarcheHT)}</td>
                          <td className="px-3 py-1.5 text-right font-mono">{fmtTTC(montantNouveauMarcheHT)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-gray-600">{fmt(montantCumuleSituationsPrecedentes)}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-orange-700">{fmt(sitTotal)}</td>
                          <td className="px-3 py-1.5 text-right font-mono">{fmt(cumTotal)}</td>
                          <td className="px-3 py-1.5 text-right text-orange-700">{pctTotal !== '-' ? pctTotal + ' %' : '-'}</td>
                        </tr>
                      </>;
                    })()}
                  </tbody>
                </table>
              </div>
            )}

            {/* Acompte */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Demande d'acompte (€)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.demande_acompte ?? ""}
                  onChange={(e) => setFormData({ ...formData, demande_acompte: parseFloat(e.target.value) || 0 })}
                  placeholder="0,00"
                />
              </div>
              <div className="space-y-2">
                <Label>Remboursement d'acompte (€)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.remboursement_acompte ?? ""}
                  onChange={(e) => setFormData({ ...formData, remboursement_acompte: parseFloat(e.target.value) || 0 })}
                  placeholder="0,00"
                />
              </div>
            </div>

            {/* Retenue de Garantie */}
            <div className="space-y-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div>
                <Label className="text-base font-semibold text-blue-900">Retenue de Garantie</Label>
              </div>
              
              {marcheSelectionne && (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Cumul des RG prélevées (TTC)</p>
                    <p className="text-lg font-bold text-blue-700">
                      {rgCumul.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                    </p>
                    {hasCalcMonthCaution && (
                      <p className="text-xs text-green-700 mt-1">✓ Caution reçue ce mois</p>
                    )}
                  </div>
                  <div>
                    <p className="text-gray-600">Remboursement auto (€)</p>
                    <p className="text-lg font-bold text-green-700">
                      {autoRembursement.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Remboursement RG (€)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.remboursement_rg ?? ""}
                    onChange={(e) => setFormData({ ...formData, remboursement_rg: parseFloat(e.target.value) || 0 })}
                    placeholder="0,00"
                  />
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, remboursement_rg: autoRembursement })}
                    className="text-xs text-blue-600 hover:text-blue-800 underline"
                  >
                    Utiliser la valeur auto
                  </button>
                </div>
                <div className="space-y-2">
                  <Label>Déblocage RG (€)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.deblocage_rg ?? ""}
                    onChange={(e) => setFormData({ ...formData, deblocage_rg: parseFloat(e.target.value) || 0 })}
                    placeholder="0,00"
                  />
                </div>
              </div>
            </div>

            {/* Pénalités et retenues diverses */}
            {(penalitesChantier.length > 0 || formData.penalites_appliquees?.length > 0) && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-base font-semibold">Pénalités et retenues diverses</Label>
                  <Button type="button" variant="outline" size="sm" onClick={handleAddPenalite} className="gap-1">
                    <Plus className="w-3 h-3" />
                    Ajouter
                  </Button>
                </div>
                {formData.penalites_appliquees?.map((pen, idx) => {
                  const categorie = pen.categorie || 'penalite';
                  return (
                    <div key={idx} className={`flex gap-2 items-end p-3 border rounded-lg ${categorie === 'retenue' ? 'bg-yellow-50 border-yellow-100' : 'bg-red-50 border-red-100'}`}>
                      {/* Case à cocher Pénalité / Retenue */}
                      <div className="flex flex-col gap-1 justify-center pt-4">
                        <label className="flex items-center gap-1 cursor-pointer text-xs font-medium text-red-700">
                          <input
                            type="radio"
                            name={`categorie_${idx}`}
                            value="penalite"
                            checked={categorie === 'penalite'}
                            onChange={() => handleUpdatePenalite(idx, 'categorie', 'penalite')}
                            className="accent-red-600"
                          />
                          Pénalité
                        </label>
                        <label className="flex items-center gap-1 cursor-pointer text-xs font-medium text-yellow-700">
                          <input
                            type="radio"
                            name={`categorie_${idx}`}
                            value="retenue"
                            checked={categorie === 'retenue'}
                            onChange={() => handleUpdatePenalite(idx, 'categorie', 'retenue')}
                            className="accent-yellow-600"
                          />
                          Retenue
                        </label>
                      </div>
                      <div className="flex-1 space-y-1">
                        <Label className="text-xs">Type</Label>
                        <Select
                          value={pen.type_penalite || ""}
                          onValueChange={(v) => {
                            const found = penalitesChantier.find(p => p.type_penalite === v);
                            handleUpdatePenalite(idx, 'type_penalite', v);
                            if (found?.categorie) handleUpdatePenalite(idx, 'categorie', found.categorie);
                          }}
                        >
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue placeholder="Sélectionner..." />
                          </SelectTrigger>
                          <SelectContent>
                            {penalitesChantier.map((p, i) => (
                              <SelectItem key={i} value={p.type_penalite}>{p.type_penalite}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-24 space-y-1">
                        <Label className="text-xs">Nombre/Jours</Label>
                        <Input
                          type="number"
                          step="1"
                          className="h-8 text-xs"
                          value={pen.nombre || ""}
                          onChange={(e) => handleUpdatePenalite(idx, 'nombre', e.target.value)}
                          placeholder="0"
                        />
                      </div>
                      <div className="w-28 space-y-1">
                        <Label className="text-xs">Montant TTC (€)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          className="h-8 text-xs"
                          value={pen.montant_calcule || ""}
                          onChange={(e) => handleUpdatePenalite(idx, 'montant_calcule', parseFloat(e.target.value) || 0)}
                          placeholder="0,00"
                        />
                      </div>
                      <Button type="button" variant="ghost" size="icon" onClick={() => handleRemovePenalite(idx)} className="text-red-500">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                })}
                {(formData.penalites_appliquees?.length > 0) && (
                  <div className="space-y-2">
                    <Label>Remboursement pénalités (€)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.remboursement_penalites ?? ""}
                      onChange={(e) => setFormData({ ...formData, remboursement_penalites: parseFloat(e.target.value) || 0 })}
                      placeholder="0,00"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Sous-traitants */}
            {entreprisesSousTraitantes?.length > 0 && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label className="text-base font-semibold">Paiements sous-traitants</Label>
                  <Button type="button" variant="outline" size="sm" onClick={handleAddSousTraitant} className="gap-1">
                    <Plus className="w-3 h-3" />
                    Ajouter
                  </Button>
                </div>
                {formData.paiements_sous_traitants?.map((st, idx) => (
                  <div key={idx} className="flex gap-2 items-end">
                    <div className="flex-1 space-y-1">
                      <Label className="text-xs">Sous-traitant</Label>
                      <Select
                        value={st.entreprise_id || ""}
                        onValueChange={(v) => handleUpdateSousTraitant(idx, 'entreprise_id', v)}
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="Sélectionner" />
                        </SelectTrigger>
                        <SelectContent>
                          {entreprisesSousTraitantes.map(e => (
                            <SelectItem key={e.id} value={e.id}>{e.nom}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-36 space-y-1">
                      <Label className="text-xs">Montant HT (€)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        className="h-8 text-xs"
                        value={st.montant_ht || ""}
                        onChange={(e) => handleUpdateSousTraitant(idx, 'montant_ht', e.target.value)}
                        placeholder="0,00"
                      />
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveSousTraitant(idx)} className="text-red-500">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            {/* Factures */}
            <div className="space-y-2">
              <Label>Factures (PDF)</Label>
              <div
                className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${isDragOver ? 'border-orange-400 bg-orange-50' : 'border-gray-300 hover:border-gray-400'}`}
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDropFacture}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-500">Glisser-déposer ou cliquer pour ajouter une ou plusieurs factures</p>
                <input ref={fileInputRef} type="file" accept=".pdf" multiple className="hidden" onChange={handleAddFacture} />
              </div>
              {facturesUrls.length > 0 && (
                <div className="space-y-1">
                  {facturesUrls.map((url, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 bg-gray-50 rounded border">
                      <FileText className="w-4 h-4 text-orange-500" />
                      <a href={url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline flex-1 truncate">
                        {getFileName(url) || `Facture ${idx + 1}`}
                      </a>
                      <Button type="button" variant="ghost" size="icon" onClick={() => handleRemoveFacture(idx)} className="h-6 w-6">
                        <X className="w-3 h-3 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Historique des notes des situations précédentes */}
            {(() => {
              if (!formData.marche_id || !certificats?.length) return null;
              const numeroActuel = formData.numero ? parseInt(formData.numero) : 9999;
              const precedents = certificats
                .filter(c => c.marche_id === formData.marche_id && c.notes && c.id !== selectedCertificat?.id && parseInt(c.numero || 0) < numeroActuel)
                .sort((a, b) => parseInt(a.numero || 0) - parseInt(b.numero || 0));
              if (precedents.length === 0) return null;
              return (
                <div className="space-y-2">
                  <Label className="text-sm font-semibold text-gray-700">Historique des notes</Label>
                  <div className="space-y-2">
                    {precedents.map(cert => (
                      <NotePrecedenteRow key={cert.id} cert={cert} />
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* Notes de la situation en cours */}
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes || ""}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Observations, commentaires..."
                rows={3}
              />
            </div>

          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { setShowDialog(false); resetForm(); }}>
              Annuler
            </Button>
            <Button
              type="submit"
              className="bg-orange-600 hover:bg-orange-700"
              disabled={createMutation.isPending || updateMutation.isPending || uploadingPDF}
            >
              {createMutation.isPending || updateMutation.isPending
                ? "Enregistrement..."
                : selectedCertificat ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}