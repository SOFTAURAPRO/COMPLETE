import React, { useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Download, Trash2, Upload, FileText } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function CertificatsEnvoyesMOE({ chantierId }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [toDelete, setToDelete] = useState(null);
  const queryClient = useQueryClient();

  const { data: fichiers = [], isLoading } = useQuery({
    queryKey: ["cp-envoyes-moe", chantierId],
    queryFn: async () => {
      const all = await base44.entities.CertificatEnvoyeMOE.list("nom_fichier");
      return all
        .filter((f) => f.chantier_id === chantierId)
        .sort((a, b) => a.nom_fichier.localeCompare(b.nom_fichier, undefined, { numeric: true }));
    },
    initialData: [],
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CertificatEnvoyeMOE.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cp-envoyes-moe", chantierId] });
      toast.success("Fichier supprimé");
    },
  });

  const handleFiles = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    let count = 0;
    for (const file of Array.from(files)) {
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        await base44.entities.CertificatEnvoyeMOE.create({
          chantier_id: chantierId,
          nom_fichier: file.name,
          url_fichier: file_url,
        });
        count++;
      } catch {
        toast.error(`Erreur pour ${file.name}`);
      }
    }
    queryClient.invalidateQueries({ queryKey: ["cp-envoyes-moe", chantierId] });
    if (count > 0) toast.success(`${count} fichier(s) ajouté(s)`);
    setUploading(false);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div className="space-y-4">
      {/* Zone de dépôt */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors ${
          dragging
            ? "border-orange-400 bg-orange-50"
            : "border-gray-200 hover:border-orange-300 hover:bg-orange-50/40"
        }`}
      >
        <Upload className="w-8 h-8 mx-auto text-orange-400 mb-3" />
        <p className="text-sm font-medium text-gray-700">
          {uploading ? "Téléchargement en cours..." : "Glissez vos certificats PDF ici"}
        </p>
        <p className="text-xs text-gray-400 mt-1">ou cliquez pour sélectionner des fichiers</p>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.xlsx,.xls"
          multiple
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      {/* Liste des fichiers */}
      {isLoading && <p className="text-sm text-gray-400">Chargement...</p>}

      {!isLoading && fichiers.length === 0 && (
        <div className="text-center py-8 text-gray-400 text-sm">
          Aucun certificat déposé pour l'instant
        </div>
      )}

      {fichiers.length > 0 && (
        <div className="border rounded-lg overflow-hidden divide-y">
          {fichiers.map((f) => (
            <div key={f.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50">
              <div className="flex items-center gap-3 min-w-0">
                <FileText className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="text-sm font-mono text-gray-800 truncate">{f.nom_fichier}</span>
              </div>
              <div className="flex gap-1 shrink-0 ml-3">
                <a href={f.url_fichier} target="_blank" rel="noopener noreferrer" download={f.nom_fichier}>
                  <Button variant="ghost" size="icon" title="Télécharger">
                    <Download className="w-4 h-4 text-gray-500" />
                  </Button>
                </a>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setToDelete(f)}
                  title="Supprimer"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer ce fichier ?</AlertDialogTitle>
            <AlertDialogDescription>{toDelete?.nom_fichier}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => { deleteMutation.mutate(toDelete.id); setToDelete(null); }}
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}