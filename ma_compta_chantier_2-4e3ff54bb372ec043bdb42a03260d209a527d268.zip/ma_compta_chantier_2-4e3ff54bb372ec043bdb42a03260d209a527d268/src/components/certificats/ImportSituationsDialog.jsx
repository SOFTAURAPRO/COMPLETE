/**
 * ImportSituationsDialog — Import en masse de situations via Excel
 * Colonnes attendues : numero_lot, mois (01-12), annee, date_situation,
 *   numero_facture, date_facture, montant_ht, notes
 *   + par tranche : base_T{numero}, avenants_T{numero}
 *   Si pas de tranches : montant_ht_base, montant_ht_avenants globaux
 */
import React, { useState } from "react";
import * as XLSX from "xlsx";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Download, CheckCircle2, AlertCircle, Loader2, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";

const MOIS_LABELS = {
  "01":"Janvier","02":"Février","03":"Mars","04":"Avril",
  "05":"Mai","06":"Juin","07":"Juillet","08":"Août",
  "09":"Septembre","10":"Octobre","11":"Novembre","12":"Décembre"
};

// Génère et télécharge le modèle Excel vide
export function downloadModeleExcel(marches, entreprises, tranches = []) {
  const wb = XLSX.utils.book_new();

  const hasTranches = tranches.length > 0;

  // Colonnes de base
  const baseHeaders = [
    "numero_lot",
    "mois (01-12)",
    "annee",
    "date_situation (JJ/MM/AAAA)",
    "numero_facture",
    "date_facture (JJ/MM/AAAA)",
    "montant_ht",
  ];

  // Colonnes par tranche ou globales
  const trancheHeaders = hasTranches
    ? tranches.flatMap(t => [
        `base_T${t.numero} (${t.libelle})`,
        `avenants_T${t.numero} (${t.libelle})`,
      ])
    : ["montant_ht_base", "montant_ht_avenants"];

  const headers = [...baseHeaders, ...trancheHeaders, "notes"];
  const wsData = [headers];

  // Pré-remplir une ligne exemple par lot
  (marches || []).forEach(m => {
    const baseRow = [
      m.numero_lot || "",
      "", // mois
      new Date().getFullYear(),
      "", // date_situation
      "", // numero_facture
      "", // date_facture
      "", // montant_ht
    ];
    const trancheRow = hasTranches
      ? tranches.flatMap(() => ["", ""])
      : ["", ""];
    wsData.push([...baseRow, ...trancheRow, ""]);
  });

  // Si aucun marché, ligne exemple vide
  if ((marches || []).length === 0) {
    const exRow = ["01", "01", new Date().getFullYear(), "31/01/2025", "FAC-001", "31/01/2025", "10000.00"];
    const exTranche = hasTranches ? tranches.flatMap(() => ["", ""]) : ["9000.00", "1000.00"];
    wsData.push([...exRow, ...exTranche, ""]);
  }

  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Largeurs colonnes dynamiques
  const baseCols = [{ wch: 12 }, { wch: 12 }, { wch: 8 }, { wch: 26 }, { wch: 18 }, { wch: 22 }, { wch: 14 }];
  const trancheCols = hasTranches
    ? tranches.flatMap(() => [{ wch: 22 }, { wch: 22 }])
    : [{ wch: 18 }, { wch: 20 }];
  ws['!cols'] = [...baseCols, ...trancheCols, { wch: 30 }];

  // Feuille 2 : référence des lots
  const refHeaders = ["numero_lot", "intitule_lot", "entreprise", "montant_marche_ht"];
  if (hasTranches) {
    tranches.forEach(t => refHeaders.push(`montant_T${t.numero} (${t.libelle})`));
  }
  const refData = [refHeaders];
  (marches || []).forEach(m => {
    const ent = (entreprises || []).find(e => e.id === m.entreprise_id);
    const row = [m.numero_lot || "", m.intitule_lot || "", ent?.nom || "", m.montant || ""];
    if (hasTranches) {
      tranches.forEach(t => {
        const tm = (m.tranches_montants || []).find(x => x.tranche_numero === t.numero);
        row.push(tm?.montant_ht || "");
      });
    }
    refData.push(row);
  });
  const wsRef = XLSX.utils.aoa_to_sheet(refData);
  wsRef['!cols'] = [{ wch: 12 }, { wch: 30 }, { wch: 30 }, { wch: 18 }, ...tranches.map(() => ({ wch: 22 }))];

  // Feuille 3 : référence des tranches (si applicable)
  if (hasTranches) {
    const trRefData = [["numero", "libelle", "date_debut", "date_fin"]];
    tranches.forEach(t => trRefData.push([t.numero, t.libelle, t.date_debut || "", t.date_fin || ""]));
    const wsTr = XLSX.utils.aoa_to_sheet(trRefData);
    wsTr['!cols'] = [{ wch: 8 }, { wch: 30 }, { wch: 14 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, wsTr, "Référence Tranches");
  }

  XLSX.utils.book_append_sheet(wb, ws, "Import Situations");
  XLSX.utils.book_append_sheet(wb, wsRef, "Référence Lots");

  XLSX.writeFile(wb, `modele_import_situations.xlsx`);
}

// Parse une date JJ/MM/AAAA ou AAAA-MM-JJ vers ISO AAAA-MM-JJ
function parseDate(val) {
  if (!val) return "";
  const s = String(val).trim();
  // JJ/MM/AAAA
  const m1 = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m1) return `${m1[3]}-${m1[2].padStart(2,'0')}-${m1[1].padStart(2,'0')}`;
  // AAAA-MM-JJ
  const m2 = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m2) return `${m2[1]}-${m2[2].padStart(2,'0')}-${m2[3].padStart(2,'0')}`;
  // Excel serial number
  const n = parseFloat(val);
  if (!isNaN(n) && n > 1000) {
    const d = new Date(Math.round((n - 25569) * 86400 * 1000));
    if (!isNaN(d.getTime())) {
      return d.toISOString().slice(0,10);
    }
  }
  return "";
}

export default function ImportSituationsDialog({ open, onOpenChange, chantierId, marches, entreprises, chantier, clients, onImportSuccess, tranches = [] }) {
  const [rows, setRows] = useState([]);
  const [errors, setErrors] = useState([]);
  const [importing, setImporting] = useState(false);
  const [fileName, setFileName] = useState("");

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (ev) => {
      const wb = XLSX.read(ev.target.result, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });

      if (raw.length < 2) { toast.error("Le fichier est vide ou mal formaté"); return; }

      // Trouver les index des colonnes
      const headerRow = raw[0].map(h => String(h).toLowerCase().trim());
      const col = (name) => headerRow.findIndex(h => h.includes(name));

      const iLot    = col("numero_lot");
      const iMois   = col("mois");
      const iAnnee  = col("annee");
      const iDateSit= col("date_situation");
      const iNumFac = col("numero_facture");
      const iDateFac= col("date_facture");
      const iHT     = col("montant_ht");
      const iNotes  = col("notes");

      const hasTranches = tranches.length > 0;

      // Index des colonnes par tranche : base_T{n} et avenants_T{n}
      const trancheColsBase = hasTranches
        ? tranches.map(t => headerRow.findIndex(h => h.startsWith(`base_t${t.numero}`)))
        : [];
      const trancheColsAv = hasTranches
        ? tranches.map(t => headerRow.findIndex(h => h.startsWith(`avenants_t${t.numero}`)))
        : [];

      // Colonnes globales fallback (pas de tranches)
      const iHTBase = hasTranches ? -1 : col("montant_ht_base");
      const iHTAv   = hasTranches ? -1 : col("montant_ht_avenants");

      const parsed = [];
      const errs = [];

      for (let i = 1; i < raw.length; i++) {
        const r = raw[i];
        const anyVal = r.some(v => String(v).trim() !== "");
        if (!anyVal) continue;

        const numeroLot = String(r[iLot] ?? "").trim();
        const mois = String(r[iMois] ?? "").trim().padStart(2, '0');
        const annee = String(r[iAnnee] ?? "").trim();
        const montantHT = parseFloat(String(r[iHT] ?? "").replace(',', '.')) || 0;

        const rowErrs = [];
        if (!numeroLot) rowErrs.push("numero_lot manquant");
        if (!MOIS_LABELS[mois]) rowErrs.push(`mois invalide (${mois})`);
        if (!annee || isNaN(parseInt(annee))) rowErrs.push("annee invalide");

        // Résolution du marché par numero_lot
        const marche = marches.find(m => String(m.numero_lot).trim() === numeroLot);
        if (!marche) rowErrs.push(`Lot ${numeroLot} introuvable`);

        if (rowErrs.length > 0) {
          errs.push({ ligne: i + 1, erreurs: rowErrs.join(", "), numeroLot, montantHT });
        }

        // Construction de montants_par_tranche
        let montantsParTranche = [];
        let montantHTBase = 0;
        let montantHTAvenants = 0;

        if (hasTranches) {
          montantsParTranche = tranches.map((t, idx) => {
            const base = parseFloat(String(r[trancheColsBase[idx]] ?? "").replace(',', '.')) || 0;
            const av   = parseFloat(String(r[trancheColsAv[idx]]   ?? "").replace(',', '.')) || 0;
            montantHTBase += base;
            montantHTAvenants += av;
            return {
              tranche_numero: t.numero,
              tranche_libelle: t.libelle,
              montant_ht_base: base,
              montant_ht_avenants: av,
            };
          });
        } else {
          montantHTBase = parseFloat(String(r[iHTBase] ?? "").replace(',', '.')) || 0;
          montantHTAvenants = parseFloat(String(r[iHTAv] ?? "").replace(',', '.')) || 0;
        }

        parsed.push({
          _ligne: i + 1,
          _valid: rowErrs.length === 0,
          _erreurs: rowErrs,
          _marcheNom: marche ? `Lot ${marche.numero_lot} — ${marche.intitule_lot}` : `Lot ${numeroLot} (introuvable)`,
          marche_id: marche?.id || null,
          entreprise_id: marche?.entreprise_id || null,
          client_id: chantier?.client_id || null,
          numero_lot: numeroLot,
          mois,
          annee,
          date_situation: parseDate(r[iDateSit]),
          numero_facture: String(r[iNumFac] ?? "").trim(),
          date_facture: parseDate(r[iDateFac]),
          montant_ht: montantHT || (montantHTBase + montantHTAvenants),
          montant_ht_base: montantHTBase,
          montant_ht_avenants: montantHTAvenants,
          montants_par_tranche: montantsParTranche,
          notes: String(r[iNotes] ?? "").trim(),
          statut: "brouillon",
        });
      }

      setRows(parsed);
      setErrors(errs);
    };
    reader.readAsArrayBuffer(file);
  };

  const validRows = rows.filter(r => r._valid);
  const invalidRows = rows.filter(r => !r._valid);

  const handleImport = async () => {
    if (validRows.length === 0) { toast.error("Aucune ligne valide à importer"); return; }
    setImporting(true);

    try {
      // Auto-numérotation par lot
      const numeroParLot = {};
      const certExistants = await base44.entities.CertificatPaiement.list();
      const certsDuChantier = certExistants.filter(c => c.chantier_id === chantierId);

      certsDuChantier.forEach(c => {
        if (c.marche_id) {
          const n = parseInt(c.numero || 0);
          if (!numeroParLot[c.marche_id] || n > numeroParLot[c.marche_id]) {
            numeroParLot[c.marche_id] = n;
          }
        }
      });

      const toCreate = validRows.map(r => {
        const nextNum = (numeroParLot[r.marche_id] || 0) + 1;
        numeroParLot[r.marche_id] = nextNum;
        return {
          chantier_id: chantierId,
          marche_id: r.marche_id,
          entreprise_id: r.entreprise_id,
          client_id: r.client_id,
          numero: nextNum.toString().padStart(2, '0'),
          mois: r.mois,
          annee: r.annee,
          date_situation: r.date_situation,
          numero_facture: r.numero_facture,
          date_facture: r.date_facture,
          montant_ht: r.montant_ht,
          montant_ht_base: r.montant_ht_base,
          montant_ht_avenants: r.montant_ht_avenants,
          montants_par_tranche: r.montants_par_tranche || [],
          notes: r.notes,
          statut: "brouillon",
          paiements_sous_traitants: [],
          penalites_appliquees: [],
        };
      });

      await base44.entities.CertificatPaiement.bulkCreate(toCreate);
      toast.success(`${toCreate.length} situation${toCreate.length > 1 ? 's' : ''} importée${toCreate.length > 1 ? 's' : ''} avec succès`);
      onImportSuccess?.();
      onOpenChange(false);
      setRows([]);
      setErrors([]);
      setFileName("");
    } catch (err) {
      toast.error("Erreur lors de l'import", { description: err.message });
    } finally {
      setImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-orange-600" />
            Import en masse de situations
          </DialogTitle>
          <DialogDescription>
            Importez plusieurs situations mensuelles en une fois depuis un fichier Excel.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Télécharger le modèle */}
          <div className="flex items-center justify-between p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <div>
              <p className="text-sm font-medium text-orange-800">Étape 1 — Télécharger le modèle Excel</p>
              <p className="text-xs text-orange-600 mt-0.5">Le modèle contient les lots du chantier pré-remplis</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 border-orange-300 text-orange-700 hover:bg-orange-100"
              onClick={() => downloadModeleExcel(marches, entreprises, tranches)}
            >
              <Download className="w-4 h-4" />
              Modèle Excel
            </Button>
          </div>

          {/* Upload du fichier */}
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">Étape 2 — Importer votre fichier rempli</p>
            <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-orange-400 hover:bg-orange-50 transition-colors">
              <Upload className="w-8 h-8 text-gray-400 mb-2" />
              <span className="text-sm text-gray-500">
                {fileName ? fileName : "Cliquez ou déposez votre fichier Excel (.xlsx)"}
              </span>
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFile} />
            </label>
          </div>

          {/* Aperçu des lignes */}
          {rows.length > 0 && (
            <div className="space-y-3">
              <div className="flex gap-3">
                <Badge className="bg-green-100 text-green-800 border-green-200 border gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  {validRows.length} ligne{validRows.length > 1 ? 's' : ''} valide{validRows.length > 1 ? 's' : ''}
                </Badge>
                {invalidRows.length > 0 && (
                  <Badge className="bg-red-100 text-red-800 border-red-200 border gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {invalidRows.length} erreur{invalidRows.length > 1 ? 's' : ''}
                  </Badge>
                )}
              </div>

              {/* Tableau aperçu */}
              <div className="border rounded-lg overflow-auto max-h-64">
                <table className="w-full text-xs">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-2 py-2 text-left font-medium text-gray-600">Ligne</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-600">Lot</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-600">Période</th>
                      <th className="px-2 py-2 text-right font-medium text-gray-600">Montant HT</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-600">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r, i) => (
                      <tr key={i} className={`border-t ${r._valid ? '' : 'bg-red-50'}`}>
                        <td className="px-2 py-1.5 text-gray-500">#{r._ligne}</td>
                        <td className="px-2 py-1.5">{r._marcheNom}</td>
                        <td className="px-2 py-1.5">{MOIS_LABELS[r.mois]} {r.annee}</td>
                        <td className="px-2 py-1.5 text-right font-mono">
                          {r.montant_ht.toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €
                        </td>
                        <td className="px-2 py-1.5">
                          {r._valid
                            ? <span className="text-green-600 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />OK</span>
                            : <span className="text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{r._erreurs.join(", ")}</span>
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => { onOpenChange(false); setRows([]); setErrors([]); setFileName(""); }}>
            Annuler
          </Button>
          <Button
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={handleImport}
            disabled={validRows.length === 0 || importing}
          >
            {importing
              ? <><Loader2 className="w-4 h-4 animate-spin" />Import en cours...</>
              : <><Upload className="w-4 h-4" />Importer {validRows.length > 0 ? `(${validRows.length})` : ''}</>
            }
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}