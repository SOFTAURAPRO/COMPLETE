/**
 * Calcule le Net à Payer TTC d'un certificat donné,
 * en tenant compte des cautions reçues mois par mois.
 *
 * @param {Object} cert - Le certificat courant
 * @param {Array}  allCertsForLot - Tous les certificats du même lot (incluant cert)
 * @param {Object} marche - Le marché associé
 * @returns {{ montantTTC, totalRetenues, netAPayer, rg, deblocageRG }}
 */
export function computeNetAPayer(cert, allCertsForLot, marche) {
  const tauxTVA = marche?.taux_tva || 20;
  const montantHT =
    (cert.montant_ht_base || 0) + (cert.montant_ht_avenants || 0) > 0
      ? (cert.montant_ht_base || 0) + (cert.montant_ht_avenants || 0)
      : cert.montant_ht || 0;
  const montantTTC = montantHT * (1 + tauxTVA / 100);

  // Situations précédentes (numéro inférieur, validées)
  const certsPrecedents = allCertsForLot
    .filter(
      (c) =>
        c.id !== cert.id &&
        c.statut === "valide" &&
        parseInt(c.numero || 0) < parseInt(cert.numero || 0)
    )
    .sort((a, b) => parseInt(a.numero || 0) - parseInt(b.numero || 0));

  // Cumul TTC des situations précédentes
  let cumulTTCRunning = 0;
  certsPrecedents.forEach((c) => {
    const ht =
      (c.montant_ht_base || 0) + (c.montant_ht_avenants || 0) > 0
        ? (c.montant_ht_base || 0) + (c.montant_ht_avenants || 0)
        : c.montant_ht || 0;
    cumulTTCRunning += ht * (1 + tauxTVA / 100);
  });

  const cautions = marche?.cautions || [];
  const pad = (n) => String(n).padStart(2, "0");
  const certYear = parseInt(cert.annee || new Date().getFullYear());
  const certMonth = parseInt(cert.mois || new Date().getMonth() + 1);
  const premierJourMoisStr = `${certYear}-${pad(certMonth)}-01`;
  const dernierJourMoisStr = `${certYear}-${pad(certMonth)}-${pad(
    new Date(certYear, certMonth, 0).getDate()
  )}`;
  const getCautionDate = (c) =>
    c.date_reception?.substring(0, 10) ||
    c.date_ajout?.substring(0, 10) ||
    dernierJourMoisStr;

  const cautionAvantMois = cautions
    .filter((c) => getCautionDate(c) < premierJourMoisStr)
    .reduce((s, c) => s + (c.montant || 0), 0);
  const cautionJusquAuMois = cautions
    .filter((c) => getCautionDate(c) <= dernierJourMoisStr)
    .reduce((s, c) => s + (c.montant || 0), 0);

  const rgAvant = Math.max(0, cumulTTCRunning * 0.05 - cautionAvantMois);
  const rgApres = Math.max(0, (cumulTTCRunning + montantTTC) * 0.05 - cautionJusquAuMois);
  const rg = rgApres - rgAvant;

  const penalites =
    (cert.penalites_appliquees || []).reduce(
      (s, p) => s + (parseFloat(p.montant_calcule) || 0),
      0
    ) - (cert.remboursement_penalites || 0);

  const cie = cert.montant_cie || 0;
  const deblocageRG = cert.deblocage_rg || 0;

  const totalRetenues = rg + penalites + cie - deblocageRG;
  const netAPayer = montantTTC - totalRetenues;

  return { montantTTC, totalRetenues, netAPayer, rg, deblocageRG };
}