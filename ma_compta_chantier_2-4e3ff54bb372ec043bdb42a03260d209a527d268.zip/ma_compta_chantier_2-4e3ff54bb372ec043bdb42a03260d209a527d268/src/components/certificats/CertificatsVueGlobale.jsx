import React, { useState, useMemo, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, Eye, Download, Pencil, Trash2, Lock, Filter, X, Upload, PlusCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { computeNetAPayer as _computeNetAPayer } from "./computeNetAPayer";

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

export default function CertificatsVueGlobale({
  certificats,
  marches,
  avenants = [],
  getEntrepriseName,
  handlePreviewCP,
  handleExportCP,
  handleEdit,
  handleDelete,
  handleValidate,
  previewing,
  exporting,
  handleUploadFactures,
  handleRemoveFacture,
  getFileName,
  uploadingPDF
}) {
  const [filterMois, setFilterMois] = useState("all");
  const [filterAnnee, setFilterAnnee] = useState("all");
  const [filterStatut, setFilterStatut] = useState("all");
  const [dragOverId, setDragOverId] = useState(null);
  const fileInputRefs = useRef({});

  const annees = useMemo(() => [
    ...new Set(certificats.map(c => c.annee).filter(Boolean))
  ].sort().reverse(), [certificats]);

  const filtered = useMemo(() => {
    return certificats.filter(c => {
      if (filterMois !== "all" && c.mois !== filterMois) return false;
      if (filterAnnee !== "all" && c.annee !== filterAnnee) return false;
      if (filterStatut === "brouillon" && c.statut !== "brouillon") return false;
      if (filterStatut === "valide" && c.statut !== "valide") return false;
      if (filterStatut === "cloture" && !c.est_cloture) return false;
      return true;
    });
  }, [certificats, filterMois, filterAnnee, filterStatut]);

  const hasFilters = filterMois !== "all" || filterAnnee !== "all" || filterStatut !== "all";

  // Calcule le Net à payer TTC d'un certificat donné (délégué à la fonction partagée)
  const computeNetAPayer = (cert) => {
    const marche = marches.find(m => m.id === cert.marche_id) || marches.find(m => m.entreprise_id === cert.entreprise_id);
    const allCertsForLot = certificats.filter(c =>
      c.marche_id === cert.marche_id || c.entreprise_id === cert.entreprise_id
    );
    return _computeNetAPayer(cert, allCertsForLot, marche);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 items-center">
        <Filter className="w-4 h-4 text-gray-400" />
        <Select value={filterMois} onValueChange={setFilterMois}>
          <SelectTrigger className="w-36 h-8 text-sm">
            <SelectValue placeholder="Mois" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les mois</SelectItem>
            {Object.entries(MOIS_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterAnnee} onValueChange={setFilterAnnee}>
          <SelectTrigger className="w-28 h-8 text-sm">
            <SelectValue placeholder="Année" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes</SelectItem>
            {annees.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterStatut} onValueChange={setFilterStatut}>
          <SelectTrigger className="w-32 h-8 text-sm">
            <SelectValue placeholder="Statut" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous statuts</SelectItem>
            <SelectItem value="brouillon">Brouillon</SelectItem>
            <SelectItem value="valide">Validé</SelectItem>
            <SelectItem value="cloture">Clôturé</SelectItem>
          </SelectContent>
        </Select>
        {hasFilters && (
          <Button variant="ghost" size="sm" className="h-8 text-xs gap-1 text-gray-500"
            onClick={() => { setFilterMois("all"); setFilterAnnee("all"); setFilterStatut("all"); }}>
            <X className="w-3 h-3" />Réinitialiser
          </Button>
        )}
        <span className="text-xs text-gray-400 ml-auto">{filtered.length} résultat{filtered.length > 1 ? 's' : ''}</span>
      </div>
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>N° Lot</TableHead>
                <TableHead>Entreprise</TableHead>
                <TableHead>N° CP</TableHead>
                <TableHead>Période</TableHead>
                <TableHead>Date facture</TableHead>
                <TableHead>Montant HT</TableHead>
                <TableHead className="text-right">Montant TTC</TableHead>
                <TableHead className="text-right">Retenues TTC</TableHead>
                <TableHead className="text-right font-semibold text-blue-700">Net à payer TTC</TableHead>
                <TableHead>Facture</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...filtered].sort((a, b) => {
                const marcheA = marches.find(m => m.id === a.marche_id) || marches.find(m => m.entreprise_id === a.entreprise_id);
                const marcheB = marches.find(m => m.id === b.marche_id) || marches.find(m => m.entreprise_id === b.entreprise_id);
                const lotA = marcheA?.numero_lot || '';
                const lotB = marcheB?.numero_lot || '';
                if (lotA !== lotB) return lotA.localeCompare(lotB, undefined, { numeric: true });
                if (a.annee !== b.annee) return (a.annee || '').localeCompare(b.annee || '');
                return (a.mois || '').localeCompare(b.mois || '');
              }).map((cert) => {
                const marche = marches.find(m => m.id === cert.marche_id) || marches.find(m => m.entreprise_id === cert.entreprise_id);
                const { montantTTC, totalRetenues, netAPayer, deblocageRG, rg } = computeNetAPayer(cert);
                const fmt = (v) => v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
                return (
                  <TableRow key={cert.id} className="hover:bg-gray-50">
                    <TableCell className="font-semibold text-gray-700">
                      {marche?.numero_lot || '-'}
                    </TableCell>
                    <TableCell>{getEntrepriseName(cert.entreprise_id)}</TableCell>
                    <TableCell className="font-mono font-semibold">
                      {cert.numero}
                    </TableCell>
                    <TableCell className="font-medium">
                      {MOIS_LABELS[cert.mois]} {cert.annee}
                    </TableCell>
                    <TableCell>
                      {cert.date_facture && new Date(cert.date_facture).toString() !== 'Invalid Date'
                        ? format(new Date(cert.date_facture), "dd/MM/yyyy", { locale: fr })
                        : 'Date non définie'}
                    </TableCell>
                    <TableCell className="font-semibold text-orange-600">
                      {cert.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                    </TableCell>
                    <TableCell className="text-right font-mono text-gray-700">{fmt(montantTTC)}</TableCell>
                    <TableCell className="text-right font-mono">
                      {totalRetenues > 0 ? (
                        <span className="text-red-600">-{fmt(totalRetenues)}</span>
                      ) : totalRetenues < 0 ? (
                        <span className="text-green-600">+{fmt(Math.abs(totalRetenues))}</span>
                      ) : (
                        <span className="text-gray-400">{fmt(0)}</span>
                      )}
                      {deblocageRG > 0 && (
                        <span className="block text-xs text-green-600 font-normal">+{fmt(deblocageRG)} RG remb.</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono font-bold text-blue-700">{fmt(netAPayer)}</TableCell>
                    <TableCell>
                      {(() => {
                        const urls = cert.factures_urls && cert.factures_urls.length > 0
                          ? cert.factures_urls
                          : (cert.facture_pdf_url ? [cert.facture_pdf_url] : []);
                        return (
                          <div className="space-y-1 min-w-[120px]">
                            {urls.map((url, idx) => (
                              <div key={idx} className="flex items-center gap-1 group">
                                <a href={url} target="_blank" rel="noopener noreferrer"
                                  className="text-blue-600 hover:underline flex items-center gap-1 text-xs truncate max-w-[80px]"
                                  title={getFileName ? getFileName(url) : url}
                                >
                                  <FileText className="w-3 h-3 flex-shrink-0" />
                                  <span className="truncate">{getFileName ? getFileName(url) || `PDF ${idx+1}` : `PDF ${idx+1}`}</span>
                                </a>
                                {!cert.est_cloture && handleRemoveFacture && (
                                  <button onClick={() => handleRemoveFacture(cert, idx)}
                                    className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 transition-opacity"
                                    title="Supprimer cette facture">
                                    <X className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            ))}
                            {!cert.est_cloture && handleUploadFactures && (
                              <div
                                className={`border border-dashed rounded p-1 text-center cursor-pointer transition-colors text-xs ${dragOverId === cert.id ? 'border-orange-400 bg-orange-50' : 'border-gray-300 hover:border-orange-300 hover:bg-orange-50/50'}`}
                                onDragOver={(e) => { e.preventDefault(); setDragOverId(cert.id); }}
                                onDragLeave={() => setDragOverId(null)}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  setDragOverId(null);
                                  const files = Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf');
                                  if (files.length > 0) handleUploadFactures(cert, files);
                                }}
                                onClick={() => {
                                  if (!fileInputRefs.current[cert.id]) return;
                                  fileInputRefs.current[cert.id].click();
                                }}
                                title="Déposer ou cliquer pour ajouter des factures"
                              >
                                <input
                                  ref={el => fileInputRefs.current[cert.id] = el}
                                  type="file" accept=".pdf" multiple className="hidden"
                                  onChange={(e) => {
                                    const files = Array.from(e.target.files);
                                    if (files.length > 0) handleUploadFactures(cert, files);
                                    e.target.value = '';
                                  }}
                                />
                                <PlusCircle className="w-3 h-3 mx-auto text-gray-400" />
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Badge className={cert.statut === "valide"
                          ? "bg-green-100 text-green-800 border-green-200 border"
                          : "bg-yellow-100 text-yellow-800 border-yellow-200 border"
                        }>
                          {cert.statut === "valide" ? "Validé" : "Brouillon"}
                        </Badge>
                        {cert.est_cloture && (
                          <Badge className="bg-gray-100 text-gray-800 border-gray-200 border flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Clôturé
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {cert.statut === "brouillon" && !cert.est_cloture && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleValidate(cert)}
                            title="Valider"
                          >
                            <Badge className="w-4 h-4 bg-green-600" />
                          </Button>
                        )}
                        {cert.statut === "valide" && (
                          <>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handlePreviewCP(cert)}
                              title="Prévisualiser en HTML"
                              disabled={previewing}
                            >
                              <Eye className="w-4 h-4 text-blue-600" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleExportCP(cert)}
                              title="Télécharger PDF (avec fusion)"
                              disabled={exporting}
                            >
                              <Download className="w-4 h-4 text-green-600" />
                            </Button>
                          </>
                        )}
                        {!cert.est_cloture && (
                          <>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(cert)}
                              title="Modifier"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(cert)}
                              title="Supprimer"
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}