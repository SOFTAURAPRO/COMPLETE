import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Layers } from "lucide-react";

/**
 * Saisie des montants HT (base + avenants) par tranche dans le formulaire de situation.
 * - tranches : liste des tranches du chantier
 * - marchesTrancheMontants : répartition du marché par tranche (pour rappel)
 * - montantsParTranche : valeur courante du formData
 * - onChange(newArray) : callback
 */
export default function TranchesHtSection({ tranches = [], marchesTrancheMontants = [], montantsParTranche = [], onChange }) {
  if (tranches.length === 0) return null;

  const getVal = (num, field) => {
    const found = montantsParTranche.find(t => t.tranche_numero === num);
    return found ? (found[field] ?? "") : "";
  };

  const getMarcheBase = (num) => {
    const found = marchesTrancheMontants.find(t => t.tranche_numero === num);
    return found ? (found.montant_ht || 0) : 0;
  };

  const handleChange = (tranche, field, value) => {
    const existing = montantsParTranche.find(t => t.tranche_numero === tranche.numero) || {
      tranche_numero: tranche.numero,
      tranche_libelle: tranche.libelle,
      montant_ht_base: 0,
      montant_ht_avenants: 0
    };
    const updated = {
      ...existing,
      tranche_libelle: tranche.libelle,
      [field]: parseFloat(value) || 0
    };
    const others = montantsParTranche.filter(t => t.tranche_numero !== tranche.numero);
    onChange([...others, updated]);
  };

  const totalBase = montantsParTranche.reduce((s, t) => s + (t.montant_ht_base || 0), 0);
  const totalAv = montantsParTranche.reduce((s, t) => s + (t.montant_ht_avenants || 0), 0);

  return (
    <div className="space-y-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
      <div className="flex items-center gap-2 mb-1">
        <Layers className="w-4 h-4 text-blue-600" />
        <Label className="text-sm font-semibold text-blue-900">Montants HT par tranche</Label>
      </div>
      <div className="grid grid-cols-[1fr_140px_140px_100px] gap-x-2 gap-y-1 text-xs font-semibold text-gray-600 px-1">
        <span>Tranche</span>
        <span className="text-right">Marché base HT</span>
        <span className="text-right">Situation base HT</span>
        <span className="text-right">Situation avenants HT</span>
      </div>
      {tranches.map((tranche) => (
        <div key={tranche.numero} className="grid grid-cols-[1fr_140px_140px_100px] gap-x-2 items-center">
          <span className="text-xs text-blue-800 font-medium truncate" title={tranche.libelle}>{tranche.libelle}</span>
          <span className="text-right text-xs text-gray-500 font-mono pr-1">
            {getMarcheBase(tranche.numero).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
          </span>
          <Input
            type="number"
            step="0.01"
            value={getVal(tranche.numero, 'montant_ht_base')}
            onChange={(e) => handleChange(tranche, 'montant_ht_base', e.target.value)}
            placeholder="0,00"
            className="h-7 text-xs"
          />
          <Input
            type="number"
            step="0.01"
            value={getVal(tranche.numero, 'montant_ht_avenants')}
            onChange={(e) => handleChange(tranche, 'montant_ht_avenants', e.target.value)}
            placeholder="0,00"
            className="h-7 text-xs"
          />
        </div>
      ))}
      <div className="flex justify-between text-xs pt-2 border-t border-blue-200 font-semibold text-blue-900">
        <span>Totaux :</span>
        <span>Base : {totalBase.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € | Avenants : {totalAv.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</span>
      </div>
    </div>
  );
}