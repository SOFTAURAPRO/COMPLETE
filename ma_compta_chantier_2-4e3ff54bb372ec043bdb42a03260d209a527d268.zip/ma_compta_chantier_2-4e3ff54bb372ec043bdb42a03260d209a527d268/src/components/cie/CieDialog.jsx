import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Upload, FileText, Calculator, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { format } from "date-fns";

export default function CieDialog({ open, onOpenChange, operation, chantierId, entreprises, onSubmit, isLoading }) {
  const [formData, setFormData] = useState({
    description: "",
    date_operation: format(new Date(), "yyyy-MM-dd"),
    entreprise_facturante_id: "",
    montant_total_ht: "",
    repartitions: [],
    documents: [],
    statut: "brouillon",
    notes: ""
  });
  
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (operation) {
      setFormData({
        ...operation,
        repartitions: operation.repartitions || [],
        documents: operation.documents || []
      });
    } else {
      setFormData({
        description: "",
        date_operation: format(new Date(), "yyyy-MM-dd"),
        entreprise_facturante_id: "",
        montant_total_ht: "",
        repartitions: [{ entreprise_responsable_id: "", pourcentage: 100, montant_ht_attribue: 0 }],
        documents: [],
        statut: "brouillon",
        notes: ""
      });
    }
  }, [operation, open]);

  // Recalculer les montants quand le total change ou les pourcentages changent
  useEffect(() => {
    const total = parseFloat(formData.montant_total_ht) || 0;
    if (total > 0 && formData.repartitions.length > 0) {
      const newRepartitions = formData.repartitions.map(rep => ({
        ...rep,
        montant_ht_attribue: (total * (rep.pourcentage || 0) / 100)
      }));
      
      // Éviter une boucle infinie en vérifiant si les valeurs ont changé
      const hasChanged = JSON.stringify(newRepartitions) !== JSON.stringify(formData.repartitions);
      if (hasChanged) {
        setFormData(prev => ({ ...prev, repartitions: newRepartitions }));
      }
    }
  }, [formData.montant_total_ht, JSON.stringify(formData.repartitions.map(r => r.pourcentage))]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRepartitionChange = (index, field, value) => {
    const newRepartitions = [...formData.repartitions];
    
    if (field === "pourcentage") {
        const pourcent = parseFloat(value) || 0;
        newRepartitions[index] = {
            ...newRepartitions[index],
            pourcentage: pourcent,
            // Le montant sera recalculé par le useEffect
        };
    } else if (field === "entreprise_responsable_id") {
        newRepartitions[index] = { ...newRepartitions[index], [field]: value };
    }
    
    setFormData(prev => ({ ...prev, repartitions: newRepartitions }));
  };

  const addRepartition = () => {
    setFormData(prev => ({
      ...prev,
      repartitions: [...prev.repartitions, { entreprise_responsable_id: "", pourcentage: 0, montant_ht_attribue: 0 }]
    }));
  };

  const removeRepartition = (index) => {
    const newRepartitions = [...formData.repartitions];
    newRepartitions.splice(index, 1);
    setFormData(prev => ({ ...prev, repartitions: newRepartitions }));
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Déterminer le type par défaut si non spécifié (via l'argument ou autre) - ici on laisse 'justificatif' par défaut ou on demande
    // Pour l'instant, on ajoute juste le fichier, on changera le type après
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({
        ...prev,
        documents: [...prev.documents, { nom: file.name, url: file_url, type: 'justificatif' }]
      }));
      toast.success("Document ajouté");
    } catch (error) {
      console.error("Erreur upload:", error);
      toast.error("Erreur lors de l'upload");
    } finally {
      setUploading(false);
    }
  };

  const removeDocument = (index) => {
    const newDocs = [...formData.documents];
    newDocs.splice(index, 1);
    setFormData(prev => ({ ...prev, documents: newDocs }));
  };

  const updateDocumentType = (index, newType) => {
    const newDocs = [...formData.documents];
    newDocs[index] = { ...newDocs[index], type: newType };
    setFormData(prev => ({ ...prev, documents: newDocs }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation simple
    const totalPourcentage = formData.repartitions.reduce((sum, r) => sum + (parseFloat(r.pourcentage) || 0), 0);
    if (Math.abs(totalPourcentage - 100) > 0.1) {
        toast.warning(`Attention : Le total des répartitions est de ${totalPourcentage}%, il devrait être de 100%`);
    }

    if (!formData.entreprise_facturante_id) {
        toast.error("Veuillez sélectionner une entreprise facturante");
        return;
    }

    onSubmit({
        ...formData,
        montant_total_ht: parseFloat(formData.montant_total_ht),
        repartitions: formData.repartitions.map(r => ({
            ...r,
            pourcentage: parseFloat(r.pourcentage),
            montant_ht_attribue: parseFloat(r.montant_ht_attribue)
        }))
    });
  };

  const availableEntreprises = entreprises.sort((a, b) => a.nom.localeCompare(b.nom));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{operation ? "Modifier l'opération C.I.E" : "Nouvelle opération C.I.E"}</DialogTitle>
          <DialogDescription>
            Créez un compte inter-entreprises pour répartir des frais entre plusieurs entreprises.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Input
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Ex: Frais nettoyage base vie"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date_operation">Date *</Label>
              <Input
                id="date_operation"
                name="date_operation"
                type="date"
                value={formData.date_operation}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="entreprise_facturante_id">Entreprise Créditrice (Facturante) *</Label>
              <Select 
                value={formData.entreprise_facturante_id} 
                onValueChange={(val) => setFormData(prev => ({ ...prev, entreprise_facturante_id: val }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner l'entreprise" />
                </SelectTrigger>
                <SelectContent>
                  {availableEntreprises.map(ent => (
                    <SelectItem key={ent.id} value={ent.id}>{ent.nom}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="montant_total_ht">Montant Total HT (€) *</Label>
              <Input
                id="montant_total_ht"
                name="montant_total_ht"
                type="number"
                step="0.01"
                value={formData.montant_total_ht}
                onChange={handleChange}
                placeholder="0.00"
                required
              />
            </div>
          </div>

          <div className="border rounded-lg p-4 bg-slate-50 space-y-4">
            <div className="flex justify-between items-center">
              <h4 className="font-medium text-sm flex items-center gap-2">
                <Calculator className="w-4 h-4 text-blue-600" />
                Répartition (Débiteurs)
              </h4>
              <Button type="button" variant="outline" size="sm" onClick={addRepartition} className="h-8">
                <Plus className="w-3 h-3 mr-1" /> Ajouter
              </Button>
            </div>
            
            {formData.repartitions.map((rep, idx) => (
              <div key={idx} className="flex flex-wrap md:flex-nowrap gap-3 items-end bg-white p-3 rounded border">
                <div className="w-full md:w-1/2 space-y-1">
                  <Label className="text-xs">Entreprise Responsable</Label>
                  <Select 
                    value={rep.entreprise_responsable_id} 
                    onValueChange={(val) => handleRepartitionChange(idx, "entreprise_responsable_id", val)}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Sélectionner" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableEntreprises.map(ent => (
                        <SelectItem key={ent.id} value={ent.id}>{ent.nom}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-1/3 md:w-1/4 space-y-1">
                  <Label className="text-xs">% Part</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      className="h-9 pr-6"
                      value={rep.pourcentage}
                      onChange={(e) => handleRepartitionChange(idx, "pourcentage", e.target.value)}
                    />
                    <span className="absolute right-2 top-2.5 text-xs text-gray-400">%</span>
                  </div>
                </div>
                <div className="w-1/3 md:w-1/4 space-y-1">
                  <Label className="text-xs">Montant HT</Label>
                  <div className="relative">
                    <Input
                      type="number"
                      className="h-9 pr-6 bg-gray-50"
                      value={rep.montant_ht_attribue?.toFixed(2)}
                      readOnly
                    />
                    <span className="absolute right-2 top-2.5 text-xs text-gray-400">€</span>
                  </div>
                </div>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  className="text-red-500 hover:text-red-700 h-9 w-9 shrink-0"
                  onClick={() => removeRepartition(idx)}
                  disabled={formData.repartitions.length === 1}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            
            <div className="flex justify-end text-sm gap-4 text-gray-600 px-2">
                <span>Total %: <strong className={Math.abs(formData.repartitions.reduce((sum, r) => sum + (parseFloat(r.pourcentage)||0), 0) - 100) < 0.1 ? "text-green-600" : "text-red-600"}>{formData.repartitions.reduce((sum, r) => sum + (parseFloat(r.pourcentage)||0), 0).toFixed(1)}%</strong></span>
                <span>Total Réparti: <strong>{formData.repartitions.reduce((sum, r) => sum + (parseFloat(r.montant_ht_attribue)||0), 0).toFixed(2)} €</strong></span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
                <Label>Documents justificatifs</Label>
                <label className="cursor-pointer inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-8 px-3">
                    <Upload className="w-3 h-3 mr-2" />
                    Ajouter un fichier
                    <input type="file" className="hidden" onChange={handleFileUpload} disabled={uploading} />
                </label>
            </div>
            
            {formData.documents.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {formData.documents.map((doc, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 border rounded bg-slate-50 gap-2">
                            <div className="flex items-center gap-2 overflow-hidden flex-1">
                                <FileText className="w-4 h-4 text-blue-500 shrink-0" />
                                <div className="flex flex-col min-w-0">
                                    <span className="text-sm truncate font-medium" title={doc.nom}>{doc.nom}</span>
                                    <a href={doc.url} target="_blank" className="text-xs text-blue-600 hover:underline">Voir</a>
                                </div>
                            </div>
                            <div className="w-32 shrink-0">
                                <Select 
                                    value={doc.type || 'justificatif'} 
                                    onValueChange={(val) => updateDocumentType(idx, val)}
                                >
                                    <SelectTrigger className="h-7 text-xs">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="justificatif">Justificatif</SelectItem>
                                        <SelectItem value="devis">Devis</SelectItem>
                                        <SelectItem value="facture">Facture</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-red-500 shrink-0" onClick={() => removeDocument(idx)}>
                                <Trash2 className="w-3 h-3" />
                            </Button>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-sm text-gray-500 italic">Aucun document joint.</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optionnel)</Label>
            <Textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Commentaires supplémentaires..."
              className="h-20"
            />
          </div>

          {operation && operation.statut === 'integre' && (
             <div className="bg-blue-50 border border-blue-200 rounded p-3 flex items-start gap-2 text-sm text-blue-800">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <p>Cette opération a déjà été intégrée dans des certificats de paiement. Les modifications de montants sont déconseillées.</p>
             </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
            <Button type="submit" disabled={isLoading || uploading} className="bg-orange-600 hover:bg-orange-700">
              {isLoading ? "Enregistrement..." : (operation ? "Mettre à jour" : "Créer l'opération")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}