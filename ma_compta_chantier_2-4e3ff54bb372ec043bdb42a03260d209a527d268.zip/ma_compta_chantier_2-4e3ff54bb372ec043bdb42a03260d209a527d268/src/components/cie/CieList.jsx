import React, { useState, useMemo } from "react";
import { 
    Table, 
    TableBody, 
    TableCell, 
    TableHead, 
    TableHeader, 
    TableRow 
} from "@/components/ui/table";
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger,
    DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    MoreHorizontal, 
    Pencil, 
    Trash2, 
    FileText, 
    CheckCircle2,
    ExternalLink,
    ArrowRight
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function CieList({ operations, entreprises, onEdit, onDelete, onStatusChange }) {
  
  const getEntrepriseName = (id) => {
    const ent = entreprises.find(e => e.id === id);
    return ent ? ent.nom : "Inconnue";
  };

  const getStatusBadge = (statut) => {
    switch(statut) {
        case 'valide':
            return <Badge className="bg-green-100 text-green-800 hover:bg-green-200 border-green-200">Validé</Badge>;
        case 'integre':
            return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200 border-blue-200">Intégré</Badge>;
        default:
            return <Badge variant="outline" className="text-gray-600 border-gray-300">Brouillon</Badge>;
    }
  };

  if (!operations || operations.length === 0) {
    return (
        <div className="text-center p-8 border rounded-lg bg-slate-50 text-gray-500">
            Aucune opération C.I.E enregistrée pour le moment.
        </div>
    );
  }

  return (
    <div className="border rounded-lg bg-white overflow-hidden shadow-sm">
      <Table>
        <TableHeader className="bg-slate-50">
          <TableRow>
            <TableHead className="w-[100px]">Date</TableHead>
            <TableHead className="w-[250px]">Description</TableHead>
            <TableHead className="w-[200px]">Créditeur (Facture)</TableHead>
            <TableHead className="w-[120px] text-right">Montant HT</TableHead>
            <TableHead className="w-[250px]">Débiteurs (Répartition)</TableHead>
            <TableHead className="w-[100px] text-center">Statut</TableHead>
            <TableHead className="w-[80px] text-center">Docs</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {operations.map((op) => (
            <TableRow key={op.id} className="hover:bg-slate-50">
              <TableCell className="font-medium text-xs">
                {op.date_operation && format(new Date(op.date_operation), "dd/MM/yyyy")}
              </TableCell>
              <TableCell>
                <div className="font-medium">{op.description}</div>
                {op.notes && <div className="text-xs text-gray-500 truncate max-w-[200px]">{op.notes}</div>}
              </TableCell>
              <TableCell className="text-green-700 font-medium">
                {getEntrepriseName(op.entreprise_facturante_id)}
              </TableCell>
              <TableCell className="text-right font-bold text-gray-900">
                {op.montant_total_ht?.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €
              </TableCell>
              <TableCell>
                <div className="flex flex-col gap-1">
                    {op.repartitions?.map((rep, idx) => (
                        <div key={idx} className="text-xs flex justify-between items-center text-red-600 bg-red-50 px-1.5 py-0.5 rounded">
                            <span className="truncate max-w-[120px]">{getEntrepriseName(rep.entreprise_responsable_id)}</span>
                            <span className="font-mono">{rep.montant_ht_attribue?.toFixed(2)} € ({rep.pourcentage}%)</span>
                        </div>
                    ))}
                </div>
              </TableCell>
              <TableCell className="text-center">
                {getStatusBadge(op.statut)}
              </TableCell>
              <TableCell className="text-center">
                {op.documents?.length > 0 && (
                    <div className="flex justify-center">
                         <a href={op.documents[0].url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">
                            <FileText className="w-4 h-4" />
                         </a>
                         {op.documents.length > 1 && <span className="text-xs text-gray-500 ml-1">+{op.documents.length-1}</span>}
                    </div>
                )}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(op)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      Modifier
                    </DropdownMenuItem>
                    
                    {op.statut === 'brouillon' && (
                        <DropdownMenuItem onClick={() => onStatusChange(op, 'valide')} className="text-green-600">
                            <CheckCircle2 className="mr-2 h-4 w-4" />
                            Valider
                        </DropdownMenuItem>
                    )}
                    
                    {op.statut === 'valide' && (
                         <DropdownMenuItem onClick={() => onStatusChange(op, 'brouillon')}>
                            <ArrowRight className="mr-2 h-4 w-4" />
                            Remettre en brouillon
                        </DropdownMenuItem>
                    )}

                    <DropdownMenuSeparator />
                    
                    <DropdownMenuItem 
                        onClick={() => onDelete(op)} 
                        className="text-red-600"
                        disabled={op.statut === 'integre'}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Supprimer
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}