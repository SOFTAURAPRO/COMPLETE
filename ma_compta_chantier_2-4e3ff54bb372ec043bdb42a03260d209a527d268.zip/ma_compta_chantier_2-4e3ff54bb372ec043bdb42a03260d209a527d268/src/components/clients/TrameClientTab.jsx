import React, { useState } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { FileText, Image, X } from "lucide-react";
import FileDropzone from "../common/FileDropzone";

export default function TrameClientTab({ formData, setFormData }) {
  const [uploadingField, setUploadingField] = useState(null);

  const trameFields = [
    { key: 'trame_marche_url', label: 'Trame Marché' },
    { key: 'trame_certificat_url', label: 'Trame Certificat de Paiement' },
    { key: 'trame_avenant_url', label: 'Trame Avenant' },
    { key: 'trame_dgd_url', label: 'Trame DGD' },
    { key: 'trame_agrement_url', label: 'Trame Demande d\'Agrément' }
  ];

  const handleFileUpload = async (field, file) => {
    if (!file) return;

    setUploadingField(field);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, [field]: file_url });
      toast.success("Trame importée avec succès");
    } catch (error) {
      console.error("Erreur upload:", error);
      toast.error("Erreur lors de l'import de la trame");
    } finally {
      setUploadingField(null);
    }
  };

  const handleRemoveFile = (field) => {
    setFormData({ ...formData, [field]: "" });
    toast.success("Trame supprimée");
  };

  const handleLogoUpload = async (file) => {
    if (!file) return;
    setUploadingField('logo_client_url');
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, logo_client_url: file_url });
      toast.success("Logo importé avec succès");
    } catch (error) {
      toast.error("Erreur lors de l'import du logo");
    } finally {
      setUploadingField(null);
    }
  };

  return (
    <div className="space-y-6 py-4">
      <div className="text-sm text-gray-600 mb-4">
        Téléversez les trames spécifiques à ce client. Ces trames seront utilisées par défaut lors de la génération de documents pour ce client.
      </div>

      {/* Logo client */}
      <Card className="p-4 border-orange-200">
        <div className="space-y-3">
          <Label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
            <Image className="w-4 h-4 text-orange-500" />
            Logo Client
          </Label>
          <p className="text-xs text-gray-500">Ce logo sera inséré dans les documents générés (certificats, avenants, marchés...).</p>
          {formData.logo_client_url ? (
            <div className="flex items-center justify-between gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center gap-3">
                <img src={formData.logo_client_url} alt="Logo client" className="h-12 w-auto max-w-[120px] object-contain rounded" />
                <span className="text-sm text-orange-700">Logo importé</span>
              </div>
              <div className="flex items-center gap-2">
                <Button type="button" variant="ghost" size="sm" onClick={() => window.open(formData.logo_client_url, '_blank')} className="text-orange-700 hover:bg-orange-100">Voir</Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setFormData({ ...formData, logo_client_url: '' })} className="text-red-600 hover:bg-red-50"><X className="w-4 h-4" /></Button>
              </div>
            </div>
          ) : (
            <FileDropzone
              onFileSelect={handleLogoUpload}
              accept="image/*"
              disabled={uploadingField === 'logo_client_url'}
              uploading={uploadingField === 'logo_client_url'}
            />
          )}
        </div>
      </Card>

      {trameFields.map(({ key, label }) => (
        <Card key={key} className="p-4">
          <div className="space-y-3">
            <Label htmlFor={key} className="text-sm font-semibold text-gray-700">
              {label}
            </Label>
            
            {formData[key] ? (
              <div className="flex items-center justify-between gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 flex-1">
                  <FileText className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-green-700 truncate">
                    Trame importée
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(formData[key], '_blank')}
                    className="text-green-700 hover:text-green-800 hover:bg-green-100"
                  >
                    Voir
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveFile(key)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <FileDropzone
                onFileSelect={(file) => handleFileUpload(key, file)}
                accept=".xlsx,.xls,.doc,.docx"
                disabled={uploadingField === key}
                uploading={uploadingField === key}
              />
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}