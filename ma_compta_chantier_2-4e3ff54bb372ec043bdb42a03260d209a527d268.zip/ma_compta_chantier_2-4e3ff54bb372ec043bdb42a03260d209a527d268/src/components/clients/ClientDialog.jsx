import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContactsTab from "../common/ContactsTab";
import TrameClientTab from "./TrameClientTab";
import { base44 } from "@/api/base44Client";

export default function ClientDialog({ open, onOpenChange, client, onSubmit, isLoading }) {
  const [formData, setFormData] = useState({
    reference: "",
    nom: "",
    forme_juridique: "",
    adresse_1: "",
    adresse_2: "",
    code_postal: "",
    ville: "",
    telephone: "",
    siret: "",
    contacts: [],
    trame_marche_url: "",
    trame_certificat_url: "",
    trame_avenant_url: "",
    trame_dgd_url: "",
    trame_agrement_url: "",
    logo_client_url: ""
  });

  useEffect(() => {
    if (client) {
      setFormData({
        reference: client.reference || "",
        nom: client.nom || "",
        forme_juridique: client.forme_juridique || "",
        adresse_1: client.adresse_1 || "",
        adresse_2: client.adresse_2 || "",
        code_postal: client.code_postal || "",
        ville: client.ville || "",
        telephone: client.telephone || "",
        siret: client.siret || "",
        contacts: client.contacts || [],
        trame_marche_url: client.trame_marche_url || "",
        trame_certificat_url: client.trame_certificat_url || "",
        trame_avenant_url: client.trame_avenant_url || "",
        trame_dgd_url: client.trame_dgd_url || "",
        trame_agrement_url: client.trame_agrement_url || "",
        logo_client_url: client.logo_client_url || ""
      });
    } else {
      // Fetch next reference
      if (open) {
        base44.functions.invoke("getNextReference", { entityName: "Client", prefix: "CLT" })
          .then(res => {
            if (res.data && res.data.nextReference) {
              setFormData(prev => ({ ...prev, reference: res.data.nextReference }));
            }
          });
      }
      setFormData({
        reference: "",
        nom: "",
        forme_juridique: "",
        adresse_1: "",
        adresse_2: "",
        code_postal: "",
        ville: "",
        telephone: "",
        siret: "",
        contacts: [],
        trame_marche_url: "",
        trame_certificat_url: "",
        trame_avenant_url: "",
        trame_dgd_url: "",
        trame_agrement_url: "",
        logo_client_url: ""
      });
    }
  }, [client, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {client ? "Modifier le client" : "Nouveau client"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="general" className="w-full mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">Général</TabsTrigger>
              <TabsTrigger value="contacts">Interlocuteurs</TabsTrigger>
              <TabsTrigger value="trames">Trames Client</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4 py-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reference">Référence</Label>
                  <Input
                    id="reference"
                    value={formData.reference}
                    readOnly
                    className="bg-gray-100 text-gray-500"
                    placeholder="Génération auto..."
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="nom">Nom du client *</Label>
                  <Input
                    id="nom"
                    value={formData.nom}
                    onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                    placeholder="Ex: Société ABC"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="forme_juridique">Forme Juridique</Label>
                  <Select
                    value={formData.forme_juridique}
                    onValueChange={(value) => setFormData({ ...formData, forme_juridique: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Forme" />
                    </SelectTrigger>
                    <SelectContent>
                      {["SA", "SAS", "SARL", "EURL", "SASU", "SCOP", "EI", "SARL UNIPERSONNELLE"].map(forme => (
                        <SelectItem key={forme} value={forme}>{forme}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_1">Adresse ligne 1</Label>
                <Input
                  id="adresse_1"
                  value={formData.adresse_1}
                  onChange={(e) => setFormData({ ...formData, adresse_1: e.target.value })}
                  placeholder="Numéro et nom de rue"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse_2">Adresse ligne 2</Label>
                <Input
                  id="adresse_2"
                  value={formData.adresse_2}
                  onChange={(e) => setFormData({ ...formData, adresse_2: e.target.value })}
                  placeholder="Complément d'adresse"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="code_postal">Code postal</Label>
                  <Input
                    id="code_postal"
                    value={formData.code_postal}
                    onChange={(e) => setFormData({ ...formData, code_postal: e.target.value })}
                    placeholder="75000"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ville">Ville</Label>
                  <Input
                    id="ville"
                    value={formData.ville}
                    onChange={(e) => setFormData({ ...formData, ville: e.target.value })}
                    placeholder="Paris"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telephone">Téléphone</Label>
                  <Input
                    id="telephone"
                    value={formData.telephone}
                    onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                    placeholder="01 23 45 67 89"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="siret">SIRET</Label>
                  <Input
                    id="siret"
                    value={formData.siret}
                    onChange={(e) => setFormData({ ...formData, siret: e.target.value })}
                    placeholder="123 456 789 00012"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="contacts">
              <ContactsTab 
                contacts={formData.contacts} 
                onChange={(newContacts) => setFormData({ ...formData, contacts: newContacts })} 
              />
            </TabsContent>

            <TabsContent value="trames">
              <TrameClientTab 
                formData={formData}
                setFormData={setFormData}
              />
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Annuler
            </Button>
            <Button 
              type="submit" 
              className="bg-orange-600 hover:bg-orange-700"
              disabled={isLoading}
            >
              {isLoading ? "Enregistrement..." : client ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}