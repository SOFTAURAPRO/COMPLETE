import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Users, MapPin, Phone, Printer } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { getFicheClientHtml } from "@/components/templates/FicheClientTemplate";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

export default function ClientsList({ clients, onEdit }) {
  const { data: infoGestionbat } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
  });

  const handlePrint = async (client) => {
    const toastId = toast.loading("Génération de la fiche...");
    try {
      const logoGestionbat = infoGestionbat && infoGestionbat.logo_url 
        ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" class="logo" />` 
        : '<div style="font-weight: bold; color: #f97316;">GESTIONBAT</div>';

      const htmlContent = getFicheClientHtml(client, logoGestionbat);

      const response = await base44.functions.invoke('htmlToPdf', {
        html_content: htmlContent,
        css: ''
      });

      if (response.data && response.data.success && response.data.pdf_base64) {
        const byteCharacters = atob(response.data.pdf_base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `Fiche_Client_${client.nom.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        toast.success("Fiche téléchargée", { id: toastId });
      } else {
        throw new Error("Erreur conversion PDF");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erreur lors de la génération de la fiche", { id: toastId });
    }
  };
  if (clients.length === 0) {
    return (
      <Card className="p-12 text-center">
        <Users className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucun client enregistré
        </h3>
        <p className="text-gray-500">
          Ajoutez votre premier client pour commencer
        </p>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {clients.map((client) => (
        <Card key={client.id} className="p-6 hover:shadow-lg transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-gray-900 mb-1 truncate">
                  {client.nom}
                </h3>
                <div className="flex gap-2 flex-wrap">
                  {client.reference && (
                    <Badge variant="secondary" className="text-xs">
                      {client.reference}
                    </Badge>
                  )}
                  {client.siret && (
                    <Badge variant="outline" className="text-xs">
                      SIRET: {client.siret}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-1 flex-shrink-0">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handlePrint(client)}
                title="Imprimer la fiche"
              >
                <Printer className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onEdit(client)}
                title="Modifier"
              >
                <Pencil className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2 text-sm text-gray-600">
            {(client.adresse_1 || client.ville) && (
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <div>
                  {client.adresse_1 && <div>{client.adresse_1}</div>}
                  {client.adresse_2 && <div>{client.adresse_2}</div>}
                  {(client.code_postal || client.ville) && (
                    <div>
                      {client.code_postal} {client.ville}
                    </div>
                  )}
                </div>
              </div>
            )}

            {client.telephone && (
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>{client.telephone}</span>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}