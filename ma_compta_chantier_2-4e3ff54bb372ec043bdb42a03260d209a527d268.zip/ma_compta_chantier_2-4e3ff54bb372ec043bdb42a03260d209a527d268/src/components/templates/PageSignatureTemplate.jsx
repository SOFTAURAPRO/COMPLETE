import { format } from "date-fns";
import { fr } from "date-fns/locale";

export const getPageSignatureHtmlTemplate = ({
  marches,
  chantier,
  entreprises,
  client,
  infoGestionbat,
  partenairesString,
  dateFormatee,
  logoClient,
  logoGestionbat
}) => {
  // Génération des cases de signature
  const signatureBoxes = marches.map(marche => {
    const entreprise = entreprises.find(e => e.id === marche.entreprise_id);
    
    // Construction des lignes d'information
    const ligneLot = `${marche.numero_lot ? marche.numero_lot + ' - ' : ''}${marche.intitule_lot || 'Lot sans nom'}`;
    
    const nomEntreprise = entreprise ? entreprise.nom : "Entreprise inconnue";

    return `
      <div class="signature-box">
        <div class="box-header">
          <strong>${ligneLot}</strong>
        </div>
        <div class="box-content">
          <div class="entreprise-name">${nomEntreprise}</div>
          <div class="signature-space">Signature</div>
        </div>
      </div>
    `;
  }).join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Page de Signature - ${chantier?.nom || 'Chantier'}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 0.5cm 1.5cm 1cm 1.5cm;
    }
    body { font-family: Arial, sans-serif; font-size: 10pt; margin: 0; padding: 20px; }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 3px solid #f97316;
      min-height: 80px;
    }
    .header-left {
      flex: 1;
      text-align: left;
      display: flex;
      align-items: center;
      min-height: 80px;
    }
    .header-center {
      flex: 2;
      text-align: center;
      padding: 0 20px;
    }
    .header-right {
      flex: 1;
      text-align: right;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      min-height: 80px;
    }
    .header h1 {
      margin: 0 0 5px 0;
      font-size: 18pt;
      color: #f97316;
    }
    .header p {
      margin: 2px 0;
      color: #666;
      font-size: 10pt;
    }

    .page-title {
      text-align: center;
      font-size: 16pt;
      font-weight: bold;
      color: #333;
      margin-bottom: 20px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .signatures-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr); /* 3 colonnes pour portrait */
      gap: 15px;
      width: 100%;
    }

    .signature-box {
      border: 1px solid #ddd;
      border-radius: 4px;
      page-break-inside: avoid;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      height: 140px; /* Hauteur fixe pour uniformité */
    }

    .box-header {
      background-color: #fff3e0;
      padding: 8px;
      font-size: 9pt;
      border-bottom: 1px solid #f97316;
      text-align: center;
      height: 35px;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }

    .box-content {
      padding: 8px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .entreprise-name {
      font-weight: bold;
      font-size: 9pt;
      color: #333;
      text-align: center;
      margin-bottom: 4px;
    }

    .representant {
      font-size: 8pt;
      color: #666;
      text-align: center;
      font-style: italic;
    }

    .signature-space {
      margin-top: auto;
      text-align: center;
      color: #ccc;
      font-size: 8pt;
      padding-top: 15px;
    }

    .footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 1.5cm;
      font-size: 9pt;
      color: #666;
      border-top: 1px solid #ddd;
      background: white;
    }
    .footer-left {
      flex: 1;
      text-align: left;
      font-size: 7pt;
      text-transform: capitalize;
    }
    .footer-center {
      flex: 1;
      text-align: center;
      font-weight: bold;
      font-size: 7pt;
    }
    .footer-right {
      flex: 1;
      text-align: right;
      font-size: 7pt;
    }

    @media print {
      .footer {
        position: fixed;
        bottom: 0;
      }
      .signature-box {
        break-inside: avoid;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="header-left">${logoClient}</div>
    <div class="header-center">
      <h1>${chantier?.nom || 'Chantier'}</h1>
      <p>${chantier?.description || ''}</p>
      <p>${chantier?.adresse || ''}</p>
    </div>
    <div class="header-right">${logoGestionbat}</div>
  </div>

  <div class="page-title">Page de Signature</div>

  <div class="signatures-grid">
    ${signatureBoxes}
  </div>

  <div class="footer">
    <div class="footer-left">${(partenairesString || '').toLowerCase()}</div>
    <div class="footer-center">Page 1</div>
    <div class="footer-right">${dateFormatee}</div>
  </div>
</body>
</html>`;
};