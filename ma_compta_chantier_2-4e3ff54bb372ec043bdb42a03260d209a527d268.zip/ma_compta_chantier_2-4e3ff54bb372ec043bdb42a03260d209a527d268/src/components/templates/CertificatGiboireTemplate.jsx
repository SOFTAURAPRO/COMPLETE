/**
 * Template certificat de paiement GIBOIRE (CLT-0003)
 * Couleur officielle : #002060
 * Structure fidèle à l'Excel CPType.xlsx
 * - Logos MOE / Client centrés au-dessus des coordonnées
 * - 36 situations (18 visibles + 18 grises si applicable)
 * - Blocs Avances / ST / Fournisseurs masqués si données absentes
 * - Retenues : caution bancaire sous Marché cautionné
 */

const DARK_BLUE = '#002060';
const LIGHT_BLUE_BG = '#DCE6F1';
const BORDER_COLOR = '#BFBFBF';

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

export function generateCertificatGiboireHtml({
  certificat,
  chantier,
  client,
  entreprise,
  marche,
  situationsPrecedentes = [],
  avenantsDeLEntreprise = [],
  paiementsSousTraitants = [],
  paiementsFournisseurs = [],
  contratsSousTraitance = [],
  penalitesAppliquees = [],
  entreprises = [],
  infoGestionbat,
  logoMoeUrl = null,
  logoClientUrl = null,
  tauxTVA = 20
}) {
  // ─── FORMATAGE ────────────────────────────────────────────────────
  const fmt = (v) => {
    const n = parseFloat(v);
    if (isNaN(n)) return '0,00 €';
    return n.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
  };
  const fmtPct = (v) => {
    const n = parseFloat(v);
    if (isNaN(n) || !isFinite(n)) return '0,0';
    return n.toFixed(1).replace('.', ',');
  };

  // ─── CALCULS FINANCIERS ───────────────────────────────────────────
  const montantMarcheBase = marche?.montant || 0;
  const totalAvenantsHT = avenantsDeLEntreprise.reduce((s, a) => s + (a.montant_total_ht || 0), 0);
  const nouveauMontantMarcheHT = montantMarcheBase + totalAvenantsHT;
  const nouveauMontantMarcheTTC = nouveauMontantMarcheHT * (1 + tauxTVA / 100);

  // Situation courante : priorité montant_ht, décomposé si disponible
  const sitMontantHTBase = certificat.montant_ht_base || 0;
  const sitMontantHTAvenants = certificat.montant_ht_avenants || 0;
  const sitMontantHT = (sitMontantHTBase + sitMontantHTAvenants) > 0
    ? (sitMontantHTBase + sitMontantHTAvenants)
    : (certificat.montant_ht || 0);
  // Si pas de décomposition base/avenants, tout va en base
  const sitHTBase = sitMontantHTBase > 0 ? sitMontantHTBase : sitMontantHT;
  const sitHTAvenants = sitMontantHTAvenants;

  // Cumuls précédents
  const cumPrecHTBase = situationsPrecedentes.reduce((s, c) => {
    const b = c.montant_ht_base || 0;
    const a = c.montant_ht_avenants || 0;
    return s + (b > 0 ? b : ((b + a) === 0 ? (c.montant_ht || 0) : b));
  }, 0);
  const cumPrecHTAvenants = situationsPrecedentes.reduce((s, c) => s + (c.montant_ht_avenants || 0), 0);
  const cumPrecHT = situationsPrecedentes.reduce((s, c) => {
    const b = c.montant_ht_base || 0;
    const a = c.montant_ht_avenants || 0;
    return s + ((b + a) > 0 ? (b + a) : (c.montant_ht || 0));
  }, 0);

  const cumTotalHTBase = cumPrecHTBase + sitHTBase;
  const cumTotalHTAvenants = cumPrecHTAvenants + sitHTAvenants;
  const cumTotalHT = cumPrecHT + sitMontantHT;
  const cumTotalTTC = cumTotalHT * (1 + tauxTVA / 100);
  const cumPrecTTC = cumPrecHT * (1 + tauxTVA / 100);

  const sitMontantTVA = sitMontantHT * (tauxTVA / 100);
  const sitMontantTTC = sitMontantHT * (1 + tauxTVA / 100);
  const cumTotalTVA = cumTotalHT * (tauxTVA / 100);
  const cumPrecTVA = cumPrecHT * (tauxTVA / 100);

  const pctBase = montantMarcheBase > 0 ? fmtPct((cumTotalHTBase / montantMarcheBase) * 100) : '0,0';
  const pctAvenants = totalAvenantsHT > 0 ? fmtPct((cumTotalHTAvenants / totalAvenantsHT) * 100) : '0,0';
  const pctTotal = nouveauMontantMarcheHT > 0 ? fmtPct((cumTotalHT / nouveauMontantMarcheHT) * 100) : '0,0';
  const pctAvancement = nouveauMontantMarcheHT > 0 ? fmtPct((cumTotalHT / nouveauMontantMarcheHT) * 100) : '0,0';

  // ─── CAUTION ─────────────────────────────────────────────────────
  const aCaution = !!(marche?.a_caution && marche?.cautions?.length > 0);
  const cautionMontant = (marche?.cautions || []).reduce((s, c) => s + (c.montant || 0), 0);
  const marcheCautionne = aCaution ? 'Oui' : 'Non';

  // ─── PÉNALITÉS (catégorie = 'penalite') ──────────────────────────
  // Seules les lignes de type 'penalite' vont dans "Pénalités de retard"
  const certPenalites = penalitesAppliquees
    .filter(p => !p.categorie || p.categorie === 'penalite')
    .reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0)
    - (certificat.remboursement_penalites || 0);

  const penPrecedentes = situationsPrecedentes.reduce((s, c) => {
    const p = (c.penalites_appliquees || [])
      .filter(pp => !pp.categorie || pp.categorie === 'penalite')
      .reduce((ps, pp) => ps + (parseFloat(pp.montant_calcule) || 0), 0);
    return s + p - (c.remboursement_penalites || 0);
  }, 0);
  const penCumulees = penPrecedentes + certPenalites;

  // ─── RETENUES DIVERSES (catégorie = 'retenue') ───────────────────
  // Les lignes de type 'retenue' vont dans "Autres retenues" (en plus du CIE)
  const certRetenuesDiverses = penalitesAppliquees
    .filter(p => p.categorie === 'retenue')
    .reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0);

  const retenuesDiversesPrecedentes = situationsPrecedentes.reduce((s, c) => {
    return s + (c.penalites_appliquees || [])
      .filter(pp => pp.categorie === 'retenue')
      .reduce((ps, pp) => ps + (parseFloat(pp.montant_calcule) || 0), 0);
  }, 0);

  // ─── RETENUE DE GARANTIE ─────────────────────────────────────────
  // Règle : on différencie les cautions reçues AVANT la période courante
  // (précédent) vs. reçues PENDANT (ou avant) le mois courant (cumul).
  // Cela gère le remboursement RG quand la caution arrive en cours de marché.
  const certYear  = parseInt(certificat.annee || new Date().getFullYear());
  const certMonth = parseInt(certificat.mois  || (new Date().getMonth() + 1));
  const certDate  = new Date(certYear, certMonth - 1, 1); // 1er du mois courant
  const cautions  = marche?.cautions || [];

  // Pad helper pour comparaison de dates en chaîne (YYYY-MM-DD), évite les problèmes UTC/timezone
  const pad = (n) => String(n).padStart(2, '0');
  const premierJourMoisStr  = `${certYear}-${pad(certMonth)}-01`;
  const dernierJourMoisStr  = `${certYear}-${pad(certMonth)}-${pad(new Date(certYear, certMonth, 0).getDate())}`;

  // Retourne la date de caution sous forme YYYY-MM-DD
  const getDateCautionStr = (c) => {
    if (c.date_reception) return c.date_reception.substring(0, 10);
    if (c.date_ajout) return c.date_ajout.substring(0, 10);
    return premierJourMoisStr; // pas de date = considérée reçue ce mois
  };

  // Cautions reçues strictement AVANT le mois courant (pour calcul précédent)
  const cautionAvantCeMois = cautions
    .filter(c => getDateCautionStr(c) < premierJourMoisStr)
    .reduce((s, c) => s + (c.montant || 0), 0);

  // Cautions reçues jusqu'au dernier jour du mois courant inclus (pour calcul cumul)
  const cautionJusquACeMois = cautions
    .filter(c => getDateCautionStr(c) <= dernierJourMoisStr)
    .reduce((s, c) => s + (c.montant || 0), 0);
  const rgCumul = Math.max(0, cumTotalTTC * 0.05 - cautionJusquACeMois);
  const rgPrec  = Math.max(0, cumPrecTTC  * 0.05 - cautionAvantCeMois);
  const rgSit   = rgCumul - rgPrec;

  // ─── AUTRES RETENUES (CIE + retenues diverses) ───────────────────
  const cieSit = (certificat.montant_cie || 0) + certRetenuesDiverses;
  const ciePrec = situationsPrecedentes.reduce((s, c) => s + (c.montant_cie || 0), 0) + retenuesDiversesPrecedentes;
  const cieCumul = ciePrec + cieSit;

  // ─── TOTAUX RETENUES ─────────────────────────────────────────────
  const retTotalCumul = rgCumul + penCumulees + cieCumul;
  const retTotalPrec = rgPrec + penPrecedentes + ciePrec;
  const retTotalSit = rgSit + certPenalites + cieSit;

  // ─── AVANCES ─────────────────────────────────────────────────────
  const avanceHT = marche?.avance_ht || 0;
  const avancePrecHT = situationsPrecedentes.reduce((s, c) => s + (c.remboursement_avance_ht || 0), 0);
  const avanceSitHT = certificat.remboursement_avance_ht || 0;
  const rembAvanceCumul = avancePrecHT + avanceSitHT;
  const soldeAvanceHTCumul = avanceHT - rembAvanceCumul;
  const soldeAvanceTTCCumul = soldeAvanceHTCumul * (1 + tauxTVA / 100);

  const hasAvances = avanceHT > 0 || avanceSitHT > 0;

  // ─── PAIEMENTS DIRECTS ST ────────────────────────────────────────
  const hasST = paiementsSousTraitants && paiementsSousTraitants.length > 0;
  // Situation courante : montant ST de ce CP
  const totalSTSit = paiementsSousTraitants.reduce((s, x) => s + (x.montant_ht || x.montant_situation_ht || 0), 0);
  // Cumul précédent ST : somme des paiements ST de tous les CPs précédents
  const totalSTPrec = situationsPrecedentes.reduce((s, c) => {
    return s + (c.paiements_sous_traitants || []).reduce((ss, x) => ss + (x.montant_ht || 0), 0);
  }, 0);
  // Nouveau cumul ST = précédent + situation courante
  const totalSTCumul = totalSTPrec + totalSTSit;

  // ─── PAIEMENTS DIRECTS FOURNISSEURS ──────────────────────────────
  const hasFou = paiementsFournisseurs && paiementsFournisseurs.length > 0;
  const totalFouCumulHT = paiementsFournisseurs.reduce((s, x) => s + (x.montant_cumul_ht || 0), 0);
  const totalFouPrecHT = paiementsFournisseurs.reduce((s, x) => s + (x.montant_precedent_ht || 0), 0);
  const totalFouSitHT = paiementsFournisseurs.reduce((s, x) => s + (x.montant_situation_ht || 0), 0);
  const totalFouCumulTVA = totalFouCumulHT * (tauxTVA / 100);
  const totalFouPrecTVA = totalFouPrecHT * (tauxTVA / 100);
  const totalFouSitTVA = totalFouSitHT * (tauxTVA / 100);
  const totalFouCumulTTC = totalFouCumulHT + totalFouCumulTVA;
  const totalFouPrecTTC = totalFouPrecHT + totalFouPrecTVA;
  const totalFouSitTTC = totalFouSitHT + totalFouSitTVA;

  // ─── NET À PAYER ─────────────────────────────────────────────────
  // Le montant ST est déduit du TTC avant calcul du Net à Payer
  const netAPayerSituation = sitMontantTTC - retTotalSit - totalSTSit + (certificat.deblocage_rg || 0);

  // ─── MONTANTS FINAUX AVEC DÉDUCTION ST ───────────────────────────
  // Cumul net = avancement TTC - retenues - ST cumulé
  const finalCumulTTC = cumTotalTTC - retTotalCumul - totalSTCumul;
  const finalPrecTTC  = cumPrecTTC  - retTotalPrec  - totalSTPrec;
  // HT = TTC / (1 + TVA)
  const finalCumulHT  = finalCumulTTC  / (1 + tauxTVA / 100);
  const finalPrecHT   = finalPrecTTC   / (1 + tauxTVA / 100);
  const finalSitHT    = netAPayerSituation / (1 + tauxTVA / 100);
  // TVA
  const finalCumulTVA = finalCumulTTC  - finalCumulHT;
  const finalPrecTVA  = finalPrecTTC   - finalPrecHT;
  const finalSitTVA   = netAPayerSituation - finalSitHT;

// ─── SITUATIONS RÉGLÉES ──────────────────────────────────────────
// On affiche dans les cases bleues le NET À PAYER TTC de chaque situation précédente.
// CP01 → case vide (pas de précédents)
// CP02 → case CP01 = Net à payer du CP01
// CP03 → case CP01 maintenue + case CP02 = Net à payer du CP02
// etc.

// Importer ou recalculer computeNetAPayer localement
const computeNetAPayer = (cert, allCerts, marcheData) => {
  const tauxTVALocal = marcheData?.taux_tva || tauxTVA;
  const htCert = (cert.montant_ht_base || 0) + (cert.montant_ht_avenants || 0) > 0
    ? (cert.montant_ht_base || 0) + (cert.montant_ht_avenants || 0)
    : (cert.montant_ht || 0);
  const ttcCert = htCert * (1 + tauxTVALocal / 100);

  const cautions = marcheData?.cautions || [];
  const certsSorted = allCerts.sort((a, b) => parseInt(a.numero || 0) - parseInt(b.numero || 0));
  let cumulTTCBefore = 0;

  for (const c of certsSorted) {
    if (c.id === cert.id) break;
    const htC = (c.montant_ht_base || 0) + (c.montant_ht_avenants || 0) > 0
      ? (c.montant_ht_base || 0) + (c.montant_ht_avenants || 0)
      : (c.montant_ht || 0);
    cumulTTCBefore += htC * (1 + tauxTVALocal / 100);
  }

  const cumulTTCAfter = cumulTTCBefore + ttcCert;

  const pad = (n) => String(n).padStart(2, '0');
  const sitYear = parseInt(cert.annee || 0);
  const sitMonth = parseInt(cert.mois || 0);
  const dernierJourSit = sitYear && sitMonth
    ? `${sitYear}-${pad(sitMonth)}-${pad(new Date(sitYear, sitMonth, 0).getDate())}`
    : '9999-12-31';

  const cautionAvantSit = cautions
    .filter(c => {
      const cDate = c.date_reception?.substring(0, 10) || c.date_ajout?.substring(0, 10);
      return cDate && cDate < `${sitYear}-${pad(sitMonth)}-01`;
    })
    .reduce((s, c) => s + (c.montant || 0), 0);

  const cautionJusquaSit = cautions
    .filter(c => {
      const cDate = c.date_reception?.substring(0, 10) || c.date_ajout?.substring(0, 10);
      return cDate && cDate <= dernierJourSit;
    })
    .reduce((s, c) => s + (c.montant || 0), 0);

  const rgAvant = Math.max(0, cumulTTCBefore * 0.05 - cautionAvantSit);
  const rgApres = Math.max(0, cumulTTCAfter * 0.05 - cautionJusquaSit);
  const rg = rgApres - rgAvant;

  const pen = (cert.penalites_appliquees || []).reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0)
    - (cert.remboursement_penalites || 0);
  const cie = cert.montant_cie || 0;
  const deblocage = cert.deblocage_rg || 0;

  const netAPayer = ttcCert - rg - pen - cie + deblocage;
  return { netAPayer, rg };
};

const situationAmounts = {};
const allCertificatsForCalc = [...situationsPrecedentes, certificat].sort((a, b) => 
  (parseInt(a.numero) || 0) - (parseInt(b.numero) || 0)
);

situationsPrecedentes.forEach(c => {
  const num = parseInt(c.numero || 0);
  if (num > 0) {
    const { netAPayer } = computeNetAPayer(c, allCertificatsForCalc, marche);
    situationAmounts[num] = netAPayer;
  }
});

  const totalRegleTTC = Object.values(situationAmounts).reduce((s, v) => s + v, 0);
  const numSituations = Math.max(18, parseInt(certificat.numero || 0));

  // ─── INFOS PARTIES ───────────────────────────────────────────────
  const entNom = entreprise?.nom || '';
  const entAdr1 = entreprise?.adresse_1 || '';
  const entCPVille = `${entreprise?.code_postal || ''} ${entreprise?.ville || ''}`.trim();

  const moaNom = client?.nom || '';
  const moaAdr1 = client?.adresse_1 || '';
  const moaCPVille = `${client?.code_postal || ''} ${client?.ville || ''}`.trim();

  const moeNomEntreprise = infoGestionbat?.nom_entreprise || '';
  const moeNom = infoGestionbat?.nom || '';
  const moeAdr = infoGestionbat?.adresse || '';
  const moeCPVille = `${infoGestionbat?.code_postal || ''} ${infoGestionbat?.ville || ''}`.trim();

  const chantierCP = chantier?.code_postal ? String(chantier.code_postal).slice(0, 2) : '';
  const chantierVille = chantier?.ville || '';

  const dateStr = certificat.date_emission
    ? new Date(certificat.date_emission).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })
    : new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });

  // ─── STYLES COMMUNS ──────────────────────────────────────────────
  const th = `background:${DARK_BLUE};color:#fff;font-weight:bold;font-size:8.5px;padding:4px 5px;border:1px solid ${DARK_BLUE};text-align:center`;
  const thL = `background:${DARK_BLUE};color:#fff;font-weight:bold;font-size:8.5px;padding:4px 5px;border:1px solid ${DARK_BLUE};text-align:left`;
  const thNoBg = `font-size:8.5px;padding:4px 5px;border:1px solid ${BORDER_COLOR};text-align:center;font-weight:bold;background:#fff;color:#000`;
  const tdBNoColor = `font-size:8.5px;padding:3px 5px;border:1px solid ${BORDER_COLOR};font-weight:bold;text-align:right`;
  const vBorder = `border-left:1px solid ${BORDER_COLOR};border-right:1px solid ${BORDER_COLOR}`;
  const tdLC = `font-size:8.5px;padding:3px 5px;${vBorder};text-align:right;background:${LIGHT_BLUE_BG}`;
  const tdLCB = `font-size:8.5px;padding:3px 5px;${vBorder};text-align:right;background:${LIGHT_BLUE_BG};font-weight:bold`;
  const td = `font-size:8.5px;padding:3px 5px;${vBorder}`;
  const tdR = `font-size:8.5px;padding:3px 5px;${vBorder};text-align:right`;
  const tdB = `font-size:8.5px;padding:3px 5px;border:1px solid ${BORDER_COLOR};font-weight:bold`;
  const tdBR = `font-size:8.5px;padding:3px 5px;border:1px solid ${BORDER_COLOR};font-weight:bold;text-align:right;background:${LIGHT_BLUE_BG}`;
  const tdG = `font-size:8px;padding:2.5px 5px;${vBorder};color:#AAAAAA`;
  const tdGR = `font-size:8px;padding:2.5px 5px;${vBorder};color:#AAAAAA;text-align:right`;
  const trSpacer5 = `<tr style="height:6px"><td style="width:36%;${vBorder};padding:0"></td><td style="width:8%;${vBorder};padding:0"></td><td style="width:18%;${vBorder};padding:0"></td><td style="width:19%;${vBorder};padding:0"></td><td style="width:19%;${vBorder};padding:0"></td></tr>`;

  // ─── HTML AVENANTS ───────────────────────────────────────────────
  // Toujours 7 lignes (comme l'Excel), montant indexé par le numéro réel de l'avenant
  // On construit un map numéro → avenant pour éviter le décalage d'index
  const avenantsParNumero = {};
  avenantsDeLEntreprise.forEach(av => {
    const num = parseInt(av.numero || 0);
    if (num > 0) avenantsParNumero[num] = av;
  });
  let avenantsHtml = '';
  for (let i = 1; i <= 7; i++) {
    const av = avenantsParNumero[i];
    avenantsHtml += `<tr>
      <td style="${td}">Avenant n° ${i}</td>
      <td style="${tdR}">${av ? fmt(av.montant_total_ht) : ''}</td>
    </tr>`;
  }

  // ─── HTML SITUATIONS ─────────────────────────────────────────────
  // Sit 1-18 : avec valeurs ; Sit 19-36 : lignes grises (si numSituations > 18)
  let situationsHtml = '';
  // Lignes 1 à 18
  for (let i = 1; i <= 18; i += 2) {
    const j = i + 1;
    const vA = situationAmounts[i] != null ? fmt(situationAmounts[i]) : '';
    const vB = situationAmounts[j] != null ? fmt(situationAmounts[j]) : '';
    const styleA = tdLC;
    const styleB = tdLC;
    situationsHtml += `<tr>
      <td style="${td};white-space:nowrap;width:22%">Situation n°${i}</td>
      <td style="${styleA};width:16%">${vA}</td>
      <td style="${td};white-space:nowrap;width:22%">Situation n°${j}</td>
      <td style="${styleB};width:16%">${vB}</td>
    </tr>`;
  }
  // Séparateur + lignes 19-36 si applicable
  if (numSituations > 18) {
    situationsHtml += `<tr><td colspan="4" style="height:3px;background:#F0F0F0;border:none"></td></tr>`;
    for (let i = 19; i <= 36; i += 2) {
      const j = i + 1;
      const vA = situationAmounts[i] != null ? fmt(situationAmounts[i]) : '';
      const vB = situationAmounts[j] != null ? fmt(situationAmounts[j]) : '';
      situationsHtml += `<tr>
        <td style="${tdG};white-space:nowrap;width:22%">Situation n°${i}</td>
        <td style="${tdGR};width:16%">${vA}</td>
        <td style="${tdG};white-space:nowrap;width:22%">Situation n°${j}</td>
        <td style="${tdGR};width:16%">${vB}</td>
      </tr>`;
    }
  }

  // ─── HTML AVANCES (conditionnel) ─────────────────────────────────
  const avancesSection = hasAvances ? `
<table style="width:100%;margin-bottom:5px;border-collapse:collapse">
  <tr>
    <td colspan="5" style="${thL}">Gestion des avances</td>
  </tr>
  <tr>
    <td style="${td};width:36%">Avance € HT</td>
    <td style="${tdR};width:8%"></td>
    <td style="${tdBR};width:18%">${fmt(avanceHT)}</td>
    <td style="${tdBR};width:19%"></td>
    <td style="${tdBR};width:19%">${fmt(avanceSitHT)}</td>
  </tr>
  <tr>
    <td style="${td}">Remboursement avance € HT</td>
    <td style="${tdR}"></td>
    <td style="${tdR}">${fmt(rembAvanceCumul)}</td>
    <td style="${tdR}">${fmt(avancePrecHT)}</td>
    <td style="${tdR}">${fmt(avanceSitHT)}</td>
  </tr>
  <tr>
    <td style="${tdB}">Solde avance en € HT</td>
    <td style="${tdR}"></td>
    <td style="${tdBR}">${fmt(soldeAvanceHTCumul)}</td>
    <td style="${tdBR}"></td>
    <td style="${tdBR}"></td>
  </tr>
  <tr>
    <td style="${tdB}">Solde avance en € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdBR}">${fmt(soldeAvanceTTCCumul)}</td>
    <td style="${tdBR}"></td>
    <td style="${tdBR}"></td>
  </tr>
</table>` : '';

  // ─── HTML PAIEMENTS ST (conditionnel) ────────────────────────────
  let stLignesHtml = '';
  if (hasST) {
    paiementsSousTraitants.forEach((st, idx) => {
      const stEntreprise = (entreprises || []).find(e => e.id === st.entreprise_id);
      const nomST = stEntreprise?.nom || st.nom || `Sous-traitant ${idx + 1}`;
      const contrat = (contratsSousTraitance || []).find(c => c.entreprise_sous_traitant_id === st.entreprise_id);
      const montantContrat = contrat?.montant || 0;
      const montantSituation = st.montant_ht || st.montant_situation_ht || 0;
      // Cumul précédent par sous-traitant : somme dans les CPs précédents
      const stPrecCumul = situationsPrecedentes.reduce((s, c) => {
        const found = (c.paiements_sous_traitants || []).find(x => x.entreprise_id === st.entreprise_id);
        return s + (found ? (found.montant_ht || 0) : 0);
      }, 0);
      const stNouveauCumul = stPrecCumul + montantSituation;
      stLignesHtml += `<tr>
        <td style="${td};width:36%">${nomST}</td>
        <td style="${tdR};width:8%">${montantContrat > 0 ? fmt(montantContrat) : ''}</td>
        <td style="${tdLC};width:18%">${fmt(stNouveauCumul)}</td>
        <td style="${tdLC};width:19%">${fmt(stPrecCumul)}</td>
        <td style="${tdR};width:19%">${fmt(montantSituation)}</td>
      </tr>`;
    });
  }
  const stSection = hasST ? `
<table style="width:100%;margin-bottom:5px;border-collapse:collapse">
  <tr>
    <td style="${thL};width:36%">Paiement direct des sous-traitants :</td>
    <td style="${th};width:8%">Montant contrat</td>
    <td style="${th};width:18%">Nouveau cumul</td>
    <td style="${th};width:19%">Cumul précédent</td>
    <td style="${th};width:19%">Situation du Mois</td>
  </tr>
  ${stLignesHtml}
  <tr>
    <td style="${tdB};width:36%">Total paiements directs S.T. (autoliquidation) € HT :</td>
    <td style="${tdR};width:8%"></td>
    <td style="${tdBR};width:18%">${fmt(totalSTCumul)}</td>
    <td style="${tdBR};width:19%">${fmt(totalSTPrec)}</td>
    <td style="${tdBR};width:19%">${fmt(totalSTSit)}</td>
  </tr>
</table>` : '';

  // ─── HTML PAIEMENTS FOURNISSEURS (conditionnel) ──────────────────
  let fouLignesHtml = '';
  if (hasFou) {
    paiementsFournisseurs.forEach((f, idx) => {
      fouLignesHtml += `<tr>
        <td style="${td}" colspan="2">${f.nom || `Fournisseur ${idx + 1}`}</td>
        <td style="${tdR}">${fmt(f.montant_cumul_ht || 0)}</td>
        <td style="${tdR}">${fmt(f.montant_precedent_ht || 0)}</td>
        <td style="${tdR}">${fmt(f.montant_situation_ht || 0)}</td>
      </tr>`;
    });
  }
  const fouSection = hasFou ? `
<table style="width:100%;margin-bottom:5px;border-collapse:collapse">
  <tr>
    <td colspan="5" style="${thL}">Paiement direct des fournisseurs :</td>
  </tr>
  ${fouLignesHtml}
  <tr>
    <td style="${tdB}" colspan="2">Total paiements directs Fournisseurs € HT</td>
    <td style="${tdBR}">${fmt(totalFouCumulHT)}</td>
    <td style="${tdBR}">${fmt(totalFouPrecHT)}</td>
    <td style="${tdBR}">${fmt(totalFouSitHT)}</td>
  </tr>
  <tr>
    <td style="${td}" colspan="2">TVA ${tauxTVA}%</td>
    <td style="${tdR}">${fmt(totalFouCumulTVA)}</td>
    <td style="${tdR}">${fmt(totalFouPrecTVA)}</td>
    <td style="${tdR}">${fmt(totalFouSitTVA)}</td>
  </tr>
  <tr>
    <td style="${tdB}" colspan="2">Total paiements directs Fournisseurs € TTC</td>
    <td style="${tdBR}">${fmt(totalFouCumulTTC)}</td>
    <td style="${tdBR}">${fmt(totalFouPrecTTC)}</td>
    <td style="${tdBR}">${fmt(totalFouSitTTC)}</td>
  </tr>
</table>` : '';

  // ─── LOGO HELPER ─────────────────────────────────────────────────
  const logoMoeHtml = logoMoeUrl ? `<img src="${logoMoeUrl}"    style="max-height:40px;max-width:100%;object-fit:contain" alt="Logo MOE">` : 'Logo MOE';
  const logoClientHtml = logoClientUrl ? `<img src="${logoClientUrl}" style="max-height:40px;max-width:100%;object-fit:contain" alt="Logo Client">` : 'Logo Client';

  // ─── RENDU HTML FINAL ────────────────────────────────────────────
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Certificat de paiement ${certificat.numero || ''} - ${chantier?.nom || ''}</title>
<style>
  @page { size: A4 portrait; margin: 5mm 5mm 5mm 5mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; font-size: 8.5px; background: #fff; width: 200mm; margin: 0 auto; }
  table { border-collapse: collapse; width: 100%; border: 1px solid #BFBFBF; }
  @media print { body { width: 100%; margin: 0; } html { margin: 0; } }
</style>
</head>
<body>

<!-- ═══════════════════════════════════════════
     EN-TÊTE (fond bleu #002060)
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:0;border-collapse:collapse">
  <tr>
    <td colspan="3" style="background:${DARK_BLUE};color:#fff;font-weight:bold;font-size:18px;padding:6px 8px;text-align:center">
      ${chantier?.nom || ''}${chantierVille ? ` - ${chantierVille}${chantierCP ? ` (${chantierCP})` : ''}` : ''}
    </td>
  </tr>
  <tr>
    <td colspan="3" style="background:${DARK_BLUE};color:#fff;font-weight:bold;font-size:12px;padding:4px 6px;text-align:center;text-transform:uppercase">
      CERTIFICAT DE PAIEMENT N°${certificat.numero || ''} &nbsp;—&nbsp; ${MOIS_LABELS[certificat.mois] || ''} ${certificat.annee || ''}
    </td>
  </tr>
  <tr>
    <td colspan="3" style="background:${DARK_BLUE};color:#fff;font-weight:bold;font-size:12px;padding:4px 6px;text-align:center">
      ${entNom} &nbsp;—&nbsp; LOT ${marche?.numero_lot || ''} &nbsp;${marche?.intitule_lot || ''}
    </td>
  </tr>
</table>

<!-- Ligne facture -->
<div style="font-size:7px;color:#444;padding:2px 4px;font-style:italic;text-align:center;margin-bottom:2px">
  Facture à libeller au nom de :&nbsp;
  <span style="text-align:left">OCDL - Groupe GIBOIRE, 34 rue de Strasbourg - CS 70213 - 44002 NANTES Cedex 1</span>
</div>

<!-- ═══════════════════════════════════════════
     LOGOS (centrés sur colonnes MOE et MOA)
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:6px;border:none">
  <tr>
    <!-- Colonne Entreprise : vide -->
    <td style="width:33%;padding:0"></td>
    <!-- Logo MOE centré sur colonne MOE -->
    <td style="width:34%;text-align:center;padding:22px 4px;border:none">
    <img src="https://base44.app/api/apps/6991f3bbe7c7ad520a448d8e/files/public/6991f3bbe7c7ad520a448d8e/bcfa5be23_gestionbat.jpg"    style="max-height:40px;max-width:100%;object-fit:contain" alt="Logo MOE">
    </td>
    <!-- Logo Client centré sur colonne MOA -->
    <td style="width:33%;text-align:center;padding:22px 4px;border:none">
     <img src="https://base44.app/api/apps/6991f3bbe7c7ad520a448d8e/files/public/6991f3bbe7c7ad520a448d8e/806b91b5f_GOURPEGIBOIRE-versionombree.png" style="max-height:40px;max-width:100%;object-fit:contain" alt="Logo Client">
    </td>      
  </tr>
</table>

<!-- ═══════════════════════════════════════════
     3 PARTIES : Entreprise | MOE | MOA
     (logos sont alignés juste au-dessus)
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:6px;border:none">
  <tr>
    <td style="width:33%;text-align:center;padding:4px 6px;vertical-align:top;font-size:10px;line-height:1.6;border:none">
      <div style="font-weight:bold;margin-bottom:4px;text-decoration:underline">Entreprise :</div>
      <div style="font-weight:bold">${entNom}</div>
      <div>${entAdr1}</div>
      <div>${entCPVille}</div>
    </td>
    <td style="width:34%;text-align:center;padding:4px 6px;vertical-align:top;font-size:10px;line-height:1.6;border:none">
      <div style="font-weight:bold;margin-bottom:4px;text-decoration:underline">Maître d'œuvre :</div>
      <div style="font-weight:bold">${moeNomEntreprise}</div>
      <div>${moeNom}</div>
      <div>${moeAdr}</div>
      <div>${moeCPVille}</div>
    </td>
    <td style="width:33%;text-align:center;padding:4px 6px;vertical-align:top;font-size:10px;line-height:1.6;border:none">
      <div style="font-weight:bold;margin-bottom:4px;text-decoration:underline">Maître d'ouvrage :</div>
      <div style="font-weight:bold">${moaNom}</div>
      <div>${moaAdr1}</div>
      <div>${moaCPVille}</div>
    </td>
  </tr>
</table>

<!-- ═══════════════════════════════════════════
     DOUBLE TABLEAU : Marché | [espace] | Situations réglées
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:6px;border:none">
  <tr>

    <!-- ── Marché & Avenants (37%) ── -->
    <td style="width:37%;vertical-align:top;padding-right:4px">
      <table style="width:100%;border-collapse:collapse">
        <tr>
          <td style="font-size:8.5px;padding:4px 5px;border:1px solid ${BORDER_COLOR};text-align:left;font-weight:bold;width:62%">Montant du marché € HT</td>
          <td style="${tdLC};width:38%">${fmt(montantMarcheBase)}</td>
        </tr>
        ${avenantsHtml}
        <tr>
          <td style="${td}">Total des avenants € HT</td>
          <td style="${tdR}">${fmt(totalAvenantsHT)}</td>
        </tr>
        <tr>
          <td style="${tdB}">Montant engagé € HT</td>
          <td style="${tdBR}">${fmt(nouveauMontantMarcheHT)}</td>
        </tr>
        <tr>
          <td style="${tdB}">Montant engagé € TTC</td>
          <td style="${tdBR}">${fmt(nouveauMontantMarcheTTC)}</td>
        </tr>
      </table>
    </td>

    <!-- ── Espace visuel ── -->
    <td style="width:10%"></td>

    <!-- ── Montants réglés (≈57%) ── -->
    <td style="vertical-align:top;padding-left:4px">
      <table style="width:100%;border-collapse:collapse">
        <tr>
          <td colspan="4" style="${th}">Montants réglés € TTC</td>
        </tr>
        ${situationsHtml}
        <tr>
          <td colspan="3" style="${tdB};text-align:right">Total réglé € TTC</td>
          <td style="${tdBR}">${fmt(totalRegleTTC)}</td>
        </tr>
      </table>
    </td>

  </tr>
</table>

<!-- ═══════════════════════════════════════════
     TABLEAU AVANCEMENT
═══════════════════════════════════════════ -->
<table style="width:100%;margin-top:10px;margin-bottom:6px;border-collapse:collapse">
  <tr>
    <td style="width:36%"></td>
    <td style="width:8%"></td>
    <td style="${thNoBg};width:18%">Nouveau cumul</td>
    <td style="${thNoBg};width:19%">Cumul précédent</td>
    <td style="${thNoBg};width:19%">Situation du Mois</td>
  </tr>
  <tr>
    <td colspan="5" style="${thL}">Avancement</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${td}">Avancement Marché € HT</td>
    <td style="${tdR}">${pctBase}%</td>
    <td style="${tdLC}">${fmt(cumTotalHTBase)}</td>
    <td style="${tdLC}">${fmt(cumPrecHTBase)}</td>
    <td style="${tdR}">${fmt(sitHTBase)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${td}">Avancement Avenants € HT</td>
    <td style="${tdR}">${pctAvenants}%</td>
    <td style="${tdLC}">${fmt(cumTotalHTAvenants)}</td>
    <td style="${tdLC}">${fmt(cumPrecHTAvenants)}</td>
    <td style="${tdR}">${fmt(sitHTAvenants)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${tdB}">Total avancement € HT</td>
    <td style="${tdBNoColor}">${pctTotal}%</td>
    <td style="${tdBNoColor}">${fmt(cumTotalHT)}</td>
    <td style="${tdBNoColor}">${fmt(cumPrecHT)}</td>
    <td style="${tdBNoColor}">${fmt(sitMontantHT)}</td>
  </tr>
  <tr style="display:none">
    <td style="${td}">TVA ${tauxTVA}%</td>
    <td style="${tdR}"></td>
    <td style="${tdR}">${fmt(cumTotalTVA)}</td>
    <td style="${tdR}">${fmt(cumPrecTVA)}</td>
    <td style="${tdR}">${fmt(sitMontantTVA)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${tdB}">Total avancement € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdBNoColor}">${fmt(cumTotalTTC)}</td>
    <td style="${tdBNoColor}">${fmt(cumPrecTTC)}</td>
    <td style="${tdBNoColor}">${fmt(sitMontantTTC)}</td>
  </tr>
</table>

<!-- ═══════════════════════════════════════════
     AVANCES (masqué si absentes)
═══════════════════════════════════════════ -->
${avancesSection}

<!-- ═══════════════════════════════════════════
     TABLEAU RETENUES
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:6px;border-collapse:collapse">
  <tr>
    <td colspan="5" style="${thL}">Retenues</td>
  </tr>
  ${trSpacer5}
  <!-- Marché cautionné + montant caution sous la même colonne -->
  <tr>
    <td style="${td};width:36%">Marché cautionné :</td>
    <td style="${tdLC};width:8%;text-align:center">${marcheCautionne}</td>
    <td style="${tdR};width:18%"></td>
    <td style="${tdR};width:19%"></td>
    <td style="${tdR};width:19%"></td>
    </tr>
  ${trSpacer5}
  ${aCaution ? `<tr>
    <td style="${td};text-align:right">Montant de la caution bancaire TTC :</td>
    <td style="${tdLC};text-align:center">${fmt(cautionMontant)}</td>
    <td style="${tdR}"></td>
    <td style="${tdR}"></td>
    <td style="${tdR}"></td>
  </tr>` : ''}
  <tr>
    <td style="${td}">Retenue de garantie 5%</td>
    <td style="${tdR}"></td>
    <td style="${tdLC}">${fmt(rgCumul)}</td>
    <td style="${tdLC}">${fmt(rgPrec)}</td>
    <td style="${tdR}">${fmt(rgSit)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${td}">Pénalités de retard € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdLC}">${fmt(penCumulees)}</td>
    <td style="${tdLC}">${fmt(penPrecedentes)}</td>
    <td style="${tdR}">${fmt(certPenalites)}</td>
  </tr>

  ${trSpacer5}
  <tr>
    <td style="${td}">Autres retenues € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdLC}">${fmt(cieCumul)}</td>
    <td style="${tdLC}">${fmt(ciePrec)}</td>
    <td style="${tdR}">${fmt(cieSit)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${tdB}">Total des retenues € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdBNoColor}">${fmt(retTotalCumul)}</td>
    <td style="${tdBNoColor}">${fmt(retTotalPrec)}</td>
    <td style="${tdBNoColor}">${fmt(retTotalSit)}</td>
  </tr>
</table>

<!-- ═══════════════════════════════════════════
     PAIEMENTS DIRECTS ST (masqué si absent)
═══════════════════════════════════════════ -->
${stSection}

<!-- ═══════════════════════════════════════════
     PAIEMENTS DIRECTS FOURNISSEURS (masqué si absent)
═══════════════════════════════════════════ -->
${fouSection}

<!-- ═══════════════════════════════════════════
     MONTANTS FINAUX
═══════════════════════════════════════════ -->
<table style="width:100%;margin-bottom:6px;border-collapse:collapse">
  ${trSpacer5}
  <tr>
    <td style="${td};width:36%">Montant total en € HT</td>
    <td style="${tdR};width:8%"></td>
    <td style="${tdR};width:18%">${fmt(finalCumulHT)}</td>
    <td style="${tdR};width:19%">${fmt(finalPrecHT)}</td>
    <td style="${tdR};width:19%">${fmt(finalSitHT)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${td}">TVA ${tauxTVA}%</td>
    <td style="${tdR}"></td>
    <td style="${tdR}">${fmt(finalCumulTVA)}</td>
    <td style="${tdR}">${fmt(finalPrecTVA)}</td>
    <td style="${tdR}">${fmt(finalSitTVA)}</td>
  </tr>
  ${trSpacer5}
  <tr>
    <td style="${tdB}">Montant total en € TTC</td>
    <td style="${tdR}"></td>
    <td style="${tdBNoColor}">${fmt(finalCumulTTC)}</td>
    <td style="${tdBNoColor}">${fmt(finalPrecTTC)}</td>
    <td style="font-size:9px;padding:3px 4px;border:1px solid ${DARK_BLUE};font-weight:bold;text-align:center;background:${DARK_BLUE};color:#fff">
      NET À PAYER<br><span style="font-size:11px">${fmt(netAPayerSituation)}</span>
    </td>
  </tr>
</table>

<!-- ═══════════════════════════════════════════
     PIED DE PAGE
═══════════════════════════════════════════ -->
<table style="width:100%;border-collapse:collapse;margin-bottom:4px">
  <tr>
    <td style="width:38%;border:1px solid ${BORDER_COLOR};padding:8px;vertical-align:top;font-size:8.5px">
      <div style="font-weight:bold;margin-bottom:4px">Commentaires du Maître d'Œuvre :</div>
      <div style="white-space:pre-wrap">${certificat.notes || certificat.commentaires || ''}</div>
      ${(() => {
        const notesHisto = [...situationsPrecedentes]
          .sort((a, b) => (parseInt(a.numero) || 0) - (parseInt(b.numero) || 0))
          .filter(c => c.notes && c.notes.trim() !== '');
        if (notesHisto.length === 0) return '';
        const moisCourt = {"01":"Janv.","02":"Févr.","03":"Mars","04":"Avr.","05":"Mai","06":"Juin","07":"Juil.","08":"Août","09":"Sept.","10":"Oct.","11":"Nov.","12":"Déc."};
        let html = `<div style="margin-top:6px;border-top:1px dashed #BFBFBF;padding-top:4px;font-size:7.5px"><strong>Historique :</strong>`;
        notesHisto.forEach(c => {
          const ml = moisCourt[c.mois] || c.mois;
          html += `<div style="margin-top:2px;padding:2px 4px;background:#DCE6F1;border-left:2px solid #002060"><strong>CP N°${c.numero} (${ml} ${c.annee}) :</strong> ${c.notes}</div>`;
        });
        html += '</div>';
        return html;
      })()}
    </td>
    <td style="width:31%;border:1px solid ${BORDER_COLOR};padding:8px;vertical-align:top;font-size:8.5px;text-align:center">
      <div style="font-weight:bold;margin-bottom:4px">Visa du Maître d'Œuvre :</div>
      <div>Fait le : ${dateStr}</div>
      <div style="min-height:65px;display:flex;align-items:center;justify-content:center;margin-top:4px">
        <img src="https://media.base44.com/images/public/6991f3bbe7c7ad520a448d8e/d2cc27d3e_Capture_d_cran_2020-11-24_085247-removebg-preview.png" alt="Signature MOE" style="max-width:120px;max-height:60px;object-fit:contain" />
      </div>
    </td>
    <td style="width:31%;border:1px solid ${BORDER_COLOR};padding:8px;vertical-align:top;font-size:8.5px;text-align:center">
      <div style="font-weight:bold;margin-bottom:4px">Visa COP :</div>
      <div style="min-height:80px"></div>
    </td>
  </tr>
</table>

<!-- Numéro et date de facture -->
<div style="font-size:8px;color:#333;padding:4px 2px;margin-top:4px;border-top:1px solid ${BORDER_COLOR}">
  <strong>Facture n°</strong> ${certificat.numero_facture || '___________'}
  &nbsp;&nbsp;|&nbsp;&nbsp;
  <strong>Date de facture :</strong> ${certificat.date_facture ? new Date(certificat.date_facture).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '___________'}
</div>

<!-- Footer -->
<div style="display:flex;justify-content:space-between;font-size:6.5px;color:#999;font-style:italic">
  <span>Certificat de paiement — version 18.11.2020</span>
  <span>Page 1/1</span>
</div>

</body>
</html>`;
}