// Template Certificat de paiement standard
// Template utilisé quand il n'y a pas de trame client
// - Montant à cautionner (5% TTC)
// - Retenue de garantie progressive (Déjà Prélevé)
// - Récapitulatif détaillé avec CP précédents
// - Sous-traitants et marché côte à côte pour optimiser l'espace
// - Optimisé pour tenir sur une page
// ⚠️ Mise à jour : Retenue de garantie + Remboursement retenue de garantie (comme l'acompte)

import { format } from "date-fns";
import { fr } from "date-fns/locale";

const MOIS_LABELS = {
  "01": "Janvier", "02": "Février", "03": "Mars", "04": "Avril",
  "05": "Mai", "06": "Juin", "07": "Juillet", "08": "Août",
  "09": "Septembre", "10": "Octobre", "11": "Novembre", "12": "Décembre"
};

export function generateCertificatStandardHtml({
  certificat,
  chantier,
  client,
  entreprise,
  marche,
  situationsPrecedentes,
  avenantsDeLEntreprise,
  paiementsSousTraitants,
  contratsSousTraitance = [],
  penalitesAppliquees,
  infoGestionbat,
  partenaires,
  entreprises,
  tauxTVA
}) {
  // Tranches du chantier
  const tranchesChantier = chantier?.tranches || [];
  const hasTranches = tranchesChantier.length > 0;
  const fmt = (v) => (parseFloat(v) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
  const cert = certificat;
  
  // Calculs de base
  const demandeAcompte = cert.demande_acompte || 0;
  const remboursementAcompte = cert.remboursement_acompte || 0;
  const montantAvecAcompte = cert.montant_ht + demandeAcompte - remboursementAcompte;
  const montantTVA = montantAvecAcompte * (tauxTVA / 100);
  const montantTTC = montantAvecAcompte + montantTVA;
  
  const certTotalPenalties = penalitesAppliquees?.reduce((sum, p) => sum + (parseFloat(p.montant_calcule) || 0), 0) || 0;
  
  const penalitesPrecedentes = situationsPrecedentes.reduce((sum, c) => {
    const pen = (c.penalites_appliquees?.reduce((pSum, p) => pSum + (parseFloat(p.montant_calcule) || 0), 0) || 0);
    const rem = (c.remboursement_penalites || 0);
    return sum + pen - rem;
  }, 0);
  const totalPenaltiesCumulees = certTotalPenalties + penalitesPrecedentes;

  const certTotalPenaltiesTTC = certTotalPenalties;
  const certTotalPenaltiesTVA = certTotalPenalties - certTotalPenalties / 1.2;
  const penalitesPrecedentesTTC = penalitesPrecedentes;
  const totalPenaltiesCumuleesTTC = totalPenaltiesCumulees;
  
  const montantCumulePrecedentHT = situationsPrecedentes.reduce((sum, c) => {
    const montantAvecAcomptePrecedent = (c.montant_ht || 0) + (c.demande_acompte || 0) - (c.remboursement_acompte || 0);
    return sum + montantAvecAcomptePrecedent;
  }, 0);
  const montantCumuleTotalHT = montantCumulePrecedentHT + montantAvecAcompte;
  
  const demandeAcomptePrecedents = situationsPrecedentes.reduce((sum, c) => sum + (c.demande_acompte || 0), 0);
  const demandeAcompteCumul = demandeAcomptePrecedents + demandeAcompte;
  const remboursementAcomptePrecedents = situationsPrecedentes.reduce((sum, c) => sum + (c.remboursement_acompte || 0), 0);
  const remboursementAcompteCumul = remboursementAcomptePrecedents + remboursementAcompte;
  const montantCumulePrecedentTTC = situationsPrecedentes.reduce((sum, c) => {
    const montantAvecAcomptePrecedent = (c.montant_ht || 0) + (c.demande_acompte || 0) - (c.remboursement_acompte || 0);
    const tva = montantAvecAcomptePrecedent * (tauxTVA / 100);
    return sum + montantAvecAcomptePrecedent + tva;
  }, 0);
  const montantCumuleTotalTTC = montantCumuleTotalHT * (1 + tauxTVA / 100);
  
  const montantCumulePrecedentHTSansAcompte = situationsPrecedentes.reduce((sum, c) => sum + (c.montant_ht || 0), 0);
  const montantCumuleTotalHTSansAcompte = montantCumulePrecedentHTSansAcompte + cert.montant_ht;
  
  const montantMarcheBase = marche?.montant || 0;
  const montantMarcheBaseTTC = montantMarcheBase * (1 + tauxTVA / 100);
  const montantTotalAvenantsHT = avenantsDeLEntreprise.reduce((sum, av) => sum + (av.montant_total_ht || 0), 0);
  const montantTotalAvenantsTTC = montantTotalAvenantsHT * (1 + tauxTVA / 100);
  const nouveauMontantMarcheHT = montantMarcheBase + montantTotalAvenantsHT;
  const nouveauMontantMarcheTTC = nouveauMontantMarcheHT * (1 + tauxTVA / 100);
  
  const totalContratsSousTraitants = contratsSousTraitance.reduce((sum, st) => sum + (st.montant || 0), 0);
  const totalContratsSousTraitantsTTC = contratsSousTraitance.reduce((sum, st) => {
    const montantHT = st.montant || 0;
    const soumisATVA = st.soumis_a_tva !== undefined ? st.soumis_a_tva : true;
    return sum + (soumisATVA ? montantHT * (1 + tauxTVA / 100) : montantHT);
  }, 0);

  const montantACautionner = nouveauMontantMarcheTTC * 0.05;
  
  const remboursementPenalites = cert.remboursement_penalites || 0;
  
  const cautions = marche?.cautions || [];
  const totalMontantCautions = cautions.reduce((sum, c) => sum + (c.montant || 0), 0);

  const sortedPrecedents = [...situationsPrecedentes].sort((a, b) => (parseInt(a.numero) || 0) - (parseInt(b.numero) || 0));
  let cumulTTCRunning = 0;
  sortedPrecedents.forEach(pCert => {
    const pMontantAvecAcompte = (pCert.montant_ht || 0) + (pCert.demande_acompte || 0) - (pCert.remboursement_acompte || 0);
    const pMontantTTC = pMontantAvecAcompte * (1 + tauxTVA / 100);
    const rgAvant = Math.max(0, cumulTTCRunning * 0.05 - totalMontantCautions);
    cumulTTCRunning += pMontantTTC;
    const rgApres = Math.max(0, cumulTTCRunning * 0.05 - totalMontantCautions);
    const pRetenue = rgApres - rgAvant;
    const pPenalites = pCert.penalites_appliquees?.reduce((sum, p) => sum + (parseFloat(p.montant_calcule) || 0), 0) || 0;
    const pRemboursementPen = pCert.remboursement_penalites || 0;
    const pMontantCIE = pCert.montant_cie || 0;
    pCert.netAPayerCalc = pMontantTTC - pRetenue - pPenalites + pRemboursementPen + pMontantCIE;
  });

  const aCaution = !!(marche?.a_caution && cautions.length > 0);
  const retenueCumuleePrecedents = aCaution ? 0 : Math.max(0, montantCumulePrecedentTTC * 0.05 - totalMontantCautions);
  const retenueCumuleeTotal = aCaution ? 0 : Math.max(0, montantCumuleTotalTTC * 0.05 - totalMontantCautions);
  const retenueSituation = retenueCumuleeTotal - retenueCumuleePrecedents;

  // 🔥 Remboursement retenue de garantie (comme l'acompte)
  const remboursementRetenue = cert.remboursement_retenue || cert.deblocage_rg || 0;
  const deblocageRGSit = cert.deblocage_rg || 0;
  const deblocageRGPrec = situationsPrecedentes.reduce((s, c) => s + (c.deblocage_rg || 0), 0);
  const deblocageRGCumul = deblocageRGPrec + deblocageRGSit;
  
  const pourcentageAvancement = nouveauMontantMarcheHT > 0 ? ((montantCumuleTotalHTSansAcompte / nouveauMontantMarcheHT) * 100).toFixed(2) : 0;
  
  const resteAPayerHT = nouveauMontantMarcheHT - montantCumuleTotalHT;
  const resteAPayerTTC = nouveauMontantMarcheTTC - montantCumuleTotalTTC;
  
  const montantCieSituation = cert.montant_cie || 0;
  const montantCiePrecedent = situationsPrecedentes.reduce((sum, c) => sum + (c.montant_cie || 0), 0);
  const montantCieCumul = montantCiePrecedent + montantCieSituation;

  const totalDeductions = retenueSituation 
                        + certTotalPenaltiesTTC 
                        - remboursementRetenue 
                        - montantCieSituation 
                        - remboursementPenalites 
                        - deblocageRGSit;
  const netAPayer = montantTTC - totalDeductions;
  
  const totalSousTraitants = paiementsSousTraitants.reduce((sum, p) => sum + (parseFloat(p.montant_ht) || 0), 0);
  const totalSousTraitantsTTC = paiementsSousTraitants.reduce((sum, p) => {
    const montantHT = parseFloat(p.montant_ht) || 0;
    const st = contratsSousTraitance.find(c => c.entreprise_sous_traitant_id === p.entreprise_id);
    const soumisATVA = st?.soumis_a_tva !== undefined ? st.soumis_a_tva : true;
    return sum + (soumisATVA ? montantHT * (1 + tauxTVA / 100) : montantHT);
  }, 0);
  const netAPayerEntreprise = netAPayer - totalSousTraitantsTTC;
  
  const partenairesList = chantier?.partenaires || [];
  const partenairesData = partenairesList
    .map(p => {
      const partenaire = partenaires?.find(part => part.id === p.partenaire_id);
      if (!partenaire) return null;
      return {
        nom: partenaire.nom,
        role: (p.role || '').toLowerCase()
      };
    })
    .filter(p => p !== null);
  
  const architecte = partenairesData.find(p => p.role.includes('architecte'));
  const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
  
  const formatPartenaireName = (name) => {
    if (!name) return "";
    return name.toLowerCase().replace(/(?:^|\s|\/)\S/g, (a) => a.toUpperCase());
  };

  const partenairesOrdonnes = [];
  if (architecte) {
    partenairesOrdonnes.push(formatPartenaireName(architecte.nom));
  }
  partenairesOrdonnes.push(formatPartenaireName(infoGestionbat?.nom_entreprise || 'Gestionbat'));
  autresPartenaires.forEach(p => partenairesOrdonnes.push(formatPartenaireName(p.nom)));
  
  const partenairesString = partenairesOrdonnes.join(" / ");
  const dateFormatee = format(new Date(), "dd/MM/yyyy", { locale: fr });
  
  const logoClient = (client?.logo_client_url || chantier?.logo_client_url)
    ? `<img src="${client?.logo_client_url || chantier?.logo_client_url}" alt="Logo" style="max-width: 150px; max-height: 80px; object-fit: contain;" />` 
    : '';
  
  const logoGestionbat = infoGestionbat?.logo_url 
    ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 100px; max-height: 50px; object-fit: contain;" />` 
    : '<p style="font-weight: bold; color: #666666; font-size: 10pt;">GESTIONBAT</p>';

  const historiquePenalites = [];
  
  situationsPrecedentes.forEach(cp => {
    const cpDateStr = cp.date_situation && new Date(cp.date_situation).toString() !== 'Invalid Date' 
      ? format(new Date(cp.date_situation), "dd/MM/yyyy", { locale: fr })
      : 'Date inconnue';
    
    if (cp.penalites_appliquees && cp.penalites_appliquees.length > 0) {
      cp.penalites_appliquees.forEach(p => {
        if (p.montant_calcule > 0) {
          historiquePenalites.push({
            source: `CP N°${cp.numero} (${cpDateStr})`,
            type: p.type_penalite,
            details: p.nombre && p.base ? `${p.nombre} ${p.base}` : '',
            montant: p.montant_calcule
          });
        }
      });
    }
    if (cp.remboursement_penalites && cp.remboursement_penalites > 0) {
      historiquePenalites.push({
        source: `CP N°${cp.numero} (${cpDateStr})`,
        type: "Remboursement pénalités",
        details: "-",
        montant: -cp.remboursement_penalites
      });
    }
  });

  if (cert.penalites_appliquees && cert.penalites_appliquees.length > 0) {
    cert.penalites_appliquees.forEach(p => {
      if (p.montant_calcule > 0) {
        historiquePenalites.push({
          source: `CP N°${cert.numero} (Actuel)`,
          type: p.type_penalite,
          details: p.nombre && p.base ? `${p.nombre} ${p.base}` : '',
          montant: p.montant_calcule
        });
      }
    });
  }
  
  const lignesSousTraitants = contratsSousTraitance.map((st, index) => {
    const stEntreprise = entreprises?.find(e => e.id === st.entreprise_sous_traitant_id);
    const montantHT = st.montant || 0;
    const soumisATVA = st.soumis_a_tva !== undefined ? st.soumis_a_tva : true;
    const montantTTC = soumisATVA ? montantHT * (1 + tauxTVA / 100) : montantHT;
    return `
      <tr>
        <td>${index + 1}</td>
        <td>${stEntreprise?.nom || 'Non spécifié'}</td>
        <td style="text-align: right;">${montantHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
    `;
  }).join('');
  
  const totalNetAPayerPrecedents = situationsPrecedentes.reduce((sum, cp) => {
    const cpTTC = (cp.montant_ht || 0) * (1 + tauxTVA / 100);
    const cpNet = cp.netAPayerCalc !== undefined ? cp.netAPayerCalc : cpTTC;
    return sum + cpNet;
  }, 0);

  const stPrevTTC = {};
  let totalSTPrevTTC = 0;
  
  situationsPrecedentes.forEach(cp => {
      if(cp.paiements_sous_traitants) {
          cp.paiements_sous_traitants.forEach(p => {
              const montantHT = parseFloat(p.montant_ht) || 0;
              const st = contratsSousTraitance.find(c => c.entreprise_sous_traitant_id === p.entreprise_id);
              const soumisATVA = st?.soumis_a_tva !== undefined ? st.soumis_a_tva : true;
              const m = soumisATVA ? montantHT * (1 + tauxTVA / 100) : montantHT;
              stPrevTTC[p.entreprise_id] = (stPrevTTC[p.entreprise_id] || 0) + m;
              totalSTPrevTTC += m;
          });
      }
  });

  const entNetPrev = totalNetAPayerPrecedents - totalSTPrevTTC;
  const entNetCumul = entNetPrev + netAPayerEntreprise;

  const cpTries = [...situationsPrecedentes].sort((a, b) => {
    const numA = parseInt(a.numero) || 0;
    const numB = parseInt(b.numero) || 0;
    return numA - numB;
  });
  
  const lignesCPPrecedents = cpTries.map((cp) => {
    const cpMontantAvecAcompte = (cp.montant_ht || 0) + (cp.demande_acompte || 0) - (cp.remboursement_acompte || 0);
    const cpTTC = cpMontantAvecAcompte * (1 + tauxTVA / 100);
    const cpNet = cp.netAPayerCalc !== undefined ? cp.netAPayerCalc : cpTTC;
    return `
      <tr>
        <td>CP N°${cp.numero} - ${MOIS_LABELS[cp.mois]} ${cp.annee}</td>
        <td style="text-align: right;">${cpMontantAvecAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${cpTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold;">${cpNet.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
    `;
  }).join('');
  
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Certificat de Paiement N° ${cert.numero}</title>
  <style>
    @page { margin: 0.8cm; size: A4; }
    body { 
      font-family: 'Calibri', Arial, sans-serif; 
      font-size: 7pt; 
      margin: 0; 
      padding: 6px;
      line-height: 1.15;
      color: #000;
    }
    .header-container { 
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 6px;
      page-break-after: avoid;
    }
    .header-logo-left, .header-logo-right { 
      width: 140px;
      text-align: center;
      vertical-align: middle;
    }
    .header-logo-left img, .header-logo-right img {
      max-width: 130px;
      max-height: 60px;
      object-fit: contain;
      display: block;
      margin: 0 auto;
    }
    .header-center {
      text-align: center;
      vertical-align: middle;
      padding: 0 10px;
    }
    .header-chantier-nom {
      font-size: 12pt;
      font-weight: bold;
      color: #f97316;
      text-transform: uppercase;
      margin-bottom: 1px;
    }
    .header-chantier-infos {
      font-size: 9pt;
      color: #000;
    }
    .doc-title-row {
      text-align: center;
      margin-bottom: 8px;
      padding-top: 6px;
      border-top: 2px solid #f97316;
      page-break-after: avoid;
    }
    .doc-title-row h1 {
      margin: 0;
      font-size: 12pt;
      font-weight: bold;
      color: #000;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .doc-title-row p {
      margin: 2px 0 0 0;
      font-size: 10pt;
      color: #000;
    }
    .section-title {
      font-size: 7.5pt;
      font-weight: bold;
      color: #f97316;
      margin: 5px 0 3px 0;
      padding-bottom: 2px;
      border-bottom: 1.5px solid #f97316;
      page-break-after: avoid;
    }
    .trois-colonnes {
      display: flex;
      gap: 5px;
      margin-bottom: 5px;
      page-break-inside: avoid;
    }
    .colonne {
      flex: 1;
      padding: 4px;
      background-color: #f9f9f9;
      border-radius: 3px;
      font-size: 6pt;
    }
    .colonne h3 {
      margin: 0 0 2px 0;
      font-size: 6.5pt;
      color: #f97316;
      border-bottom: 1px solid #ddd;
      padding-bottom: 1px;
    }
    .colonne p {
      margin: 1px 0;
      line-height: 1.25;
    }
    .lot-info {
      padding: 4px;
      background-color: #f9f9f9;
      border-radius: 3px;
      margin-bottom: 4px;
      font-size: 7pt;
      font-weight: bold;
      color: #000;
    }
    .deux-colonnes {
      display: flex;
      gap: 5px;
      margin: 4px 0;
      page-break-inside: avoid;
    }
    .deux-colonnes > div {
      flex: 1;
    }
    table { 
      width: 100%; 
      border-collapse: collapse; 
      margin: 3px 0;
      font-size: 6pt;
      page-break-inside: avoid;
    }
    th { 
      background-color: #666666; 
      color: white; 
      padding: 3px 3px; 
      text-align: left; 
      font-weight: bold; 
      border: 1px solid #555555; 
      font-size: 6pt;
    }
    td { 
      padding: 2.5px 3px; 
      border: 1px solid #ddd; 
      font-size: 6pt;
    }
    tr:nth-child(even) { 
      background-color: #f9f9f9; 
    }
    .header-container tr,
    .header-container tr:nth-child(even) {
      background-color: transparent !important;
    }
    .header-container td {
      border: none;
    }
    .total-row { 
      font-weight: bold; 
      background-color: #e5e5e5 !important; 
      border-top: 2px solid #666666;
      page-break-inside: avoid;
    }
    .total-row td { 
      padding: 3px; 
      font-size: 6.5pt; 
    }
    .deduction-row {
      background-color: #f9f9f9 !important;
    }
    .net-row {
      background-color: #fff3e0 !important;
      font-weight: bold;
      font-size: 7pt;
    }
    .info-line {
      margin: 3px 0;
      padding: 2px 5px;
      background-color: #f9f9f9;
      border-radius: 3px;
      font-size: 6pt;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .info-line.alert {
      background-color: #fff3cd;
      border: 1px solid #ffc107;
      color: #856404;
      font-weight: bold;
    }
    .checkbox {
      display: inline-block;
      width: 9px;
      height: 9px;
      border: 1px solid #333;
      margin-right: 3px;
      vertical-align: middle;
    }
    .checkbox.checked::after {
      content: "✓";
      display: block;
      text-align: center;
      line-height: 9px;
      font-weight: bold;
      font-size: 7pt;
    }
    .signatures {
      margin-top: 5px;
      display: flex;
      justify-content: space-between;
      gap: 5px;
      page-break-inside: avoid;
    }
    .signature-bloc {
      flex: 1;
      padding: 4px;
      background-color: #f9f9f9;
      border-radius: 3px;
      font-size: 6pt;
      min-height: 90px;
      display: flex;
      flex-direction: column;
    }
    .signature-bloc h3 {
      margin: 0 0 2px 0;
      font-size: 6.5pt;
      color: #f97316;
      border-bottom: 1px solid #ddd;
      padding-bottom: 2px;
      text-align: center;
    }
    .signature-bloc p {
      margin: 1px 0;
      line-height: 1.25;
      text-align: center;
      font-size: 6pt;
    }
    .signature-bloc p strong {
      font-size: 6.5pt;
    }
    .signature-space {
      flex: 1;
      margin-top: 6px;
      border-bottom: 1px solid #333;
      margin-bottom: 2px;
    }
    .commentaire-bloc {
      flex: 1;
      padding: 4px;
      background-color: #f9f9f9;
      border-radius: 3px;
      font-size: 6pt;
      min-height: 90px;
    }
    .commentaire-bloc h3 {
      margin: 0 0 2px 0;
      font-size: 6.5pt;
      color: #f97316;
      border-bottom: 1px solid #ddd;
    }
    .footer { 
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 40px;
      font-size: 7.5pt;
      color: #666;
      background: white;
    }
    .footer-line {
      border-top: 1px solid #ccc;
      margin: 0 0.8cm 4px 0.8cm;
    }
    .footer-content {
      position: relative;
      height: 32px;
      padding: 0 0.8cm;
    }
    .footer-left { 
      position: absolute;
      left: 0.8cm;
      top: 0;
      width: 40%;
      text-align: left;
      white-space: normal;
      line-height: 1.1;
    }
    .footer-center { 
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      text-align: center;
    }
    .footer-right { 
      position: absolute;
      right: 0.8cm;
      top: 0;
      text-align: right;
    }
    @media print {
      body { padding-bottom: 45px; }
      .footer {
        position: fixed;
        bottom: 0;
      }
    }
  </style>
</head>
<body>
  <table class="header-container">
    <tr>
      <td class="header-logo-left">${logoClient}</td>
      <td class="header-center">
        <div class="header-chantier-nom">${chantier?.nom || ''}</div>
        <div class="header-chantier-infos">
          ${chantier?.description ? chantier.description + '<br/>' : ''}
          ${chantier?.adresse || ''}${(chantier?.adresse && (chantier?.code_postal || chantier?.ville)) ? ' – ' : ''}${chantier?.code_postal || ''} ${chantier?.ville || ''}
        </div>
      </td>
      <td class="header-logo-right">${logoGestionbat}</td>
    </tr>
  </table>
  
  <div class="doc-title-row">
    <h1 style="font-size: 12pt; margin-bottom: 2px;">Certificat de paiement N° ${cert.numero}</h1>
    <p style="font-size: 10pt; margin-top: 0;">Situation du mois ${['Avril', 'Août', 'Octobre'].includes(MOIS_LABELS[cert.mois]) ? "d'" : "de "}${MOIS_LABELS[cert.mois].toLowerCase()} ${cert.annee}</p>
  </div>
  
  <div class="trois-colonnes">
    <div class="colonne">
      <h3>ENTREPRISE</h3>
      <p><strong>${entreprise?.nom || ''}</strong></p>
      ${entreprise?.adresse_1 ? `<p>${entreprise.adresse_1}</p>` : ''}
      ${entreprise?.code_postal || entreprise?.ville ? `<p>${entreprise?.code_postal || ''} ${entreprise?.ville || ''}</p>` : ''}
      ${entreprise?.siret ? `<p>SIRET: ${entreprise.siret}</p>` : ''}
    </div>
    <div class="colonne">
      <h3>MOE</h3>
      <p><strong>${infoGestionbat?.nom_entreprise || 'GESTIONBAT'}</strong></p>
      ${infoGestionbat?.adresse ? `<p>${infoGestionbat.adresse}</p>` : ''}
      ${infoGestionbat?.code_postal || infoGestionbat?.ville ? `<p>${infoGestionbat?.code_postal || ''} ${infoGestionbat?.ville || ''}</p>` : ''}
      ${infoGestionbat?.telephone ? `<p>Tél: ${infoGestionbat.telephone}</p>` : ''}
    </div>
    <div class="colonne">
      <h3>MAÎTRE D'OUVRAGE</h3>
      <p><strong>${client?.nom || ''}</strong></p>
      ${client?.adresse_1 ? `<p>${client.adresse_1}</p>` : ''}
      ${client?.code_postal || client?.ville ? `<p>${client?.code_postal || ''} ${client?.ville || ''}</p>` : ''}
      ${client?.siret ? `<p>SIRET: ${client.siret}</p>` : ''}
    </div>
  </div>

  <h2 class="section-title">Informations du Lot</h2>
  ${marche?.numero_lot && marche?.intitule_lot ? `
  <div class="lot-info">
    <strong>Lot:</strong> ${marche.numero_lot} - ${marche.intitule_lot}${marche.numero_marche ? ` • <strong>Marché N°:</strong> ${marche.numero_marche}` : ''}
  </div>
  ` : ''}

  <div class="deux-colonnes">
    <div>
      <table>
        <thead>
          <tr>
            <th style="width: 50%;">Désignation</th>
            <th style="width: 25%; text-align: right;">HT</th>
            <th style="width: 25%; text-align: right;">TTC</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="font-weight: 600;">Marché de base</td>
            <td style="text-align: right;">${montantMarcheBase.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
            <td style="text-align: right;">${montantMarcheBaseTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
          </tr>
          ${[...avenantsDeLEntreprise].sort((a, b) => parseInt(a.numero) - parseInt(b.numero)).map(av => `
            <tr>
              <td>Avenant N°${av.numero}</td>
              <td style="text-align: right;">${(av.montant_total_ht || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
              <td style="text-align: right;">${((av.montant_total_ht || 0) * (1 + tauxTVA / 100)).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
            </tr>
          `).join('')}
          <tr class="total-row">
            <td style="font-weight: bold;">NOUVEAU MARCHÉ</td>
            <td style="text-align: right;"><strong>${nouveauMontantMarcheHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
            <td style="text-align: right;"><strong>${nouveauMontantMarcheTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
          </tr>
          <tr>
            <td colspan="2" style="text-align: right; border: none; padding-top: 5px; font-size: 6pt;"><strong>Montant marché à cautionner TTC (5%) :</strong></td>
            <td style="text-align: right; border: none; font-weight: bold; color: #666666;">${montantACautionner.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
      <table>
        <thead>
          <tr>
            <th style="width: 10%;">N°</th>
            <th style="width: 45%;">Sous-traitant</th>
            <th style="width: 22%; text-align: right;">HT</th>
            <th style="width: 23%; text-align: right;">TTC</th>
          </tr>
        </thead>
        <tbody>
          ${lignesSousTraitants}
          <tr class="total-row">
            <td colspan="2"><strong>TOTAL ST</strong></td>
            <td style="text-align: right;"><strong>${totalContratsSousTraitants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
            <td style="text-align: right;"><strong>${totalContratsSousTraitantsTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="info-line">
    <div>
      <span class="checkbox ${marche?.a_caution ? 'checked' : ''}"></span> <strong>Marché cautionné : ${marche?.a_caution ? 'OUI' : 'NON'}</strong>
      ${marche?.a_caution && cautions.length > 0 ? `
      <div style="margin-left: 20px; font-size: 6pt;">
        ${cautions.map(c => {
          const dateAjout = c.date_ajout && new Date(c.date_ajout).toString() !== 'Invalid Date' 
            ? format(new Date(c.date_ajout), 'dd/MM/yyyy') 
            : 'N/A';
          return `<div>• Réf: ${c.reference || 'N/A'} - Montant: ${(c.montant || 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € TTC - Date: ${dateAjout}</div>`;
        }).join('')}
        <div style="font-weight: bold; margin-top: 2px;">Total Cautions: ${cautions.reduce((sum, c) => sum + (c.montant || 0), 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € TTC</div>
      </div>
      ` : ''}
    </div>
  </div>

  ${retenueCumuleeTotal > 0 ? `
  <div class="info-line alert">
    <span>⚠️ ${totalMontantCautions === 0 ? 'Marché non cautionné' : 'Caution insuffisante (< 5% TTC du cumul travaux)'} - Retenue de garantie 5% appliquée</span>
  </div>
  ` : ''}

  <h2 class="section-title">AVANCEMENT DES TRAVAUX - ${pourcentageAvancement}%</h2>
  <p style="font-size: 6pt; margin: 3px 0;"><strong>Facture n°</strong> ${cert.numero_facture || '__________'} <strong>du</strong> ${cert.date_facture && new Date(cert.date_facture).toString() !== 'Invalid Date' ? format(new Date(cert.date_facture), "dd/MM/yyyy", { locale: fr }) : '__________'}</p>
  
  <table>
    <thead>
      <tr>
        <th style="width: 40%;">Désignation</th>
        <th style="width: 20%; text-align: right;">Cumulés</th>
        <th style="width: 20%; text-align: right;">Précédents</th>
        <th style="width: 20%; text-align: right;">Situation</th>
      </tr>
    </thead>
    <tbody>
      ${hasTranches ? (() => {
        // Lignes par tranche : base + avenants
        const tranchesActuelles = cert.montants_par_tranche || [];
        let lignes = '';
        tranchesChantier.forEach(tranche => {
          const tAct = tranchesActuelles.find(t => t.tranche_numero === tranche.numero) || {};
          const baseAct = tAct.montant_ht_base || 0;
          const avAct = tAct.montant_ht_avenants || 0;
          const totalAct = baseAct + avAct;

          // Cumul précédents pour cette tranche
          const basePrev = situationsPrecedentes.reduce((s, c) => {
            const t = (c.montants_par_tranche || []).find(x => x.tranche_numero === tranche.numero);
            return s + (t?.montant_ht_base || 0);
          }, 0);
          const avPrev = situationsPrecedentes.reduce((s, c) => {
            const t = (c.montants_par_tranche || []).find(x => x.tranche_numero === tranche.numero);
            return s + (t?.montant_ht_avenants || 0);
          }, 0);
          const totalPrev = basePrev + avPrev;
          const totalCumul = totalPrev + totalAct;

          // Montant marché de base pour cette tranche
          const marcheTrancheBase = (marche?.tranches_montants || []).find(t => t.tranche_numero === tranche.numero)?.montant_ht || 0;

          lignes += `
          <tr>
            <td style="font-weight:600; padding-left:6px;">${tranche.libelle} (base)</td>
            <td style="text-align:right;">${fmt(basePrev + baseAct)}</td>
            <td style="text-align:right;">${fmt(basePrev)}</td>
            <td style="text-align:right; font-weight:bold;">${fmt(baseAct)}</td>
          </tr>`;
          if (avAct > 0 || avPrev > 0) {
            lignes += `
          <tr>
            <td style="padding-left:12px; font-style:italic; color:#555;">${tranche.libelle} (avenants)</td>
            <td style="text-align:right;">${fmt(avPrev + avAct)}</td>
            <td style="text-align:right;">${fmt(avPrev)}</td>
            <td style="text-align:right; font-weight:bold;">${fmt(avAct)}</td>
          </tr>`;
          }
        });
        lignes += `
        <tr style="background:#f0f4ff; font-weight:bold;">
          <td>TOTAL Travaux HT</td>
          <td style="text-align:right;">${fmt(montantCumuleTotalHTSansAcompte)}</td>
          <td style="text-align:right;">${fmt(montantCumulePrecedentHTSansAcompte)}</td>
          <td style="text-align:right; font-weight:bold;">${fmt(cert.montant_ht)}</td>
        </tr>`;
        return lignes;
      })() : `
      <tr>
        <td style="font-weight: 600;">Travaux HT</td>
        <td style="text-align: right;">${montantCumuleTotalHTSansAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${montantCumulePrecedentHTSansAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold;">${cert.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>`}
      ${demandeAcompte > 0 || demandeAcomptePrecedents > 0 ? `
      <tr class="deduction-row">
        <td style="font-weight: 600; color: #3b82f6;">Demande d'acompte</td>
        <td style="text-align: right; color: #3b82f6;">+ ${demandeAcompteCumul.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; color: #3b82f6;">+ ${demandeAcomptePrecedents.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold; color: #3b82f6;">+ ${demandeAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}
      ${remboursementAcompte > 0 || remboursementAcomptePrecedents > 0 ? `
      <tr class="deduction-row">
        <td style="font-weight: 600; color: #f97316;">Remboursement d'acompte</td>
        <td style="text-align: right; color: #f97316;">- ${remboursementAcompteCumul.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; color: #f97316;">- ${remboursementAcomptePrecedents.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">- ${remboursementAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}
      <tr>
        <td style="font-weight: 600;">TVA (${tauxTVA}%)</td>
        <td style="text-align: right;">${(montantCumuleTotalHT * tauxTVA / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${(montantCumulePrecedentHT * tauxTVA / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold;">${montantTVA.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      <tr class="total-row">
        <td style="font-weight: bold;">TOTAL TTC</td>
        <td style="text-align: right;"><strong>${montantCumuleTotalTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${montantCumulePrecedentTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
      </tr>

      <!-- Section DÉDUCTIONS -->
      ${(retenueCumuleeTotal > 0 || remboursementRetenue > 0 || certTotalPenalties > 0 || remboursementPenalites > 0 || montantCieSituation !== 0) ? `
      <tr>
        <td colspan="4" style="font-weight: bold; color: #666666; border-bottom: 1px solid #666666; padding-top: 8px; padding-bottom: 2px;">DÉDUCTIONS</td>
      </tr>
      ` : ''}

      <!-- Retenue de garantie -->
      ${retenueCumuleeTotal > 0 ? `
      <tr>
        <td style="font-size: 7pt; font-weight: 600; color: #ef4444;">Retenue de garantie (5%)</td>
        <td style="text-align: right; color: #ef4444;">${retenueCumuleeTotal.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; color: #ef4444;">${retenueCumuleePrecedents > 0 ? retenueCumuleePrecedents.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-'}</td>
        <td style="text-align: right; font-weight: bold; color: #ef4444;">${retenueSituation.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}

      <!-- Remboursement retenue de garantie - Version qui correspond à ton image -->
      ${(deblocageRGCumul > 0 || remboursementRetenue > 0) ? `
      <tr class="deduction-row">
        <td style="font-weight: 600; color: #10b981;">Remboursement retenue de garantie</td>
        <td style="text-align: right; color: #10b981;">- ${deblocageRGCumul.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; color: #10b981;">${deblocageRGPrec > 0 ? '- ' + deblocageRGPrec.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-'}</td>
        <td style="text-align: right; font-weight: bold; color: #10b981;">- ${remboursementRetenue.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}

      ${remboursementPenalites > 0 ? `
      <tr class="deduction-row">
        <td style="font-weight: 600; color: #f97316;">Remboursement Pénalités</td>
        <td style="text-align: center;">-</td>
        <td style="text-align: center;">-</td>
        <td style="text-align: right; color: #f97316;">+ ${remboursementPenalites.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}

      ${(certTotalPenalties > 0 || penalitesPrecedentes > 0) ? `
      <tr>
        <td style="font-size: 7pt;">Pénalités et retenues diverses TTC</td>
        <td style="text-align: right;">${totalPenaltiesCumuleesTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${penalitesPrecedentesTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${certTotalPenaltiesTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      <tr class="deduction-row">
        <td style="font-size: 6pt; font-style: italic; padding-left: 16px; color: #888;">dont TVA (20%)</td>
        <td style="text-align: right; font-size: 6pt; color: #888;">${(totalPenaltiesCumulees - totalPenaltiesCumulees / 1.2).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-size: 6pt; color: #888;">${(penalitesPrecedentes - penalitesPrecedentes / 1.2).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-size: 6pt; color: #888;">${certTotalPenaltiesTVA.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ` : ''}

      ${(montantCieCumul !== 0 || montantCieSituation !== 0) ? `
      <tr class="deduction-row">
        <td style="font-weight: 600; ${montantCieSituation > 0 ? 'color: #f97316;' : ''}">Compte Inter-Entreprises (C.I.E)</td>
        <td style="text-align: right;">${montantCieCumul !== 0 ? (montantCieCumul > 0 ? '+ ' : '- ') + Math.abs(montantCieCumul).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-'}</td>
        <td style="text-align: right;">${montantCiePrecedent !== 0 ? (montantCiePrecedent > 0 ? '+ ' : '- ') + Math.abs(montantCiePrecedent).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-'}</td>
        <td style="text-align: right; ${montantCieSituation > 0 ? 'color: #f97316;' : ''}">${montantCieSituation !== 0 ? (montantCieSituation > 0 ? '+ ' : '- ') + Math.abs(montantCieSituation).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €' : '-'}</td>
      </tr>
      ` : ''}

      <tr class="net-row">
        <td style="font-weight: bold; color: #f97316;">NET À PAYER</td>
        <td style="text-align: center;">-</td>
        <td style="text-align: center;">-</td>
        <td style="text-align: right; font-weight: bold; font-size: 9pt; color: #f97316;">${netAPayer.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
    </tbody>
  </table>

  ${(paiementsSousTraitants.length > 0 || contratsSousTraitance.length > 0) ? `
  <h3 style="font-size: 7pt; font-weight: bold; margin: 6px 0 3px 0;">Répartition du Net à Payer</h3>
  <table>
    <thead>
      <tr>
        <th style="width: 40%;">Bénéficiaire</th>
        <th style="width: 20%; text-align: right;">Cumul TTC</th>
        <th style="width: 20%; text-align: right;">Précédent TTC</th>
        <th style="width: 20%; text-align: right;">Situation TTC</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>${entreprise?.nom || ''}</strong> (Entreprise principale)</td>
        <td style="text-align: right; font-weight: 600;">${entNetCumul.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${entNetPrev.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: 600;">${netAPayerEntreprise.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ${contratsSousTraitance.map((st) => {
        const stId = st.entreprise_sous_traitant_id;
        const stEntreprise = entreprises?.find(e => e.id === stId);
        const soumisATVA = st.soumis_a_tva !== undefined ? st.soumis_a_tva : true;
        
        const currentPaiement = paiementsSousTraitants.find(p => p.entreprise_id === stId);
        const currentHT = parseFloat(currentPaiement?.montant_ht) || 0;
        const currentTTC = soumisATVA ? currentHT * (1 + tauxTVA / 100) : currentHT;
        
        const prevTTC = stPrevTTC[stId] || 0;
        const cumulTTC = prevTTC + currentTTC;
        
        if (cumulTTC === 0 && currentTTC === 0 && prevTTC === 0) return '';

        return `
          <tr>
            <td>${stEntreprise?.nom || 'Non spécifié'} (Sous-traitant)${!soumisATVA ? ' (HT)' : ''}</td>
            <td style="text-align: right;">${cumulTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
            <td style="text-align: right;">${prevTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
            <td style="text-align: right; font-weight: 600;">${currentTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
          </tr>
        `;
      }).join('')}
      <tr class="total-row">
        <td style="font-weight: bold;">TOTAL NET À PAYER</td>
        <td style="text-align: right; font-weight: bold;">${(entNetCumul + totalSTPrevTTC + totalSousTraitantsTTC).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold;">${totalNetAPayerPrecedents.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold;">${netAPayer.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
    </tbody>
  </table>
  ` : ''}

  <h2 class="section-title">Récapitulatif Cumulé</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 40%;">Certificats</th>
        <th style="width: 20%; text-align: right;">Montant HT</th>
        <th style="width: 20%; text-align: right;">Montant TTC</th>
        <th style="width: 20%; text-align: right;">Net à Payer</th>
      </tr>
    </thead>
    <tbody>
      ${situationsPrecedentes.length > 0 ? `
        ${lignesCPPrecedents}
        <tr class="total-row">
          <td style="font-weight: bold;">Total CP précédents</td>
          <td style="text-align: right;"><strong>${montantCumulePrecedentHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
          <td style="text-align: right;"><strong>${montantCumulePrecedentTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
          <td style="text-align: right;"><strong>${totalNetAPayerPrecedents.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        </tr>
      ` : ''}
      <tr style="background-color: #fff3e0;">
        <td style="font-weight: bold; color: #f97316;">Situation en cours (CP N°${cert.numero})</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">${montantAvecAcompte.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">${netAPayer.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      <tr class="total-row">
        <td style="font-weight: bold;">TOTAL CUMULÉ</td>
        <td style="text-align: right;"><strong>${montantCumuleTotalHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${montantCumuleTotalTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${(totalNetAPayerPrecedents + netAPayer).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
      </tr>
    </tbody>
  </table>
  <table>
    <thead>
      <tr>
        <th style="width: 50%;">Désignation</th>
        <th style="width: 25%; text-align: right;">Montant HT</th>
        <th style="width: 25%; text-align: right;">Montant TTC</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="font-weight: 600; color: #f97316;">Reste à payer</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">${resteAPayerHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: bold; color: #f97316;">${resteAPayerTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
    </tbody>
  </table>

  <h3 style="font-size: 7pt; font-weight: bold; margin: 6px 0 3px 0; border-bottom: 1px solid #666666; padding-bottom: 2px;">OBSERVATIONS / DÉTAIL PÉNALITÉS</h3>
  <div style="border: 1px solid #ddd; padding: 4px; min-height: 40px; font-size: 6pt; background-color: #fcfcfc; margin-bottom: 8px;">
    ${historiquePenalites.length > 0 ? `
      <table style="margin: 0; width: 100%;">
        <thead>
          <tr>
            <th style="padding: 2px; font-size: 6pt; background-color: #eee; color: #333; border: 1px solid #ccc;">Date / CP</th>
            <th style="padding: 2px; font-size: 6pt; background-color: #eee; color: #333; border: 1px solid #ccc;">Motif / Type</th>
            <th style="padding: 2px; font-size: 6pt; background-color: #eee; color: #333; border: 1px solid #ccc;">Détails (Jours/Base)</th>
            <th style="padding: 2px; text-align: right; background-color: #eee; color: #333; border: 1px solid #ccc;">Montant</th>
          </tr>
        </thead>
        <tbody>
          ${historiquePenalites.map(p => `
            <tr>
              <td style="padding: 2px; border: 1px solid #eee;">${p.source}</td>
              <td style="padding: 2px; border: 1px solid #eee;">${p.type}</td>
              <td style="padding: 2px; border: 1px solid #eee;">${p.details || '-'}</td>
              <td style="padding: 2px; text-align: right; border: 1px solid #eee;">${p.montant.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p style="font-style: italic; color: #999; margin: 0;">Aucune pénalité appliquée à ce jour.</p>'}
    ${remboursementPenalites > 0 ? `<p style="margin-top: 4px; color: #f97316;"><strong>Remboursement pénalités :</strong> ${remboursementPenalites.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>` : ''}
    
    ${cert.details_cie && cert.details_cie.length > 0 ? `
      <div style="margin-top: 6px; border-top: 1px dashed #ccc; padding-top: 4px;">
        <strong style="color: #333;">Détail C.I.E :</strong>
        <ul style="margin: 2px 0; padding-left: 15px; list-style-type: disc;">
          ${cert.details_cie.map(d => `
            <li>
              ${d.description} : <span style="${d.type === 'credit' ? 'color: #f97316;' : ''}">${d.type === 'credit' ? '+' : '-'} ${Math.abs(d.montant).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</span>
            </li>
          `).join('')}
        </ul>
      </div>
    ` : ''}

    ${(() => {
      const notesHisto = [...situationsPrecedentes]
        .sort((a, b) => (parseInt(a.numero) || 0) - (parseInt(b.numero) || 0))
        .filter(c => c.notes && c.notes.trim() !== '');
      if (notesHisto.length === 0 && !cert.notes) return '';
      let html = '<div style="margin-top: 6px; border-top: 1px dashed #ccc; padding-top: 4px;">';
      html += '<strong>Historique des notes :</strong>';
      notesHisto.forEach(c => {
        const moisLabel = {"01":"Janv.","02":"Févr.","03":"Mars","04":"Avr.","05":"Mai","06":"Juin","07":"Juil.","08":"Août","09":"Sept.","10":"Oct.","11":"Nov.","12":"Déc."}[c.mois] || c.mois;
        html += `<p style="margin-top: 3px; padding: 2px 4px; background: #f5f5f5; border-left: 2px solid #f97316;"><strong>CP N°${c.numero} (${moisLabel} ${c.annee}) :</strong> ${c.notes}</p>`;
      });
      if (cert.notes) {
        html += `<p style="margin-top: 3px; padding: 2px 4px; background: #fff3e0; border-left: 2px solid #f97316;"><strong>CP N°${cert.numero} (en cours) :</strong> ${cert.notes}</p>`;
      }
      html += '</div>';
      return html;
    })()}
  </div>

  <div class="signatures">
    <div class="signature-bloc">
      <h3>Pour la MOE</h3>
      <p><strong>${infoGestionbat?.nom_entreprise || 'GESTIONBAT'}</strong></p>
      <div class="signature-space" style="display: flex; align-items: center; justify-content: center;">
        <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690322d4278b9ec835ac6014/02d68ee08_Capture_d_cran_2020-11-24_085247-removebg-preview.png" alt="Signature MOE" style="max-width: 150px; max-height: 80px; object-fit: contain;" />
      </div>
      <p style="font-style: italic; color: #666;">Signature et cachet</p>
    </div>
    <div class="signature-bloc">
      <h3>Pour le Maître d'Ouvrage</h3>
      <p><strong>${client?.nom || ''}</strong></p>
      <div class="signature-space"></div>
      <p style="font-style: italic; color: #666;">Signature et cachet</p>
    </div>
    <div class="commentaire-bloc">
      <h3>Commentaires de la MOA</h3>
      <div style="min-height: 50px; padding: 2px; border: 1px dashed #ddd; border-radius: 2px; margin-top: 2px;"></div>
    </div>
  </div>

  <div class="footer">
    <div class="footer-line"></div>
    <div class="footer-content">
      <div class="footer-left">${partenairesString}</div>
      <div class="footer-center">Page 1</div>
      <div class="footer-right">${dateFormatee}</div>
    </div>
  </div>
</body>
</html>`;
}