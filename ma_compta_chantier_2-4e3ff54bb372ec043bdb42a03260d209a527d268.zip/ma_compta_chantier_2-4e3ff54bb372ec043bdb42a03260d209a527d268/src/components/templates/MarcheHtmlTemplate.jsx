// Trame d'Acte d'Engagement HTML utilisée quand il n'y a pas de modèle client
// Cette trame est figée et sert de fallback pour la génération PDF
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export const getMarcheHtmlTemplate = ({
  marche,
  chantier,
  client,
  entreprise,
  montantHT,
  montantTVA,
  montantTTC,
  tauxTVA,
  logoClient,
  partenairesString,
  dateFormatee
}) => {
  const formatPartenaireName = (name) => {
    if (!name) return "";
    return name.toLowerCase().replace(/(?:^|\s|\/)\S/g, (a) => a.toUpperCase());
  };
  
  const partenairesFormatted = formatPartenaireName(partenairesString);

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acte d'Engagement - ${marche.intitule_lot}</title>
  <style>
    @page {
      size: A4;
      margin: 2cm 2cm 2.5cm 2cm;
    }
    
    body {
      font-family: 'Calibri', Arial, sans-serif;
      font-size: 11pt;
      line-height: 1.3;
      margin: 0;
      padding: 0;
      color: #000;
    }
    
    .page {
      width: 21cm;
      min-height: 29.7cm;
      padding: 1.5cm 2cm;
      margin: 0 auto;
      background: white;
      position: relative;
      padding-bottom: 3cm; /* Ensure space for footer */
    }
    
    .header-container { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      margin-bottom: 10px;
      page-break-after: avoid;
    }
    .header-logo-left, .header-logo-right { 
      flex: 0 0 150px;
      width: 150px;
      text-align: center;
    }
    .header-logo-left img, .header-logo-right img {
      max-width: 150px;
      max-height: 70px;
      object-fit: contain;
    }
    .header-center {
      flex: 1;
      text-align: center;
      padding: 0 10px;
    }
    .header-chantier-nom {
      font-size: 14pt;
      font-weight: bold;
      color: #f97316;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .header-chantier-infos {
      font-size: 10pt;
      color: #000;
    }
    .doc-title-row {
      text-align: center;
      margin-bottom: 20px;
      padding-top: 15px;
      border-top: 2px solid #f97316;
      page-break-after: avoid;
    }
    .doc-title-row h1 {
      margin: 0;
      font-size: 16pt;
      font-weight: bold;
      color: #000;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .doc-title-row p {
      margin: 5px 0 0 0;
      font-size: 11pt;
      color: #000;
    }
    .footer { 
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 50px;
      font-size: 8pt;
      color: #666;
      background: white;
    }
    .footer-line {
      border-top: 1px solid #ccc;
      margin: 0 1cm 5px 1cm;
    }
    .footer-content {
      position: relative;
      height: 40px;
      padding: 0 1cm;
    }
    .footer-left { 
      position: absolute;
      left: 1cm;
      top: 0;
      width: 40%;
      text-align: left;
      white-space: normal;
      line-height: 1.1;
    }
    .footer-center { 
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      text-align: center;
    }
    .footer-right { 
      position: absolute;
      right: 1cm;
      top: 0;
      text-align: right;
    }
    
    .info-section {
      display: table;
      width: 100%;
      margin-bottom: 1.5cm;
      font-size: 10pt;
    }
    
    .info-left {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      padding-right: 1cm;
    }
    
    .info-right {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      text-align: left;
    }
    
    .info-label {
      font-weight: bold;
      display: inline;
    }
    
    h2 {
      font-size: 11pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 1.2cm 0 0.3cm 0;
    }
    
    p {
      margin: 0.3cm 0;
      text-align: justify;
    }
    
    .indent {
      margin-left: 0.5cm;
    }
    
    .signatures {
      margin-top: 2cm;
    }
    
    .signatures-row {
      display: table;
      width: 100%;
      margin-top: 1cm;
    }
    
    .signature-cell {
      display: table-cell;
      width: 33%;
      vertical-align: top;
      text-align: center;
    }
    
    .annexes {
      margin-top: 1.5cm;
    }
    
    .page-number {
      position: absolute;
      bottom: 1.5cm;
      left: 0;
      right: 0;
      text-align: center;
      font-size: 10pt;
    }
    
    ul {
      margin: 0.3cm 0;
      padding-left: 1cm;
    }
    
    li {
      margin: 0.2cm 0;
    }
    
    @media print {
      .page {
        margin: 0;
        page-break-after: always;
      }
      body {
        margin: 0;
      }
    }
  </style>
</head>
<body>
  <div class="page">
    <div class="header-container">
      <div class="header-logo-left">${logoClient}</div>
      <div class="header-center">
        <div class="header-chantier-nom">${chantier?.nom || ''}</div>
        <div class="header-chantier-infos">
          ${chantier?.description ? chantier.description + '<br/>' : ''}
          ${[chantier?.adresse, [chantier?.code_postal, chantier?.ville].filter(Boolean).join(' ')].filter(Boolean).join(' – ')}
        </div>
      </div>
      <div class="header-logo-right"><!-- GESTIONBAT logo placeholder or text -->GESTIONBAT</div>
    </div>
    
    <div class="doc-title-row">
      <h1>ACTE D'ENGAGEMENT</h1>
    </div>
    
    <div class="info-section">
      <div class="info-left">
        <p><span class="info-label">Maître d'ouvrage :</span></p>
        <p><strong>${client?.nom || ''}</strong><br/>
        ${client?.adresse_1 || ''}<br/>
        ${client?.code_postal || ''} ${client?.ville || ''}</p>
      </div>
      <div class="info-right">
        <p><span class="info-label">Entreprise :</span> ${entreprise?.nom || ''}<br/>
        <span class="info-label">Siret :</span> ${entreprise?.siret || ''}<br/>
        <span class="info-label">Lot :</span> ${marche.numero_lot || ''} – ${marche.intitule_lot}</p>
        <p><span class="info-label">Montant :</span> ${montantHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT<br/>
        <span class="info-label">Valeur :</span> ferme et non révisable</p>
      </div>
    </div>

    <h2>ARTICLE I – PARTIES CONTRACTANTES</h2>
    <p>Il est passé un marché de travaux pour ${chantier?.nom || 'le projet'} – ${[chantier?.adresse, [chantier?.code_postal, chantier?.ville].filter(Boolean).join(' ')].filter(Boolean).join(', ')}</p>
    
    <p>Dans les articles ci-après, entre</p>
    
    <p>D'une part de :</p>
    <p class="indent">. <strong>${client?.nom || ''}</strong> – ${client?.adresse_1 || ''} ${client?.code_postal || ''} ${client?.ville || ''}, (${client?.siret ? 'SIRET ' + client.siret : ''}), désignée dans les documents du marché sous la dénomination : « le Maître de l'Ouvrage ».</p>
    
    <p>D'autre part</p>
    <p class="indent">. L'entreprise <strong>${entreprise?.nom || ''}</strong> – ${entreprise?.adresse_1 || ''} ${entreprise?.code_postal || ''} ${entreprise?.ville || ''}, représentée par ${entreprise?.representant_civilite || ''} ${entreprise?.representant_nom || ''} ${entreprise?.representant_prenom || ''} en qualité de ${entreprise?.representant_qualite || ''}, et désignée dans les documents du marché sous la dénomination : « L'entreprise ».</p>

    <h2>ARTICLE II – OBJET DU MARCHÉ</h2>
    <p>Le présent marché a pour objet l'exécution du lot n° ${marche.numero_lot || ''} – ${marche.intitule_lot}.</p>
    <p>L'entreprise s'engage à réaliser les travaux dont la consistance est définie dans les documents contractuels.</p>
    <p>Les pièces constitutives du marché qui définissent l'ensemble des obligations de l'Entreprise sont énumérées à l'article 4.2 du CCAP.</p>
    
    <h2>ARTICLE III – COMMENCEMENT DES TRAVAUX ET DÉLAI DE RÉALISATION</h2>
    <p>Le présent Acte d'Engagement vaut Ordre de service n°1.</p>
    <p>Le délai d'exécution des travaux compris intempéries décrites au CCAP et périodes de congés payés, est fixé par le planning contractuel${chantier?.date_debut && chantier?.date_fin_prevue ? ', soit pour :' : '.'}</p>
    ${chantier?.date_debut && chantier?.date_fin_prevue ? `
    <p class="indent">- un début le : ${format(new Date(chantier.date_debut), "dd MMMM yyyy", { locale: fr })}<br/>
    - une fin le : ${format(new Date(chantier.date_fin_prevue), "dd MMMM yyyy", { locale: fr })}</p>
    ` : ''}

    <h2>ARTICLE IV – PÉNALITÉS DE RETARD DANS L'EXÉCUTION</h2>
    <p>Conformément à l'article 9.5 du CCAP</p>

    <div class="footer">
      <div class="footer-line"></div>
      <div class="footer-content">
        <div class="footer-left">${partenairesFormatted}</div>
        <div class="footer-center">Page 1 sur 2</div>
        <div class="footer-right">${dateFormatee}</div>
      </div>
    </div>
  </div>

  <div class="page">
    <div class="header-container">
      <div class="header-logo-left">${logoClient}</div>
      <div class="header-center">
        <div class="header-chantier-nom">${chantier?.nom || ''}</div>
        <div class="header-chantier-infos">
          ${chantier?.description ? chantier.description + '<br/>' : ''}
          ${[chantier?.adresse, [chantier?.code_postal, chantier?.ville].filter(Boolean).join(' ')].filter(Boolean).join(' – ')}
        </div>
      </div>
      <div class="header-logo-right">GESTIONBAT</div>
    </div>
    
    <div class="doc-title-row">
      <h1>ACTE D'ENGAGEMENT (Suite)</h1>
    </div>

    <h2>ARTICLE V – PRIX DU MARCHÉ</h2>
    <p>L'entrepreneur, après avoir pris connaissance de toutes les pièces contractuelles, s'engage envers le Maître de l'Ouvrage à exécuter les travaux moyennant un prix global et forfaitaire de :</p>
    
    <p class="indent">- Montant hors TVA : ${montantHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €<br/>
    - TVA au taux de ${tauxTVA}% = ${montantTVA.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €<br/>
    - Montant TTC = ${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>

    <h2>ARTICLE VI – MODALITÉS DE RÈGLEMENT DE TRAVAUX</h2>
    <p>Le maître de l'ouvrage s'engage à effectuer les paiements conformément aux prescriptions du CCAP sur présentation de l'état d'avancement à 45 jours fin de mois.</p>
    <p>Le prix est ferme et non révisable</p>

    <h2>ARTICLE VII – RETENUE DE GARANTIE</h2>
    <p>Conformément à l'article 20.5 du CCAP</p>

    <h2>ARTICLE VIII – CLAUSES ADMINISTRATIVES ET DIVERSES COMPLÉMENTAIRES OU MODIFICATIVES</h2>
    <p>Les prestations faisant l'objet de la présente commande sont celles :</p>
    <ul style="list-style-type: none; padding-left: 1cm;">
      <li>- du Cahier des Charges Techniques Particulières « marchés signés »</li>
      <li>- les plans techniques</li>
      <li>- les plans contractuels « Architecte »</li>
    </ul>

    <div class="signatures">
      <p>Fait en 3 exemplaires</p>
      <p>A ${client?.ville || 'NANTES'}, le ${dateFormatee} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; le</p>
      
      <div class="signatures-row">
        <div class="signature-cell">
          <p>Signature et mention manuscrite<br/>« Lu et Approuvé »</p>
          <p style="margin-top: 3cm;"><strong>L'entreprise</strong></p>
        </div>
        <div class="signature-cell">
          <p>Signature et mention manuscrite<br/>« Bon pour valoir Marché »</p>
          <p style="margin-top: 3cm;"><strong>Le Maître de l'Ouvrage</strong></p>
        </div>
        <div class="signature-cell">
          <p>Vu le Maître d'œuvre</p>
          <p>Le</p>
        </div>
      </div>
    </div>

    <div class="annexes">
      <p><strong>Annexés à la présente :</strong></p>
      <ul style="list-style-type: none; padding-left: 1cm;">
        <li>- DPGF de l'entreprise</li>
        <li>- attestation d'assurance de l'entreprise</li>
      </ul>
    </div>

    <div class="footer">
      <div class="footer-line"></div>
      <div class="footer-content">
        <div class="footer-left">${partenairesFormatted}</div>
        <div class="footer-center">Page 2 sur 2</div>
        <div class="footer-right">${dateFormatee}</div>
      </div>
    </div>
  </div>
</body>
</html>`;
};