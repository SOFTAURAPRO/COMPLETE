export const getFicheEntrepriseHtml = (entreprise, logoGestionbat) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Fiche Entreprise - ${entreprise.nom}</title>
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; color: #333; padding: 20px; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #f97316; padding-bottom: 10px; margin-bottom: 20px; }
        .title { font-size: 18pt; font-weight: bold; color: #f97316; }
        .ref { font-size: 12pt; color: #666; }
        .section { margin-bottom: 20px; }
        .section-title { font-size: 12pt; font-weight: bold; background: #fff3e0; padding: 5px; border-left: 4px solid #f97316; margin-bottom: 10px; }
        .row { display: flex; margin-bottom: 5px; }
        .label { font-weight: bold; width: 150px; }
        .value { flex: 1; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #f97316; color: white; padding: 5px; text-align: left; }
        td { border: 1px solid #ddd; padding: 5px; }
        .logo { max-height: 50px; }
      </style>
    </head>
    <body>
      <div class="header">
        <div>
          <div class="title">${entreprise.nom}</div>
          <div class="ref">Réf: ${entreprise.reference || 'Non défini'}</div>
        </div>
        <div>${logoGestionbat || ''}</div>
      </div>

      <div class="section">
        <div class="section-title">Informations Générales</div>
        <div class="row"><span class="label">Forme Juridique:</span><span class="value">${entreprise.forme_juridique || '-'}</span></div>
        <div class="row"><span class="label">SIRET:</span><span class="value">${entreprise.siret || '-'}</span></div>
        <div class="row"><span class="label">Téléphone:</span><span class="value">${entreprise.telephone || '-'}</span></div>
        <div class="row"><span class="label">Adresse:</span><span class="value">${entreprise.adresse_1 || ''} ${entreprise.adresse_2 || ''} ${entreprise.code_postal || ''} ${entreprise.ville || ''}</span></div>
      </div>

      <div class="section">
        <div class="section-title">Représentant Légal</div>
        <div class="row"><span class="label">Nom:</span><span class="value">${entreprise.representant_civilite || ''} ${entreprise.representant_prenom || ''} ${entreprise.representant_nom || ''}</span></div>
        <div class="row"><span class="label">Qualité:</span><span class="value">${entreprise.representant_qualite || '-'}</span></div>
      </div>

      <div class="section">
        <div class="section-title">Corps d'état</div>
        <div class="value">${entreprise.corps_etat?.join(', ') || 'Aucun'}</div>
      </div>

      <div class="section">
        <div class="section-title">Interlocuteurs</div>
        <table>
          <thead>
            <tr>
              <th style="width: 20%">Service</th>
              <th style="width: 30%">Contact</th>
              <th style="width: 25%">Fonction</th>
              <th style="width: 25%">Email</th>
            </tr>
          </thead>
          <tbody>
            ${(() => {
              const services = ["Direction", "Travaux", "Etudes", "Administratif", "Comptabilité", "Appel d'offres", "Signataire doc marchés", "Autre"];
              return services.map(service => {
                const serviceContacts = (entreprise.contacts || []).filter(c => c.service === service);
                if (serviceContacts.length === 0) {
                   return `<tr>
                     <td><strong>${service}</strong></td>
                     <td style="color: #999; font-style: italic;">-</td>
                     <td>-</td>
                     <td>-</td>
                   </tr>`;
                }
                return serviceContacts.map(c => `
                  <tr>
                    <td><strong>${service}</strong></td>
                    <td>
                      <div style="font-weight:bold;">${c.civilite || ''} ${c.prenom || ''} ${c.nom || ''}</div>
                      <div style="font-size: 0.9em; color: #666; margin-top:2px;">${[c.telephone, c.portable].filter(Boolean).join(' / ')}</div>
                    </td>
                    <td>${c.fonction || '-'}</td>
                    <td>${c.email || '-'}</td>
                  </tr>
                `).join('');
              }).join('');
            })()}
          </tbody>
        </table>
      </div>
    </body>
    </html>
  `;
};