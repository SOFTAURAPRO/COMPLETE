/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export function generatePdfHtml({
  title,
  subtitle,
  chantier,
  client,
  infoGestionbat,
  partenaires,
  tableContentHtml,
  orientation = "landscape", // 'landscape' or 'portrait'
  withPageNumbers = false,
  customFooterDate = null
}) {
  const dateFormatee = customFooterDate || format(new Date(), "dd/MM/yyyy", { locale: fr });

  const logoClient = (client?.logo_client_url || chantier?.logo_client_url)
    ? `<img src="${client?.logo_client_url || chantier?.logo_client_url}" alt="Logo Client" style="max-width: 150px; max-height: 70px; object-fit: contain;" />` 
    : `<p style="font-weight: bold; color: #1e40af; font-size: 12pt;">${client?.nom || 'CLIENT'}</p>`;

  const logoGestionbat = infoGestionbat?.logo_url 
    ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 100px; max-height: 50px; object-fit: contain;" />` 
    : '<p style="font-weight: bold; color: #f97316; font-size: 10pt;">GESTIONBAT</p>';

  // Helper pour formater les noms des partenaires (Minuscule avec Première Lettre Majuscule)
  const formatPartenaireName = (name) => {
    if (!name) return "";
    return name.toLowerCase().replace(/(?:^|\s|\/)\S/g, (a) => a.toUpperCase());
  };

  // Partenaires pour footer
  const partenairesList = chantier?.partenaires || [];
  const partenairesData = partenairesList
    .map(p => {
      const partenaire = partenaires?.find(part => part.id === p.partenaire_id);
      if (!partenaire) return null;
      return {
        nom: partenaire.nom,
        role: (p.role || '').toLowerCase()
      };
    })
    .filter(p => p !== null);
  
  const architecte = partenairesData.find(p => p.role.includes('architecte'));
  const autresPartenaires = partenairesData.filter(p => !p.role.includes('architecte'));
  
  const partenairesOrdonnes = [];
  if (architecte) {
    partenairesOrdonnes.push(formatPartenaireName(architecte.nom));
  }
  partenairesOrdonnes.push(formatPartenaireName(infoGestionbat?.nom_entreprise || 'Gestionbat'));
  autresPartenaires.forEach(p => partenairesOrdonnes.push(formatPartenaireName(p.nom)));
  
  const partenairesString = partenairesOrdonnes.join(" / ");

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${title}</title>
  <style>
    @page { 
      size: A4 ${orientation}; 
      margin: 1.2cm 1cm 1.2cm 1cm; 
    }
    body { 
      font-family: 'Calibri', Arial, sans-serif; 
      font-size: 9pt; 
      margin: 0; 
      padding: 10px;
      color: #000;
    }
    .header-container { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      margin-bottom: 20px;
      padding-bottom: 10px;
    }
    .header-logo-left, .header-logo-right { 
      flex: 0 0 150px;
      width: 150px;
      text-align: center;
    }
    .header-center {
      flex: 1;
      text-align: center;
      padding: 0 10px;
    }
    .header-chantier-nom {
      font-size: 14pt;
      font-weight: bold;
      color: #f97316;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .header-chantier-infos {
      font-size: 10pt;
      color: #000;
    }
    
    .doc-title-row {
      text-align: center;
      margin-bottom: 20px;
      padding-top: 15px;
      border-top: 2px solid #f97316;
    }
    .doc-title-row h1 {
      margin: 0;
      font-size: 16pt;
      font-weight: bold;
      color: #000;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .doc-title-row p {
      margin: 5px 0 0 0;
      font-size: 11pt;
      color: #000;
    }
    
    table { 
      width: 100%; 
      border-collapse: collapse; 
      margin: 15px 0;
      font-size: 8pt;
    }
    th { 
      background-color: #666666; 
      color: white; 
      padding: 8px 5px; 
      text-align: left; 
      font-weight: bold; 
      border: 1px solid #555555;
    }
    td { 
      padding: 6px 5px; 
      border: 1px solid #ddd; 
    }
    tr:nth-child(even) { 
      background-color: #f9f9f9; 
    }
    
    tbody tr { 
      page-break-inside: avoid;
      page-break-after: auto;
    }
    tbody tr.enterprise-row {
      page-break-inside: avoid;
    }
    tbody tr.total-row {
      page-break-before: auto;
      page-break-inside: avoid;
      page-break-after: avoid;
    }
    
    @media print {
      body {
        padding-bottom: 60px;
      }
    }
    
    .footer { 
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 35px;
      font-size: 7pt;
      color: #666;
      background: white;
      z-index: 10;
    }
    .footer-line {
      border-top: 1px solid #ccc;
      margin: 0 1cm 3px 1cm;
    }
    .footer-content {
      position: relative;
      height: 28px;
      padding: 0 1cm;
    }
    .footer-left { 
      position: absolute;
      left: 1cm;
      top: 0;
      width: 40%;
      text-align: left;
      white-space: normal;
      line-height: 1.1;
    }
    .footer-center { 
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      text-align: center;
    }
    .pageNumber:after { content: counter(page); }
    .totalPages:after { content: counter(pages); }
    .footer-right { 
      position: absolute;
      right: 1cm;
      top: 0;
      text-align: right;
    }
    
    /* Utility classes for content injection */
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .font-bold { font-weight: bold; }
    .text-orange { color: #f97316; }
    .bg-orange-light { background-color: #fff7ed; }
    .total-row { font-weight: bold; background-color: #e5e5e5; border-top: 2px solid #666666; }
  </style>
</head>
<body>
  <div class="header-container">
    <div class="header-logo-left">${logoClient}</div>
    <div class="header-center">
      <div class="header-chantier-nom">${chantier?.nom || ''}</div>
      <div class="header-chantier-infos">
        ${chantier?.description ? chantier.description + '<br/>' : ''}
        ${chantier?.adresse || ''}
      </div>
    </div>
    <div class="header-logo-right">${logoGestionbat}</div>
  </div>

  <div class="doc-title-row">
    <h1>${title}</h1>
    ${subtitle ? `<p>${subtitle}</p>` : ''}
  </div>

  ${tableContentHtml}

  <div class="footer">
    <div class="footer-line"></div>
    <div class="footer-content">
      <div class="footer-left">${partenairesString}</div>
      <div class="footer-center">${withPageNumbers ? 'Page <span class="pageNumber"></span> / <span class="totalPages"></span>' : ''}</div>
      <div class="footer-right">${dateFormatee}</div>
    </div>
  </div>
</body>
</html>`;
}