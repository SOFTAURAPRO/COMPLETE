import { format } from "date-fns";
import { fr } from "date-fns/locale";

// Fonction utilitaire pour générer le contenu HTML d'un seul marché (sans les balises html/head/body)
const getMarcheContent = ({
  marche,
  chantier,
  client,
  entreprise,
  montantHT,
  montantTVA,
  montantTTC,
  tauxTVA,
  logoClient,
  logoGestionbat,
  partenairesString,
  dateFormatee,
  pageOffset = 0,
  totalPages = 2
  }) => {
  // Logique pour la délégation de pouvoir
  const signataire = entreprise?.contacts?.find(c => c.service === "Signataire doc marchés");
  const isDelegation = signataire && (
    (signataire.nom || '').trim().toLowerCase() !== (entreprise?.representant_nom || '').trim().toLowerCase() ||
    (signataire.prenom || '').trim().toLowerCase() !== (entreprise?.representant_prenom || '').trim().toLowerCase()
  );

  const representantText = isDelegation
    ? `représentée par ${signataire.civilite || ''} ${signataire.prenom || ''} ${signataire.nom || ''}, agissant en qualité de ${signataire.fonction || ''}, dûment habilité à l’effet des présentes en vertu du pouvoir qui lui a été confié par ${entreprise?.representant_civilite || ''} ${entreprise?.representant_prenom || ''} ${entreprise?.representant_nom || ''}, ${entreprise?.representant_qualite || ''}`
    : `représentée par ${entreprise?.representant_civilite || ''} ${entreprise?.representant_nom || ''} ${entreprise?.representant_prenom || ''} en qualité de ${entreprise?.representant_qualite || ''}`;

  return `
  <!-- PAGE 1 - Lot ${marche.numero_lot} -->
  <div class="page">
    <div class="header">
      <div class="header-left">${logoClient}</div>
      <div class="header-center">
        <h1>${chantier?.nom || 'Chantier'}</h1>
        <p>${chantier?.description || ''}</p>
        <p>${chantier?.adresse || ''}</p>
      </div>
      <div class="header-right">${logoGestionbat}</div>
    </div>

    <div class="page-title">ACTE D'ENGAGEMENT</div>

    <div class="content">
      <div class="info-section">
        <div class="info-left">
          <p><span class="info-label">Maître d'ouvrage :</span></p>
          <p><strong>${client?.nom || ''}</strong><br/>
          ${client?.adresse_1 || ''}<br/>
          ${client?.code_postal || ''} ${client?.ville || ''}</p>
        </div>
        <div class="info-right">
          <p><span class="info-label">Entreprise :</span> ${entreprise?.nom || ''}<br/>
          <span class="info-label">Siret :</span> ${entreprise?.siret || ''}<br/>
          <span class="info-label">Lot :</span> ${marche.numero_lot || ''} – ${marche.intitule_lot}</p>
          <p><span class="info-label">Montant :</span> ${montantHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT<br/>
          <span class="info-label">Valeur :</span> Ferme et non révisable<br/>
          <span class="info-label">Marché n° :</span> ${marche.numero_marche || ''}</p>
        </div>
      </div>

      <h2>ARTICLE I – PARTIES CONTRACTANTES</h2>
      <p>Il est passé un marché de travaux pour ${chantier?.nom || 'le projet'} – ${chantier?.adresse || ''}</p>

      <p>Dans les articles ci-après, entre</p>

      <p>D'une part de :</p>
      <p class="indent">. <strong>${client?.nom || ''}</strong> – ${client?.adresse_1 || ''} ${client?.code_postal || ''} ${client?.ville || ''}, (${client?.siret ? 'SIRET ' + client.siret : ''}), désignée dans les documents du marché sous la dénomination : « le Maître de l'Ouvrage ».</p>

      <p>D'autre part</p>
      <p class="indent">. L'entreprise <strong>${entreprise?.nom || ''}</strong> – ${entreprise?.adresse_1 || ''} ${entreprise?.code_postal || ''} ${entreprise?.ville || ''}, ${representantText}, et désignée dans les documents du marché sous la dénomination : « L'entreprise ».</p>

      <h2>ARTICLE II – OBJET DU MARCHÉ</h2>
      <p>Le présent marché a pour objet l'exécution du lot n° ${marche.numero_lot || ''} – ${marche.intitule_lot}.</p>
      <p>L'entreprise s'engage à réaliser les travaux dont la consistance est définie dans les documents contractuels.</p>
      <p>Les pièces constitutives du marché qui définissent l'ensemble des obligations de l'Entreprise sont énumérées à l'article 2 du CCAP.</p>

      <h2>ARTICLE III – COMMENCEMENT DES TRAVAUX ET DÉLAI DE RÉALISATION</h2>
      <p>Le présent Acte d'Engagement vaut Ordre de service n°1.</p>
      <p>Le délai d'exécution des travaux compris intempéries décrites au CCAP et périodes de congés payés, est fixé par le planning contractuel${chantier?.date_debut && chantier?.date_fin_prevue ? ', soit pour :' : '.'}</p>
      ${chantier?.date_debut && chantier?.date_fin_prevue ? `
      <p class="indent">- un début le : ${format(new Date(chantier.date_debut), "dd MMMM yyyy", { locale: fr })}<br/>
      - une fin le : ${format(new Date(chantier.date_fin_prevue), "dd MMMM yyyy", { locale: fr })}</p>
      ` : ''}

      <h2>ARTICLE IV – PÉNALITÉS DE RETARD DANS L'EXÉCUTION</h2>
      <p>Conformément à l'article 9.5 du CCAP</p>

      <h2>ARTICLE V – PRIX DU MARCHÉ</h2>
      <p>L'entrepreneur, après avoir pris connaissance de toutes les pièces contractuelles, s'engage envers le Maître de l'Ouvrage à exécuter les travaux moyennant un prix global et forfaitaire de :</p>

      <div style="background:#f9f9f9; padding:10px; border:1px solid #eee; border-radius:4px; margin:10px 0;">
        <p class="indent" style="font-weight:bold;">- Montant hors TVA : ${montantHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>
        <p class="indent">- TVA au taux de ${tauxTVA}% = ${montantTVA.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>
        <p class="indent" style="font-weight:bold;">- Montant TTC = ${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</p>
      </div>
    </div>

    <div class="footer">
      <div class="footer-left">${(partenairesString || '').toLowerCase()}</div>
      <div class="footer-center">Page 1/2</div>
      <div class="footer-right">${dateFormatee}</div>
    </div>
  </div>

  <!-- PAGE 2 - Lot ${marche.numero_lot} -->
  <div class="page">
    <div class="header">
      <div class="header-left">${logoClient}</div>
      <div class="header-center">
        <h1>${chantier?.nom || 'Chantier'}</h1>
        <p>${chantier?.description || ''}</p>
        <p>${chantier?.adresse || ''}</p>
      </div>
      <div class="header-right">${logoGestionbat}</div>
    </div>

    <div class="page-title">ACTE D'ENGAGEMENT (SUITE)</div>

    <div class="content">
      <h2>ARTICLE VI – MODALITÉS DE RÈGLEMENT DE TRAVAUX</h2>
      <p>Le maître de l'ouvrage s'engage à effectuer les paiements conformément aux prescriptions du CCAP sur présentation de l'état d'avancement à 45 jours fin de mois.</p>
      <p>Le prix est ferme et non révisable</p>

      <h2>ARTICLE VII – RETENUE DE GARANTIE</h2>
      <p>Conformément à l'article 20.5 du CCAP</p>

      <h2>ARTICLE VIII – CLAUSES ADMINISTRATIVES ET DIVERSES COMPLÉMENTAIRES OU MODIFICATIVES</h2>
      <p>Les prestations faisant l'objet de la présente commande sont celles :</p>
      <ul style="list-style-type: none; padding-left: 1cm;">
        <li>- du Cahier des Charges Techniques Particulières « marchés signés »</li>
        <li>- les plans techniques</li>
        <li>- les plans contractuels « Architecte »</li>
      </ul>

      <div class="signatures">
        <p>Le présent acte d’engagement est établi et signé de façon dématérialisée le &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.</p>
        <p>Il constitue l’original unique du marché, opposable à toutes les parties.</p>
        <p>Chaque partie reçoit immédiatement une copie conforme du document signé électroniquement.</p>

        <div class="signatures-row">
          <div class="signature-cell">
            <div style="border-bottom:1px solid #f97316; padding-bottom:5px; margin-bottom:10px; background:#fff3e0; font-weight:bold;">L'entreprise</div>
            <p style="font-size:8pt;">Signature électronique</p>
          </div>
          <div class="signature-cell">
            <div style="border-bottom:1px solid #f97316; padding-bottom:5px; margin-bottom:10px; background:#fff3e0; font-weight:bold;">Le Maître d'œuvre</div>
            <p style="font-size:8pt;">Signature électronique</p>
          </div>
          <div class="signature-cell">
            <div style="border-bottom:1px solid #f97316; padding-bottom:5px; margin-bottom:10px; background:#fff3e0; font-weight:bold;">Le Maître de l'Ouvrage</div>
            <p style="font-size:8pt;">Signature électronique</p>
          </div>
        </div>
      </div>

      <div class="annexes">
        <p><strong>Annexés à la présente :</strong></p>
        <ul style="list-style-type: none; padding-left: 1cm;">
          <li>- DPGF de l'entreprise</li>
          <li>- Attestation d'assurance de l'entreprise</li>
          <li>- K-bis de moins de 3 mois</li>
          <li>- Attestation vigilance Urssaf de moins de 6 mois</li>
          <li>- Liste nominative des salariés étrangers</li>
          ${isDelegation ? '<li>- Délégation de pouvoir</li>' : ''}
        </ul>
      </div>
    </div>

    <div class="footer">
      <div class="footer-left">${(partenairesString || '').toLowerCase()}</div>
      <div class="footer-center">Page 2/2</div>
      <div class="footer-right">${dateFormatee}</div>
    </div>
  </div>
  `;
}

export const getGlobalMarchesHtmlTemplate = ({
  marchesData, // Array of { marche, entreprise, montants... }
  chantier,
  client,
  logoClient,
  logoGestionbat,
  partenairesString,
  dateFormatee
}) => {
  const content = marchesData.map(data => getMarcheContent({
    ...data,
    chantier,
    client,
    logoClient,
    logoGestionbat,
    partenairesString,
    dateFormatee
  })).join('');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Actes d'Engagement - Global</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 0.5cm 1.5cm 1cm 1.5cm;
    }

    body {
      font-family: Arial, sans-serif;
      font-size: 10pt;
      line-height: 1.3;
      margin: 0;
      padding: 20px;
      color: #000;
    }

    .page {
      position: relative;
      min-height: 95vh; /* Ensure full page height for footer positioning */
      display: flex;
      flex-direction: column;
      page-break-after: always;
    }

    /* Pour éviter une page blanche à la toute fin si nécessaire, mais page-break-after: always est généralement ok sauf dernier élément */
    .page:last-child {
      page-break-after: auto;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 3px solid #f97316;
      min-height: 80px;
    }
    .header-left {
      flex: 1;
      text-align: left;
      display: flex;
      align-items: center;
      min-height: 80px;
    }
    .header-center {
      flex: 2;
      text-align: center;
      padding: 0 20px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    .header-right {
      flex: 1;
      text-align: right;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      min-height: 80px;
    }
    .header h1 {
      margin: 0 0 5px 0;
      font-size: 16pt; /* Slightly smaller to match signature page style */
      color: #f97316;
      text-transform: uppercase;
    }
    .header p {
      margin: 2px 0;
      color: #666;
      font-size: 9pt;
    }

    .page-title {
      text-align: center;
      font-size: 14pt;
      font-weight: bold;
      color: #333;
      margin-bottom: 20px;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 1px solid #ddd;
      padding-bottom: 10px;
    }

    .content {
      flex: 1;
    }

    .info-section {
      display: table;
      width: 100%;
      margin-bottom: 1cm;
      font-size: 9pt;
      background-color: #f9f9f9;
      border: 1px solid #eee;
      padding: 10px;
      border-radius: 4px;
    }

    .info-left {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      padding-right: 1cm;
      border-right: 1px solid #eee;
    }

    .info-right {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      text-align: left;
      padding-left: 1cm;
    }

    .info-label {
      font-weight: bold;
      color: #555;
    }

    h2 {
      font-size: 10pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 15px 0 5px 0;
      color: #f97316;
      border-bottom: 1px solid #eee;
      padding-bottom: 2px;
    }

    p {
      margin: 5px 0;
      text-align: justify;
      font-size: 9pt;
    }

    .indent {
      margin-left: 0.5cm;
    }

    .signatures {
      margin-top: 2cm;
      page-break-inside: avoid;
    }

    .signatures-row {
      display: flex;
      width: 100%;
      margin-top: 1cm;
      justify-content: space-between;
    }

    .signature-cell {
      width: 32%;
      vertical-align: top;
      text-align: center;
      border: 1px solid #ddd;
      padding: 10px;
      min-height: 120px;
      background: white;
    }

    .annexes {
      margin-top: 1.5cm;
      font-size: 9pt;
    }

    ul {
      margin: 0.3cm 0;
      padding-left: 1cm;
    }

    li {
      margin: 0.2cm 0;
    }

    .footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 1.5cm;
      font-size: 7pt;
      color: #666;
      border-top: 1px solid #ddd;
      background: white;
      z-index: 1000;
      box-sizing: border-box;
    }
    .footer-left {
      flex: 1;
      text-align: left;
      text-transform: capitalize;
    }
    .footer-center {
      flex: 1;
      text-align: center;
      font-weight: bold;
    }
    .footer-right {
      flex: 1;
      text-align: right;
    }

    @media print {
      .page {
        min-height: auto;
        display: block;
        page-break-after: always;
      }
      .footer {
        position: fixed;
        bottom: 0;
        background-color: white;
        z-index: 1000;
        left: 0;
        right: 0;
        box-sizing: border-box;
      }
      body {
        margin: 0;
      }
    }
  </style>
</head>
<body>
  ${content}
</body>
</html>`;
};

export const getMarcheHtmlTemplateProposition = ({
  marche,
  chantier,
  client,
  entreprise,
  montantHT,
  montantTVA,
  montantTTC,
  tauxTVA,
  logoClient,
  logoGestionbat,
  partenairesString,
  dateFormatee
}) => {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acte d'Engagement - ${marche.intitule_lot}</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 0.5cm 1.5cm 1cm 1.5cm;
    }
    
    body {
      font-family: Arial, sans-serif;
      font-size: 10pt;
      line-height: 1.3;
      margin: 0;
      padding: 20px;
      color: #000;
    }
    
    .page {
      position: relative;
      min-height: 95vh; /* Ensure full page height for footer positioning */
      display: flex;
      flex-direction: column;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 3px solid #f97316;
      min-height: 80px;
    }
    .header-left {
      flex: 1;
      text-align: left;
      display: flex;
      align-items: center;
      min-height: 80px;
    }
    .header-center {
      flex: 2;
      text-align: center;
      padding: 0 20px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
    .header-right {
      flex: 1;
      text-align: right;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      min-height: 80px;
    }
    .header h1 {
      margin: 0 0 5px 0;
      font-size: 16pt; /* Slightly smaller to match signature page style */
      color: #f97316;
      text-transform: uppercase;
    }
    .header p {
      margin: 2px 0;
      color: #666;
      font-size: 9pt;
    }

    .page-title {
      text-align: center;
      font-size: 14pt;
      font-weight: bold;
      color: #333;
      margin-bottom: 20px;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 1px solid #ddd;
      padding-bottom: 10px;
    }
    
    .content {
      flex: 1;
    }

    .info-section {
      display: table;
      width: 100%;
      margin-bottom: 1cm;
      font-size: 9pt;
      background-color: #f9f9f9;
      border: 1px solid #eee;
      padding: 10px;
      border-radius: 4px;
    }
    
    .info-left {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      padding-right: 1cm;
      border-right: 1px solid #eee;
    }
    
    .info-right {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      text-align: left;
      padding-left: 1cm;
    }
    
    .info-label {
      font-weight: bold;
      color: #555;
    }
    
    h2 {
      font-size: 10pt;
      font-weight: bold;
      text-transform: uppercase;
      margin: 15px 0 5px 0;
      color: #f97316;
      border-bottom: 1px solid #eee;
      padding-bottom: 2px;
    }
    
    p {
      margin: 5px 0;
      text-align: justify;
      font-size: 9pt;
    }
    
    .indent {
      margin-left: 0.5cm;
    }
    
    .signatures {
      margin-top: 2cm;
      page-break-inside: avoid;
    }
    
    .signatures-row {
      display: flex;
      width: 100%;
      margin-top: 1cm;
      justify-content: space-between;
    }
    
    .signature-cell {
      width: 32%;
      vertical-align: top;
      text-align: center;
      border: 1px solid #ddd;
      padding: 10px;
      min-height: 120px;
      background: white;
    }
    
    .annexes {
      margin-top: 1.5cm;
      font-size: 9pt;
    }
    
    ul {
      margin: 0.3cm 0;
      padding-left: 1cm;
    }
    
    li {
      margin: 0.2cm 0;
    }

    .footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 1.5cm;
      font-size: 7pt;
      color: #666;
      border-top: 1px solid #ddd;
      background: white;
      z-index: 1000;
      box-sizing: border-box;
    }
    .footer-left {
      flex: 1;
      text-align: left;
      text-transform: capitalize;
    }
    .footer-center {
      flex: 1;
      text-align: center;
      font-weight: bold;
    }
    .footer-right {
      flex: 1;
      text-align: right;
    }
    
    @media print {
      .page {
        min-height: auto;
        display: block;
        page-break-after: always;
      }
      .footer {
        position: fixed;
        bottom: 0;
        background-color: white;
        z-index: 1000;
        left: 0;
        right: 0;
        box-sizing: border-box;
      }
      body {
        margin: 0;
      }
    }
  </style>
</head>
<body>
  ${getMarcheContent({
    marche,
    chantier,
    client,
    entreprise,
    montantHT,
    montantTVA,
    montantTTC,
    tauxTVA,
    logoClient,
    logoGestionbat,
    partenairesString,
    dateFormatee
  })}
</body>
</html>`;
};