import { format } from "date-fns";
import { fr } from "date-fns/locale";

export const getCiePdfTemplate = ({
  chantier,
  operations,
  entreprises,
  totalCredit,
  totalValide,
  logoClient,
  infoGestionbat,
  partenairesString,
  dateFormatee
}) => {
  
  const lignesOperations = operations.map(op => {
    const creditrice = entreprises.find(e => e.id === op.entreprise_facturante_id)?.nom || "Inconnue";
    const repartitionDetails = op.repartitions?.map(r => {
      const entName = entreprises.find(e => e.id === r.entreprise_responsable_id)?.nom || "Inconnue";
      return `<div>${entName}: ${r.montant_ht_attribue?.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}€ (${r.pourcentage}%)</div>`;
    }).join("");

    return `
      <tr>
        <td>${format(new Date(op.date_operation), "dd/MM/yyyy")}</td>
        <td>${op.description}</td>
        <td>${creditrice}</td>
        <td style="text-align: right;">${op.montant_total_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td>${op.statut}</td>
        <td>${repartitionDetails}</td>
      </tr>
    `;
  }).join('');

  const logoGestionbat = infoGestionbat?.logo_url 
    ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" style="max-width: 100px; max-height: 50px; object-fit: contain;" />` 
    : '<p style="font-weight: bold; color: #666666; font-size: 10pt;">GESTIONBAT</p>';

  const formatPartenaireName = (name) => {
    if (!name) return "";
    return name.toLowerCase().replace(/(?:^|\s|\/)\S/g, (a) => a.toUpperCase());
  };
  
  const partenairesFormatted = formatPartenaireName(partenairesString);

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Suivi C.I.E - ${chantier?.nom}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 1.5cm;
    }
    
    body {
      font-family: 'Calibri', Arial, sans-serif;
      font-size: 9pt;
      line-height: 1.3;
      margin: 0;
      padding: 0;
      color: #000;
    }
    
    .page {
      width: 100%;
      background: white;
      position: relative;
    }
    
    .header-container { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      margin-bottom: 20px;
    }
    .header-logo-left, .header-logo-right { 
      flex: 0 0 150px;
      width: 150px;
      text-align: center;
    }
    .header-logo-left img, .header-logo-right img {
      max-width: 150px;
      max-height: 70px;
      object-fit: contain;
    }
    .header-center {
      flex: 1;
      text-align: center;
      padding: 0 10px;
    }
    .header-chantier-nom {
      font-size: 14pt;
      font-weight: bold;
      color: #f97316;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .header-chantier-infos {
      font-size: 10pt;
      color: #000;
    }
    
    .doc-title-row {
      text-align: center;
      margin-bottom: 20px;
      padding-top: 15px;
      border-top: 2px solid #f97316;
    }
    .doc-title-row h1 {
      margin: 0;
      font-size: 16pt;
      font-weight: bold;
      color: #000;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    
    th {
      background-color: #f97316;
      color: white;
      padding: 8px;
      text-align: left;
      font-weight: bold;
      border: 1px solid #e86710;
      font-size: 8pt;
    }
    
    td {
      padding: 6px;
      border: 1px solid #ddd;
      font-size: 8pt;
      vertical-align: top;
    }
    
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    
    .summary-box {
      margin-top: 20px;
      padding: 15px;
      background-color: #f3f4f6;
      border-radius: 5px;
      display: flex;
      gap: 30px;
    }
    
    .summary-item {
      font-size: 10pt;
    }
    
    .footer { 
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 50px;
      font-size: 8pt;
      color: #666;
      background: white;
      border-top: 1px solid #ccc;
      padding-top: 5px;
    }
    
    .footer-content {
      position: relative;
      height: 40px;
      padding: 0 20px;
    }
    .footer div:nth-child(1) { 
      position: absolute;
      left: 20px;
      top: 5px;
      width: 40%;
      text-align: left;
      white-space: normal;
      line-height: 1.1;
    }
    .footer div:nth-child(2) { 
      position: absolute;
      left: 50%;
      top: 5px;
      transform: translateX(-50%);
      text-align: center;
    }
    .footer div:nth-child(3) { 
      position: absolute;
      right: 20px;
      top: 5px;
      text-align: right;
    }
  </style>
</head>
<body>
  <div class="page">
    <div class="header-container">
      <div class="header-logo-left">${logoClient}</div>
      <div class="header-center">
        <div class="header-chantier-nom">${chantier?.nom || ''}</div>
        <div class="header-chantier-infos">
          ${chantier?.description ? chantier.description + '<br/>' : ''}
          ${chantier?.adresse || ''}
        </div>
      </div>
      <div class="header-logo-right">${logoGestionbat}</div>
    </div>
    
    <div class="doc-title-row">
      <h1>SUIVI COMPTE INTER-ENTREPRISES (C.I.E)</h1>
    </div>
    
    <div class="summary-box">
      <div class="summary-item"><strong>Total Engagé :</strong> ${totalCredit.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT</div>
      <div class="summary-item"><strong>Total Validé :</strong> ${totalValide.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT</div>
    </div>
    
    <table>
      <thead>
        <tr>
          <th style="width: 10%">Date</th>
          <th style="width: 25%">Description</th>
          <th style="width: 20%">Entreprise Créditrice</th>
          <th style="width: 10%; text-align: right">Montant HT</th>
          <th style="width: 10%">Statut</th>
          <th style="width: 25%">Répartition (Débiteurs)</th>
        </tr>
      </thead>
      <tbody>
        ${lignesOperations}
        ${operations.length === 0 ? '<tr><td colspan="6" style="text-align: center; padding: 20px;">Aucune opération enregistrée</td></tr>' : ''}
      </tbody>
    </table>
    
    <div class="footer">
      <div class="footer-content">
        <div>${partenairesFormatted}</div>
        <div>Page <span class="pageNumber"></span></div>
        <div>${dateFormatee}</div>
      </div>
    </div>
  </div>
</body>
</html>`;
};