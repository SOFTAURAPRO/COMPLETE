// Trame d'avenant HTML utilisée quand il n'y a pas de modèle client
// Cette trame est figée et sert de fallback pour la génération PDF
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export const getAvenantHtmlTemplate = ({
  avenant,
  chantier,
  client,
  entreprise,
  marche,
  devisAssocies,
  avenantsPrecedents,
  montantMarcheBase,
  tauxTVA,
  infoGestionbat,
  logoClient,
  logoGestionbat,
  partenairesString
}) => {
  const formatPartenaireName = (name) => {
    if (!name) return "";
    return name.toLowerCase().replace(/(?:^|\s|\/)\S/g, (a) => a.toUpperCase());
  };
  
  const partenairesFormatted = formatPartenaireName(partenairesString);

  const montantTotalTTC = avenant.montant_total_ht * (1 + tauxTVA / 100);
  
  const montantMarcheBaseTTC = montantMarcheBase * (1 + tauxTVA / 100);
  const montantTotalAvenantsPrecedentsHT = avenantsPrecedents.reduce((sum, av) => sum + (av.montant_total_ht || 0), 0);
  const montantTotalAvenantsPrecedentsTTC = montantTotalAvenantsPrecedentsHT * (1 + tauxTVA / 100);
  const nouveauMontantMarcheHT = montantMarcheBase + montantTotalAvenantsPrecedentsHT + avenant.montant_total_ht;
  const nouveauMontantMarcheTTC = nouveauMontantMarcheHT * (1 + tauxTVA / 100);

  const lignesDevis = devisAssocies.map((d, index) => {
    const montantTTC = d.montant_ht * (1 + tauxTVA / 100);
    const phaseLabel = d.tranche_numero != null ? `Phase ${d.tranche_numero}` : '-';
    return `
    <tr>
      <td style="text-align: center;">${index + 1}</td>
      <td>${d.numero_devis || `No.${index + 1}`}</td>
      <td>${format(new Date(d.date_devis), "dd/MM/yyyy", { locale: fr })}</td>
      <td>${d.intitule_devis}</td>
      <td style="text-align: center;">${phaseLabel}</td>
      <td style="text-align: center;">${d.type_devis}</td>
      <td style="text-align: right;">${d.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      <td style="text-align: right;">${montantTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
    </tr>
  `}).join('');

  const lignesAvenantsPrecedents = avenantsPrecedents.length > 0 ? avenantsPrecedents.map(av => `
    <tr>
      <td>Avenant N°${av.numero}</td>
      <td style="text-align: right; font-weight: 600; color: #f97316;">${av.montant_total_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      <td style="text-align: right; font-weight: 600; color: #f97316;">${(av.montant_total_ht * (1 + tauxTVA / 100)).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
    </tr>
  `).join('') : '';

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Avenant N° ${avenant.numero}</title>
  <style>
    @page { margin: 0.8cm; size: A4; }
    body {
      font-family: 'Calibri', Arial, sans-serif;
      font-size: 7pt;
      margin: 0;
      padding: 10px;
      line-height: 1.2;
      color: #000;
    }
    .header-container { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      margin-bottom: 10px;
      page-break-after: avoid;
    }
    .header-logo-left, .header-logo-right { 
      flex: 0 0 150px;
      width: 150px;
      text-align: center;
    }
    .header-logo-left img, .header-logo-right img {
      max-width: 150px;
      max-height: 70px;
      object-fit: contain;
    }
    .header-center {
      flex: 1;
      text-align: center;
      padding: 0 10px;
    }
    .header-chantier-nom {
      font-size: 14pt;
      font-weight: bold;
      color: #f97316;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .header-chantier-infos {
      font-size: 10pt;
      color: #000;
    }
    .doc-title-row {
      text-align: center;
      margin-bottom: 20px;
      padding-top: 15px;
      border-top: 2px solid #f97316;
      page-break-after: avoid;
    }
    .doc-title-row h1 {
      margin: 0;
      font-size: 16pt;
      font-weight: bold;
      color: #000;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .doc-title-row p {
      margin: 5px 0 0 0;
      font-size: 11pt;
      color: #000;
    }
    .footer { 
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 50px;
      font-size: 8pt;
      color: #666;
      background: white;
    }
    .footer-line {
      border-top: 1px solid #ccc;
      margin: 0 1cm 5px 1cm;
    }
    .footer-content {
      position: relative;
      height: 40px;
      padding: 0 1cm;
    }
    .footer-left { 
      position: absolute;
      left: 1cm;
      top: 0;
      width: 40%;
      text-align: left;
      white-space: normal;
      line-height: 1.1;
    }
    .footer-center { 
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
      text-align: center;
    }
    .footer-right { 
      position: absolute;
      right: 1cm;
      top: 0;
      text-align: right;
    }
    .section-title {
      font-size: 9pt;
      font-weight: bold;
      color: #f97316;
      margin: 10px 0 6px 0;
      padding-bottom: 3px;
      border-bottom: 1.5px solid #f97316;
      page-break-after: avoid;
    }
    .info-grid {
      display: table;
      width: 100%;
      margin-bottom: 8px;
      page-break-inside: avoid;
    }
    .info-row {
      display: table-row;
    }
    .info-label {
      display: table-cell;
      width: 30%;
      font-weight: 600;
      padding: 3px 10px 3px 0;
      vertical-align: top;
      color: #555;
      font-size: 7.5pt;
    }
    .info-value {
      display: table-cell;
      padding: 3px 0;
      vertical-align: top;
      color: #333;
      font-size: 7.5pt;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 8px 0;
      font-size: 7pt;
      page-break-inside: avoid;
    }
    th {
      background-color: #666666;
      color: white;
      padding: 6px 4px;
      text-align: left;
      font-weight: bold;
      border: 1px solid #555555;
      font-size: 7pt;
    }
    td {
      padding: 5px 4px;
      border: 1px solid #ddd;
      font-size: 7pt;
    }
    tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .total-row {
      font-weight: bold;
      background-color: #fff3e0 !important;
      border-top: 2px solid #f97316;
      page-break-inside: avoid;
    }
    .total-row td {
      padding: 5px 4px;
      font-size: 7pt;
    }
    .mentions-legales {
      margin: 12px 0;
      padding: 8px;
      background-color: #f8f9fa;
      border-left: 3px solid #f97316;
      font-size: 7pt;
      line-height: 1.4;
      page-break-inside: avoid;
    }
    .mentions-legales p {
      margin: 4px 0;
    }
    .signatures {
      margin-top: 15px;
      display: flex;
      justify-content: space-between;
      gap: 15px;
      page-break-inside: avoid;
    }
    .signature-bloc {
      flex: 1;
      text-align: center;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 4px;
      background-color: #fafafa;
      min-height: 150px;
    }
    .signature-bloc p {
      font-size: 7pt;
      margin: 3px 0;
    }
    .signature-bloc p strong {
      font-size: 7.5pt;
    }
    .signature-space {
      margin-top: 65px;
      border-bottom: 1px solid #333;
      margin-bottom: 5px;
    }
  </style>
</head>
<body>
  <div class="header-container">
    <div class="header-logo-left">${logoClient}</div>
    <div class="header-center">
      <div class="header-chantier-nom">${chantier?.nom || ''}</div>
      <div class="header-chantier-infos">
        ${chantier?.description ? chantier.description + '<br/>' : ''}
        ${chantier?.adresse || ''}${(chantier?.adresse && (chantier?.code_postal || chantier?.ville)) ? ' – ' : ''}${chantier?.code_postal || ''} ${chantier?.ville || ''}
      </div>
    </div>
    <div class="header-logo-right">${logoGestionbat}</div>
  </div>
  
  <div class="doc-title-row">
    <h1>Avenant N° ${avenant.numero}</h1>
    <p>Date : ${format(new Date(avenant.date), "dd MMMM yyyy", { locale: fr })}</p>
  </div>

  <h2 class="section-title">Maître d'Ouvrage</h2>
  <div class="info-grid">
    <div class="info-row">
      <div class="info-label">Nom :</div>
      <div class="info-value">
        <strong>${client?.nom || ''}</strong><br/>
        ${client?.adresse_1 || ''}<br/>
        ${client?.adresse_2 || '' ? client?.adresse_2 + '<br/>' : ''}
        ${client?.code_postal || ''} ${client?.ville || ''}
      </div>
    </div>
  </div>

  <h2 class="section-title">Entreprise</h2>
  <div class="info-grid">
    <div class="info-row">
      <div class="info-label">Raison sociale :</div>
      <div class="info-value"><strong>${entreprise?.nom || ''}</strong></div>
    </div>
    ${entreprise?.siret ? `
    <div class="info-row">
      <div class="info-label">SIRET :</div>
      <div class="info-value">${entreprise.siret}</div>
    </div>
    ` : ''}
    ${entreprise?.adresse_1 ? `
    <div class="info-row">
      <div class="info-label">Adresse :</div>
      <div class="info-value">
        ${entreprise.adresse_1}<br/>
        ${entreprise.adresse_2 ? entreprise.adresse_2 + '<br/>' : ''}
        ${entreprise.code_postal || ''} ${entreprise.ville || ''}
      </div>
    </div>
    ` : ''}
    ${marche?.numero_lot || marche?.intitule_lot ? `
    <div class="info-row">
      <div class="info-label">Lot :</div>
      <div class="info-value"><strong>${marche?.numero_lot || ''} ${marche?.numero_lot && marche?.intitule_lot ? '- ' : ''}${marche?.intitule_lot || ''}</strong></div>
    </div>
    ` : ''}
    ${marche?.numero_marche ? `
    <div class="info-row">
      <div class="info-label">Marché N° :</div>
      <div class="info-value"><strong>${marche.numero_marche}</strong></div>
    </div>
    ` : ''}
  </div>

  <h2 class="section-title">Détail des Devis Inclus</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 4%;">N°</th>
        <th style="width: 10%;">N° Devis</th>
        <th style="width: 10%;">Date</th>
        <th style="width: 30%;">Intitulé</th>
        <th style="width: 10%;">Phase</th>
        <th style="width: 8%;">Type</th>
        <th style="width: 14%; text-align: right;">Montant HT</th>
        <th style="width: 14%; text-align: right;">Montant TTC</th>
      </tr>
    </thead>
    <tbody>
      ${lignesDevis}
      <tr class="total-row">
        <td colspan="5"><strong>MONTANT TOTAL DE L'AVENANT</strong></td>
        <td style="text-align: right;"><strong>${avenant.montant_total_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${montantTotalTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
      </tr>
    </tbody>
  </table>

  <h2 class="section-title">Mise à jour du Montant Marché</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 60%;">Désignation</th>
        <th style="width: 20%; text-align: right;">Montant HT</th>
        <th style="width: 20%; text-align: right;">Montant TTC</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Marché de base</strong></td>
        <td style="text-align: right;">${montantMarcheBase.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right;">${montantMarcheBaseTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      ${lignesAvenantsPrecedents}
      <tr>
        <td><strong>Avenant N°${avenant.numero} (actuel)</strong></td>
        <td style="text-align: right; font-weight: 600; color: #f97316;">${avenant.montant_total_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
        <td style="text-align: right; font-weight: 600; color: #f97316;">${montantTotalTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</td>
      </tr>
      <tr class="total-row">
        <td><strong>NOUVEAU MONTANT MARCHÉ</strong></td>
        <td style="text-align: right;"><strong>${nouveauMontantMarcheHT.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
        <td style="text-align: right;"><strong>${nouveauMontantMarcheTTC.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</strong></td>
      </tr>
    </tbody>
  </table>

  <div class="mentions-legales">
    <p><strong>• Les conditions particulières et conditions générales du marché sont applicables au présent avenant.</strong></p>
    <p><strong>• Le présent avenant vaut ordre de service.</strong></p>
  </div>

  <div class="signatures">
    <div class="signature-bloc">
      <p><strong>Pour l'Entreprise</strong></p>
      <p style="margin-top: 3px;">${entreprise?.nom || ''}</p>
      <div class="signature-space"></div>
      <p style="font-style: italic; color: #666;">Signature</p>
    </div>
    <div class="signature-bloc">
      <p><strong>Pour la MOE</strong></p>
      <p style="margin-top: 3px;">${infoGestionbat?.nom_entreprise || 'GESTIONBAT'}</p>
      <div class="signature-space"></div>
      <p style="font-style: italic; color: #666;">Signature</p>
    </div>
    <div class="signature-bloc">
      <p><strong>Pour le Maître d'Ouvrage</strong></p>
      <p style="margin-top: 3px;">${client?.nom || ''}</p>
      <div class="signature-space"></div>
      <p style="font-style: italic; color: #666;">Signature</p>
    </div>
  </div>

  <div class="footer">
    <div class="footer-line"></div>
    <div class="footer-content">
      <div class="footer-left">${partenairesFormatted}</div>
      <div class="footer-center">Page 1</div>
      <div class="footer-right">${format(new Date(), "dd/MM/yyyy", { locale: fr })}</div>
    </div>
  </div>
</body>
</html>`;
};