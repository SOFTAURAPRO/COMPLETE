export const getFichePartenaireHtml = (partenaire, logoGestionbat) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Fiche Partenaire - ${partenaire.nom}</title>
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; color: #333; padding: 20px; }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #f97316; padding-bottom: 10px; margin-bottom: 20px; }
        .title { font-size: 18pt; font-weight: bold; color: #f97316; }
        .ref { font-size: 12pt; color: #666; }
        .section { margin-bottom: 20px; }
        .section-title { font-size: 12pt; font-weight: bold; background: #fff3e0; padding: 5px; border-left: 4px solid #f97316; margin-bottom: 10px; }
        .row { display: flex; margin-bottom: 5px; }
        .label { font-weight: bold; width: 150px; }
        .value { flex: 1; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #f97316; color: white; padding: 5px; text-align: left; }
        td { border: 1px solid #ddd; padding: 5px; }
        .logo { max-height: 50px; }
        .partenaire-logo { max-height: 80px; margin-bottom: 10px; }
      </style>
    </head>
    <body>
      <div class="header">
        <div>
          <div class="title">${partenaire.nom}</div>
          <div class="ref">Réf: ${partenaire.reference || 'Non défini'}</div>
        </div>
        <div>${logoGestionbat || ''}</div>
      </div>

      ${partenaire.logo_url ? `<div class="section"><img src="${partenaire.logo_url}" class="partenaire-logo" /></div>` : ''}

      <div class="section">
        <div class="section-title">Informations Générales</div>
        <div class="row"><span class="label">Missions:</span><span class="value">${(partenaire.missions || [partenaire.mission]).join(', ') || '-'}</span></div>
        <div class="row"><span class="label">Forme Juridique:</span><span class="value">${partenaire.forme_juridique || '-'}</span></div>
        <div class="row"><span class="label">SIRET:</span><span class="value">${partenaire.siret || '-'}</span></div>
        <div class="row"><span class="label">Téléphone:</span><span class="value">${partenaire.telephone || '-'}</span></div>
        <div class="row"><span class="label">Adresse:</span><span class="value">${partenaire.adresse_1 || ''} ${partenaire.adresse_2 || ''} ${partenaire.code_postal || ''} ${partenaire.ville || ''}</span></div>
      </div>

      <div class="section">
        <div class="section-title">Interlocuteurs</div>
        <table>
          <thead>
            <tr>
              <th style="width: 20%">Service</th>
              <th style="width: 30%">Contact</th>
              <th style="width: 25%">Fonction</th>
              <th style="width: 25%">Email</th>
            </tr>
          </thead>
          <tbody>
            ${(() => {
              const services = ["Direction", "Travaux", "Etudes", "Administratif", "Comptabilité", "Signataire doc marchés", "Autre"];
              return services.map(service => {
                const serviceContacts = (partenaire.contacts || []).filter(c => c.service === service);
                if (serviceContacts.length === 0) {
                   return `<tr>
                     <td><strong>${service}</strong></td>
                     <td style="color: #999; font-style: italic;">-</td>
                     <td>-</td>
                     <td>-</td>
                   </tr>`;
                }
                return serviceContacts.map(c => `
                  <tr>
                    <td><strong>${service}</strong></td>
                    <td>
                      <div style="font-weight:bold;">${c.civilite || ''} ${c.prenom || ''} ${c.nom || ''}</div>
                      <div style="font-size: 0.9em; color: #666; margin-top:2px;">${[c.telephone, c.portable].filter(Boolean).join(' / ')}</div>
                    </td>
                    <td>${c.fonction || '-'}</td>
                    <td>${c.email || '-'}</td>
                  </tr>
                `).join('');
              }).join('');
            })()}
          </tbody>
        </table>
      </div>
    </body>
    </html>
  `;
};