/**
 * Template Certificat de paiement format CISN (CLT-0001)
 * Mise en page identique au modèle officiel modleCP.pdf
 */

export function generateCertificatCisnHtml({
  certificat,
  chantier,
  client,
  entreprise,
  marche,
  situationsPrecedentes = [],
  avenantsDeLEntreprise = [],
  paiementsSousTraitants = [],
  penalitesAppliquees = [],
  infoGestionbat,
  clients = [],
  tauxTVA = 20
}) {
  const fmt = (v) => (parseFloat(v) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  // ── Calculs ────────────────────────────────────────────────────────────────
  const montantMarcheBase    = marche?.montant || 0;
  const montantAvenantsHT    = avenantsDeLEntreprise.reduce((s, a) => s + (a.montant_total_ht || 0), 0);
  const montantMarcheTotal   = montantMarcheBase + montantAvenantsHT;

  const situationHT          = certificat.montant_ht || 0;
  const situationBaseHT      = certificat.montant_ht_base || situationHT;
  const situationAvenantsHT  = certificat.montant_ht_avenants || 0;

  const precedentBaseHT      = situationsPrecedentes.reduce((s, c) => s + (c.montant_ht_base || c.montant_ht || 0), 0);
  const precedentAvenantsHT  = situationsPrecedentes.reduce((s, c) => s + (c.montant_ht_avenants || 0), 0);
  const precedentTotalHT     = precedentBaseHT + precedentAvenantsHT;

  const cumuleBaseHT         = precedentBaseHT + situationBaseHT;
  const cumuleAvenantsHT     = precedentAvenantsHT + situationAvenantsHT;
  const cumuleTotalHT        = cumuleBaseHT + cumuleAvenantsHT;

  const pctAvancement        = montantMarcheTotal > 0 ? ((cumuleTotalHT / montantMarcheTotal) * 100).toFixed(2) : '0.00';

  const tauxRG               = marche?.a_caution ? 0 : 0.05;
  const rgSituationBase      = situationBaseHT * tauxRG;
  const rgSituationAvenant   = situationAvenantsHT * tauxRG;
  const rgSituationTotal     = rgSituationBase + rgSituationAvenant;
  const rgPrecedentBase      = precedentBaseHT * tauxRG;
  const rgPrecedentTotal     = precedentTotalHT * tauxRG;

  const provSituation        = situationHT * 0.03;
  const provPrecedent        = precedentTotalHT * 0.03;

  const totalHTSituation     = situationHT - rgSituationTotal - provSituation;
  const totalHTPrecedent     = precedentTotalHT - rgPrecedentTotal - provPrecedent;

  const tvaSituation         = totalHTSituation * (tauxTVA / 100);
  const tvaPrecedent         = totalHTPrecedent * (tauxTVA / 100);

  const ttcSituation         = totalHTSituation + tvaSituation;
  const ttcPrecedent         = totalHTPrecedent + tvaPrecedent;

  const totalPenalitesSituation   = penalitesAppliquees.reduce((s, p) => s + (parseFloat(p.montant_calcule) || 0), 0);
  const totalPenalitesPrecedentes = situationsPrecedentes.reduce((s, c) => s + (c.penalites_appliquees || []).reduce((ps, p) => ps + (parseFloat(p.montant_calcule) || 0), 0), 0);
  const totalPenalitesCumulees    = totalPenalitesPrecedentes + totalPenalitesSituation;

  const montantFinal         = ttcSituation - totalPenalitesSituation;
  const totalST              = paiementsSousTraitants.reduce((s, p) => s + (parseFloat(p.montant_ht) || 0), 0);

  const dateSituation        = certificat.date_situation ? new Date(certificat.date_situation).toLocaleDateString('fr-FR') : '';
  const dateAujourdhui       = new Date().toLocaleDateString('fr-FR');

  // ── Logos ──────────────────────────────────────────────────────────────────
  const logoSrc = client?.logo_client_url || chantier?.logo_client_url;
  const logoHtml = logoSrc
    ? `<img src="${logoSrc}" alt="Logo" style="max-width:110px;max-height:55px;object-fit:contain;">`
    : `<span style="font-weight:bold;font-size:10pt;color:#1e3a6e;">CISN</span>`;

  const logoGestionbat = infoGestionbat?.logo_url
    ? `<img src="${infoGestionbat.logo_url}" alt="GestionBat" style="max-width:90px;max-height:45px;object-fit:contain;">`
    : `<span style="font-weight:bold;font-size:8pt;">${infoGestionbat?.nom_entreprise || ''}</span>`;

  // ── Pénalités CISN ─────────────────────────────────────────────────────────
  const penalitesCisn = [
    { code: '8.1.1.*',  label: "Retard dans l'exécution/jours",                        unite: 'jour(s)', valeur: 80,  isMarche: false },
    { code: '8.1.2.*',  label: 'Retard transmission de documents/jours',                unite: 'jour(s)', valeur: 80,  isMarche: false },
    { code: '8.1.3.*',  label: 'Retard transmi. situations-mémoires/jours',             unite: 'jour(s)', valeur: 40,  isMarche: false },
    { code: '8.1.4.*',  label: "Retard présentation d'échantillons/jours",              unite: 'jour(s)', valeur: 80,  isMarche: false },
    { code: '8.1.5.*',  label: "Retard présentation d'un sous traitant/jours",          unite: 'jour(s)', valeur: 0,   isMarche: true  },
    { code: '8.1.6*',   label: 'Retard ou absence à une coordination/U',                unite: 'jour(s)', valeur: 150, isMarche: false },
    { code: '8.1.10*',  label: 'Non respect des observations du CSPS',                  unite: 'jour(s)', valeur: 80,  isMarche: false },
    { code: '8.1.11*',  label: 'Non respect engagement chantier à faibles nuisances',  unite: 'jour(s)', valeur: 150, isMarche: false },
  ];

  const lignesPenalites = penalitesCisn.map(pen => {
    const appliquee = penalitesAppliquees.find(p => p.type_penalite && p.type_penalite.includes(pen.code.replace('*','').trim()));
    const nombre    = appliquee ? (parseFloat(appliquee.nombre) || 0) : 0;
    const montant   = appliquee ? (parseFloat(appliquee.montant_calcule) || 0) : 0;
    const valeurStr = pen.isMarche ? '0,005 Marché H.T.' : `x ${pen.valeur} € H.T.`;
    return `
    <tr>
      <td style="padding:1px 4px;font-size:6.5pt;border-right:1px solid #ccc;border-bottom:1px solid #ccc;">${pen.code} ${pen.label}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:center;border-right:1px solid #ccc;border-bottom:1px solid #ccc;">${nombre > 0 ? nombre + ' ' + pen.unite : ''}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border-right:1px solid #ccc;border-bottom:1px solid #ccc;">${valeurStr}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border-right:1px solid #ccc;border-bottom:1px solid #ccc;">${montant > 0 ? fmt(montant) : ''}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border-right:1px solid #ccc;border-bottom:1px solid #ccc;"></td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border-bottom:1px solid #ccc;">${montant > 0 ? fmt(montant) : ''}</td>
    </tr>`;
  }).join('');

  // ── Lignes sous-traitants (2 lignes minimum) ──────────────────────────────
  const stPadded = [...paiementsSousTraitants];
  while (stPadded.length < 2) stPadded.push({ montant_ht: '' });
  const lignesSTVides = stPadded.slice(0, 2).map(st => `
    <tr>
      <td colspan="3" style="padding:2px 6px;font-size:7pt;border-right:1px solid #999;border-top:1px solid #ccc;">Dont paiement H.T. au sous traitant</td>
      <td style="padding:2px 6px;font-size:7pt;text-align:right;border-top:1px solid #ccc;">${st.montant_ht ? fmt(parseFloat(st.montant_ht)) : ''}</td>
    </tr>`).join('');

  // ══════════════════════════════════════════════════════════════════════════
  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Certificat de Paiement N°${certificat.numero}</title>
  <style>
    @page { size: A4; margin-top: 0.8cm; margin-bottom: 0.8cm; margin-left: 2cm; margin-right: 2cm; }
    body {
      font-family: Arial, sans-serif;
      font-size: 7.5pt;
      margin: 0; padding: 0;
      color: #000;
      line-height: 1.25;
    }
    table { width: 100%; border-collapse: collapse; }
    td, th { vertical-align: middle; }
    .outer { border: 1px solid #999; margin-bottom: 3px; }
    .bg-gray { background-color: #d9d9d9; }
    .bg-light { background-color: #ebebeb; }
    .row-total td { font-weight: bold; background-color: #ebebeb; }
  </style>
</head>
<body>

<!-- ═══ 1. EN-TÊTE ═══ -->
<table class="outer" style="background-color:#d9d9d9;height:1.2cm;">
  <tr>
    <td style="width:20%;text-align:center;padding:2px 6px;vertical-align:middle;background-color:#d9d9d9;">
      ${logoHtml}
    </td>
    <td style="text-align:center;font-weight:bold;font-size:11pt;padding:2px 6px;background-color:#d9d9d9;vertical-align:middle;">
      CERTFICAT DE PAIEMENT N°&nbsp;: ${certificat.numero}
    </td>
  </tr>
</table>

<!-- ═══ 2. COORDONNÉES CLIENT / INFOS CHANTIER ═══ -->
<table class="outer" style="height:1.8cm;">
  <tr>
    <!-- 1/3 gauche : coordonnées client -->
    <td style="width:33%;padding:3px 7px;border-right:1px solid #999;vertical-align:middle;">
      <div style="font-weight:bold;font-size:8pt;">${(client?.nom || '').toUpperCase()}</div>
      <div style="font-size:7pt;margin-top:1px;">${client?.adresse_1 || ''}</div>
      <div style="font-size:7pt;">${[client?.code_postal, client?.ville].filter(Boolean).join(' ')}</div>
      <div style="font-size:7pt;margin-top:2px;">${client?.telephone || ''}</div>
    </td>
    <!-- 2/3 droite : infos chantier -->
    <td style="width:67%;padding:3px 7px;vertical-align:middle;">
      <div style="font-weight:bold;font-size:8.5pt;">${(chantier?.nom || '').toUpperCase()}</div>
      <div style="font-size:7pt;margin-top:1px;">${chantier?.adresse || ''}</div>
      <div style="font-size:7pt;">${[chantier?.code_postal, chantier?.ville].filter(Boolean).join(' ')}</div>
      <div style="font-size:7pt;margin-top:3px;">à la date du ${dateSituation}</div>
    </td>
  </tr>
</table>

<!-- ═══ 3. LOT / ENTREPRISE / MARCHÉ / HT-TVA-TTC ═══ -->
<table class="outer" style="height:3.60cm;">
  <tr>
    <!-- Colonne principale gauche : LOT, ENTREPRISE, données marché -->
    <td style="width:81%;padding:0;border-right:1px solid #999;vertical-align:top;">
      <!-- LOT + ENTREPRISE -->
      <table style="width:100%;border-collapse:collapse;">
        <tr>
          <td style="padding:3px 8px;border-bottom:1px solid #999;font-size:7.5pt;font-weight:bold;">
            LOT N° ${marche?.numero_lot || ''} &nbsp;–&nbsp; ${marche?.intitule_lot || ''}
          </td>
        </tr>
        <tr>
          <td style="padding:2px 8px;border-bottom:1px solid #ccc;font-size:7pt;">
            <table style="width:100%;border-collapse:collapse;">
              <tr>
                <td style="width:90px;font-size:7pt;white-space:nowrap;">ENTREPRISE</td>
                <td style="font-size:7pt;">${entreprise?.nom || ''}</td>
              </tr>
              <tr>
                <td style="font-size:7pt;"></td>
                <td style="font-size:7pt;">${entreprise?.adresse_1 || ''}</td>
              </tr>
              <tr>
                <td style="font-size:7pt;"></td>
                <td style="font-size:7pt;">${entreprise?.telephone || ''}</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <!-- Marché n° + TVA + colonnes HT/TVA/TTC -->
      <table style="width:100%;border-collapse:collapse;">
        <colgroup>
          <col style="width:40%">
          <col style="width:20%">
          <col style="width:20%">
          <col style="width:20%">
        </colgroup>
        <tr>
          <td style="padding:2px 8px;font-size:7pt;" colspan="2">
            Marché n° <strong>${marche?.numero_marche || ''}</strong>
          </td>
          <td style="padding:2px 4px;text-align:center;font-size:7pt;font-weight:bold;font-style:italic;"></td>
          <td style="padding:2px 4px;text-align:center;font-size:7pt;font-weight:bold;font-style:italic;"></td>
        </tr>
        <tr>
          <td style="padding:2px 8px;font-size:7pt;">Taux de T.V.A. <strong>${tauxTVA}%</strong></td>
          <td style="padding:2px 4px;text-align:center;font-size:7pt;font-weight:bold;font-style:italic;"><em>HT</em></td>
          <td style="padding:2px 4px;text-align:center;font-size:7pt;font-weight:bold;font-style:italic;"><em>TVA</em></td>
          <td style="padding:2px 4px;text-align:center;font-size:7pt;font-weight:bold;font-style:italic;"><em>TTC</em></td>
        </tr>
        <tr>
          <td style="padding:2px 8px;font-size:7pt;">Montant du marché................................</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheBase)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheBase * tauxTVA / 100)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheBase * (1 + tauxTVA / 100))}</td>
        </tr>
        <tr>
          <td style="padding:2px 8px;font-size:7pt;">Avenant(s) à ce jour.............................</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantAvenantsHT)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantAvenantsHT * tauxTVA / 100)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;"></td>
        </tr>
        <tr style="font-weight:bold;">
          <td style="padding:2px 8px;font-size:7pt;">Total à ce jour.......................................</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheTotal)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheTotal * tauxTVA / 100)}</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(montantMarcheTotal * (1 + tauxTVA / 100))}</td>
        </tr>
        <tr>
          <td style="padding:2px 8px;font-size:7pt;">Dont Montant sous traité</td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(totalST)}</td>
          <td style="padding:2px 4px;font-size:7pt;"></td>
          <td style="padding:2px 4px;text-align:right;font-size:7pt;">${fmt(totalST)}</td>
        </tr>
        <tr>
          <td colspan="4" style="padding:3px 8px;font-size:7.5pt;">
            Avancement du Marché &nbsp;<strong>${pctAvancement}%</strong>
          </td>
        </tr>
      </table>
    </td>
    <!-- Colonne droite : SITUATION + à la date du -->
    <td style="width:2cm;min-width:2cm;max-width:2cm;vertical-align:top;padding:0;">
      <table style="width:100%;height:100%;border-collapse:collapse;">
        <tr>
          <td style="padding:6px;text-align:center;font-weight:bold;font-size:9pt;border-bottom:1px solid #999;vertical-align:middle;">
            SITUATION ${certificat.numero}
          </td>
        </tr>
        <tr>
          <td style="padding:6px;text-align:center;font-size:7pt;vertical-align:middle;">
            à la date du<br><strong>${dateSituation}</strong>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>

<!-- ═══ 4. TRAVAUX ═══ -->
<!-- Tableau fond blanc, bordures uniquement sur les cellules de montants, libellés collés à droite des colonnes -->
<table style="width:100%;border-collapse:collapse;margin-bottom:3px;font-family:Arial,sans-serif;font-size:7pt;height:7.25cm;">
  <colgroup>
    <col>           <!-- libellé : prend l'espace restant -->
    <col style="width:2.5cm;"> <!-- Cumulés -->
    <col style="width:2.5cm;"> <!-- Précédents -->
    <col style="width:2cm;">   <!-- Mois -->
  </colgroup>

  <!-- Titre TRAVAUX -->
  <tr>
    <td colspan="4" style="padding:3px 6px;font-weight:bold;font-size:8pt;">TRAVAUX</td>
  </tr>

  <!-- En-tête : "détails des règlements H.T." + Cumulés/Précédents/Mois -->
  <tr>
    <td style="padding:1px 4px;"></td>
    <td colspan="3" style="padding:1px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;">détails des règlements H.T.</td>
  </tr>
  <tr>
    <td style="padding:1px 4px;"></td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;">Cumulés</td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">Précédents</td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">Mois</td>
  </tr>

  <!-- Travaux de base marché -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">Travaux de base marché</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;">${fmt(cumuleBaseHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(precedentBaseHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(situationBaseHT)}</td>
  </tr>

  <!-- Travaux sur avenants -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">Travaux sur avenants</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;">${fmt(cumuleAvenantsHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(precedentAvenantsHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(situationAvenantsHT)}</td>
  </tr>

  <!-- Total des travaux -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;font-weight:bold;">Total des travaux</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;">${fmt(cumuleTotalHT)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(precedentTotalHT)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(situationHT)}</td>
  </tr>

  <!-- Actualisation et révision -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">Actualisation et révision de prix</td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
  </tr>

  <!-- Total actualisé et révisé -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">Total actualisé et révisé</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;">${fmt(cumuleTotalHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(precedentTotalHT)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(situationHT)}</td>
  </tr>

  <!-- Ligne vide séparatrice -->
  <tr><td colspan="4" style="height:4px;"></td></tr>

  <!-- RG Marché initial -->
  <tr>
    <td style="padding:2px 0;font-size:6.5pt;text-align:right;white-space:nowrap;">
      3.4.1 Retenue de garantie ou caution bancaire (Marché initial)&nbsp;
      <span style="display:inline-block;border:1px solid #000;padding:0 6px;font-weight:bold;">${marche?.a_caution ? 'Caution' : '5%'}</span>
    </td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;">${fmt(rgPrecedentBase + rgSituationBase)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">${fmt(rgPrecedentBase)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">${fmt(rgSituationBase)}</td>
  </tr>

  <!-- RG Avenant -->
  <tr>
    <td style="padding:2px 0;font-size:6.5pt;text-align:right;white-space:nowrap;">
      3.4.1 Retenue de garantie ou caution bancaire (Avenant)&nbsp;
      <span style="display:inline-block;border:1px solid #000;padding:0 6px;font-weight:bold;">${marche?.a_caution ? 'Caution' : '5%'}</span>
    </td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;">${fmt(rgSituationAvenant)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">0,00</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(rgSituationAvenant)}</td>
  </tr>

  <!-- Total retenue -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;font-weight:bold;">Total retenue</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;">${fmt(rgPrecedentTotal + rgSituationTotal)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(rgPrecedentTotal)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(rgSituationTotal)}</td>
  </tr>

  <!-- Ligne vide -->
  <tr><td colspan="4" style="height:4px;"></td></tr>

  <!-- Provision 3% -->
  <tr>
    <td style="padding:2px 0;font-size:6.5pt;text-align:right;white-space:nowrap;">
      3.4.6 Provision (compte-prorata, DOE, levées des réserves)&nbsp;
      <span style="display:inline-block;border:1px solid #000;padding:0 6px;font-weight:bold;">3%</span>
    </td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;">${fmt(provPrecedent + provSituation)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">${fmt(provPrecedent)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">${fmt(provSituation)}</td>
  </tr>

  <!-- Autres retenues -->
  <tr>
    <td style="padding:2px 0;font-size:6.5pt;text-align:right;white-space:nowrap;">Autres retenues (ex: Compte Inter Entreprise)</td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
  </tr>

  <!-- Total provision -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;font-weight:bold;">Total provision</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;">${fmt(provPrecedent + provSituation)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(provPrecedent)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(provSituation)}</td>
  </tr>

  <!-- Déblocage provision -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">Déblocage provision</td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
    <td style="padding:2px 4px;border:1px solid #000;border-top:none;border-left:none;"></td>
  </tr>

  <!-- Ligne vide -->
  <tr><td colspan="4" style="height:4px;"></td></tr>

  <!-- Total H.T. -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;font-weight:bold;">Total H.T.</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;">${fmt(totalHTPrecedent + totalHTSituation)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-left:none;">${fmt(totalHTPrecedent)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-left:none;">${fmt(totalHTSituation)}</td>
  </tr>

  <!-- TVA -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;">TVA</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;">${fmt(tvaPrecedent + tvaSituation)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(tvaPrecedent)}</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${fmt(tvaSituation)}</td>
  </tr>

  <!-- Total T.T.C. -->
  <tr>
    <td style="padding:2px 0;text-align:right;white-space:nowrap;font-weight:bold;">Total T.T.C.</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;">${fmt(ttcPrecedent + ttcSituation)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(ttcPrecedent)}</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(ttcSituation)}</td>
  </tr>

  <!-- Ligne vide -->
  <tr><td colspan="4" style="height:4px;"></td></tr>

  <!-- Montant de la présente situation -->
  <tr>
    <td colspan="3" style="padding:2px 4px;text-align:right;font-size:7pt;">Montant des travaux de la présente situtation</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;">${fmt(ttcSituation)}</td>
  </tr>
</table>

<!-- ═══ 5. PÉNALITÉS ═══ -->
<table style="width:100%;border-collapse:collapse;margin-bottom:3px;font-family:Arial,sans-serif;font-size:7pt;height:4.40cm;">
  <colgroup>
    <col>                      <!-- libellé : prend l'espace restant -->
    <col style="width:1.2cm;"> <!-- Nbre/jrs -->
    <col style="width:2.2cm;"> <!-- barème -->
    <col style="width:2.5cm;"> <!-- Cumulés -->
    <col style="width:2.5cm;"> <!-- Précédents -->
    <col style="width:2cm;">   <!-- Mois -->
  </colgroup>

  <!-- Mention italique rouge -->
  <tr>
    <td colspan="6" style="padding:2px 4px;font-size:6.5pt;color:#c00;font-style:italic;">(Les pénalités ne sont pas soumises à TVA)</td>
  </tr>

  <!-- En-tête : "détails des pénalités" uniquement sur les 3 colonnes de droite -->
  <tr>
    <td colspan="3" style="padding:1px 4px;"></td>
    <td colspan="3" style="padding:1px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;">détails des pénalités</td>
  </tr>
  <tr>
    <td style="padding:2px 4px;font-size:6.5pt;font-weight:bold;"><!-- vide --></td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;">Nbre/jrs</td>
    <td style="padding:2px 4px;"></td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;">Cumulés</td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">Précédents</td>
    <td style="padding:2px 4px;text-align:center;font-size:6.5pt;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">Mois</td>
  </tr>

  <!-- Lignes pénalités -->
  ${penalitesCisn.map(pen => {
    const appliquee = penalitesAppliquees.find(p => p.type_penalite && p.type_penalite.includes(pen.code.replace('*','').trim()));
    const nombre = appliquee ? (parseFloat(appliquee.nombre) || 0) : 0;
    const montant = appliquee ? (parseFloat(appliquee.montant_calcule) || 0) : 0;
    const valeurStr = pen.isMarche ? '0,005 Marché H.T.' : `x ${pen.valeur} € H.T.`;
    return `<tr>
      <td style="padding:1px 4px;font-size:6.5pt;">${pen.code} ${pen.label}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:center;">${nombre} jour(s)</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;">${valeurStr}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border:1px solid #000;border-top:none;">${montant > 0 ? fmt(montant) + ' €' : ''}</td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border:1px solid #000;border-top:none;border-left:none;"></td>
      <td style="padding:1px 4px;font-size:6.5pt;text-align:right;border:1px solid #000;border-top:none;border-left:none;">${montant > 0 ? fmt(montant) + ' €' : ''}</td>
    </tr>`;
  }).join('')}

  <!-- Total pénalités -->
  <tr>
    <td colspan="3" style="padding:2px 4px;text-align:right;font-weight:bold;">Total pénalités</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;">${fmt(totalPenalitesCumulees)} €</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(totalPenalitesPrecedentes)} €</td>
    <td style="padding:2px 4px;text-align:right;font-weight:bold;border:1px solid #000;border-top:none;border-left:none;">${fmt(totalPenalitesSituation)} €</td>
  </tr>

  <!-- Ligne vide -->
  <tr><td colspan="6" style="height:4px;"></td></tr>

  <!-- Déblocage pénalités -->
  <tr>
    <td colspan="3" style="padding:2px 4px;text-align:right;">Déblocage pénalités</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;">0,00 €</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">0,00 €</td>
    <td style="padding:2px 4px;text-align:right;border:1px solid #000;border-left:none;">0,00 €</td>
  </tr>
</table>

<!-- ═══ 6. RÉCAPITULATIF HT / TVA / TTC ═══ -->
<table class="outer" style="height:2.37cm;">
  <colgroup>
    <col style="width:14%">
    <col style="width:14%">
    <col style="width:16%">
    <col style="width:18%">
    <col style="width:38%">
  </colgroup>
  <tr class="bg-light">
    <td style="padding:2px 5px;border-right:1px solid #999;border-bottom:1px solid #999;text-align:center;font-weight:bold;font-style:italic;font-size:7pt;">H.T.</td>
    <td style="padding:2px 5px;border-right:1px solid #999;border-bottom:1px solid #999;text-align:center;font-weight:bold;font-style:italic;font-size:7pt;">T.V.A.</td>
    <td style="padding:2px 5px;border-right:1px solid #999;border-bottom:1px solid #999;text-align:center;font-weight:bold;font-style:italic;font-size:7pt;">Taux de T.V.A.</td>
    <td style="padding:2px 5px;border-right:1px solid #999;border-bottom:1px solid #999;text-align:center;font-weight:bold;font-style:italic;font-size:7pt;">T.T.C</td>
    <td style="padding:2px 5px;border-bottom:1px solid #999;text-align:center;font-weight:bold;font-style:italic;font-size:7pt;">TOTAL</td>
  </tr>
  <tr>
    <td style="padding:2px 5px;border-right:1px solid #999;text-align:right;font-size:7pt;">${fmt(totalHTSituation)}</td>
    <td style="padding:2px 5px;border-right:1px solid #999;text-align:right;font-size:7pt;">${fmt(tvaSituation)}</td>
    <td style="padding:2px 5px;border-right:1px solid #999;text-align:center;font-size:7pt;">${tauxTVA}%</td>
    <td style="padding:2px 5px;border-right:1px solid #999;text-align:right;font-size:7pt;">${fmt(ttcSituation)}</td>
    <td rowspan="2" style="text-align:center;vertical-align:middle;font-weight:bold;font-size:13pt;padding:4px;">${fmt(montantFinal)}</td>
  </tr>
  <tr>
    <td colspan="4" style="padding:2px 5px;border-right:1px solid #999;border-top:1px solid #ccc;font-size:6.5pt;">
      PENALITES Sans objet (BOI 3b-1-06)&nbsp;: ${fmt(totalPenalitesSituation)} €
    </td>
  </tr>
</table>

<!-- ═══ 7. MONTANT DU RÈGLEMENT + SOUS-TRAITANTS ═══ -->
<table class="outer">
  <colgroup>
    <col style="width:50%">
    <col style="width:15%">
    <col style="width:15%">
    <col style="width:20%">
  </colgroup>
  <tr>
    <td colspan="3" style="padding:4px 6px;border-right:1px solid #999;font-weight:bold;font-size:8pt;text-align:center;">
      Montant du réglement de la présente situation
    </td>
    <td style="padding:4px 6px;font-weight:bold;font-size:13pt;text-align:center;">${fmt(montantFinal)}</td>
  </tr>
  ${lignesSTVides}
</table>

<!-- ═══ 8. PIED DE PAGE ═══ -->
<div style="text-align:center;font-size:7.5pt;margin-top:6px;">
  Fait à ${infoGestionbat?.ville || client?.ville || chantier?.ville || ''}&nbsp;&nbsp;Date ${dateSituation || dateAujourdhui}
</div>
<div style="text-align:center;font-size:7pt;color:#555;margin-top:3px;">Tampon + signature</div>
<div style="margin-top:10px;text-align:center;">
  ${logoGestionbat}
</div>

</body>
</html>`;
}