import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, User } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function ContactsTab({ contacts = [], onChange }) {
  const handleAddContact = () => {
    const newContact = {
      civilite: "Monsieur",
      nom: "",
      prenom: "",
      fonction: "",
      service: "Autre",
      email: "",
      telephone: "",
      portable: ""
    };
    onChange([...contacts, newContact]);
  };

  const handleRemoveContact = (index) => {
    const newContacts = contacts.filter((_, i) => i !== index);
    onChange(newContacts);
  };

  const handleChange = (index, field, value) => {
    const newContacts = [...contacts];
    newContacts[index] = { ...newContacts[index], [field]: value };
    onChange(newContacts);
  };

  return (
    <div className="space-y-4 py-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Interlocuteurs</h3>
        <Button onClick={handleAddContact} type="button" size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Ajouter
        </Button>
      </div>

      <div className="space-y-4">
        {contacts.length === 0 && (
          <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed">
            <User className="w-8 h-8 mx-auto text-gray-400 mb-2" />
            <p className="text-sm text-gray-500">Aucun interlocuteur enregistré</p>
          </div>
        )}

        {contacts.map((contact, index) => (
          <Card key={index} className="p-4 relative">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 text-gray-400 hover:text-red-600"
              onClick={() => handleRemoveContact(index)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Ligne 1: Identité */}
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-32">
                    <Label className="text-xs">Civilité</Label>
                    <Select
                      value={contact.civilite}
                      onValueChange={(v) => handleChange(index, "civilite", v)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Monsieur">M.</SelectItem>
                        <SelectItem value="Madame">Mme</SelectItem>
                        <SelectItem value="Mademoiselle">Mlle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex-1">
                    <Label className="text-xs">Nom</Label>
                    <Input
                      value={contact.nom}
                      onChange={(e) => handleChange(index, "nom", e.target.value)}
                      className="h-8"
                      placeholder="Nom"
                    />
                  </div>
                  <div className="flex-1">
                    <Label className="text-xs">Prénom</Label>
                    <Input
                      value={contact.prenom}
                      onChange={(e) => handleChange(index, "prenom", e.target.value)}
                      className="h-8"
                      placeholder="Prénom"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                   <div className="flex-1">
                    <Label className="text-xs">Service</Label>
                    <Select
                      value={contact.service}
                      onValueChange={(v) => handleChange(index, "service", v)}
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Direction">Direction</SelectItem>
                        <SelectItem value="Travaux">Travaux</SelectItem>
                        <SelectItem value="Etudes">Etudes</SelectItem>
                        <SelectItem value="Appel d'offres">Appel d'offres</SelectItem>
                        <SelectItem value="Administratif">Administratif</SelectItem>
                        <SelectItem value="Comptabilité">Comptabilité</SelectItem>
                        <SelectItem value="Signataire doc marchés">Signataire doc marchés</SelectItem>
                        <SelectItem value="Autre">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex-1">
                    <Label className="text-xs">Fonction</Label>
                    <Input
                      value={contact.fonction}
                      onChange={(e) => handleChange(index, "fonction", e.target.value)}
                      className="h-8"
                      placeholder="Ex: Gérant, Conducteur Tx"
                    />
                  </div>
                </div>
              </div>

              {/* Ligne 2: Coordonnées */}
              <div className="space-y-4">
                <div>
                  <Label className="text-xs">Email</Label>
                  <Input
                    value={contact.email}
                    onChange={(e) => handleChange(index, "email", e.target.value)}
                    className="h-8"
                    placeholder="email@exemple.com"
                  />
                </div>
                <div className="flex gap-3">
                  <div className="flex-1">
                    <Label className="text-xs">Téléphone</Label>
                    <Input
                      value={contact.telephone}
                      onChange={(e) => handleChange(index, "telephone", e.target.value)}
                      className="h-8"
                      placeholder="Fixe"
                    />
                  </div>
                  <div className="flex-1">
                    <Label className="text-xs">Portable</Label>
                    <Input
                      value={contact.portable}
                      onChange={(e) => handleChange(index, "portable", e.target.value)}
                      className="h-8"
                      placeholder="Mobile"
                    />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}