/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useNavigate } from "react-router-dom";

export default function NotificationBell() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);

  // Fetch notifications
  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      const res = await base44.entities.Notification.list('-created_date', 50);
      return res || [];
    },
    refetchInterval: 30000 // Refresh every 30s
  });

  // Real-time subscription
  useEffect(() => {
    const unsubscribe = base44.entities.Notification.subscribe((event) => {
      if (event.type === 'create') {
        queryClient.invalidateQueries({ queryKey: ['notifications'] });
      }
    });
    return unsubscribe;
  }, [queryClient]);

  const markAsReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { lue: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifs = notifications.filter(n => !n.lue);
      await Promise.all(unreadNotifs.map(n => base44.entities.Notification.update(n.id, { lue: true })));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }
  });

  const handleNotificationClick = (notification) => {
    markAsReadMutation.mutate(notification.id);
    if (notification.lien) {
      navigate(notification.lien);
      setIsOpen(false);
    }
  };

  const unreadCount = notifications.filter(n => !n.lue).length;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-600 text-white text-[10px] rounded-full"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="font-semibold text-sm">Notifications</h3>
          {unreadCount > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 text-xs"
              onClick={() => markAllAsReadMutation.mutate()}
            >
              Tout marquer comme lu
            </Button>
          )}
        </div>
        <ScrollArea className="h-[400px]">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-sm">
              Aucune notification
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-4 cursor-pointer transition-colors ${
                    notif.lue ? 'bg-white hover:bg-gray-50' : 'bg-blue-50 hover:bg-blue-100'
                  }`}
                  onClick={() => handleNotificationClick(notif)}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        {!notif.lue && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full" />
                        )}
                        <h4 className="font-medium text-sm">{notif.titre}</h4>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">{notif.message}</p>
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-400 mt-2">
                    {format(new Date(notif.created_date), "dd MMM yyyy 'à' HH:mm", { locale: fr })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}