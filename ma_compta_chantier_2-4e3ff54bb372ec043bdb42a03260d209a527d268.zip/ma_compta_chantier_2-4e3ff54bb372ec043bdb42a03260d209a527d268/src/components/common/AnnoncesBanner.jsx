import React from "react";

export default function AnnoncesBanner({ currentPage }) {
  // Désactivé temporairement (l'entité Annonce n'existe plus)
  return null;
}