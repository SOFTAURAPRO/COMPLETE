import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowRight, AlertCircle, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

export default function DuplicateResolutionDialog({ 
  open, 
  onOpenChange, 
  duplicates = [], 
  onConfirm, 
  isUpdating 
}) {
  // Set of indices selected for update
  const [selectedIndices, setSelectedIndices] = useState(new Set());

  const handleToggle = (index) => {
    const newSelected = new Set(selectedIndices);
    if (newSelected.has(index)) {
      newSelected.delete(index);
    } else {
      newSelected.add(index);
    }
    setSelectedIndices(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedIndices.size === duplicates.length) {
      setSelectedIndices(new Set());
    } else {
      setSelectedIndices(new Set(duplicates.map((_, i) => i)));
    }
  };

  const handleConfirm = () => {
    // Return list of duplicates that were selected for update
    const toUpdate = duplicates.filter((_, index) => selectedIndices.has(index));
    onConfirm(toUpdate);
  };

  const renderValue = (val) => {
    if (!val) return <span className="text-gray-400 italic">Vide</span>;
    if (typeof val === 'object') return JSON.stringify(val);
    return <span className="font-medium">{String(val)}</span>;
  };

  const getDifferingFields = (existing, incoming) => {
    const keys = Object.keys(incoming);
    return keys.filter(key => {
        // Simple comparison, ignoring null/undefined differences if roughly same
        const val1 = existing[key];
        const val2 = incoming[key];
        if (!val1 && !val2) return false;
        // Special case for objects like contact_ao
        if (typeof val2 === 'object' && val2 !== null) {
             return JSON.stringify(val1) !== JSON.stringify(val2);
        }
        return String(val1) !== String(val2);
    });
  };

  return (
    <Dialog open={open} onOpenChange={(val) => !isUpdating && onOpenChange(val)}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col p-0">
        <div className="p-6 pb-2 border-b">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <AlertCircle className="w-5 h-5 text-orange-600" />
              Doublons détectés ({duplicates.length})
            </DialogTitle>
            <DialogDescription>
              Des contacts existants correspondent à certaines lignes de votre fichier.
              Sélectionnez ceux que vous souhaitez mettre à jour avec les nouvelles données.
            </DialogDescription>
          </DialogHeader>

          <div className="flex items-center justify-between mt-4 p-2 bg-orange-50 rounded-lg border border-orange-100">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="select-all"
                checked={selectedIndices.size === duplicates.length && duplicates.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <label
                htmlFor="select-all"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Tout sélectionner pour mise à jour
              </label>
            </div>
            <span className="text-sm text-orange-800 font-medium">
              {selectedIndices.size} sélectionné(s)
            </span>
          </div>
        </div>

        <ScrollArea className="flex-1 p-6 bg-gray-50/50">
          <div className="space-y-4">
            {duplicates.map((dup, index) => {
              const diffFields = getDifferingFields(dup.existing, dup.new);
              const isSelected = selectedIndices.has(index);

              return (
                <Card 
                  key={index} 
                  className={`border transition-all ${isSelected ? 'border-orange-500 ring-1 ring-orange-500' : 'border-gray-200'} overflow-hidden`}
                >
                  <div 
                    className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => handleToggle(index)}
                  >
                    <div className="flex items-start gap-3">
                      <Checkbox 
                        checked={isSelected}
                        onCheckedChange={() => handleToggle(index)}
                        className="mt-1"
                      />
                      <div className="flex-1 space-y-3">
                        <div className="flex justify-between items-start">
                          <h4 className="font-semibold text-gray-900">
                            {dup.existing.nom} 
                            {dup.existing.siret && <span className="ml-2 text-sm font-normal text-gray-500">({dup.existing.siret})</span>}
                          </h4>
                          <Badge variant={isSelected ? "default" : "outline"} className={isSelected ? "bg-orange-600" : ""}>
                            {isSelected ? "À mettre à jour" : "Ignorer"}
                          </Badge>
                        </div>

                        {diffFields.length > 0 ? (
                          <div className="bg-white rounded-md border text-sm">
                            <div className="grid grid-cols-[1fr_auto_1fr] gap-2 p-2 bg-gray-50 border-b font-medium text-gray-500 text-xs uppercase">
                              <div>Données actuelles</div>
                              <div></div>
                              <div>Nouvelles données</div>
                            </div>
                            {diffFields.map(field => (
                              <div key={field} className="grid grid-cols-[1fr_auto_1fr] gap-4 p-3 border-b last:border-0 items-center hover:bg-orange-50/30">
                                <div className="break-words text-red-700/80">
                                  <div className="text-xs text-gray-400 mb-0.5 uppercase">{field}</div>
                                  {renderValue(dup.existing[field])}
                                </div>
                                <ArrowRight className="w-4 h-4 text-gray-300 flex-shrink-0" />
                                <div className="break-words text-green-700">
                                  <div className="text-xs text-gray-400 mb-0.5 uppercase">{field}</div>
                                  {renderValue(dup.new[field])}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-sm text-gray-500 italic p-2 bg-gray-100 rounded text-center">
                            Aucune différence détectée dans les champs principaux
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </ScrollArea>

        <DialogFooter className="p-4 border-t bg-white">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isUpdating}
          >
            Annuler l'import des doublons
          </Button>
          <Button
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={handleConfirm}
            disabled={isUpdating}
          >
            {isUpdating ? "Mise à jour..." : `Mettre à jour (${selectedIndices.size})`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}