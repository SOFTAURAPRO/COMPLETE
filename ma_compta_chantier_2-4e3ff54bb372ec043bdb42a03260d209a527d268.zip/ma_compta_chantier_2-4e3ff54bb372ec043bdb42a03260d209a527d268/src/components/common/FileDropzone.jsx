import React, { useState, useRef } from 'react';
import { Upload, File, CheckCircle2, X } from 'lucide-react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export default function FileDropzone({ onFileSelect, currentFileUrl, label = "Déposer un fichier ici", className, accept }) {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState(null);
  const inputRef = useRef(null);

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      setFile(droppedFile);
      onFileSelect(droppedFile);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      onFileSelect(selectedFile);
    }
  };

  const removeFile = (e) => {
    e.stopPropagation();
    setFile(null);
    onFileSelect(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  return (
    <div className={className}>
      <div
        onDragOver={handleDragOver}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "relative border-2 border-dashed rounded-lg p-6 transition-all text-center cursor-pointer min-h-[120px] flex flex-col items-center justify-center",
          isDragging 
            ? "border-blue-500 bg-blue-50 ring-2 ring-blue-200 ring-offset-2" 
            : "border-gray-300 hover:border-orange-400 hover:bg-orange-50/30",
          currentFileUrl && !file ? "bg-green-50/50 border-green-200" : ""
        )}
      >
        <input
          ref={inputRef}
          type="file"
          className="hidden"
          onChange={handleChange}
          accept={accept}
        />
        
        <div className="flex flex-col items-center justify-center gap-2 pointer-events-none">
          {file ? (
            <div className="animate-in fade-in zoom-in duration-300">
              <div className="bg-blue-100 p-3 rounded-full mb-2 mx-auto w-fit">
                <File className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-sm font-medium text-gray-900 truncate max-w-[200px] mx-auto">
                {file.name}
              </div>
              <p className="text-xs text-blue-600 font-medium mt-1">Prêt à être envoyé</p>
              <div className="pointer-events-auto mt-2">
                 <Button 
                   variant="ghost" 
                   size="sm" 
                   className="h-6 text-xs text-red-500 hover:text-red-700 hover:bg-red-50"
                   onClick={removeFile}
                 >
                   <X className="w-3 h-3 mr-1" /> Retirer
                 </Button>
              </div>
            </div>
          ) : currentFileUrl ? (
             <div className="animate-in fade-in zoom-in duration-300">
              <div className="bg-green-100 p-3 rounded-full mb-2 mx-auto w-fit">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-sm font-medium text-gray-900">Fichier actuel présent</p>
              <p className="text-xs text-gray-500 mt-1">Glissez ou cliquez pour remplacer</p>
             </div>
          ) : (
            <div className="space-y-1">
              <div className="bg-gray-100 p-3 rounded-full mb-2 mx-auto w-fit group-hover:bg-orange-100 group-hover:text-orange-600 transition-colors">
                <Upload className="w-6 h-6 text-gray-400 group-hover:text-orange-500" />
              </div>
              <p className="text-sm font-medium text-gray-700">{label}</p>
              <p className="text-xs text-gray-400">PDF, Excel, Images...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
