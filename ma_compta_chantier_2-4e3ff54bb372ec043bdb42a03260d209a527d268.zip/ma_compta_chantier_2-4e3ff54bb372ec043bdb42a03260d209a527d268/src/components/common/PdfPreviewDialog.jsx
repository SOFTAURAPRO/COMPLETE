import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Eye } from "lucide-react";

export default function PdfPreviewDialog({ open, onOpenChange, pdfBase64, fileName, onDownload }) {
  const pdfDataUrl = `data:application/pdf;base64,${pdfBase64}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-orange-600" />
            Aperçu du document - {fileName}
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden rounded-lg border border-gray-200">
          <iframe
            src={pdfDataUrl}
            className="w-full h-full"
            title="Aperçu PDF"
          />
        </div>

        <DialogFooter className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
          >
            Fermer
          </Button>
          <Button 
            className="bg-orange-600 hover:bg-orange-700 gap-2"
            onClick={onDownload}
          >
            <Download className="w-4 h-4" />
            Télécharger
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}