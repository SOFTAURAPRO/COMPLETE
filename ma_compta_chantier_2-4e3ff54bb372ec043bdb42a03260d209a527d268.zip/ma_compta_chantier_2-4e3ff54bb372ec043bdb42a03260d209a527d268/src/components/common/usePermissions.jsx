/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export function usePermissions() {
  const { data: currentUser, isLoading } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const isAdmin = currentUser?.role === 'admin';

  // Règles simplifiées :
  // - Tous les utilisateurs authentifiés : create, read, update autorisés
  // - Suppression réservée aux admins uniquement
  const isAuthenticated = !!currentUser;

  return {
    currentUser,
    isLoading,
    isAdmin,
    hasPermission: () => isAuthenticated,

    canViewChantiers: isAuthenticated,
    canCreateChantiers: isAuthenticated,
    canEditChantiers: isAuthenticated,
    canDeleteChantiers: isAdmin,

    canViewMarches: isAuthenticated,
    canCreateMarches: isAuthenticated,
    canEditMarches: isAuthenticated,
    canDeleteMarches: isAdmin,
    canExportMarches: isAuthenticated,

    canViewTravauxSup: isAuthenticated,
    canCreateTravauxSup: isAuthenticated,
    canEditTravauxSup: isAuthenticated,
    canDeleteTravauxSup: isAdmin,

    canViewCertificats: isAuthenticated,
    canCreateCertificats: isAuthenticated,
    canEditCertificats: isAuthenticated,
    canValidateCertificats: isAuthenticated,
    canExportCertificats: isAuthenticated,

    canManageClients: isAuthenticated,
    canManageEntreprises: isAuthenticated,
    canManagePartenaires: isAuthenticated,
    canManageEquipe: isAuthenticated,

    canViewRapports: isAuthenticated,
    canExportRapports: isAuthenticated,

    canManageUsers: isAdmin,
  };
}