/**
 * © Alice MINARD – Créatrice originale
 *
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com)
 * Transfert de propriété du module comptabilité chantier le 23 février 2026 vers le repository de GestionBat (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier
 * MAJ pour intégration de données le 02 mars 2026
 * Arrêt du développement au 02 mars 2026 par Alice MINARD sur son temps personnel suite document de cadrage signé le 11 février 2026
 *
 * Ce logiciel a été initié, conçu et développé par Alice MINARD et cédé à la société Gestionbat est protégé par le droit d'auteur Français.
 * Toute reproduction, modification ou exploitation par tout autre personne extérieure nécessite un accord écrit préalable des deux parties.
 */
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Hook réutilisable pour récupérer les informations de l'entreprise GESTIONBAT
 * Ces informations sont partagées dans toute l'application (logo, adresse, SIRET, etc.)
 * 
 * Utilisation:
 * const { infoGestionbat, isLoading } = useInfoGestionbat();
 */
export function useInfoGestionbat() {
  const { data: infoGestionbat, isLoading } = useQuery({
    queryKey: ['info-gestionbat'],
    queryFn: async () => {
      const infos = await base44.entities.InfoGestionbat.list();
      return infos.length > 0 ? infos[0] : null;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes - évite les requêtes répétées
  });

  return {
    infoGestionbat,
    isLoading,
    // Helpers pour accès facile
    nom: infoGestionbat?.nom_entreprise || 'GESTIONBAT',
    adresse: infoGestionbat?.adresse || '',
    codePostal: infoGestionbat?.code_postal || '',
    ville: infoGestionbat?.ville || '',
    telephone: infoGestionbat?.telephone || '',
    siret: infoGestionbat?.siret || '',
    logoUrl: infoGestionbat?.logo_url || '',
  };
}