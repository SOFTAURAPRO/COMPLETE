import * as XLSX from "xlsx";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export function exportDevisExcel({ devis, avenants, chantier, getEntrepriseName }) {
  if (!devis.length) return false;
  const tranches = chantier?.tranches || [];
  const headers = ["ID Devis", "Date", "N° Devis", "Entreprise", "Intitulé", "Phase", "Type", "Origine", "Montant HT (€)", "Statut", "N° Avenant"];
  const rows = devis.map(d => {
    const av = d.avenant_id ? avenants.find(a => a.id === d.avenant_id) : null;
    const tr = tranches.find(t => t.numero === d.tranche_numero);
    return [
      d.id,
      d.date_devis ? format(new Date(d.date_devis), "dd/MM/yyyy", { locale: fr }) : "",
      d.numero_devis || "",
      getEntrepriseName(d.entreprise_id),
      d.intitule_devis || "",
      tr ? `Phase ${tr.numero}${tr.libelle ? ' – ' + tr.libelle : ''}` : (d.tranche_numero != null ? `Phase ${d.tranche_numero}` : ""),
      d.type_devis || "",
      d.origine_devis || "",
      d.montant_ht || 0,
      d.statut === "brouillon" ? "Brouillon" : d.statut === "valide" ? "Validé" : "Intégré avenant",
      av ? `N°${av.numero}` : ""
    ];
  });
  rows.push(["", "", "", "", "", "", "", "TOTAL", devis.reduce((s, d) => s + (d.montant_ht || 0), 0), "", ""]);
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  ws["!cols"] = [36, 14, 16, 28, 40, 20, 8, 22, 16, 18, 12].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Devis");
  XLSX.writeFile(wb, `devis_${(chantier?.nom || "chantier").replace(/[^a-z0-9]/gi, "_")}.xlsx`);
  return true;
}

export function exportAvenantsExcel({ avenants, marches, devis, chantier, getEntrepriseName }) {
  if (!avenants.length) return false;
  const headers = ["ID Avenant", "N° Avenant", "Date", "Entreprise", "N° Lot", "Intitulé", "Montant Total HT (€)", "Statut", "Devis associés"];
  const rows = avenants.map(av => {
    const marche = av.marche_id ? marches.find(m => m.id === av.marche_id) : marches.find(m => m.entreprise_id === av.entreprise_id);
    const devisAssocies = (av.devis_ids || []).map(id => devis.find(d => d.id === id)).filter(Boolean);
    return [
      av.id,
      `N°${av.numero}`,
      av.date ? format(new Date(av.date), "dd/MM/yyyy", { locale: fr }) : "",
      getEntrepriseName(av.entreprise_id),
      marche?.numero_lot || "",
      av.intitule || "",
      av.montant_total_ht || 0,
      av.statut === "en_preparation" ? "En préparation" : av.statut === "en_signature" ? "En signature" : "Signé",
      devisAssocies.map(d => d.numero_devis || d.intitule_devis).join(", ")
    ];
  });
  rows.push(["", "", "", "", "", "TOTAL", avenants.reduce((s, a) => s + (a.montant_total_ht || 0), 0), "", ""]);
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  ws["!cols"] = [36, 12, 14, 28, 10, 40, 20, 18, 50].map(w => ({ wch: w }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Avenants");
  XLSX.writeFile(wb, `avenants_${(chantier?.nom || "chantier").replace(/[^a-z0-9]/gi, "_")}.xlsx`);
  return true;
}