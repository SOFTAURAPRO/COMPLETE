import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Pencil, Trash2, Upload, Loader2, Filter, X } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";

const statutColors = {
  brouillon: "bg-yellow-100 text-yellow-800 border-yellow-200",
  valide: "bg-green-100 text-green-800 border-green-200",
  integre_avenant: "bg-blue-100 text-blue-800 border-blue-200"
};

const statutLabels = {
  brouillon: "Brouillon",
  valide: "Validé",
  integre_avenant: "Intégré à avenant"
};

// Composant cellule PDF avec drag & drop inline
function PdfCell({ devisItem, onPdfUpdated }) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef();

  const uploadPdf = async (file) => {
    if (!file || !file.name.toLowerCase().endsWith('.pdf')) {
      toast.error("Seuls les fichiers PDF sont acceptés");
      return;
    }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.TravauxSupplementaire.update(devisItem.id, { devis_pdf_url: file_url });
      onPdfUpdated();
      toast.success("PDF ajouté");
    } catch {
      toast.error("Erreur lors de l'upload");
    } finally {
      setUploading(false);
      setIsDragging(false);
    }
  };

  if (uploading) {
    return <Loader2 className="w-4 h-4 animate-spin text-gray-400" />;
  }

  if (devisItem.devis_pdf_url) {
    return (
      <a
        href={devisItem.devis_pdf_url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-600 hover:underline flex items-center gap-1"
      >
        <FileText className="w-4 h-4" />
        PDF
      </a>
    );
  }

  return (
    <div
      className={`border border-dashed rounded px-2 py-1 text-xs cursor-pointer transition-colors flex items-center gap-1 ${
        isDragging ? "border-orange-400 bg-orange-50 text-orange-600" : "border-gray-300 text-gray-400 hover:border-orange-300 hover:text-orange-500"
      }`}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) uploadPdf(f); }}
      onClick={() => inputRef.current?.click()}
      title="Glisser un PDF ou cliquer"
    >
      <Upload className="w-3 h-3" />
      PDF
      <input ref={inputRef} type="file" accept=".pdf" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadPdf(f); }} />
    </div>
  );
}

export default function DevisTab({
  devis,
  avenants,
  selectedDevisIds,
  montantTotalSelection,
  onToggleSelection,
  onSelectAll,
  onClearSelection,
  onCreateAvenant,
  onEdit,
  onDelete,
  navigateToAvenant,
  getEntrepriseName,
  devisNonIntegres,
  onRefresh,
}) {
  const [filtreEntreprise, setFiltreEntreprise] = useState("all");
  const [filtreType, setFiltreType] = useState("all");
  const [filtreStatut, setFiltreStatut] = useState("all");

  // Options dynamiques entreprises
  const entreprisesUniques = [...new Map(devis.map(d => [d.entreprise_id, d.entreprise_id])).values()];

  const devisFiltres = devis.filter(d => {
    if (filtreEntreprise !== "all" && d.entreprise_id !== filtreEntreprise) return false;
    if (filtreType !== "all" && d.type_devis !== filtreType) return false;
    if (filtreStatut !== "all" && d.statut !== filtreStatut) return false;
    return true;
  });

  const hasFilters = filtreEntreprise !== "all" || filtreType !== "all" || filtreStatut !== "all";

  const resetFiltres = () => {
    setFiltreEntreprise("all");
    setFiltreType("all");
    setFiltreStatut("all");
  };

  if (devis.length === 0) {
    return (
      <Card className="p-12 text-center">
        <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucun devis enregistré
        </h3>
        <p className="text-gray-500">
          Ajoutez votre premier devis pour commencer
        </p>
      </Card>
    );
  }

  return (
    <>
      {/* Filtres */}
      <Card className="p-3 mb-3">
        <div className="flex flex-wrap gap-3 items-center">
          <div className="flex items-center gap-1 text-sm font-medium text-gray-600">
            <Filter className="w-4 h-4" />
            Filtres :
          </div>
          <Select value={filtreEntreprise} onValueChange={setFiltreEntreprise}>
            <SelectTrigger className="w-48 h-8 text-sm">
              <SelectValue placeholder="Entreprise" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes les entreprises</SelectItem>
              {entreprisesUniques.map(id => (
                <SelectItem key={id} value={id}>{getEntrepriseName(id)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filtreType} onValueChange={setFiltreType}>
            <SelectTrigger className="w-36 h-8 text-sm">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les types</SelectItem>
              <SelectItem value="TS">TS</SelectItem>
              <SelectItem value="TMA">TMA</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filtreStatut} onValueChange={setFiltreStatut}>
            <SelectTrigger className="w-44 h-8 text-sm">
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="brouillon">Brouillon</SelectItem>
              <SelectItem value="valide">Validé</SelectItem>
              <SelectItem value="integre_avenant">Intégré à avenant</SelectItem>
            </SelectContent>
          </Select>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={resetFiltres} className="h-8 text-gray-500 hover:text-gray-800">
              <X className="w-3 h-3 mr-1" /> Réinitialiser
            </Button>
          )}
          <span className="text-xs text-gray-400 ml-auto">{devisFiltres.length} / {devis.length} devis</span>
        </div>
      </Card>

      {selectedDevisIds.length > 0 && (
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold text-blue-900">
                {selectedDevisIds.length} devis sélectionné{selectedDevisIds.length > 1 ? 's' : ''}
              </p>
              <p className="text-sm text-blue-700">
                Montant total: {montantTotalSelection.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € HT
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={onClearSelection}>
                Annuler la sélection
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={onCreateAvenant}>
                Éditer l'avenant
              </Button>
            </div>
          </div>
        </Card>
      )}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto rounded-lg">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedDevisIds.length === devisNonIntegres.length && devisNonIntegres.length > 0}
                    onCheckedChange={onSelectAll}
                  />
                </TableHead>
                <TableHead>Date</TableHead>
                <TableHead>N° Devis</TableHead>
                <TableHead>Entreprise</TableHead>
                <TableHead>Intitulé</TableHead>
                <TableHead>Phase</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Origine</TableHead>
                <TableHead>Montant HT</TableHead>
                <TableHead>N° Avenant</TableHead>
                <TableHead>PDF</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {devisFiltres.map((devisItem) => {
                const isIntegre = devisItem.statut === 'integre_avenant';
                const avenant = devisItem.avenant_id ? avenants.find(a => a.id === devisItem.avenant_id) : null;

                return (
                  <TableRow
                    key={devisItem.id}
                    className={`hover:bg-gray-50 ${isIntegre ? 'bg-blue-50 opacity-70' : ''}`}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedDevisIds.includes(devisItem.id)}
                        onCheckedChange={() => onToggleSelection(devisItem.id)}
                        disabled={isIntegre}
                      />
                    </TableCell>
                    <TableCell className="font-medium">
                      {format(new Date(devisItem.date_devis), "dd/MM/yyyy", { locale: fr })}
                    </TableCell>
                    <TableCell>{devisItem.numero_devis || '-'}</TableCell>
                    <TableCell>{getEntrepriseName(devisItem.entreprise_id)}</TableCell>
                    <TableCell>{devisItem.intitule_devis}</TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {devisItem.tranche_numero != null ? `Phase ${devisItem.tranche_numero}` : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{devisItem.type_devis}</Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">{devisItem.origine_devis || 'N/A'}</TableCell>
                    <TableCell className="font-semibold text-orange-600">
                      {devisItem.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                    </TableCell>
                    <TableCell>
                      {avenant ? (
                        <Button
                          variant="link"
                          className="p-0 h-auto font-medium text-blue-600 hover:underline"
                          onClick={() => navigateToAvenant(avenant.id)}
                        >
                          N°{avenant.numero}
                        </Button>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <PdfCell devisItem={devisItem} onPdfUpdated={onRefresh || (() => {})} />
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statutColors[devisItem.statut]} border`}>
                        {statutLabels[devisItem.statut]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(devisItem)}
                          title="Modifier"
                          disabled={isIntegre}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(devisItem)}
                          title="Supprimer"
                          disabled={isIntegre}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>
    </>
  );
}