import React from "react";

export default function AvenantStatusLegend() {
  return (
    <div className="mt-4 flex justify-end">
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
        <p className="text-xs font-semibold text-gray-700 mb-2">Légende des statuts</p>
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-semibold bg-gray-200 text-gray-700 rounded">EP</span>
            <span className="text-xs text-gray-600">En préparation</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-semibold bg-gray-200 text-gray-700 rounded">ES</span>
            <span className="text-xs text-gray-600">En signature</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-semibold bg-gray-200 text-gray-700 rounded">S</span>
            <span className="text-xs text-gray-600">Signé</span>
          </div>
        </div>
      </div>
    </div>
  );
}