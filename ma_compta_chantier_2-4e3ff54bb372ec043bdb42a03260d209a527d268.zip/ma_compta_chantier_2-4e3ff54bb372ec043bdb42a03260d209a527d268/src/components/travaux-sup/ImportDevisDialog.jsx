import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle2, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

// Colonnes attendues dans le fichier Excel
const EXPECTED_COLUMNS = ["date_devis", "numero_devis", "entreprise_nom", "intitule_devis", "type_devis", "origine_devis", "montant_ht"];

export default function ImportDevisDialog({ open, onOpenChange, marches, entreprises, clients, chantier, onImportSuccess }) {
  const [step, setStep] = useState("upload"); // upload | validate | importing
  const [rows, setRows] = useState([]);
  const [validationResults, setValidationResults] = useState([]);
  const [enterpriseResolutions, setEnterpriseResolutions] = useState({}); // nom_import -> entreprise_id ou 'skip'
  const [pendingResolution, setPendingResolution] = useState(null); // {rowIndex, nomImport, candidates}
  const [importing, setImporting] = useState(false);
  const fileRef = useRef();

  const reset = () => {
    setStep("upload");
    setRows([]);
    setValidationResults([]);
    setEnterpriseResolutions({});
    setPendingResolution(null);
    setImporting(false);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleClose = () => {
    reset();
    onOpenChange(false);
  };

  // Trouver une entreprise par nom (fuzzy)
  const findEntreprise = (nom) => {
    if (!nom) return null;
    const nomLower = nom.trim().toLowerCase();
    // Correspondance exacte
    const exact = entreprises.find(e => e.nom.toLowerCase() === nomLower);
    if (exact) return { match: exact, confidence: "exact" };
    // Correspondance partielle (contient)
    const partial = entreprises.filter(e =>
      e.nom.toLowerCase().includes(nomLower) || nomLower.includes(e.nom.toLowerCase())
    );
    if (partial.length === 1) return { match: partial[0], confidence: "partial" };
    if (partial.length > 1) return { match: null, confidence: "ambiguous", candidates: partial };
    return null;
  };

  // Trouver le marché associé à une entreprise
  const findMarche = (entrepriseId) => {
    return marches.find(m => m.entreprise_id === entrepriseId) || null;
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    parseExcel(file);
  };

  const parseExcel = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: "array", cellDates: true });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonRows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

        if (jsonRows.length === 0) {
          toast.error("Le fichier est vide ou ne contient pas de données");
          return;
        }

        // Normaliser les noms de colonnes (case insensitive, trim)
        const normalized = jsonRows.map(row => {
          const norm = {};
          Object.entries(row).forEach(([k, v]) => {
            norm[k.trim().toLowerCase().replace(/[^a-z_]/g, "_")] = v;
          });
          return norm;
        });

        validateRows(normalized);
      } catch (err) {
        toast.error("Impossible de lire le fichier Excel : " + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const validateRows = (rawRows) => {
    const results = [];
    const newResolutions = {};

    rawRows.forEach((row, idx) => {
      const nomEntreprise = String(row["entreprise_nom"] || row["entreprise"] || "").trim();
      const intitule = String(row["intitule_devis"] || row["intitulé"] || row["intitule"] || "").trim();
      const montant = parseFloat(String(row["montant_ht"] || row["montant"] || "0").replace(",", "."));
      const dateRaw = row["date_devis"] || row["date"] || "";
      const typeDevis = String(row["type_devis"] || row["type"] || "TS").trim().toUpperCase();
      const origineDevis = String(row["origine_devis"] || row["origine"] || "").trim();
      const numeroDevis = String(row["numero_devis"] || row["n_devis"] || row["numero"] || "").trim();
      const trancheNumeroRaw = row["tranche_numero"] || row["phase"] || row["tranche"] || "";
      const trancheNumero = trancheNumeroRaw !== "" ? parseFloat(String(trancheNumeroRaw).replace(",", ".")) || null : null;

      // Conversion date
      let dateDevis = "";
      if (dateRaw instanceof Date) {
        dateDevis = dateRaw.toISOString().split("T")[0];
      } else if (typeof dateRaw === "string" && dateRaw) {
        // Essayer d'interpréter dd/MM/yyyy ou yyyy-MM-dd
        const parts = dateRaw.split(/[\/\-]/);
        if (parts.length === 3) {
          if (parts[0].length === 4) {
            dateDevis = dateRaw; // yyyy-MM-dd
          } else {
            dateDevis = `${parts[2]}-${parts[1].padStart(2,"0")}-${parts[0].padStart(2,"0")}`;
          }
        }
      } else if (typeof dateRaw === "number") {
        // Numéro de série Excel
        const d = XLSX.SSF.parse_date_code(dateRaw);
        if (d) dateDevis = `${d.y}-${String(d.m).padStart(2,"0")}-${String(d.d).padStart(2,"0")}`;
      }

      const errors = [];
      if (!intitule) errors.push("Intitulé manquant");
      if (!dateDevis) errors.push("Date invalide");
      if (isNaN(montant)) errors.push("Montant invalide");

      // Résolution entreprise
      let entrepriseStatus = "unknown";
      let entrepriseId = null;
      let candidates = [];
      const resolution = findEntreprise(nomEntreprise);

      if (!nomEntreprise) {
        errors.push("Entreprise manquante");
        entrepriseStatus = "missing";
      } else if (resolution?.confidence === "exact") {
        entrepriseStatus = "found";
        entrepriseId = resolution.match.id;
        newResolutions[nomEntreprise] = resolution.match.id;
      } else if (resolution?.confidence === "partial") {
        entrepriseStatus = "found";
        entrepriseId = resolution.match.id;
        newResolutions[nomEntreprise] = resolution.match.id;
      } else if (resolution?.confidence === "ambiguous") {
        entrepriseStatus = "ambiguous";
        candidates = resolution.candidates;
      } else {
        entrepriseStatus = "not_found";
      }

      results.push({
        idx,
        nomEntreprise,
        entrepriseStatus,
        entrepriseId,
        candidates,
        intitule,
        dateDevis,
        montant,
        typeDevis: ["TMA", "TS"].includes(typeDevis) ? typeDevis : "TS",
        origineDevis,
        numeroDevis,
        trancheNumero,
        errors,
        valid: errors.length === 0 && (entrepriseStatus === "found" || entrepriseStatus === "ambiguous" || entrepriseStatus === "not_found")
      });
    });

    setRows(rawRows);
    setValidationResults(results);
    setEnterpriseResolutions(newResolutions);
    setStep("validate");
  };

  // Résoudre manuellement une entreprise douteuse
  const resolveEntreprise = (nomImport, entrepriseId) => {
    setEnterpriseResolutions(prev => ({ ...prev, [nomImport]: entrepriseId }));
    setPendingResolution(null);
  };

  const skipEntreprise = (nomImport) => {
    setEnterpriseResolutions(prev => ({ ...prev, [nomImport]: "skip" }));
    setPendingResolution(null);
  };

  // Nombre de lignes importables
  const importableRows = validationResults.filter(r => {
    if (r.errors.filter(e => e !== "Entreprise manquante").length > 0) return false;
    const res = enterpriseResolutions[r.nomEntreprise];
    if (res === "skip") return false;
    if (res && res !== "skip") return true;
    if (r.entrepriseStatus === "found") return true;
    return false;
  });

  const handleImport = async () => {
    setImporting(true);
    let created = 0;
    let skipped = 0;

    for (const row of importableRows) {
      const entrepriseId = enterpriseResolutions[row.nomEntreprise] || row.entrepriseId;
      const marche = findMarche(entrepriseId);

      try {
        await base44.entities.TravauxSupplementaire.create({
          chantier_id: chantier.id,
          marche_id: marche?.id || "",
          entreprise_id: entrepriseId,
          client_id: chantier.client_id,
          numero_devis: row.numeroDevis || null,
          date_devis: row.dateDevis,
          intitule_devis: row.intitule,
          montant_ht: row.montant,
          type_devis: row.typeDevis,
          origine_devis: row.origineDevis || "",
          tranche_numero: row.trancheNumero || null,
          statut: "brouillon",
        });
        created++;
      } catch {
        skipped++;
      }
    }

    setImporting(false);
    toast.success(`Import terminé : ${created} devis créés${skipped > 0 ? `, ${skipped} erreurs` : ""}`);
    onImportSuccess();
    handleClose();
  };

  // Lignes nécessitant une résolution manuelle
  const rowsNeedingResolution = validationResults.filter(r =>
    (r.entrepriseStatus === "ambiguous" || r.entrepriseStatus === "not_found") &&
    !enterpriseResolutions[r.nomEntreprise]
  );

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => { if (!o) handleClose(); }}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-green-600" />
              Importer des devis depuis Excel
            </DialogTitle>
            <DialogDescription>
              {step === "upload" && "Sélectionnez un fichier Excel (.xlsx) contenant la liste des devis à importer."}
              {step === "validate" && `${validationResults.length} ligne(s) détectée(s). Vérifiez les correspondances avant d'importer.`}
            </DialogDescription>
          </DialogHeader>

          {step === "upload" && (
            <div className="py-4 space-y-4">
              <div
                className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center cursor-pointer hover:border-orange-400 hover:bg-orange-50 transition-colors"
                onClick={() => fileRef.current?.click()}
                onDragOver={e => e.preventDefault()}
                onDrop={e => {
                  e.preventDefault();
                  const file = e.dataTransfer.files?.[0];
                  if (file) parseExcel(file);
                }}
              >
                <Upload className="w-10 h-10 mx-auto text-gray-400 mb-3" />
                <p className="text-gray-600 font-medium">Glissez votre fichier ici ou cliquez pour sélectionner</p>
                <p className="text-xs text-gray-400 mt-1">Fichier .xlsx uniquement</p>
                <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFileChange} />
              </div>

              <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-800">
                <p className="font-semibold mb-1">Colonnes attendues dans le fichier :</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {["date_devis", "numero_devis", "entreprise_nom", "intitule_devis", "type_devis", "origine_devis", "montant_ht"].map(c => (
                    <code key={c} className="bg-blue-100 px-2 py-0.5 rounded text-xs">{c}</code>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === "validate" && (
            <div className="py-2 space-y-3">
              {/* Résumé */}
              <div className="flex gap-3 flex-wrap text-sm">
                <span className="flex items-center gap-1 text-green-700">
                  <CheckCircle2 className="w-4 h-4" /> {importableRows.length} importable(s)
                </span>
                {rowsNeedingResolution.length > 0 && (
                  <span className="flex items-center gap-1 text-orange-600">
                    <AlertTriangle className="w-4 h-4" /> {rowsNeedingResolution.length} entreprise(s) à valider
                  </span>
                )}
                {validationResults.filter(r => r.errors.filter(e => e !== "Entreprise manquante").length > 0).length > 0 && (
                  <span className="flex items-center gap-1 text-red-600">
                    <X className="w-4 h-4" /> {validationResults.filter(r => r.errors.filter(e => e !== "Entreprise manquante").length > 0).length} erreur(s)
                  </span>
                )}
              </div>

              {/* Tableau des lignes */}
              <div className="border rounded-lg overflow-hidden text-xs">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left px-3 py-2 font-medium">Date</th>
                      <th className="text-left px-3 py-2 font-medium">N° Devis</th>
                      <th className="text-left px-3 py-2 font-medium">Entreprise</th>
                      <th className="text-left px-3 py-2 font-medium">Intitulé</th>
                      <th className="text-right px-3 py-2 font-medium">Montant HT</th>
                      <th className="text-center px-3 py-2 font-medium">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {validationResults.map((row, i) => {
                      const resEntreprise = enterpriseResolutions[row.nomEntreprise];
                      const resolvedEntreprise = resEntreprise && resEntreprise !== "skip"
                        ? entreprises.find(e => e.id === resEntreprise)
                        : null;
                      const hasErrors = row.errors.filter(e => e !== "Entreprise manquante").length > 0;
                      const needsResolution = (row.entrepriseStatus === "ambiguous" || row.entrepriseStatus === "not_found") && !resEntreprise;
                      const isSkipped = resEntreprise === "skip";

                      return (
                        <tr key={i} className={`border-t ${hasErrors ? "bg-red-50" : isSkipped ? "bg-gray-50 opacity-50" : needsResolution ? "bg-orange-50" : "bg-white"}`}>
                          <td className="px-3 py-2">{row.dateDevis || <span className="text-red-500">—</span>}</td>
                          <td className="px-3 py-2 text-gray-500">{row.numeroDevis || "—"}</td>
                          <td className="px-3 py-2">
                            {resolvedEntreprise ? (
                              <span className="text-green-700 font-medium">{resolvedEntreprise.nom}</span>
                            ) : needsResolution ? (
                              <button
                                className="text-orange-600 underline hover:text-orange-800"
                                onClick={() => setPendingResolution({ nomImport: row.nomEntreprise, candidates: row.candidates || [] })}
                              >
                                {row.nomEntreprise} ⚠️
                              </button>
                            ) : isSkipped ? (
                              <span className="text-gray-400 line-through">{row.nomEntreprise}</span>
                            ) : (
                              <span className="text-green-600">{row.nomEntreprise}</span>
                            )}
                          </td>
                          <td className="px-3 py-2">{row.intitule || <span className="text-red-500">—</span>}</td>
                          <td className="px-3 py-2 text-right font-medium">
                            {!isNaN(row.montant) ? `${row.montant.toLocaleString("fr-FR", { minimumFractionDigits: 2 })} €` : <span className="text-red-500">—</span>}
                          </td>
                          <td className="px-3 py-2 text-center">
                            {hasErrors ? (
                              <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">Erreur</Badge>
                            ) : isSkipped ? (
                              <Badge className="bg-gray-100 text-gray-500 border-gray-200 text-xs">Ignoré</Badge>
                            ) : needsResolution ? (
                              <Badge className="bg-orange-100 text-orange-700 border-orange-200 text-xs cursor-pointer" onClick={() => setPendingResolution({ nomImport: row.nomEntreprise, candidates: row.candidates || [] })}>
                                À valider
                              </Badge>
                            ) : (
                              <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">OK</Badge>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={handleClose}>Annuler</Button>
            {step === "validate" && (
              <Button
                onClick={handleImport}
                disabled={importing || importableRows.length === 0}
                className="bg-orange-600 hover:bg-orange-700 gap-2"
              >
                {importing ? <><Loader2 className="w-4 h-4 animate-spin" />Import en cours...</> : `Importer ${importableRows.length} devis`}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog résolution entreprise inconnue */}
      {pendingResolution && (
        <AlertDialog open={!!pendingResolution} onOpenChange={() => setPendingResolution(null)}>
          <AlertDialogContent className="max-w-md">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                Entreprise introuvable
              </AlertDialogTitle>
              <AlertDialogDescription asChild>
                <div className="space-y-3">
                  <p>Le nom <strong>"{pendingResolution.nomImport}"</strong> ne correspond à aucune entreprise exacte dans la base.</p>
                  {pendingResolution.candidates.length > 0 && (
                    <div>
                      <p className="text-sm font-medium mb-1">Correspondances possibles :</p>
                      <div className="space-y-1">
                        {pendingResolution.candidates.map(c => (
                          <button
                            key={c.id}
                            className="w-full text-left px-3 py-2 text-sm bg-orange-50 hover:bg-orange-100 border border-orange-200 rounded-md"
                            onClick={() => resolveEntreprise(pendingResolution.nomImport, c.id)}
                          >
                            {c.nom}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  <div>
                    <Label className="text-sm font-medium">Ou sélectionner manuellement :</Label>
                    <Select onValueChange={(v) => resolveEntreprise(pendingResolution.nomImport, v)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Choisir une entreprise" />
                      </SelectTrigger>
                      <SelectContent>
                        {entreprises.map(e => (
                          <SelectItem key={e.id} value={e.id}>{e.nom}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => skipEntreprise(pendingResolution.nomImport)}>
                Ignorer cette ligne
              </AlertDialogCancel>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </>
  );
}