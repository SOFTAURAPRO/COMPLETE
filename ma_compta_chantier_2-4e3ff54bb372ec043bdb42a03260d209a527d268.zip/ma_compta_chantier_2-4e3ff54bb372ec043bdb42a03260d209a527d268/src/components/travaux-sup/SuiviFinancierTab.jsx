import React from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, FileText } from "lucide-react";
import AvenantStatusLegend from "./AvenantStatusLegend";

export default function SuiviFinancierTab({
  suiviFinancier,
  avenants,
  onExport,
  navigateToAvenant
}) {
  if (suiviFinancier.length === 0) {
    return (
      <Card className="p-12 text-center">
        <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucune donnée disponible
        </h3>
        <p className="text-gray-500">
          Ajoutez des marchés et des avenants pour voir le suivi financier
        </p>
      </Card>
    );
  }

  return (
    <>
      <div className="flex justify-end">
        <Button variant="outline" className="gap-2" onClick={onExport}>
          <Download className="w-4 h-4" />
          Exporter en PDF
        </Button>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto rounded-lg">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Entreprise</TableHead>
                <TableHead className="text-right">Marché Initial HT</TableHead>
                <TableHead>Avenants</TableHead>
                <TableHead className="text-right">Montant Final HT</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {suiviFinancier.map((item, index) => (
                <TableRow key={index} className="hover:bg-gray-50">
                  <TableCell className="font-semibold">
                    {item.numero_lot && <span className="text-orange-600 mr-1">Lot {item.numero_lot} –</span>}
                    {item.entreprise?.nom || 'Non spécifié'}
                  </TableCell>
                  <TableCell className="text-right">
                    {item.montant_marche_initial.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </TableCell>
                  <TableCell>
                    {item.avenants.length === 0 ? (
                      <span className="text-gray-400 text-sm">Aucun avenant</span>
                    ) : (
                      <div className="space-y-1">
                        {item.avenants.map((av, idx) => {
                          const avenantComplet = avenants.find(a => a.id === av.id);
                          return (
                            <div key={idx} className="text-sm flex items-center gap-2">
                              <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-semibold bg-gray-200 text-gray-700 rounded">
                                {avenantComplet?.statut === 'signe' ? 'S' : avenantComplet?.statut === 'en_signature' ? 'ES' : 'EP'}
                              </span>
                              <Button 
                                variant="link" 
                                className="p-0 h-auto font-medium text-blue-600 hover:underline text-left" 
                                onClick={() => avenantComplet && navigateToAvenant(avenantComplet.id)} 
                                disabled={!avenantComplet}
                              >
                                N°{av.numero}
                              </Button>
                              {av.intitule && <span className="text-gray-600"> - {av.intitule}</span>}
                              : <span className="font-semibold">{av.montant.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</span>
                            </div>
                          );
                        })}
                        {item.avenants.length > 0 && (
                          <div className="text-sm font-semibold text-blue-600 pt-1 border-t">
                            Total: {item.montant_total_avenants.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                          </div>
                        )}
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-bold text-orange-600">
                    {item.montant_total_final.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-orange-50 font-bold">
                <TableCell>TOTAL</TableCell>
                <TableCell className="text-right">
                  {suiviFinancier.reduce((sum, item) => sum + item.montant_marche_initial, 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                </TableCell>
                <TableCell className="text-right">
                  {suiviFinancier.reduce((sum, item) => sum + item.montant_total_avenants, 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                </TableCell>
                <TableCell className="text-right text-orange-600">
                  {suiviFinancier.reduce((sum, item) => sum + item.montant_total_final, 0).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <AvenantStatusLegend />
        </div>
      </Card>
    </>
  );
}