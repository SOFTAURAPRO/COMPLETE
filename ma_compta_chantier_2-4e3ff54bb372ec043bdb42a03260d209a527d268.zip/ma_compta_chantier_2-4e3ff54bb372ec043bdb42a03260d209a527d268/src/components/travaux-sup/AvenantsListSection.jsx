import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Building, Eye, Download, Trash2, FileCheck, Upload, FileText, X } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function AvenantsListSection({
  avenants,
  loadingAvenants,
  avenantParEntreprise,
  openAccordionItems,
  setOpenAccordionItems,
  highlightedAvenantId,
  devis,
  getStatutColor,
  getStatutLabel,
  handlePreviewAvenant,
  handleEditAvenant,
  handleDeleteAvenant,
  handleChangeStatutAvenant,
  handleUploadAvenantSigne,
  uploadAvenantSigneMutation,
  handleEdit,
  previewingAvenant,
  generatingAvenantPDF
}) {
  const [uploadingFiles, setUploadingFiles] = useState({});

  const handleAddMultipleFiles = async (avenantId, files) => {
    const avenant = avenants.find(a => a.id === avenantId);
    if (!avenant) return;

    setUploadingFiles(prev => ({ ...prev, [avenantId]: true }));

    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        if (file.type !== 'application/pdf') {
          toast.error(`${file.name} n'est pas un PDF`);
          return null;
        }
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return {
          nom: file.name,
          url: file_url,
          date_ajout: new Date().toISOString()
        };
      });

      const uploadedFiles = (await Promise.all(uploadPromises)).filter(f => f !== null);
      
      const existingFiles = avenant.avenants_signes || [];
      const newFiles = [...existingFiles, ...uploadedFiles];

      await base44.entities.Avenant.update(avenantId, { 
        avenants_signes: newFiles,
        statut: 'signe'
      });

      toast.success(`${uploadedFiles.length} fichier(s) ajouté(s)`);
      window.location.reload();
    } catch (error) {
      console.error("Erreur upload:", error);
      toast.error("Erreur lors de l'upload");
    } finally {
      setUploadingFiles(prev => ({ ...prev, [avenantId]: false }));
    }
  };

  const handleRemoveFile = async (avenantId, fileIndex) => {
    const avenant = avenants.find(a => a.id === avenantId);
    if (!avenant) return;

    const newFiles = (avenant.avenants_signes || []).filter((_, idx) => idx !== fileIndex);
    
    await base44.entities.Avenant.update(avenantId, { 
      avenants_signes: newFiles,
      statut: newFiles.length > 0 ? 'signe' : 'en_signature'
    });

    toast.success("Fichier supprimé");
    window.location.reload();
  };
  if (loadingAvenants) {
    return (
      <div className="space-y-3">
        {Array(3).fill(0).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  if (avenantParEntreprise.length === 0) {
    return (
      <Card className="p-12 text-center">
        <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">
          Aucun avenant trouvé avec ces filtres
        </h3>
        <p className="text-sm mt-1">
          Essayez de modifier vos filtres
        </p>
      </Card>
    );
  }

  return (
    <Accordion
      type="multiple"
      className="space-y-4"
      value={openAccordionItems}
      onValueChange={setOpenAccordionItems}
    >
      {avenantParEntreprise.map((groupe) => (
        <AccordionItem
          key={groupe.groupKey || groupe.entrepriseId || 'unknown'}
          value={groupe.groupKey || groupe.entrepriseId || 'unknown'}
          className="border rounded-lg overflow-hidden bg-white shadow-sm"
        >
          <AccordionTrigger className="px-6 py-4 hover:bg-gray-50 hover:no-underline">
            <div className="flex items-center justify-between w-full pr-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                  <Building className="w-5 h-5 text-orange-600" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-lg text-gray-900">
                    {groupe.numero_lot ? <span className="text-orange-600 mr-1">Lot {groupe.numero_lot} –</span> : null}{groupe.entreprise?.nom || 'Entreprise non spécifiée'}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {groupe.avenants.length} avenant{groupe.avenants.length > 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              <div className="text-right mr-2">
                <p className="text-sm text-gray-500">Montant total validé</p>
                <p className="text-2xl font-bold text-orange-600">
                  {groupe.montantValide.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                </p>
                {groupe.montantTotal !== groupe.montantValide && (
                  <p className="text-xs text-gray-400">
                    Total : {groupe.montantTotal.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                  </p>
                )}
              </div>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-0 pb-0">
            <div className="border-t space-y-4 p-4">
              {groupe.avenants.map(avenant => {
                const devisAvenant = devis.filter(d => avenant.devis_ids?.includes(d.id));
                const isHighlighted = highlightedAvenantId === avenant.id;

                return (
                  <Card
                    key={avenant.id}
                    id={`avenant-${avenant.id}`}
                    className={`border-l-4 border-l-orange-500 transition-all duration-500 ${
                      isHighlighted ? 'ring-4 ring-orange-200 shadow-xl' : ''
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-bold text-lg">Avenant N°{avenant.numero}</h3>
                            <Badge className={`${getStatutColor(avenant.statut)} border`}>
                              {getStatutLabel(avenant.statut)}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-1">
                            <strong>Date:</strong> {format(new Date(avenant.date), "dd/MM/yyyy", { locale: fr })}
                          </p>
                          <p className="text-sm text-gray-600">
                            <strong>Montant total HT:</strong>{" "}
                            <span className="text-orange-600 font-semibold">
                              {avenant.montant_total_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                            </span>
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handlePreviewAvenant(avenant)}
                            title="Prévisualiser en HTML"
                            disabled={previewingAvenant}
                          >
                            <Eye className="w-4 h-4 text-blue-600" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleEditAvenant(avenant)}
                            title="Télécharger PDF (avec fusion)"
                            disabled={generatingAvenantPDF}
                          >
                            <Download className="w-4 h-4 text-green-600" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleDeleteAvenant(avenant.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Gestion du statut */}
                      <div className="mb-3 pb-3 border-b">
                        <Label className="text-xs text-gray-500 mb-2 block">Changer le statut</Label>
                        <Select
                          value={avenant.statut}
                          onValueChange={(value) => handleChangeStatutAvenant(avenant.id, value)}
                        >
                          <SelectTrigger className="w-48">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en_preparation">📋 En préparation</SelectItem>
                            <SelectItem value="en_signature">📝 En signature</SelectItem>
                            <SelectItem value="signe">✅ Signé</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Liste des devis inclus */}
                      {devisAvenant.length > 0 && (
                        <div className="mb-3 pb-3 border-b">
                          <p className="text-xs font-medium text-gray-500 mb-2">
                            Devis inclus dans cet avenant:
                          </p>
                          <div className="space-y-1">
                            {devisAvenant.map(d => (
                              <div key={d.id} className="text-xs bg-gray-50 p-2 rounded flex justify-between items-center">
                                <Button
                                  variant="link"
                                  className="p-0 h-auto text-xs font-medium text-blue-600 hover:underline text-left"
                                  onClick={() => handleEdit(d)}
                                >
                                  <strong>{d.numero_devis || 'N/A'}</strong> - {d.intitule_devis}
                                </Button>
                                <span className="text-orange-600 font-semibold">
                                  {d.montant_ht.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Avenants signés - Plusieurs pièces possibles */}
                      <div>
                        <Label className="text-xs text-gray-500 mb-2 block">Avenants signés</Label>
                        
                        {/* Liste des fichiers existants */}
                        {(avenant.avenants_signes?.length > 0 || avenant.avenant_signe_url) && (
                          <div className="space-y-2 mb-3">
                            {/* Legacy: ancien champ avenant_signe_url */}
                            {avenant.avenant_signe_url && !avenant.avenants_signes?.length && (
                              <div className="flex items-center justify-between bg-gray-50 p-2 rounded">
                                <Button
                                  variant="link"
                                  className="p-0 h-auto text-xs font-medium text-blue-600 hover:underline"
                                  onClick={() => window.open(avenant.avenant_signe_url, '_blank')}
                                >
                                  <FileCheck className="w-4 h-4 mr-1 text-green-600" />
                                  Avenant signé (Legacy)
                                </Button>
                              </div>
                            )}
                            
                            {/* Nouveaux fichiers multiples */}
                            {avenant.avenants_signes?.map((file, idx) => (
                              <div key={idx} className="flex items-center justify-between bg-gray-50 p-2 rounded group">
                                <Button
                                  variant="link"
                                  className="p-0 h-auto text-xs font-medium text-blue-600 hover:underline flex-1 text-left"
                                  onClick={() => window.open(file.url, '_blank')}
                                >
                                  <FileCheck className="w-4 h-4 mr-1 text-green-600 inline" />
                                  {file.nom}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                                  onClick={() => handleRemoveFile(avenant.id, idx)}
                                >
                                  <X className="w-3 h-3 text-red-600" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Zone d'upload multiple */}
                        <div
                          onDragOver={(e) => {
                            e.preventDefault();
                            e.currentTarget.classList.add('border-orange-500', 'bg-orange-50');
                          }}
                          onDragLeave={(e) => {
                            e.currentTarget.classList.remove('border-orange-500', 'bg-orange-50');
                          }}
                          onDrop={async (e) => {
                            e.preventDefault();
                            e.currentTarget.classList.remove('border-orange-500', 'bg-orange-50');
                            handleAddMultipleFiles(avenant.id, e.dataTransfer.files);
                          }}
                          className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:border-orange-400 hover:bg-orange-50 transition-all"
                        >
                          <Upload className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                          <p className="text-xs text-gray-600">
                            {uploadingFiles[avenant.id] ? "Upload en cours..." : "Glissez un ou plusieurs PDF ou"}{" "}
                            <label className="text-orange-600 cursor-pointer underline">
                              parcourez
                              <input
                                type="file"
                                accept=".pdf"
                                multiple
                                onChange={(e) => handleAddMultipleFiles(avenant.id, e.target.files)}
                                className="hidden"
                                disabled={uploadingFiles[avenant.id]}
                              />
                            </label>
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}