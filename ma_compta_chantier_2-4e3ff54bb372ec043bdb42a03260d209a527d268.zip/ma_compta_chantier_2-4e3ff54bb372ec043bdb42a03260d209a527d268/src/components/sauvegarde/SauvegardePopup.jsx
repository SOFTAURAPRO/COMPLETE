import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { FolderArchive, Clock, ShieldCheck } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { toast } from 'sonner';

const DOSSIERS = [
  { id: '1_marches', label: '1_Marchés entreprises', desc: 'Fichiers ZIP marchés + tableau PDF marchés' },
  { id: '2_cautions', label: '2_Cautions', desc: 'Documents cautions des marchés' },
  { id: '3_certificats', label: '3_Certificats de paiement', desc: 'CP envoyés MOE + tableau PDF récap avancement' },
  { id: '4_avenants', label: '4_Avenants', desc: 'Avenants signés uniquement' },
  { id: '5_ts_avenants', label: '5_TS Validés avec avenants', desc: 'Devis ayant un avenant + tableau PDF récap avenants' },
  { id: '6_ts_attente', label: '6_TS en attente', desc: 'Devis sans avenant' },
  { id: '7_cie', label: '7_CIE', desc: 'Documents CIE + tableau PDF suivi CIE' },
  { id: '8_sous_traitance', label: '8_Sous-Traitance', desc: 'Fichiers ZIP sous-traitance' },
  { id: '9_en_cours', label: '9_En cours marchés', desc: 'Tableau PDF en cours marchés' },
];

export default function SauvegardePopup() {
  const [notification, setNotification] = useState(null);
  const [open, setOpen] = useState(false);
  const [dossiers, setDossiers] = useState({});
  const [saving, setSaving] = useState(false);

  // Vérifier les notifications en attente au montage + abonnement temps réel
  useEffect(() => {
    const checkNotifications = async () => {
      try {
        const all = await base44.entities.SauvegardeNotification.list('-created_date', 1);
        const pending = all.find(n => n.statut === 'en_attente');
        if (pending) {
          setNotification(pending);
          setDossiers(pending.dossiers_selectionnes || Object.fromEntries(DOSSIERS.map(d => [d.id, true])));
          setOpen(true);
        }
      } catch (e) {
        console.error('Erreur chargement notification sauvegarde:', e);
      }
    };

    checkNotifications();

    // Abonnement temps réel
    const unsubscribe = base44.entities.SauvegardeNotification.subscribe((event) => {
      if (event.type === 'create' && event.data?.statut === 'en_attente') {
        setNotification(event.data);
        setDossiers(event.data.dossiers_selectionnes || Object.fromEntries(DOSSIERS.map(d => [d.id, true])));
        setOpen(true);
      }
    });

    return () => unsubscribe();
  }, []);

  const toggleDossier = (id) => {
    setDossiers(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleAll = (val) => {
    setDossiers(Object.fromEntries(DOSSIERS.map(d => [d.id, val])));
  };

  const handleValider = async () => {
    if (!notification) return;
    setSaving(true);
    try {
      // Sauvegarder les préférences et acquitter
      await base44.entities.SauvegardeNotification.update(notification.id, {
        dossiers_selectionnes: dossiers,
        statut: 'acquittee',
      });
      toast.success('Préférences de sauvegarde enregistrées');
      setOpen(false);
      setNotification(null);
    } catch (e) {
      toast.error('Erreur lors de la validation');
    } finally {
      setSaving(false);
    }
  };

  const handleIgnorer = async () => {
    if (!notification) return;
    try {
      await base44.entities.SauvegardeNotification.update(notification.id, { statut: 'acquittee' });
    } catch (e) { /* silencieux */ }
    setOpen(false);
    setNotification(null);
  };

  if (!notification) return null;

  const dateSauvegarde = notification.date_sauvegarde
    ? format(new Date(notification.date_sauvegarde), "EEEE dd MMMM yyyy 'à' HH'h'mm", { locale: fr })
    : 'dans 24 heures';

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleIgnorer(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
              <FolderArchive className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <DialogTitle className="text-lg">Sauvegarde automatique planifiée</DialogTitle>
              <div className="flex items-center gap-1.5 text-sm text-orange-600 font-medium mt-0.5">
                <Clock className="w-4 h-4" />
                <span>Sauvegarde prévue le {dateSauvegarde}</span>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Une sauvegarde automatique de vos documents chantier aura lieu dans <strong>24 heures</strong>.
            Vérifiez et ajustez les dossiers à inclure ci-dessous.
          </p>
        </DialogHeader>

        <div className="space-y-1 py-2 max-h-72 overflow-y-auto">
          <div className="flex gap-4 mb-3 text-sm border-b pb-2">
            <button onClick={() => toggleAll(true)} className="text-indigo-600 hover:underline">Tout sélectionner</button>
            <button onClick={() => toggleAll(false)} className="text-gray-400 hover:underline">Tout désélectionner</button>
          </div>
          {DOSSIERS.map(d => (
            <div key={d.id} className="flex items-start gap-3 p-2 rounded hover:bg-gray-50 cursor-pointer" onClick={() => toggleDossier(d.id)}>
              <Checkbox
                id={`sauv-${d.id}`}
                checked={dossiers[d.id] ?? true}
                onCheckedChange={() => toggleDossier(d.id)}
                className="mt-0.5"
              />
              <div>
                <Label htmlFor={`sauv-${d.id}`} className="font-semibold cursor-pointer text-sm">{d.label}</Label>
                <p className="text-xs text-gray-500">{d.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <DialogFooter className="gap-2 flex-col sm:flex-row">
          <Button variant="ghost" onClick={handleIgnorer} className="text-gray-400 text-sm">
            Ignorer
          </Button>
          <Button
            onClick={handleValider}
            disabled={saving || !Object.values(dossiers).some(Boolean)}
            className="bg-orange-600 hover:bg-orange-700 gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            {saving ? 'Enregistrement...' : 'Valider la sélection'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}