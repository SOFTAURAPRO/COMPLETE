/** 
 * © Alice MINARD – Créatrice originale 
 *  
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com) 
 * Mise à disposition pour usage interne chez GestionBat le 23 février 2026 (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier 
 *  
 * Ce logiciel a été initié, conçu et développé par Alice MINARD sur son temps personnel jusqu'au 23 février 2026.
 * Il est protégé par le droit d’auteur français. Toute reproduction, modification ou exploitation 
 * au-delà de l’usage interne chez GestionBat nécessite un accord écrit préalable de l’autrice. 
 */

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, Building2, Building, Users, FileText, LogOut, UserCog, Shield, RefreshCw, Database, FolderOpen, Trophy, TrendingUp, MoreHorizontal, Settings, Download, Tag, Wrench } from "lucide-react";
import NotificationBell from "@/components/common/NotificationBell";
import AnnoncesBanner from "@/components/common/AnnoncesBanner";
import { base44 } from "@/api/base44Client";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

const APP_VERSION = "2.8.56";

const navigationModules = [
  {
    title: "Concours",
    icon: Trophy,
    items: [
      // À créer
    ]
  },

  {
    title: "Chantier",
    icon: Building2,
    items: [
      {
        title: "Tableau de bord",
        url: createPageUrl("Dashboard"),
        icon: LayoutDashboard,
      },
      {
        title: "Planning chantiers",
        url: createPageUrl("PlanningChantiers"),
        icon: LayoutDashboard,
      },
      {
        title: "Chantiers",
        url: createPageUrl("Chantiers"),
        icon: Building2,
      },
    ]
  },
  {
    title: "Base de données",
    icon: Database,
    items: [
      {
        title: "Clients",
        url: createPageUrl("Clients"),
        icon: Users,
      },
      {
        title: "Entreprises",
        url: createPageUrl("Entreprises"),
        icon: Building,
      },
      {
        title: "Partenaires",
        url: createPageUrl("Partenaires"),
        icon: UserCog,
      },
      {
        title: "Equipe GESTIONBAT",
        url: createPageUrl("EquipeGestionbat"),
        icon: UserCog,
      },
    ]
  },
  {
    title: "Divers",
    icon: MoreHorizontal,
    items: [
      {
        title: "Guide Utilisateur",
        url: createPageUrl("GuideUtilisateur"),
        icon: FileText,
      },
      {
        title: "Rapports",
        url: createPageUrl("Rapports"),
        icon: FileText,
      },
      {
        title: "Analytics",
        url: createPageUrl("Analytics"),
        icon: TrendingUp,
      },
      {
        title: "Téléchargement Chantier",
        url: createPageUrl("TelechargementChantier"),
        icon: Download,
      },
      {
        title: "Export / Import",
        url: createPageUrl("ExportImportDonnees"),
        icon: Database,
      },
      {
        title: "Gestion des utilisateurs",
        url: createPageUrl("GestionUtilisateurs"),
        icon: Shield,
      },
      {
        title: "Gestion des annonces",
        url: createPageUrl("GestionAnnonces"),
        icon: Settings,
      },
      {
        title: "Gestion des versions",
        url: createPageUrl("GestionVersions"),
        icon: Tag,
      },
      {
        title: "Réconciliation chantiers",
        url: createPageUrl("ReconciliationChantier"),
        icon: Wrench,
      },
      {
        title: "Admin Guide",
        url: createPageUrl("AdminGuideUtilisateur"),
        icon: Settings,
      },
      {
        title: "Paramètres AOS",
        url: createPageUrl("ParametresAOS"),
        icon: Settings,
      },
    ]
  },
];

export default function Layout({ children, currentPageName }) {
  const [showUpdateBanner, setShowUpdateBanner] = useState(false);
  const [latestVersion, setLatestVersion] = useState(null);

  useEffect(() => {
    // Forcer la langue française et désactiver la traduction automatique pour éviter les erreurs React et les mauvaises traductions (ex: CFO -> Directeur Financier)
    document.documentElement.lang = 'fr';
    document.documentElement.setAttribute('translate', 'no');
    
    // Ajouter la balise meta google notranslate si elle n'existe pas
    if (!document.querySelector('meta[name="google"][content="notranslate"]')) {
      const meta = document.createElement('meta');
      meta.name = 'google';
      meta.content = 'notranslate';
      document.head.appendChild(meta);
    }

    const storedVersion = localStorage.getItem('app_version');
    console.log(`📦 Version actuelle: ${APP_VERSION}, Version stockée: ${storedVersion || 'aucune'}`);
    
    if (storedVersion && storedVersion !== APP_VERSION) {
      console.log(`🔔 Nouvelle version disponible: ${APP_VERSION}`);
      setShowUpdateBanner(true);
    } else if (!storedVersion) {
      localStorage.setItem('app_version', APP_VERSION);
    }
  }, []);

  // Abonnement temps réel aux nouvelles versions publiées
  useEffect(() => {
    const seenKey = "seen_versions";
    const seen = JSON.parse(localStorage.getItem(seenKey) || "[]");

    const unsubscribe = base44.entities.Version.subscribe((event) => {
      if (
        (event.type === "create" || event.type === "update") &&
        event.data?.est_publiee &&
        !seen.includes(event.id)
      ) {
        setLatestVersion(event.data);
      }
    });

    // Charger la dernière version publiée au démarrage
    base44.entities.Version.list("-created_date", 1).then((versions) => {
      const last = versions.find((v) => v.est_publiee);
      if (last && !seen.includes(last.id)) {
        setLatestVersion(last);
      }
    }).catch(() => {});

    return () => unsubscribe();
  }, []);

  const dismissVersion = () => {
    if (latestVersion) {
      const seenKey = "seen_versions";
      const seen = JSON.parse(localStorage.getItem(seenKey) || "[]");
      localStorage.setItem(seenKey, JSON.stringify([...seen, latestVersion.id]));
    }
    setLatestVersion(null);
  };

  // Tracking du temps de connexion avec rôle utilisateur
  useEffect(() => {
    const sessionStartTime = Date.now();
    let userRole = 'user';

    // Récupérer le rôle de l'utilisateur
    const fetchUserRole = async () => {
      try {
        const user = await base44.auth.me();
        if (user?.role) {
          userRole = user.role;
        }
      } catch (error) {
        userRole = 'user';
      }
    };
    
    fetchUserRole();

    const trackSessionDuration = async () => {
      const sessionDuration = Math.round((Date.now() - sessionStartTime) / 1000); // en secondes
      const durationHours = (sessionDuration / 3600).toFixed(2); // en heures avec 2 décimales
      
      try {
        // Récupérer l'utilisateur pour avoir son email
        const user = await base44.auth.me().catch(() => null);
        
        // Sauvegarder dans l'entité SessionAnalytics
        await base44.entities.SessionAnalytics.create({
          duration_seconds: sessionDuration,
          duration_minutes: Math.round(sessionDuration / 60),
          duration_hours: parseFloat(durationHours),
          user_role: userRole,
          user_email: user?.email || 'unknown'
        });
        
        // Aussi tracker dans analytics
        await base44.analytics.track({
          eventName: "session_duration",
          properties: {
            duration_seconds: sessionDuration,
            duration_minutes: Math.round(sessionDuration / 60),
            duration_hours: parseFloat(durationHours),
            user_role: userRole
          }
        });
      } catch (err) {
        console.error('Analytics error:', err);
      }
    };

    // Envoyer l'événement avant que l'utilisateur quitte
    window.addEventListener('beforeunload', trackSessionDuration);

    return () => {
      trackSessionDuration();
      window.removeEventListener('beforeunload', trackSessionDuration);
    };
  }, []);

  // Protection des routes : Redirection vers login si non connecté (sauf pages publiques)
  useEffect(() => {
    const protectRoute = async () => {
      // Liste des pages publiques
      const publicPages = ['depot-offre', 'DepotOffre'];
      
      if (publicPages.includes(currentPageName)) {
        return;
      }

      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        console.log("🔒 Accès non autorisé, redirection vers login");
        await base44.auth.redirectToLogin(window.location.href);
      }
    };

    protectRoute();
  }, [currentPageName]);

  const handleUpdateApp = () => {
    console.log(`🔄 Mise à jour vers la version ${APP_VERSION}`);
    localStorage.setItem('app_version', APP_VERSION);
    sessionStorage.clear();
    
    if ('caches' in window) {
      caches.keys().then(names => {
        names.forEach(name => caches.delete(name));
      });
    }
    
    window.location.reload(true);
  };

  // Layout simplifié pour la page publique de dépôt d'offre
  if (currentPageName === 'depot-offre' || currentPageName === 'DepotOffre') {
    return (
      <>
        {children}
        <Toaster 
          position="top-right"
          expand={false}
          richColors={false}
          closeButton={true}
          duration={1500}
          visibleToasts={2}
          toastOptions={{
            unstyled: false,
            style: {
              background: 'white',
              border: '1px solid #e5e7eb',
              fontSize: '12px',
              padding: '8px 12px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
            },
            classNames: {
              toast: 'toast-ultra-minimal',
              title: 'text-xs',
              description: 'text-xs',
            },
          }}
        />
      </>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 to-blue-50 notranslate" translate="no">
        <Sidebar className="border-r border-gray-200">
          <SidebarHeader className="border-b border-gray-200 p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center shadow-md">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900">GESTIONBAT</h2>
                <p className="text-xs text-gray-500">v{APP_VERSION}</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-2">
            {navigationModules.map((module) => (
              <SidebarGroup key={module.title}>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-700 uppercase tracking-wider px-2 py-3 flex items-center gap-2">
                  <module.icon className="w-4 h-4 text-orange-600" />
                  {module.title}
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  {module.items.length === 0 ? (
                    <div className="px-4 py-2 text-xs text-gray-400 italic">
                      À créer
                    </div>
                  ) : (
                    <SidebarMenu>
                      {module.items.map((item) => (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton 
                            asChild 
                            className="hover:bg-orange-50 hover:text-orange-700 transition-colors duration-200 rounded-lg mb-1"
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-3 py-2">
                              <item.icon className="w-5 h-5" />
                              <span>{item.title}</span>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      ))}
                    </SidebarMenu>
                  )}
                </SidebarGroupContent>
              </SidebarGroup>
            ))}
          </SidebarContent>

          <SidebarFooter className="border-t border-gray-200 p-4">
            <Button 
              variant="outline" 
              className="w-full justify-start gap-2"
              onClick={() => base44.auth.logout()}
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </Button>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
            <div className="flex items-center gap-4 md:hidden">
              <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-semibold">GESTIONBAT v{APP_VERSION}</h1>
            </div>
            <div className="ml-auto">
              <NotificationBell />
            </div>
          </header>

          {latestVersion && (
            <Alert className="m-4 bg-orange-50 border-orange-200">
              <Tag className="h-4 w-4 text-orange-600" />
              <AlertDescription className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-sm text-orange-900">
                  <strong>Nouveauté v{latestVersion.numero} — {latestVersion.titre}</strong>
                  {latestVersion.notes && (
                    <span className="ml-2 text-orange-700 whitespace-pre-line">{latestVersion.notes}</span>
                  )}
                </span>
                <Button size="sm" variant="outline" onClick={dismissVersion} className="text-xs border-orange-300 text-orange-700 hover:bg-orange-100">
                  Fermer
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {showUpdateBanner && (
            <Alert className="m-4 bg-blue-50 border-blue-200">
              <RefreshCw className="h-4 w-4 text-blue-600" />
              <AlertDescription className="flex items-center justify-between">
                <span className="text-sm text-blue-900">
                  <strong>Nouvelle version disponible !</strong> Version {APP_VERSION} avec de nouvelles fonctionnalités.
                </span>
                <div className="flex gap-2 ml-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowUpdateBanner(false)}
                    className="text-xs"
                  >
                    Plus tard
                  </Button>
                  <Button 
                    size="sm"
                    onClick={handleUpdateApp}
                    className="bg-blue-600 hover:bg-blue-700 text-xs"
                  >
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Mettre à jour
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex-1 overflow-auto">
            <div className="p-4">
              <AnnoncesBanner currentPage={currentPageName} />
            </div>
            {children}
          </div>
        </main>
      </div>
      
      <Toaster 
        position="top-right"
        expand={false}
        richColors={false}
        closeButton={true}
        duration={1500}
        visibleToasts={2}
        toastOptions={{
          unstyled: false,
          style: {
            background: 'white',
            border: '1px solid #e5e7eb',
            fontSize: '12px',
            padding: '8px 12px',
            boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          },
          classNames: {
            toast: 'toast-ultra-minimal',
            title: 'text-xs',
            description: 'text-xs',
          },
        }}
      />
    </SidebarProvider>
  );
}