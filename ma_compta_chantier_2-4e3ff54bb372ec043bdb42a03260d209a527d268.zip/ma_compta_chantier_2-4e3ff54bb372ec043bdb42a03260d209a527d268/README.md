/** 
 * © Alice MINARD – Créatrice originale 
 *  
 * Premier commit / origine du projet : 30 octobre 2025 - GB-AM/gestionmoe_app (aliceminard.gb@gmail.com) 
 * Mise à disposition pour usage interne chez GestionBat le 03 mars 2026 (mcc@gestionbat.fr) - GESTIONBAT/Ma_Compta_Chantier 
 *  
 * Ce logiciel a été initié, conçu et développé par Alice MINARD. 
 * Il est protégé par le droit d’auteur français. Toute reproduction, modification ou exploitation 
 * au-delà de l’usage interne chez GestionBat nécessite un accord écrit préalable de l’autrice. 
 */

