import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { utils, write } from 'npm:xlsx@0.18.5';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Récupérer les tranches du chantier si chantier_id fourni
        let tranches = [];
        const body = await req.json().catch(() => ({}));
        const { chantier_id } = body;

        if (chantier_id) {
            const chantiers = await base44.entities.Chantier.list();
            const chantier = chantiers.find(c => c.id === chantier_id);
            if (chantier?.tranches?.length > 0) {
                tranches = chantier.tranches;
            }
        }

        const baseHeaders = [
            "ID Marché (mise à jour)",   // col A — optionnel, si renseigné = mise à jour
            "Date (JJ/MM/AAAA)",
            "N° Lot",
            "Intitulé Lot",
            "Référence Entreprise",
            "Entreprise (Nom ou SIRET)",
            "Montant HT Total",
            "Taux TVA (%)",
            "N° Marché",
            "Avec Caution (Oui/Non)",
            "Notes",
            "Indice BT 1",
            "Indice BT 2",
            "M0 n°1",
            "M0 n°2",
            "Répartition 1 (%)",
            "Répartition 2 (%)",
            "Formule actualisation 1",
            "Formule actualisation 2",
            "Formule révision 1",
            "Formule révision 2"
        ];

        // Ajouter colonnes tranches si elles existent
        const trancheHeaders = tranches.map(t => `Tranche ${t.numero} - ${t.libelle || 'T' + t.numero} (Montant HT)`);
        const headers = [...baseHeaders, ...trancheHeaders];

        const exampleBase = [
            "",                           // ID vide = création
            "01/01/2025",
            "01",
            "Gros Oeuvre",
            "ENT-001",
            "BTP Construction",
            "150000",
            "20",
            "2025-001",
            "Oui",
            "Remarques éventuelles",
            "BT01",
            "BT50",
            "123,4",
            "456,7",
            "70",
            "30",
            "0,15 + 0,85 x (BT01n / BT01m0)",
            "0,15 + 0,85 x (BT50n / BT50m0)",
            "Pn = P0 x (BT01n / BT01m0)",
            "Pn = P0 x (BT50n / BT50m0)"
        ];
        // Montants par tranche exemple (répartition équitable)
        const trancheExample = tranches.map((_, i) => i === 0 ? "90000" : "60000");
        const example = [...exampleBase, ...trancheExample];

        const exampleUpdateBase = [
            "abc123def456",               // ID existant = mise à jour
            "15/03/2025",
            "01",
            "Gros Oeuvre",
            "ENT-001",
            "",
            "162000",
            "20",
            "2025-001",
            "Oui",
            "Montant révisé",
            "BT01",
            "",
            "123,4",
            "",
            "70",
            "",
            "0,15 + 0,85 x (BT01n / BT01m0)",
            "",
            "Pn = P0 x (BT01n / BT01m0)",
            ""
        ];
        const trancheExampleUpdate = tranches.map((_, i) => i === 0 ? "100000" : "62000");
        const exampleUpdate = [...exampleUpdateBase, ...trancheExampleUpdate];

        const wb = utils.book_new();
        const ws = utils.aoa_to_sheet([headers, example, exampleUpdate]);

        // Style colonnes
        const wscols = headers.map(h => ({ wch: Math.max(h.length + 3, 15) }));
        ws['!cols'] = wscols;

        utils.book_append_sheet(wb, ws, "Modèle Import Marchés");

        // Onglet instructions
        const instructionsRows = [
            ["INSTRUCTIONS D'IMPORT"],
            [""],
            ["Colonne A - ID Marché", "Laisser vide pour créer un nouveau marché. Remplir l'ID existant pour mettre à jour un marché existant."],
            ["Colonne C - N° Lot", "Si renseigné et qu'un marché avec le même N° Lot existe déjà, un doublon sera signalé et vous pourrez choisir de remplacer ou d'ajouter."],
            ["Colonnes E/F - Entreprise", "Privilégier la Référence (col E). Si vide, recherche par Nom ou SIRET (col F). Si non trouvé, l'entreprise est créée."],
            ["Colonne G - Montant HT Total", "Montant total HT du marché. Si des colonnes tranches sont renseignées, ce montant sera calculé automatiquement."],
            ["Ligne 2", "Exemple de création (colonne A vide)"],
            ["Ligne 3", "Exemple de mise à jour (colonne A = ID existant)"],
        ];

        if (tranches.length > 0) {
            instructionsRows.push([""], ["TRANCHES / PHASES"]);
            tranches.forEach(t => {
                instructionsRows.push([
                    `Tranche ${t.numero} - ${t.libelle || 'T' + t.numero}`,
                    `Montant HT attribué à la tranche ${t.numero}${t.date_debut ? ` (début: ${t.date_debut})` : ''}${t.date_fin ? ` (fin: ${t.date_fin})` : ''}`
                ]);
            });
            instructionsRows.push(["Note tranches", "Si les colonnes tranches sont renseignées, le Montant HT Total sera automatiquement calculé comme la somme des tranches."]);
        }

        const wsInstructions = utils.aoa_to_sheet(instructionsRows);
        wsInstructions['!cols'] = [{ wch: 35 }, { wch: 90 }];
        utils.book_append_sheet(wb, wsInstructions, "Instructions");

        // Onglet référence tranches
        if (tranches.length > 0) {
            const trancheRefRows = [
                ["N° Tranche", "Libellé", "Date début", "Date fin"],
                ...tranches.map(t => [t.numero, t.libelle || '', t.date_debut || '', t.date_fin || ''])
            ];
            const wsTranches = utils.aoa_to_sheet(trancheRefRows);
            wsTranches['!cols'] = [{ wch: 12 }, { wch: 30 }, { wch: 15 }, { wch: 15 }];
            utils.book_append_sheet(wb, wsTranches, "Référence Tranches");
        }

        const buf = write(wb, { type: "base64", bookType: "xlsx" });

        return Response.json({ success: true, file_base64: buf });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});