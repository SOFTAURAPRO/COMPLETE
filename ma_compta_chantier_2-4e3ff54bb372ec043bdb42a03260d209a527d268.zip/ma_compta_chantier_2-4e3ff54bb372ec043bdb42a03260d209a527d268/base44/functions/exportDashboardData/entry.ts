import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const [
      chantiers, clients, entreprises, partenaires, membreEquipe,
      marches, avenants, travauxSup, certificats, sousTraitances, cieOperations
    ] = await Promise.all([
      base44.asServiceRole.entities.Chantier.list(),
      base44.asServiceRole.entities.Client.list(),
      base44.asServiceRole.entities.Entreprise.list(),
      base44.asServiceRole.entities.Partenaire.list(),
      base44.asServiceRole.entities.MembreEquipe.list(),
      base44.asServiceRole.entities.MarcheEntreprise.list(),
      base44.asServiceRole.entities.Avenant.list(),
      base44.asServiceRole.entities.TravauxSupplementaire.list(),
      base44.asServiceRole.entities.CertificatPaiement.list(),
      base44.asServiceRole.entities.SousTraitance.list(),
      base44.asServiceRole.entities.CieOperation.list()
    ]);

    const exportData = {
      export_date: new Date().toISOString(),
      version: "1.0",
      user: user.email,
      data: {
        chantiers, clients, entreprises, partenaires, membreEquipe,
        marches, avenants, travauxSup, certificats, sousTraitances, cieOperations
      }
    };

    return Response.json({ success: true, export: exportData });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});