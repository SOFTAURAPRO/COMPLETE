import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        if (user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const { entityName, prefix } = await req.json();

        if (!['Entreprise', 'Client', 'Partenaire'].includes(entityName)) {
            return Response.json({ error: 'Invalid entity name' }, { status: 400 });
        }

        const entities = await base44.entities[entityName].list('created_date');

        entities.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

        let maxRef = 0;
        entities.forEach(e => {
            if (e.reference && e.reference.startsWith(prefix + '-')) {
                const num = parseInt(e.reference.split('-')[1]);
                if (!isNaN(num) && num > maxRef) maxRef = num;
            }
        });

        const updates = [];
        let count = 0;

        for (const entity of entities) {
            if (!entity.reference) {
                maxRef++;
                const ref = `${prefix}-${maxRef.toString().padStart(4, '0')}`;
                updates.push(base44.entities[entityName].update(entity.id, { reference: ref }));
                count++;
            }
        }

        await Promise.all(updates);

        return Response.json({
            success: true,
            message: `${count} ${entityName}s updated with references.`,
            count
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});