import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { read, utils } from 'npm:xlsx@0.18.5';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { file_url, chantier_id, duplicate_action } = await req.json();
        // duplicate_action: undefined (first pass - detect), "replace" (update all duplicates), "add" (create new even if duplicate)

        if (!file_url || !chantier_id) {
            return Response.json({ error: "file_url and chantier_id are required" }, { status: 400 });
        }

        // Download file
        const fileRes = await fetch(file_url);
        const arrayBuffer = await fileRes.arrayBuffer();
        const workbook = read(new Uint8Array(arrayBuffer), { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = utils.sheet_to_json(worksheet, { header: 1 });

        // Parse headers to detect tranche columns dynamically
        const headerRow = (jsonData[0] || []).map(h => String(h || '').trim());

        // Detect base column count dynamically by finding the first tranche column
        // Tranche columns contain "(Montant HT)" in their header
        // Base columns are fixed: ID Marché, Date, N° Lot, Intitulé, Ref Ent, Nom/SIRET, Montant HT,
        //   TVA, N° Marché, Caution, Notes, BT1, BT2, M0_1, M0_2, Rep1, Rep2, FormAct1, FormAct2, FormRev1, FormRev2
        // = 21 columns. With "ID Marché" in col A it's still 21 (col A = ID, cols B-U = 20 others).
        // We detect tranche columns by their header containing "(Montant HT)" or by position after col 21.
        const trancheColIndices = []; // [{index, label}]
        for (let i = 0; i < headerRow.length; i++) {
            const h = headerRow[i];
            // A tranche column header contains "(Montant HT)" or starts with "Tranche"
            if (h && (h.includes('(Montant HT)') || h.toLowerCase().startsWith('tranche'))) {
                trancheColIndices.push({ index: i, label: h });
            }
        }

        // Remove header row
        const rows = jsonData.slice(1);

        // Get all enterprises for matching
        const entreprises = await base44.entities.Entreprise.list();
        const entreprisesMap = new Map();
        const entreprisesRefMap = new Map();

        entreprises.forEach(e => {
            if (e.nom) entreprisesMap.set(e.nom.toLowerCase().trim(), e.id);
            if (e.siret) entreprisesMap.set(e.siret.replace(/\s/g, ''), e.id);
            if (e.reference) entreprisesRefMap.set(e.reference.trim(), e.id);
        });

        // Get chantier to access tranches
        const chantiers = await base44.entities.Chantier.list();
        const chantier = chantiers.find(c => c.id === chantier_id);
        const chantierTranches = chantier?.tranches || [];

        // Get existing marchés for this chantier to detect duplicates
        const existingMarches = await base44.entities.MarcheEntreprise.filter({ chantier_id }, '-date', 500);
        const marchesById = new Map();
        const marchesByNumLot = new Map();
        existingMarches.forEach(m => {
            marchesById.set(m.id, m);
            if (m.numero_lot) marchesByNumLot.set(m.numero_lot.trim().toLowerCase(), m);
        });

        const results = {
            success: 0,
            updated: 0,
            failed: 0,
            errors: [],
            duplicates: [] // list of {row_index, intitule_lot, numero_lot, existing_id} for confirmation
        };

        // Helper to parse date (dd/mm/yyyy or Excel serial date)
        const parseDate = (value) => {
            if (!value) return new Date().toISOString().split('T')[0];
            if (typeof value === 'number') {
                const date = new Date(Math.round((value - 25569) * 86400 * 1000));
                return date.toISOString().split('T')[0];
            }
            if (typeof value === 'string') {
                const parts = value.split('/');
                if (parts.length === 3) {
                    return `${parts[2]}-${parts[1]}-${parts[0]}`;
                }
            }
            return new Date().toISOString().split('T')[0];
        };

        // First pass: detect duplicates (only when no duplicate_action given)
        if (duplicate_action === undefined) {
            for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
                const row = rows[rowIdx];
                if (!row || row.length === 0) continue;
                const marcheIdRaw = row[0];
                const numeroLot = row[2];
                const intituleLot = row[3];
                if (!intituleLot) continue;

                // Check if it's a duplicate (no explicit ID, but same numero_lot exists)
                if (!marcheIdRaw && numeroLot) {
                    const existing = marchesByNumLot.get(String(numeroLot).trim().toLowerCase());
                    if (existing) {
                        results.duplicates.push({
                            row_index: rowIdx,
                            intitule_lot: String(intituleLot),
                            numero_lot: String(numeroLot),
                            existing_id: existing.id,
                            existing_intitule: existing.intitule_lot
                        });
                    }
                }
            }

            // If duplicates found, return them for user confirmation
            if (results.duplicates.length > 0) {
                return Response.json({ duplicates_detected: true, duplicates: results.duplicates });
            }
        }

        // Second pass (or first if no duplicates): actually import
        for (let rowIdx = 0; rowIdx < rows.length; rowIdx++) {
            const row = rows[rowIdx];
            if (!row || row.length === 0) continue;

            const [
                marcheIdRaw,
                dateRaw,
                numeroLot,
                intituleLot,
                refEntreprise,
                nomOuSiretEntreprise,
                montantHTRaw,
                tauxTVA,
                numeroMarche,
                avecCaution,
                notes,
                indiceBt1,
                indiceBt2,
                m0_1,
                m0_2,
                repartition1,
                repartition2,
                formuleActualisation1,
                formuleActualisation2,
                formuleRevision1,
                formuleRevision2
            ] = row;

            if (!intituleLot) {
                results.failed++;
                results.errors.push(`Ligne ${rowIdx + 2} ignorée: Intitulé manquant`);
                continue;
            }

            // Parse tranche amounts
            const tranchesMontants = [];
            let montantHTFromTranches = 0;
            if (trancheColIndices.length > 0) {
                trancheColIndices.forEach((tc, idx) => {
                    const valRaw = row[tc.index];
                    const montantT = parseFloat(String(valRaw || '0').replace(',', '.')) || 0;
                    montantHTFromTranches += montantT;
                    // Map to chantier tranche if available
                    const chantierTranche = chantierTranches[idx];
                    tranchesMontants.push({
                        tranche_numero: chantierTranche?.numero || (idx + 1),
                        tranche_libelle: chantierTranche?.libelle || tc.label,
                        montant_ht: montantT
                    });
                });
            }

            // Montant HT: use tranches sum if tranches present, else column G
            const montantHT = tranchesMontants.length > 0 && montantHTFromTranches > 0
                ? montantHTFromTranches
                : (parseFloat(String(montantHTRaw || '0').replace(',', '.')) || 0);

            if (!montantHT) {
                results.failed++;
                results.errors.push(`Ligne ${rowIdx + 2} ignorée: Montant HT manquant (${intituleLot})`);
                continue;
            }

            let entrepriseId = null;

            if (refEntreprise) {
                const refKey = String(refEntreprise).trim();
                entrepriseId = entreprisesRefMap.get(refKey);
                if (!entrepriseId && nomOuSiretEntreprise) {
                    // Fallback: chercher par nom ou SIRET
                    const key = String(nomOuSiretEntreprise).toLowerCase().trim();
                    const siretKey = String(nomOuSiretEntreprise).replace(/\s/g, '');
                    entrepriseId = entreprisesMap.get(key) || entreprisesMap.get(siretKey);
                }
                if (!entrepriseId && nomOuSiretEntreprise) {
                    // Créer l'entreprise avec le nom fourni
                    try {
                        const newEnt = await base44.entities.Entreprise.create({ nom: String(nomOuSiretEntreprise).trim(), reference: String(refEntreprise).trim() });
                        entrepriseId = newEnt.id;
                        entreprisesMap.set(newEnt.nom.toLowerCase().trim(), newEnt.id);
                        entreprisesRefMap.set(String(refEntreprise).trim(), newEnt.id);
                    } catch (e) {
                        console.error("Failed to create entreprise", e);
                    }
                }
                if (!entrepriseId) {
                    results.failed++;
                    results.errors.push(`Ligne ${rowIdx + 2} ignorée: Entreprise avec référence '${refEntreprise}' introuvable.`);
                    continue;
                }
            } else if (nomOuSiretEntreprise) {
                const key = String(nomOuSiretEntreprise).toLowerCase().trim();
                const siretKey = String(nomOuSiretEntreprise).replace(/\s/g, '');
                entrepriseId = entreprisesMap.get(key) || entreprisesMap.get(siretKey);
                if (!entrepriseId) {
                    try {
                        const newEnt = await base44.entities.Entreprise.create({ nom: String(nomOuSiretEntreprise).trim() });
                        entrepriseId = newEnt.id;
                        entreprisesMap.set(newEnt.nom.toLowerCase().trim(), newEnt.id);
                    } catch (e) {
                        console.error("Failed to create entreprise", e);
                    }
                }
            }

            const marcheData = {
                chantier_id,
                entreprise_id: entrepriseId,
                date: parseDate(dateRaw),
                numero_lot: String(numeroLot || ""),
                intitule_lot: String(intituleLot || ""),
                montant: montantHT,
                taux_tva: parseFloat(tauxTVA || 20),
                numero_marche: String(numeroMarche || ""),
                a_caution: String(avecCaution || "").toLowerCase() === 'oui',
                notes: String(notes || ""),
                indice_bt_1: String(indiceBt1 || ""),
                indice_bt_2: String(indiceBt2 || ""),
                m0_1: String(m0_1 || ""),
                m0_2: String(m0_2 || ""),
                repartition_1: repartition1 ? parseFloat(repartition1) : null,
                repartition_2: repartition2 ? parseFloat(repartition2) : null,
                formule_actualisation_1: String(formuleActualisation1 || ""),
                formule_actualisation_2: String(formuleActualisation2 || ""),
                formule_revision_1: String(formuleRevision1 || ""),
                formule_revision_2: String(formuleRevision2 || ""),
                tranches_montants: tranchesMontants.length > 0 ? tranchesMontants : undefined
            };

            // Remove undefined fields
            Object.keys(marcheData).forEach(k => marcheData[k] === undefined && delete marcheData[k]);

            // Determine if update or create
            let existingMarche = null;

            // Priority 1: explicit ID in col A
            if (marcheIdRaw) {
                const idStr = String(marcheIdRaw).trim();
                existingMarche = marchesById.get(idStr);
            }

            // Priority 2: same numero_lot
            if (!existingMarche && numeroLot) {
                existingMarche = marchesByNumLot.get(String(numeroLot).trim().toLowerCase());
            }

            try {
                if (existingMarche) {
                    if (duplicate_action === 'add') {
                        // Force create even if duplicate
                        await base44.entities.MarcheEntreprise.create(marcheData);
                        results.success++;
                    } else {
                        // Default: replace (update)
                        await base44.entities.MarcheEntreprise.update(existingMarche.id, marcheData);
                        results.updated++;
                    }
                } else {
                    await base44.entities.MarcheEntreprise.create(marcheData);
                    results.success++;
                }
            } catch (err) {
                results.failed++;
                results.errors.push(`Erreur ${existingMarche ? 'mise à jour' : 'création'} marché ${intituleLot}: ${err.message}`);
            }
        }

        return Response.json(results);

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});