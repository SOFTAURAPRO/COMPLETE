import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { Resend } from 'npm:resend@4.0.0';

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const resend = new Resend(RESEND_API_KEY);

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { entreprise_email, appel_offre_titre, lots_names } = await req.json();

    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: "Configuration Resend manquante (RESEND_API_KEY)" }), { status: 500 });
    }

    const htmlContent = `
      <html>
        <body>
          <h2>Accusé de réception de votre offre</h2>
          <p>Bonjour,</p>
          <p>Nous confirmons la bonne réception de votre offre pour l'appel d'offres : <strong>${appel_offre_titre}</strong>.</p>
          <p>Lots concernés :</p>
          <ul>
            ${lots_names.map(name => `<li>${name}</li>`).join('')}
          </ul>
          <p>Vos documents ont bien été enregistrés sur notre plateforme sécurisée.</p>
          <p>Cordialement,<br/>L'équipe GESTIONBAT</p>
        </body>
      </html>
    `;

    await resend.emails.send({
      from: 'GESTIONBAT <onboarding@resend.dev>',
      to: [entreprise_email],
      subject: `Confirmation de dépôt - ${appel_offre_titre}`,
      html: htmlContent,
    });

    console.log(`✅ Email de confirmation envoyé à ${entreprise_email}`);

    return new Response(JSON.stringify({ success: true }), { 
      status: 200, 
      headers: { "Content-Type": "application/json" } 
    });

  } catch (error) {
    console.error("❌ Erreur confirmDepotOffre:", error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
});