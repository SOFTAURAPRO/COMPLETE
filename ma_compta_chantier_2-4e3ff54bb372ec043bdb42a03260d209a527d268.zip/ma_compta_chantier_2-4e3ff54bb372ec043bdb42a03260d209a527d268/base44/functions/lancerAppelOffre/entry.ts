import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { Resend } from 'npm:resend@4.0.0';

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
const resend = new Resend(RESEND_API_KEY);

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { appel_offre_id, entreprises } = await req.json();

    if (!appel_offre_id || !entreprises || !Array.isArray(entreprises) || entreprises.length === 0) {
      return Response.json({ error: "Paramètres invalides" }, { status: 400 });
    }

    const aos = await base44.entities.AppelOffre.filter({ id: appel_offre_id });
    const ao = aos[0];

    if (!ao) return Response.json({ error: "Appel d'offre introuvable" }, { status: 404 });

    const batchEmails = [];
    const emailToTokenMap = {};

    for (const email of entreprises) {
      try {
        const token = crypto.randomUUID();
        const trackingLink = `https://chantier-pro-35ac6014.base44.app/depot-offre?token=${token}`;

        await base44.asServiceRole.entities.EnvoiMail.create({
          appel_offre_id: ao.id,
          entreprise_email: email.trim(),
          token,
          lien_tracke: trackingLink,
          dce_url: ao.dce_file || "",
          date_envoi: new Date().toISOString(),
          telecharge: false,
          statut: "envoyé"
        });

        const client = ao.client_id ? (await base44.asServiceRole.entities.Client.filter({ id: ao.client_id }))[0] : null;
        const infoGestionbat = (await base44.asServiceRole.entities.InfoGestionbat.list())[0] || {};
        const responsable = ao.responsable_economie_id ? (await base44.asServiceRole.entities.MembreEquipe.filter({ id: ao.responsable_economie_id }))[0] : null;

        const lots = await base44.asServiceRole.entities.Lot.filter({ appel_offre_id: ao.id });
        const lotsSorted = lots.sort((a, b) => {
          const numA = parseInt(a.nom_lot.match(/\d+/)?.[0] || '0');
          const numB = parseInt(b.nom_lot.match(/\d+/)?.[0] || '0');
          return numA - numB;
        });
        const lotsText = lotsSorted.map(l => l.nom_lot).join(', ') || 'Lots à définir';

        const questionLink = `https://chantier-pro-35ac6014.base44.app/poser-question?token=${token}`;
        const dateFormatee = ao.date_limite ? new Date(ao.date_limite).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }) : "Non précisée";

        const htmlBody = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 700px; margin: 0 auto; padding: 20px; }
              .btn { display: inline-block; padding: 10px 20px; margin: 5px 5px 5px 0; text-decoration: none; border-radius: 5px; font-weight: bold; color: white; }
              .btn-primary { background: #2563eb; }
              .btn-success { background: #16a34a; }
              .btn-danger { background: #dc2626; }
              .btn-warning { background: #ea580c; }
              .signature { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px; }
              .footer { margin-top: 30px; text-align: center; }
              .footer img { max-width: 120px; margin-top: 10px; }
            </style>
          </head>
          <body>
            <div>
              <p><strong>Objet :</strong> Lancement AO - ${ao.titre}</p>
            </div>
            <div>
              <p>Madame, Monsieur,</p>
              <p>Nous vous invitons à participer à l'appel d'offre concernant <strong>${ao.titre}</strong>, situé <strong>${ao.adresse || ''} ${ao.code_postal || ''} ${ao.ville || ''}</strong>.</p>
              ${ao.date_debut ? `<p><strong>Date prévue de démarrage des travaux :</strong> ${new Date(ao.date_debut).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}</p>` : ''}
              <p><strong>Liste des lots :</strong> ${lotsText}</p>
              <div>
                <p>Vous pouvez dès à présent télécharger le DCE</p>
                ${ao.dce_file ? `<a href="${ao.dce_file}" class="btn btn-primary">📥 Télécharger le DCE</a>` : ''}
                <p style="margin-top: 20px;">Nous vous serions reconnaissant de bien vouloir nous indiquer si vous souhaitez répondre à cette consultation :</p>
                <a href="${trackingLink}" class="btn btn-success">✓ Je vais remettre une offre</a>
                <a href="${trackingLink}" class="btn btn-danger">✗ Je ne remettrai pas d'offre</a>
                <p style="margin-top: 20px;">Si vous avez des questions concernant cette consultation merci d'utiliser le bouton ci-après :</p>
                <a href="${questionLink}" class="btn btn-primary">❓ Questions / Réponses</a>
                <p style="margin-top: 20px;">Votre offre est à remettre avant le <strong>${dateFormatee}</strong> :</p>
                <a href="${trackingLink}" class="btn btn-warning">📤 Déposer mon offre</a>
              </div>
              <div class="signature">
                <p>Bien Cordialement,</p>
                <p>${responsable ? `${responsable.civilite || ''} ${responsable.prenom || ''} ${responsable.nom || ''}` : "Personne en charge de l'AO"}</p>
                <p><a href="https://www.gestionbat.fr" style="color: #2563eb;">www.gestionbat.fr</a></p>
              </div>
            </div>
            <div class="footer">
              ${infoGestionbat?.logo_url ? `<img src="${infoGestionbat.logo_url}" alt="Logo GESTIONBAT" />` : '<strong>GESTIONBAT</strong>'}
            </div>
          </body>
          </html>
        `;

        batchEmails.push({
          from: 'GESTIONBAT <onboarding@resend.dev>',
          to: email.trim(),
          subject: `Consultation : ${ao.titre}`,
          html: htmlBody,
        });

        emailToTokenMap[email.trim()] = token;

      } catch (err) {
        console.error(`❌ Erreur création EnvoiMail pour ${email}:`, err);
      }
    }

    const results = [];
    for (const emailObj of batchEmails) {
      try {
        await resend.emails.send(emailObj);
        console.log(`✅ Email envoyé via Resend à ${emailObj.to}`);
        results.push({ email: emailObj.to, status: "sent" });
      } catch (err) {
        console.error(`❌ Échec envoi à ${emailObj.to}:`, err);
        results.push({ email: emailObj.to, status: "error", error: err.message });
      }
    }

    return Response.json({ success: true, results });

  } catch (error) {
    console.error("Erreur globale fonction lancerAppelOffre :", error);
    return Response.json({ error: "Erreur interne", details: error.message }, { status: 500 });
  }
});