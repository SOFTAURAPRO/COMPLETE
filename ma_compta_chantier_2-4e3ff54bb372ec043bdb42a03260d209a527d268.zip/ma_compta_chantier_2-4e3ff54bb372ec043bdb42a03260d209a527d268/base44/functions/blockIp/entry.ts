import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        if (user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const { ip_address, reason } = await req.json();

        if (!ip_address) {
            return Response.json({ error: "IP address is required" }, { status: 400 });
        }

        await base44.asServiceRole.entities.BlockedIp.create({
            ip_address,
            reason: reason || "Blocage automatique par Sentinelle Sécurité",
            blocked_at: new Date().toISOString()
        });

        console.log(`[SECURITY] Blocked IP: ${ip_address} - Reason: ${reason}`);

        return Response.json({ success: true, message: `IP ${ip_address} bloquée avec succès` });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});