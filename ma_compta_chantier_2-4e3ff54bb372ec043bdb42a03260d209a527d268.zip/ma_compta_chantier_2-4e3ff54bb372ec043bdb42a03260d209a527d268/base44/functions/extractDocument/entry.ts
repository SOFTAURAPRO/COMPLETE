import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

const BACKEND_URL = "https://base44-backend.onrender.com";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Vérifier l'authentification
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { document } = await req.json();
    
    if (!document) {
      return Response.json({ 
        error: 'Document manquant. Fournissez une URL ou base64.' 
      }, { status: 400 });
    }

    // Préparer le body pour l'API externe
    const bodyData = {
      document: document
    };

    // Appel à l'API externe
    const response = await fetch(`${BACKEND_URL}/extract_from_certificate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bodyData)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erreur API externe: ${response.status} - ${errorText}`);
    }

    const result = await response.json();

    return Response.json({
      success: true,
      extracted_data: result.extracted_data || result,
      message: 'Données extraites avec succès'
    });

  } catch (error) {
    console.error('Erreur extraction document:', error);
    return Response.json({ 
      error: error.message || 'Erreur lors de l\'extraction du document',
      success: false 
    }, { status: 500 });
  }
});