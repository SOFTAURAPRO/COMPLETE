import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token, question, lot_id, document_url } = await req.json();

    if (!token || !question) {
      return Response.json({ error: "Paramètres invalides" }, { status: 400 });
    }

    // 1. Vérifier le token
    const envois = await base44.asServiceRole.entities.EnvoiMail.filter({ token });
    if (!envois || envois.length === 0) {
      return Response.json({ error: "Token invalide" }, { status: 403 });
    }

    const envoi = envois[0];

    // 2. Créer la question
    const questionReponse = await base44.asServiceRole.entities.QuestionReponse.create({
      appel_offre_id: envoi.appel_offre_id,
      lot_id: lot_id || null,
      entreprise_email: envoi.entreprise_email,
      question,
      date_envoi: new Date().toISOString(),
      document_question_url: document_url || null
    });

    console.log(`✅ Question créée - ID: ${questionReponse.id}, Email: ${envoi.entreprise_email}`);

    // 3. Créer une notification
    const appelOffre = await base44.asServiceRole.entities.AppelOffre.get(envoi.appel_offre_id);
    let lot = null;
    if (lot_id) {
      lot = await base44.asServiceRole.entities.Lot.get(lot_id);
    }

    await base44.asServiceRole.entities.Notification.create({
      type: "autre",
      titre: "Nouvelle question reçue",
      message: `${envoi.entreprise_email} a posé une question sur ${lot ? lot.nom_lot : "l'appel d'offres"}`,
      lien: `/economie?ao=${envoi.appel_offre_id}`,
      lue: false,
      data: {
        entreprise_email: envoi.entreprise_email,
        appel_offre_id: envoi.appel_offre_id,
        question_id: questionReponse.id
      }
    });

    console.log("🔔 Notification créée");

    return Response.json({ success: true });

  } catch (error) {
    console.error("❌ Erreur poserQuestion:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});