import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { PDFDocument } from 'npm:pdf-lib@1.17.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { pdfs } = await req.json();
    
    if (!pdfs || !Array.isArray(pdfs) || pdfs.length < 2) {
      return Response.json({ error: 'Au moins 2 PDFs requis pour la fusion' }, { status: 400 });
    }

    console.log(`Fusion de ${pdfs.length} PDFs...`);

    // Créer un nouveau document PDF vide
    const mergedPdf = await PDFDocument.create();

    // Parcourir chaque PDF et l'ajouter au document fusionné
    for (let i = 0; i < pdfs.length; i++) {
      const pdf = pdfs[i];
      let pdfBytes;

      try {
        if (typeof pdf === 'string') {
          // Si c'est une URL
          if (pdf.startsWith('http://') || pdf.startsWith('https://')) {
            console.log(`PDF ${i}: Téléchargement depuis URL...`);
            const response = await fetch(pdf);
            if (!response.ok) {
              throw new Error(`Erreur téléchargement: ${response.status}`);
            }
            pdfBytes = new Uint8Array(await response.arrayBuffer());
          } 
          // Si c'est du base64
          else {
            console.log(`PDF ${i}: Décodage base64 (${pdf.length} chars)...`);
            // Nettoyer le préfixe data: si présent
            const base64Clean = pdf.startsWith('data:') 
              ? pdf.split(',')[1] 
              : pdf;
            
            // Décoder le base64 de manière plus efficace
            const binaryString = atob(base64Clean);
            const len = binaryString.length;
            const bytes = new Uint8Array(len);
            for (let j = 0; j < len; j++) {
              bytes[j] = binaryString.charCodeAt(j);
            }
            pdfBytes = bytes;
          }
        } 
        else if (pdf?.url) {
          console.log(`PDF ${i}: Téléchargement depuis URL (objet)...`);
          const response = await fetch(pdf.url);
          if (!response.ok) {
            throw new Error(`Erreur téléchargement: ${response.status}`);
          }
          pdfBytes = new Uint8Array(await response.arrayBuffer());
        } 
        else if (pdf?.base64) {
          console.log(`PDF ${i}: Décodage base64 (objet)...`);
          const base64Clean = pdf.base64.startsWith('data:') 
            ? pdf.base64.split(',')[1] 
            : pdf.base64;
          
          const binaryString = atob(base64Clean);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let j = 0; j < len; j++) {
            bytes[j] = binaryString.charCodeAt(j);
          }
          pdfBytes = bytes;
        } 
        else {
          throw new Error(`Format invalide pour PDF ${i}`);
        }

        // Charger le PDF et copier ses pages
        console.log(`PDF ${i}: Chargement (${pdfBytes.length} bytes)...`);
        const pdfDoc = await PDFDocument.load(pdfBytes, { ignoreEncryption: true });
        const pageCount = pdfDoc.getPageCount();
        console.log(`PDF ${i}: ${pageCount} page(s)`);
        
        // Copier toutes les pages
        const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
        copiedPages.forEach(page => mergedPdf.addPage(page));
        
        console.log(`PDF ${i}: ✅ ${pageCount} pages ajoutées`);
      } catch (pdfError) {
        console.error(`Erreur PDF ${i}:`, pdfError.message);
        throw new Error(`Erreur PDF ${i}: ${pdfError.message}`);
      }
    }

    // Générer le PDF fusionné
    console.log('Génération du PDF final...');
    const mergedPdfBytes = await mergedPdf.save();
    
    // Convertir en base64
    const uint8Array = new Uint8Array(mergedPdfBytes);
    let binary = '';
    const chunkSize = 0x8000; // 32KB chunks pour éviter stack overflow
    for (let i = 0; i < uint8Array.length; i += chunkSize) {
      const chunk = uint8Array.subarray(i, Math.min(i + chunkSize, uint8Array.length));
      binary += String.fromCharCode.apply(null, Array.from(chunk));
    }
    const base64 = btoa(binary);
    
    console.log(`✅ Fusion réussie: ${mergedPdf.getPageCount()} pages, ${base64.length} chars base64`);

    return Response.json({
      success: true,
      merged_pdf_base64: base64,
      pages: mergedPdf.getPageCount()
    });

  } catch (error) {
    console.error('Erreur fusion:', error);
    return Response.json({ 
      error: error.message || 'Erreur fusion PDFs',
      success: false 
    }, { status: 500 });
  }
});