import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const BACKEND_URL = "https://base44-backend.onrender.com";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    console.log('htmlToPdf appelé - payload:', JSON.stringify(body, null, 2));

    const { html_content, css } = body;
    if (!html_content) {
      return Response.json({ error: 'Contenu HTML requis' }, { status: 400 });
    }

    const htmlBody = { html_content, css: css || '' };
    const response = await fetch(`${BACKEND_URL}/html_to_pdf`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(htmlBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erreur /html_to_pdf: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('PDF base64 reçu - length:', result.pdf_base64?.length || 0);

    return Response.json({
      success: true,
      pdf_base64: result.pdf_base64,
      message: 'PDF généré'
    });

  } catch (error) {
    console.error('Erreur htmlToPdf:', error);
    return Response.json({ error: error.message, success: false }, { status: 500 });
  }
});