import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token } = await req.json();

    if (!token) {
      return Response.json({ error: "Token manquant" }, { status: 400 });
    }

    console.log("🔍 Recherche token:", token);

    // Utilisation de asServiceRole pour accéder aux données sans authentification
    const envois = await base44.asServiceRole.entities.EnvoiMail.filter({ token });
    console.log("📧 EnvoiMail trouvés:", envois.length);

    if (envois.length === 0) {
      return Response.json({ valid: false }, { status: 200 });
    }

    const envoi = envois[0];

    let appelOffre = null;
    if (envoi.appel_offre_id) {
        const aos = await base44.asServiceRole.entities.AppelOffre.filter({ id: envoi.appel_offre_id });
        if (aos.length > 0) appelOffre = aos[0];
    }

    if (!appelOffre) {
      console.error("❌ Appel d'offre introuvable pour envoi:", envoi.id);
      return Response.json({ valid: false }, { status: 200 });
    }

    // Récupérer tous les lots de l'AO
    const allLots = await base44.asServiceRole.entities.Lot.filter({ appel_offre_id: appelOffre.id });

    // Récupérer les offres existantes pour cette entreprise
    const existingOffers = await base44.asServiceRole.entities.OffreParLot.filter({ 
      appel_offre_id: appelOffre.id,
      entreprise_email: envoi.entreprise_email
    });

    console.log("✅ Données récupérées:", {
      envoi: envoi.id,
      appelOffre: appelOffre.titre,
      lots: allLots.length,
      offres: existingOffers.length
    });

    return Response.json({ 
        valid: true, 
        envoi,
        lots: allLots,
        appelOffre,
        existingOffers
    });

  } catch (error) {
    console.error("❌ Erreur checkDepotToken:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});