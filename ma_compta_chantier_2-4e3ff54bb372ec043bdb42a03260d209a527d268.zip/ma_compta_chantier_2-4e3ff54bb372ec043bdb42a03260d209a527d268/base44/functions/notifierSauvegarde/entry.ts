import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const dateSauvegarde = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    const defaultDossiers = {
      '1_marches': true,
      '2_cautions': true,
      '3_certificats': true,
      '4_avenants': true,
      '5_ts_avenants': true,
      '6_ts_attente': true,
      '7_cie': true,
      '8_sous_traitance': true,
      '9_en_cours': true,
    };

    await base44.asServiceRole.entities.SauvegardeNotification.create({
      date_sauvegarde: dateSauvegarde,
      dossiers_selectionnes: defaultDossiers,
      statut: 'en_attente',
    });

    return Response.json({ success: true, date_sauvegarde: dateSauvegarde });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});