import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ success: false, error: 'Admin only' }, { status: 403 });
    }

    const [
      clients, entreprises, partenaires, chantiers,
      marches, avenants, travauxSup, certificats,
      sousTraitances, cieOperations
    ] = await Promise.all([
      base44.asServiceRole.entities.Client.list(),
      base44.asServiceRole.entities.Entreprise.list(),
      base44.asServiceRole.entities.Partenaire.list(),
      base44.asServiceRole.entities.Chantier.list(),
      base44.asServiceRole.entities.MarcheEntreprise.list(),
      base44.asServiceRole.entities.Avenant.list(),
      base44.asServiceRole.entities.TravauxSupplementaire.list(),
      base44.asServiceRole.entities.CertificatPaiement.list(),
      base44.asServiceRole.entities.SousTraitance.list(),
      base44.asServiceRole.entities.CieOperation.list()
    ]);

    const exportData = {
      export_date: new Date().toISOString(),
      version: "2.9",
      data: {
        clients,
        entreprises,
        partenaires,
        chantiers,
        marches,
        avenants,
        travauxSup,
        certificats,
        sousTraitances,
        cieOperations
      }
    };

    return Response.json({ success: true, export: exportData });

  } catch (e) {
    console.error(e);
    return Response.json({ success: false, error: e.message }, { status: 500 });
  }
});