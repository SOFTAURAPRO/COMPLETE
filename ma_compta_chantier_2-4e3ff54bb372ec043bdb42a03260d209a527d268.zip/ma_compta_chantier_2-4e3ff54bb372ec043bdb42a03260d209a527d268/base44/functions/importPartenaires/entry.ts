import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import * as XLSX from 'npm:xlsx';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { file_url } = await req.json();
    if (!file_url) {
      return Response.json({ error: 'File URL is required' }, { status: 400 });
    }

    const fileResponse = await fetch(file_url);
    const fileBuffer = await fileResponse.arrayBuffer();
    const workbook = XLSX.read(fileBuffer);

    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    if (rows.length < 2) {
      return Response.json({ error: "Le fichier est vide ou ne contient pas de données" }, { status: 400 });
    }

    const dataRows = rows.slice(1);
    const results = { created: 0, updated: 0, errors: 0, duplicates: [] };

    for (const row of dataRows) {
      if (!row[0]) continue;

      const missions = row[2] ? String(row[2]).split(',').map(s => s.trim()) : [];

      const partenaireData = {
        nom: row[0],
        forme_juridique: row[1] || null,
        missions: missions,
        mission: missions.length > 0 ? missions[0] : null, // Backward compatibility
        adresse_1: row[3] || "",
        adresse_2: row[4] || "",
        code_postal: row[5] ? String(row[5]) : "",
        ville: row[6] || "",
        telephone: row[7] ? String(row[7]) : "",
        siret: row[8] ? String(row[8]).replace(/\s/g, '') : "",
        contacts: []
      };

      // Extract Contact 1 (indices 9-16)
      if (row[10]) { // If Nom is present
        partenaireData.contacts.push({
          civilite: row[9] || "Monsieur",
          nom: row[10],
          prenom: row[11] || "",
          fonction: row[12] || "",
          service: row[13] || "Autre",
          email: row[14] || "",
          telephone: row[15] ? String(row[15]) : "",
          portable: row[16] ? String(row[16]) : ""
        });
      }

      // Extract Contact 2 (indices 17-24)
      if (row[18]) { // If Nom is present
        partenaireData.contacts.push({
          civilite: row[17] || "Monsieur",
          nom: row[18],
          prenom: row[19] || "",
          fonction: row[20] || "",
          service: row[21] || "Autre",
          email: row[22] || "",
          telephone: row[23] ? String(row[23]) : "",
          portable: row[24] ? String(row[24]) : ""
        });
      }

      try {
        let existingPartenaire = null;
        
        if (partenaireData.siret) {
          const search = await base44.entities.Partenaire.list();
          existingPartenaire = search.find(e => e.siret === partenaireData.siret);
        }
        
        if (!existingPartenaire) {
           const search = await base44.entities.Partenaire.list();
           existingPartenaire = search.find(e => e.nom.toLowerCase() === partenaireData.nom.toLowerCase());
        }

        if (existingPartenaire) {
          // Ne pas mettre à jour automatiquement, ajouter à la liste des doublons
          if (!results.duplicates) results.duplicates = [];
          results.duplicates.push({
            existing: existingPartenaire,
            new: partenaireData
          });
        } else {
          await base44.entities.Partenaire.create(partenaireData);
          results.created++;
        }
      } catch (err) {
        console.error(`Erreur import ligne ${row[0]}:`, err);
        results.errors++;
      }
    }

    return Response.json({ success: true, results });

  } catch (error) {
    console.error("Erreur lors de l'import:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});