import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { envoi_id } = await req.json();

    if (!envoi_id) {
      return Response.json({ error: "envoi_id requis" }, { status: 400 });
    }

    await base44.asServiceRole.entities.EnvoiMail.update(envoi_id, {
      telecharge: true,
      date_telechargement: new Date().toISOString()
    });

    return Response.json({ success: true });

  } catch (error) {
    console.error("❌ Erreur updateEnvoiTelecharge:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});