import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import * as XLSX from 'npm:xlsx';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { file_url } = await req.json();

    if (!file_url) {
      return Response.json({ error: 'File URL is required' }, { status: 400 });
    }

    // Télécharger le fichier
    const fileResponse = await fetch(file_url);
    const fileBuffer = await fileResponse.arrayBuffer();
    const workbook = XLSX.read(fileBuffer);

    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Convertir en JSON (tableau de tableaux pour gérer les entêtes nous-mêmes ou tableau d'objets)
    // On utilise tableau de tableaux pour mapper par index car les noms de colonnes peuvent varier légèrement
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    if (rows.length < 2) {
      return Response.json({ error: "Le fichier est vide ou ne contient pas de données" }, { status: 400 });
    }

    // On saute la première ligne (entêtes)
    const dataRows = rows.slice(1);
    const results = { created: 0, updated: 0, errors: 0, duplicates: [] };

    for (const row of dataRows) {
      if (!row[0]) continue; // Ignorer les lignes sans nom d'entreprise

      // Mapping des colonnes selon l'ordre défini dans le template
      const entrepriseData = {
        nom: row[0],
        forme_juridique: row[1] || "",
        adresse_1: row[2] || "",
        adresse_2: row[3] || "",
        code_postal: row[4] ? String(row[4]) : "",
        ville: row[5] || "",
        telephone: row[6] ? String(row[6]) : "",
        siret: row[7] ? String(row[7]).replace(/\s/g, '') : "",
        corps_etat: row[8] ? String(row[8]).split(',').map(s => s.trim()) : [],
        representant_civilite: row[9] || "",
        representant_nom: row[10] || "",
        representant_prenom: row[11] || "",
        representant_qualite: row[12] || "",
        contact_ao: {
          civilite: row[13] || "",
          nom: row[14] || "",
          prenom: row[15] || "",
          email: row[16] || "",
          telephone: row[17] ? String(row[17]) : "",
          portable: row[18] ? String(row[18]) : ""
        },
        contact_comptabilite: {
          civilite: row[19] || "",
          nom: row[20] || "",
          prenom: row[21] || "",
          email: row[22] || "",
          telephone: row[23] ? String(row[23]) : ""
        },
        contacts: []
      };

      // Extract Autre Contact 1 (indices 24-31)
      if (row[25]) { // If Nom is present
        entrepriseData.contacts.push({
          civilite: row[24] || "Monsieur",
          nom: row[25],
          prenom: row[26] || "",
          fonction: row[27] || "",
          service: row[28] || "Autre",
          email: row[29] || "",
          telephone: row[30] ? String(row[30]) : "",
          portable: row[31] ? String(row[31]) : ""
        });
      }

      // Extract Autre Contact 2 (indices 32-39)
      if (row[33]) { // If Nom is present
        entrepriseData.contacts.push({
          civilite: row[32] || "Monsieur",
          nom: row[33],
          prenom: row[34] || "",
          fonction: row[35] || "",
          service: row[36] || "Autre",
          email: row[37] || "",
          telephone: row[38] ? String(row[38]) : "",
          portable: row[39] ? String(row[39]) : ""
        });
      }

      // Nettoyer les objets vides
      if (!Object.values(entrepriseData.contact_ao).some(v => v)) delete entrepriseData.contact_ao;
      if (!Object.values(entrepriseData.contact_comptabilite).some(v => v)) delete entrepriseData.contact_comptabilite;

      try {
        // Vérifier si l'entreprise existe déjà par SIRET (si présent) ou Nom
        let existingEntreprise = null;
        
        if (entrepriseData.siret) {
          const searchBySiret = await base44.entities.Entreprise.list(); // Pas optimal mais filtre pas dispo sur siret direct ? On va filtrer en JS si nécessaire ou via query filter
          // Optimisation: utiliser filter si possible.
          // Comme je ne suis pas sûr du filtre exact sur champs string, je vais lister et trouver.
          // Pour être plus efficace :
          // const search = await base44.entities.Entreprise.filter({ siret: entrepriseData.siret });
          // Mais filter retourne un array.
          const search = await base44.entities.Entreprise.list(); // On liste tout pour l'instant car pas de filtre précis doc
          existingEntreprise = search.find(e => e.siret === entrepriseData.siret);
        }
        
        if (!existingEntreprise) {
           // Fallback sur le nom si pas de SIRET ou pas trouvé
           const search = await base44.entities.Entreprise.list();
           existingEntreprise = search.find(e => e.nom.toLowerCase() === entrepriseData.nom.toLowerCase());
        }

        if (existingEntreprise) {
          // Ne pas mettre à jour automatiquement, ajouter à la liste des doublons
          if (!results.duplicates) results.duplicates = [];
          results.duplicates.push({
            existing: existingEntreprise,
            new: entrepriseData
          });
        } else {
          await base44.entities.Entreprise.create(entrepriseData);
          results.created++;
        }
      } catch (err) {
        console.error(`Erreur import ligne ${row[0]}:`, err);
        results.errors++;
      }
    }

    return Response.json({ success: true, results });

  } catch (error) {
    console.error("Erreur lors de l'import:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});