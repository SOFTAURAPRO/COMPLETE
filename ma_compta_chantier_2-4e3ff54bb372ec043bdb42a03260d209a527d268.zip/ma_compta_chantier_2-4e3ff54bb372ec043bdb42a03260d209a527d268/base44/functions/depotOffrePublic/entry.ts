import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { token, lots_to_submit, entreprise_email, appel_offre_id } = await req.json();

    if (!token || !lots_to_submit || !entreprise_email || !appel_offre_id) {
      return Response.json({ error: "Paramètres invalides" }, { status: 400 });
    }

    // 1. Vérifier le token
    const envois = await base44.asServiceRole.entities.EnvoiMail.filter({ token });
    if (!envois || envois.length === 0) {
      return Response.json({ error: "Token invalide" }, { status: 403 });
    }

    const envoi = envois[0];

    // 2. Créer les OffreParLot
    const createdOffers = [];
    for (const lot of lots_to_submit) {
      const offre = await base44.asServiceRole.entities.OffreParLot.create({
        entreprise_email,
        dpgf_recu: lot.file_url,
        lot_id: lot.lot_id,
        appel_offre_id,
        date_reception: new Date().toISOString(),
        statut: "Reçue",
        montant_lot: null
      });
      createdOffers.push(offre);
      console.log(`✅ OffreParLot créée - Lot: ${lot.lot_id}, Email: ${entreprise_email}, AO: ${appel_offre_id}`);
    }

    // 3. Mettre à jour EnvoiMail
    await base44.asServiceRole.entities.EnvoiMail.update(envoi.id, {
      offre_deposee: true,
      date_depot: new Date().toISOString()
    });

    // 4. Créer ou mettre à jour OffreEntreprise global
    const existingGlobal = await base44.asServiceRole.entities.OffreEntreprise.filter({
      appel_offre_id,
      entreprise_email
    });

    const newLotIds = lots_to_submit.map(l => l.lot_id);

    if (existingGlobal.length > 0) {
      const global = existingGlobal[0];
      const currentLots = global.lots_concernes || [];
      const allLotIds = [...new Set([...currentLots, ...newLotIds])];
      await base44.asServiceRole.entities.OffreEntreprise.update(global.id, {
        lots_concernes: allLotIds,
        date_reception: new Date().toISOString()
      });
    } else {
      await base44.asServiceRole.entities.OffreEntreprise.create({
        appel_offre_id,
        entreprise_email,
        lots_concernes: newLotIds,
        montant_total: 0,
        date_reception: new Date().toISOString()
      });
    }

    // 5. Créer une notification
    const notif = await base44.asServiceRole.entities.Notification.create({
      type: "offre_recue",
      titre: "Nouvelle offre reçue",
      message: `${entreprise_email} a déposé ${lots_to_submit.length} offre(s)`,
      lien: `/economie`,
      lue: false,
      data: {
        entreprise_email,
        appel_offre_id,
        lot_ids: lots_to_submit.map(l => l.lot_id)
      }
    });
    console.log("🔔 Notification créée:", notif.id);

    console.log(`✅ Dépôt complet - ${createdOffers.length} offres créées`);
    return Response.json({ 
      success: true, 
      created_offers: createdOffers.map(o => o.id)
    });

  } catch (error) {
    console.error("❌ Erreur depotOffrePublic:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});