import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ success: false, error: 'Admin only' }, { status: 403 });
    }

    const { export: exportData } = await req.json();
    if (!exportData || !exportData.data) throw new Error('JSON invalide');

    console.log('🚀 Import All Data - Version corrigée avec codes (Alice)');

    const results = { created: {}, updated: {}, skipped: {}, ignored: {} };

    // Maps code → nouvel ID
    const clientCodeToId = {};
    const entrepriseCodeToId = {};
    const chantierCodeToId = {};

    // ====================== 1. CHANTIERS (clé = code_chantier) ======================
    console.log(`📦 1/7 - Chantiers (${(exportData.data.chantiers || []).length})`);
    for (const item of exportData.data.chantiers || []) {
      const code = item.code_chantier || item.nom; // fallback si pas de code
      const clean = { ...item };
      delete clean.id; delete clean.created_date; delete clean.updated_date;

      const existing = await base44.asServiceRole.entities.Chantier.list({ filter: `code_chantier eq '${code}'` });
      let newId;

      if (existing.length > 0) {
        newId = existing[0].id;
        await base44.asServiceRole.entities.Chantier.update(newId, clean);
        results.updated.chantiers = (results.updated.chantiers || 0) + 1;
      } else {
        const created = await base44.asServiceRole.entities.Chantier.create(clean);
        newId = created.id;
        results.created.chantiers = (results.created.chantiers || 0) + 1;
      }
      chantierCodeToId[code] = newId;
    }

    // ====================== 2. CLIENTS & ENTREPRISES (par reference) ======================
    for (const [key, entityName, codePrefix] of [
      ['clients', 'Client', 'CLT'],
      ['entreprises', 'Entreprise', 'ENT']
    ]) {
      console.log(`📦 ${key} (${(exportData.data[key] || []).length})`);
      for (const item of exportData.data[key] || []) {
        const code = item.reference || `${codePrefix}-${item.nom}`;
        const clean = { ...item };
        delete clean.id;

        const existing = await base44.asServiceRole.entities[entityName].list({ filter: `reference eq '${code}'` });
        let newId;

        if (existing.length > 0) {
          newId = existing[0].id;
          await base44.asServiceRole.entities[entityName].update(newId, clean);
        } else {
          const created = await base44.asServiceRole.entities[entityName].create(clean);
          newId = created.id;
        }

        if (key === 'clients') clientCodeToId[code] = newId;
        if (key === 'entreprises') entrepriseCodeToId[code] = newId;
      }
    }

    // ====================== 3 à 7 : les tables dépendantes (seulement si chantier existe) ======================
    const dependentOrder = [
      {key: 'marches', entity: 'MarcheEntreprise'},
      {key: 'travauxSup', entity: 'TravauxSupplementaire'},
      {key: 'avenants', entity: 'Avenant'},
      {key: 'sousTraitances', entity: 'SousTraitance'},
      {key: 'cieOperations', entity: 'CieOperation'},
      {key: 'certificats', entity: 'CertificatPaiement'}
    ];

    for (const {key, entity} of dependentOrder) {
      const records = exportData.data[key] || [];
      if (records.length === 0) continue;

      console.log(`📦 ${key} (${records.length})`);

      for (const item of records) {
        const clean = { ...item };
        delete clean.created_date; delete clean.updated_date;

        // Remplacer par les nouveaux IDs via les codes
        if (clean.chantier_id && chantierCodeToId[clean.chantier_id]) clean.chantier_id = chantierCodeToId[clean.chantier_id];
        if (clean.client_id && clientCodeToId[clean.client_id]) clean.client_id = clientCodeToId[clean.client_id];
        if (clean.entreprise_id && entrepriseCodeToId[clean.entreprise_id]) clean.entreprise_id = entrepriseCodeToId[clean.entreprise_id];

        const originalId = clean.id;
        delete clean.id;

        const exists = await base44.asServiceRole.entities[entity].get(originalId).catch(() => null);
        if (exists) {
          await base44.asServiceRole.entities[entity].update(originalId, clean);
          results.updated[key] = (results.updated[key] || 0) + 1;
        } else {
          await base44.asServiceRole.entities[entity].create({ id: originalId, ...clean });
          results.created[key] = (results.created[key] || 0) + 1;
        }
      }
    }

    // Ignorer les entités inutiles
    results.ignored = { appelOffres: (exportData.data.appelOffres || []).length, lots: 0, offres: 0 };

    console.log('🎉 Import terminé ! Résultats :', results);

    return Response.json({
      success: true,
      message: 'Import terminé avec mapping par codes (CHT/CLT/ENT) – tout est bien rattaché !',
      results
    });

  } catch (error) {
    console.error('Erreur :', error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});