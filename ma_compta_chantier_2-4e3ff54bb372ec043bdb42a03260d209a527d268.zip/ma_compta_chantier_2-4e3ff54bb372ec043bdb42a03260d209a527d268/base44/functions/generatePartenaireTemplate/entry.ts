import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import * as XLSX from 'npm:xlsx';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const headers = [
      "Nom *",
      "Forme Juridique",
      "Missions (séparées par des virgules)",
      "Adresse 1",
      "Adresse 2",
      "Code Postal",
      "Ville",
      "Téléphone",
      "SIRET",
      "Contact 1 Civilité",
      "Contact 1 Nom",
      "Contact 1 Prénom",
      "Contact 1 Fonction",
      "Contact 1 Service",
      "Contact 1 Email",
      "Contact 1 Téléphone",
      "Contact 1 Portable",
      "Contact 2 Civilité",
      "Contact 2 Nom",
      "Contact 2 Prénom",
      "Contact 2 Fonction",
      "Contact 2 Service",
      "Contact 2 Email",
      "Contact 2 Téléphone",
      "Contact 2 Portable"
    ];

    const exampleRow = [
      "Partenaire Exemple",
      "SARL",
      "Architecte, Maître d'œuvre",
      "45 Avenue de la République",
      "",
      "44000",
      "Nantes",
      "0240000000",
      "98765432100012",
      "Madame",
      "Durand",
      "Marie",
      "Architecte",
      "Etudes",
      "marie.durand@archi.com",
      "0102030405",
      "0601020304",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    ];

    const ws = XLSX.utils.aoa_to_sheet([headers, exampleRow]);
    ws['!cols'] = headers.map(() => ({ wch: 25 }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Modèle Import Partenaires");

    const fileBase64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });

    return Response.json({ success: true, file_base64: fileBase64 });

  } catch (error) {
    console.error("Erreur lors de la génération du modèle:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});