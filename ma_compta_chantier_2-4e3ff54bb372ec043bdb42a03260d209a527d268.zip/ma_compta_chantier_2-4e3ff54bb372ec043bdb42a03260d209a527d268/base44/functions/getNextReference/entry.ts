import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Authentication check (optional depending on usage, but recommended)
        const user = await base44.auth.me();
        if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

        const { entityName, prefix } = await req.json();
        
        if (!['Entreprise', 'Client', 'Partenaire'].includes(entityName)) {
            return Response.json({ error: 'Invalid entity name' }, { status: 400 });
        }

        // Fetch all entities to determine the next ID
        // Note: This is not transactional safe for high concurrency, but fine for this app scale
        const entities = await base44.entities[entityName].list();
        
        let maxRef = 0;
        entities.forEach(e => {
            if (e.reference && e.reference.startsWith(prefix + '-')) {
                const num = parseInt(e.reference.split('-')[1]);
                if (!isNaN(num) && num > maxRef) maxRef = num;
            }
        });

        const nextNum = maxRef + 1;
        const nextRef = `${prefix}-${nextNum.toString().padStart(4, '0')}`;

        return Response.json({ nextReference: nextRef });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});