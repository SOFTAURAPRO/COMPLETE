import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Vérifier que l'utilisateur est authentifié
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { question_id, reponse, document_url } = await req.json();

    if (!question_id || !reponse) {
      return Response.json({ error: "Paramètres invalides" }, { status: 400 });
    }

    // 1. Récupérer la question
    const question = await base44.entities.QuestionReponse.get(question_id);
    if (!question) {
      return Response.json({ error: "Question introuvable" }, { status: 404 });
    }

    // 2. Mettre à jour la question avec la réponse
    await base44.entities.QuestionReponse.update(question_id, {
      reponse,
      date_reponse: new Date().toISOString(),
      document_reponse_url: document_url || null
    });

    console.log(`✅ Réponse enregistrée - Question ID: ${question_id}`);

    // 3. Récupérer les informations de l'appel d'offres et du lot
    const appelOffre = await base44.entities.AppelOffre.get(question.appel_offre_id);
    let lotInfo = "";
    if (question.lot_id) {
      const lot = await base44.entities.Lot.get(question.lot_id);
      lotInfo = ` concernant le ${lot.nom_lot}`;
    }

    // 4. Envoyer un email à l'entreprise
    const emailBody = `
Bonjour,

Vous avez reçu une réponse à votre question sur l'appel d'offres "${appelOffre.titre}"${lotInfo}.

Votre question :
${question.question}

Réponse :
${reponse}

${document_url ? `\nDocument joint : ${document_url}` : ''}

Cordialement,
L'équipe GESTIONBAT
    `.trim();

    await base44.integrations.Core.SendEmail({
      to: question.entreprise_email,
      subject: `Réponse à votre question - ${appelOffre.titre}`,
      body: emailBody
    });

    console.log(`📧 Email envoyé à ${question.entreprise_email}`);

    return Response.json({ success: true });

  } catch (error) {
    console.error("❌ Erreur repondreQuestion:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});