import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// ⚠️ PLACEHOLDERS DISPONIBLES
// Liste complète : Voir page "Documentation Placeholders" dans l'application
// ou télécharger le fichier de référence depuis cette page

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Vérifier l'authentification
        const user = await base44.auth.me();
        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Récupérer les paramètres
        const { template_url, data } = await req.json();

        if (!template_url) {
            return Response.json({ 
                error: 'template_url is required' 
            }, { status: 400 });
        }

        if (!data || typeof data !== 'object') {
            return Response.json({ 
                error: 'data object is required' 
            }, { status: 400 });
        }

        // ====================== URL CONFIGURABLE ======================
        // Va dans Base44 → Settings de la fonction → Variables d'environnement
        // et ajoute : BACKEND_URL = https://base44-backend.onrender.com (ou ton URL si tu en as une autre)
        const BACKEND_URL = Deno.env.get('BACKEND_URL') || 'https://base44-backend.onrender.com';
        // =============================================================

        // Si l'URL est une URL base44.app (non accessible depuis l'extérieur),
        // télécharger le fichier et l'envoyer en base64
        let requestBody;
        if (template_url.includes('base44.app/api/')) {
            console.log('URL base44 détectée, téléchargement du fichier...');
            const fileResponse = await fetch(template_url, {
                headers: { 'Authorization': req.headers.get('Authorization') || '' }
            });
            if (!fileResponse.ok) {
                return Response.json({ error: `Impossible de télécharger la trame: ${fileResponse.status}` }, { status: 400 });
            }
            const fileBuffer = await fileResponse.arrayBuffer();
            const base64 = btoa(String.fromCharCode(...new Uint8Array(fileBuffer)));
            requestBody = { template: { base64 }, data };
        } else {
            requestBody = { template: { url: template_url }, data };
        }

        // Appeler l'API externe pour remplir le template Excel
        const response = await fetch(`${BACKEND_URL}/fill_excel`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            const errorText = await response.text();
            return Response.json({ 
                error: 'Failed to fill Excel template',
                details: errorText,
                status: response.status
            }, { status: 500 });
        }

        const result = await response.json();

        // Normaliser : le service externe retourne filled_excel_base64
        const base64 = result.filled_excel_base64 || result.file_base64 || result.data;
        return Response.json({
            success: true,
            file_base64: base64,
            message: 'Excel template filled successfully'
        });

    } catch (error) {
        console.error('Error in fillExcelTemplate:', error);
        return Response.json({ 
            error: error.message,
            stack: error.stack
        }, { status: 500 });
    }
});