import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { lot_id } = await req.json();

    if (!lot_id) {
      return Response.json({ error: "ID du lot requis" }, { status: 400 });
    }

    console.log(`🔍 Recherche offres pour lot_id: ${lot_id}`);

    const offres = await base44.asServiceRole.entities.OffreParLot.filter({ lot_id });
    console.log(`📊 Offres trouvées: ${offres.length}`, offres);

    if (!offres || offres.length === 0) {
      return Response.json({ success: true, data: [] });
    }

    const validOffres = offres.filter(o => o.montant_lot && o.montant_lot > 0);

    if (validOffres.length === 0) {
      const allOffres = offres.map(o => ({
        ...o,
        is_meilleur: false,
        ecart: null,
        ecart_pourcent: null
      }));
      return Response.json({ success: true, data: allOffres });
    }

    const montantMin = Math.min(...validOffres.map(o => o.montant_lot));

    const offresAvecEcarts = offres.map(offre => {
      if (!offre.montant_lot || offre.montant_lot <= 0) {
        return { ...offre, is_meilleur: false, ecart: null, ecart_pourcent: null };
      }
      const ecart = offre.montant_lot - montantMin;
      const ecart_pourcent = montantMin > 0 ? ((ecart / montantMin) * 100).toFixed(2) : 0;
      return {
        ...offre,
        is_meilleur: offre.montant_lot === montantMin,
        ecart: Math.round(ecart),
        ecart_pourcent: parseFloat(ecart_pourcent)
      };
    });

    const sortedOffres = offresAvecEcarts.sort((a, b) => {
      if (!a.montant_lot || a.montant_lot <= 0) return 1;
      if (!b.montant_lot || b.montant_lot <= 0) return -1;
      return a.montant_lot - b.montant_lot;
    });

    return Response.json({ success: true, data: sortedOffres });

  } catch (error) {
    console.error("❌ Erreur getComparatifLot:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});