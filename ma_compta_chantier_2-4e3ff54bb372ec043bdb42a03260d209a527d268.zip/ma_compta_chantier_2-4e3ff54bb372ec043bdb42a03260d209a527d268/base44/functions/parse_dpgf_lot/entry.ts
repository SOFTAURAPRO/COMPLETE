import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

export default async function handler(req) {
  try {
    const base44 = createClientFromRequest(req);
    const { offre_id } = await req.json();

    if (!offre_id) {
      return new Response(JSON.stringify({ error: "ID de l'offre requis" }), { status: 400 });
    }

    const offre = await base44.entities.OffreParLot.get(offre_id);
    if (!offre) {
      return new Response(JSON.stringify({ error: "Offre introuvable" }), { status: 404 });
    }

    if (!offre.dpgf_recu) {
      return new Response(JSON.stringify({ error: "Aucun fichier DPGF associé à cette offre" }), { status: 400 });
    }

    // --- SIMULATION DU PARSING ---
    // Dans un cas réel, on téléchargerait le fichier (Excel/PDF) et on utiliserait une lib pour extraire la cellule "Total".
    // Ici, on simule une analyse qui prend un peu de temps et retourne un montant réaliste.
    
    // Génère un montant aléatoire entre 10k et 100k pour la démo
    const simulatedAmount = Math.floor(Math.random() * (100000 - 10000 + 1) + 10000);

    // Mise à jour de l'entité avec le montant extrait
    await base44.entities.OffreParLot.update(offre.id, {
      montant_lot: simulatedAmount
    });

    return new Response(JSON.stringify({ 
      success: true, 
      extracted_amount: simulatedAmount,
      message: "Analyse terminée avec succès" 
    }), { 
      status: 200, 
      headers: { "Content-Type": "application/json" } 
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
}