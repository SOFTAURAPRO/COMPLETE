import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import * as XLSX from 'npm:xlsx';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { file_url, appel_offre_id } = await req.json();

    if (!file_url || !appel_offre_id) {
      return Response.json({ error: "Paramètres manquants (file_url ou appel_offre_id)" }, { status: 400 });
    }

    const fileResponse = await fetch(file_url);
    if (!fileResponse.ok) {
      return Response.json({ error: "Impossible de télécharger le fichier" }, { status: 400 });
    }
    const arrayBuffer = await fileResponse.arrayBuffer();

    const workbook = XLSX.read(new Uint8Array(arrayBuffer), { type: 'array' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(sheet);

    const results = [];
    let addedCount = 0;

    for (const row of data) {
      const normalizedRow = {};
      Object.keys(row).forEach(key => {
        normalizedRow[key.toLowerCase()] = row[key];
      });

      const nom_lot = normalizedRow['nom'] || normalizedRow['lot'] || normalizedRow['titre'] || normalizedRow['nom du lot'];
      const description = normalizedRow['description'] || normalizedRow['desc'] || '';

      if (nom_lot) {
        try {
          await base44.asServiceRole.entities.Lot.create({
            appel_offre_id,
            nom_lot: String(nom_lot),
            description: String(description),
            dpgf_type: ""
          });
          results.push({ status: 'success', nom: nom_lot });
          addedCount++;
        } catch (e) {
          results.push({ status: 'error', nom: nom_lot, error: e.message });
        }
      }
    }

    return Response.json({
      success: true,
      count: addedCount,
      total_rows: data.length,
      details: results
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});