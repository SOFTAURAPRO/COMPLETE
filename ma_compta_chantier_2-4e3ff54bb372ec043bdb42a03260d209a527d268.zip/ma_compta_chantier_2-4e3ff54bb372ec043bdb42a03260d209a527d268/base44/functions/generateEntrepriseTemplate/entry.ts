import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import * as XLSX from 'npm:xlsx';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Données de test pour le modèle
    const headers = [
      "Nom *",
      "Forme Juridique",
      "Adresse 1",
      "Adresse 2",
      "Code Postal",
      "Ville",
      "Téléphone",
      "SIRET",
      "Corps d'état (séparés par des virgules)",
      "Représentant Civilité (M/Mme/Mlle)",
      "Représentant Nom",
      "Représentant Prénom",
      "Représentant Qualité",
      "Contact AO Civilité",
      "Contact AO Nom",
      "Contact AO Prénom",
      "Contact AO Email",
      "Contact AO Téléphone",
      "Contact AO Portable",
      "Contact Compta Civilité",
      "Contact Compta Nom",
      "Contact Compta Prénom",
      "Contact Compta Email",
      "Contact Compta Téléphone",
      "Autre Contact 1 Civilité",
      "Autre Contact 1 Nom",
      "Autre Contact 1 Prénom",
      "Autre Contact 1 Fonction",
      "Autre Contact 1 Service",
      "Autre Contact 1 Email",
      "Autre Contact 1 Téléphone",
      "Autre Contact 1 Portable",
      "Autre Contact 2 Civilité",
      "Autre Contact 2 Nom",
      "Autre Contact 2 Prénom",
      "Autre Contact 2 Fonction",
      "Autre Contact 2 Service",
      "Autre Contact 2 Email",
      "Autre Contact 2 Téléphone",
      "Autre Contact 2 Portable"
    ];

    const exampleRow = [
      "Entreprise Exemple",
      "SARL",
      "123 Rue de la Paix",
      "Batiment B",
      "75000",
      "Paris",
      "0102030405",
      "12345678900012",
      "Maçonnerie, Gros Oeuvre",
      "Monsieur",
      "Dupont",
      "Jean",
      "Gérant",
      "Madame",
      "Martin",
      "Sophie",
      "ao@exemple.com",
      "0102030406",
      "0601020304",
      "Monsieur",
      "Durand",
      "Pierre",
      "compta@exemple.com",
      "0102030407",
      "Monsieur",
      "Petit",
      "Louis",
      "Conducteur Tx",
      "Travaux",
      "louis.petit@entreprise.com",
      "0102030408",
      "0601020305",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    ];

    const ws = XLSX.utils.aoa_to_sheet([headers, exampleRow]);
    
    // Ajuster la largeur des colonnes
    ws['!cols'] = headers.map(() => ({ wch: 25 }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Modèle Import Entreprises");

    // Générer le fichier en base64
    const fileBase64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });

    return Response.json({ success: true, file_base64: fileBase64 });

  } catch (error) {
    console.error("Erreur lors de la génération du modèle:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});