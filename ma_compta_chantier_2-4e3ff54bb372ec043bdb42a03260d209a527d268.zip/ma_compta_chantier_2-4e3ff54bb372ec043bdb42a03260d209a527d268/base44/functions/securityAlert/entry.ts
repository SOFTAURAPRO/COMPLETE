import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { type, message, level = 'info' } = await req.json();

        console.log(`[SECURITY] ${level.toUpperCase()} - ${type}: ${message}`);

        if ((level === 'critical' || level === 'warning') && user.email) {
            try {
                await base44.integrations.Core.SendEmail({
                    to: user.email,
                    subject: `Alerte Sécurité: ${type}`,
                    body: `Une alerte de sécurité a été détectée:\n\nType: ${type}\nMessage: ${message}\nNiveau: ${level}`
                });
            } catch (emailError) {
                console.error("Failed to send security email:", emailError);
            }
        }

        return Response.json({ success: true, message: "Alerte traitée" });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});