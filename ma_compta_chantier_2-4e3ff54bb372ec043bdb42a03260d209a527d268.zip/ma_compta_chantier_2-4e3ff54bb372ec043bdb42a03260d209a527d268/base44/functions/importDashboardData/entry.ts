import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  console.log('🚀 [IMPORT DASHBOARD] Démarrage - Version finale Alice');

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ success: false, error: 'Admin only' }, { status: 403 });
    }

    // Lecture du fichier envoyé par le bouton "Importer données"
    const formData = await req.formData();
    const file = formData.get('file');
    if (!file) throw new Error('Aucun fichier reçu');

    console.log(`📄 Fichier reçu : ${file.name} (${file.size} octets)`);

    const text = await file.text();
    const jsonData = JSON.parse(text);

    const exportData = jsonData.export || jsonData;
    if (!exportData || !exportData.data) throw new Error('Format JSON invalide');

    console.log('✅ JSON parsé avec succès');

    const results = { created: {}, updated: {}, skipped: {} };

    // Maps code → ID
    const chantierCodeToId = {};
    const clientCodeToId = {};
    const entrepriseCodeToId = {};

    // 1. CHANTIERS (par code_chantier)
    console.log(`📦 Chantiers (${(exportData.data.chantiers || []).length})`);
    for (const item of exportData.data.chantiers || []) {
      const code = item.code_chantier || item.nom;
      const clean = { ...item };
      delete clean.id; delete clean.created_date; delete clean.updated_date;

      const exists = await base44.asServiceRole.entities.Chantier.get(item.id).catch(() => null);
      if (exists) {
        await base44.asServiceRole.entities.Chantier.update(item.id, clean);
        results.updated.chantiers = (results.updated.chantiers || 0) + 1;
      } else {
        await base44.asServiceRole.entities.Chantier.create({ id: item.id, ...clean });
        results.created.chantiers = (results.created.chantiers || 0) + 1;
      }
      chantierCodeToId[code] = item.id;
    }

    // 2. CLIENTS & ENTREPRISES (par reference)
    for (const [key, entityName] of [['clients', 'Client'], ['entreprises', 'Entreprise']]) {
      console.log(`📦 ${key} (${(exportData.data[key] || []).length})`);
      for (const item of exportData.data[key] || []) {
        const code = item.reference;
        const clean = { ...item };
        delete clean.id;

        const exists = await base44.asServiceRole.entities[entityName].get(item.id).catch(() => null);
        if (exists) {
          await base44.asServiceRole.entities[entityName].update(item.id, clean);
        } else {
          await base44.asServiceRole.entities[entityName].create({ id: item.id, ...clean });
        }
        if (key === 'clients') clientCodeToId[code] = item.id;
        if (key === 'entreprises') entrepriseCodeToId[code] = item.id;
      }
    }

    // 3. Tables dépendantes (marchés, avenants, travaux sup, certificats, sous-traitance)
    const dependent = [
      { key: 'marches', entity: 'MarcheEntreprise' },
      { key: 'avenants', entity: 'Avenant' },
      { key: 'travauxSup', entity: 'TravauxSupplementaire' },
      { key: 'certificats', entity: 'CertificatPaiement' },
      { key: 'sousTraitances', entity: 'SousTraitance' }
    ];

    for (const { key, entity } of dependent) {
      const records = exportData.data[key] || [];
      if (records.length === 0) continue;

      console.log(`📦 ${key} (${records.length})`);

      for (const item of records) {
        const clean = { ...item };
        delete clean.created_date; delete clean.updated_date;

        // Remplacer les codes par les nouveaux IDs
        if (clean.chantier_id) clean.chantier_id = chantierCodeToId[clean.chantier_id] || clean.chantier_id;
        if (clean.client_id) clean.client_id = clientCodeToId[clean.client_id] || clean.client_id;
        if (clean.entreprise_id) clean.entreprise_id = entrepriseCodeToId[clean.entreprise_id] || clean.entreprise_id;

        const originalId = item.id;
        const exists = await base44.asServiceRole.entities[entity].get(originalId).catch(() => null);

        if (exists) {
          await base44.asServiceRole.entities[entity].update(originalId, clean);
          results.updated[key] = (results.updated[key] || 0) + 1;
        } else {
          await base44.asServiceRole.entities[entity].create({ id: originalId, ...clean });
          results.created[key] = (results.created[key] || 0) + 1;
        }
      }
    }

    console.log('🎉 Import terminé avec succès !', results);

    return Response.json({
      success: true,
      message: 'Import terminé – tout est bien rattaché avec les codes CHT/CLT/ENT ! 🎉',
      results
    });

  } catch (error) {
    console.error('💥 ERREUR :', error.message);
    console.error(error.stack);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});